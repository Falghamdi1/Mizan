# Mizan: final audit (2026-10-10)

Source of truth: the official brief (`Capstone_Project_Brief.docx`, Tuwaiq, October 2026): 12 core requirements (at least 10 for the core level, **always including model adaptation**), 3 advanced requirements (at least 1 more for the advanced level). Final submission Wednesday 14 October; Submission 2 (technical design) Sunday 11 October.

Evidence markers: **verified** = run or read in this audit; **logged** = recorded earlier in `docs/EXPERIMENT_LOG.md` with its result file; **unverified** = needs something this session did not have (a GPU, real models, a second person, a real service).

## 1. Verdict

**Mizan is on the right track and is now a credible, honest capstone in code and documentation. It does not yet meet the core level on evidence: 8 of 12 core requirements are fully met (two of them with an unverified caveat), 4 are partial, none is missing; the brief needs 10, including model adaptation. Every remaining gap needs one Colab session or one teammate's hour; none needs new code.** Responsible AI, the chosen advanced requirement, is implemented and tested, but the advanced level only counts once the core level does.

What is genuinely strong:
1. **A fair experiment with honest statistics** (one variable, a pipeline-independent scorer, paired intervals, hand-worked metric tests, negative results kept).
2. **A real, explained, repeatable efficiency result**: kashida padding is 12.3% of the PDFs' characters and 29.7% of their tokens; removing it cuts retrieved tokens 23% to 31% per question (95% of questions, all 8 documents) and the generator's input tokens 19% (n=51, interval −275 to −179), at no measured quality loss, and gains +0.234 hit@4 for a weak embedder. The token figures use the generator's own tokenizer and the generator's own usage count.
3. **Real model adaptation with before/after on held-out documents** (LoRA, hit@4 0.600 → 0.867 with a paired interval above zero on the generated questions).

What is weaker than it first looked: the headline gain exists only for a weak embedder on damaged PDFs; with a strong embedder plus reranker the final top 4 does not change; on clean text nothing changes; answer *quality* has never been measured by humans; there is no untouched test set yet; and the fine-tuning result rests on LLM-written questions (only 15 style-independent held-out questions exist).

## 2. What was verified in this audit

| Check | Result |
|---|---|
| Version control and backup | the project was not under version control; now a git repository (first commit before any change) plus a zip of the git-ignored outputs outside the project (a folder outside the project) |
| Test suite | **170 passed** (was 52 at the start of the previous audit). Includes hand-worked metric examples, leakage guards, safeguards, monitoring with a webhook delivered to a real local HTTP server, and a guard that every module a notebook needs is written by the notebook |
| Main notebook, clean folder, top to bottom | **47 code cells executed, 0 errors**, with downloads disabled, the hash embedder and the mock generator (19 s). **This is a smoke test of the code path, not of the models** |
| Web-evaluation notebook, same conditions | **54 code cells, 0 errors** (190 s), with the reranker and the adaptation section switched off |
| **Reliability fix found while smoke-testing** | Chroma occasionally loses a collection or silently returns nothing from one that holds chunks (reproduced: 76 failed queries in 1,200 with three collections in one in-memory client, 0 in another run of 480): the web notebook crashed twice on it with the offline embedder. `src/retrieval.py` now keeps the vectors in memory and rebuilds a lost or empty collection without re-embedding, and still raises if rebuilding does not help. Re-run of the 1,200-query reproduction: 0 errors, with the rebuild triggered twice. Five new tests |
| Bugs found by those runs and fixed | `src/corpus.py` and `src/web_corpus.py` were not written by the main notebook (it would have crashed on Colab); `src/safety.py`, `src/citations.py`, `src/monitoring.py` likewise; an empty `finetune/__init__.py` made `%%writefile` fail; the `finetune/` folder was not created. A test now prevents this class of bug |
| UI | launched with the real pipelines (hash embedder, mock generator) and used in a browser: notices, upload note, side-by-side cards, citation row, monitoring panel, reminder all rendered |
| Data | profiled by `scripts/profile_data.py` (section Q of `docs/DATA_AUDIT.md`): 739 web records, 591,913 characters, 1,569 chunks; the 8 PDFs 159 pages, 139,053 characters; fingerprints `b3871676ff02…` (web) and `c1b846432f4f…` (PDF) |
| Token claims | recomputed from result files and the corpora by `scripts/token_analysis.py` (`EXPERIMENT_RESULTS.md` section 5) |
| **Not verified** | any run with real embedders, the reranker, the generator or a judge in this session (local models were deleted and the notebook run that tried to download them was stopped; 8 GB of downloaded files were removed); Colab runs of the current notebooks; real e-mail delivery; the effect of prompt v4 and of text that passes the injection scan on a real model; the adaptation experiment on Mizan-lite text; anything involving people (blind questions, human grades, alignment review) |

## 3. Requirement-by-requirement

Status key: **Complete** (the evidence exists and can be shown now), **Partial** (the work exists, evidence incomplete), **Missing**, **Unverified** (cannot be judged without something not available here).

| # | Requirement | Status | Evidence | Smallest remaining action | How to show it |
|---|---|---|---|---|---|
| 1 | Needs analysis | **Complete** | `docs/NEEDS_ANALYSIS.md`: users, user flow, wireframe of the real screen, 7 functional specs with acceptance criteria mapped to tests, component and sequence diagrams | none for the repository; copy into Template 2 | Submission 2 slides |
| 2 | Comparison of existing services | **Partial** | `docs/DESIGN_CHOICES.md`: embedders (3, measured), reranker (on/off, measured), judges (3, hand-checked), backends, vector DB, PDF reader; generators, PDF parsers (Docling, Marker), 4-bit vs 16-bit, hosted APIs not compared | state in the talk that generators and parsers were not compared (or run one Docling comparison) | the comparison table |
| 3 | Prompt engineering | **Partial** | four prompt versions in `src/rag.py` (v1 original, v2 explicit rules, v3 structured, v4 = v2 + untrusted-text rule), `scripts/compare_prompts.py` (same retrieved passages, no judge, citation check, blind sheet), notebook section 7b, tests | **run section 7b on Colab with the real generator** and write which prompt won and why | the generated comparison table |
| 4 | Tool selection | **Complete** | `docs/DESIGN_CHOICES.md` section 2: each tool, why it was chosen, what was not used and why | none | the tool table |
| 5 | Domain data analysis | **Complete** | `docs/DATA_AUDIT.md` (audit of 15 candidate sources, then the verified profile Q1 to Q9), `docs/data_audit/profile.json` | none | profile tables |
| 6 | Data preprocessing | **Complete** | `src/preprocessing.py` (15 named flags), ablations, leave-one-out, Mizan-lite, effect on results (`EXPERIMENT_RESULTS.md` 3 to 5) | none | kashida: tokens, chunks and hit@4 table |
| 7 | Embeddings and vector database | **Complete** | `src/embeddings.py`, `src/retrieval.py` (Chroma, cosine), three embedders compared, choices explained in `docs/DESIGN_CHOICES.md` | none | the embedder table |
| 8 | Retrieval-augmented generation | **Complete** | `src/rag.py` (retrieve, rerank, filter, generate with citations), citation check (`src/citations.py`), answers in the UI and in 31 earlier real-generator runs | none | live demo |
| 9 | Monitoring | **Complete**, delivery to real services **unverified** | `src/monitoring.py`: one log line per answer, failure or event; rules for errors, refusals, p95 latency, citations, empty retrieval, ingestion, security; alerts to log, screen and webhook; a test delivers a real HTTP POST to a local server; e-mail is covered only by a simulated server | set `MIZAN_ALERT_WEBHOOK` to a real Discord/Slack URL once and capture the alert | trigger five out-of-scope questions and show the alert |
| 10 | Evaluation | **Partial** | retrieval metrics defined and tested by hand, paired intervals, failure cases analysed (`EXPERIMENT_RESULTS.md` 5b), token analysis at four levels, citation metrics; **missing:** answer-level evidence from people, an untouched test set | write the blind questions (kit built), run the final comparison once, grade ~30 answers with two people (kit built) | results tables, failure cases |
| 11 | Interactive application | **Complete** (verified offline; real-model run **unverified**) | Gradio app and notebook UI used in a browser; matches the wireframe | one Colab run of the main notebook with real models | live demo or recorded video |
| 12 | Model adaptation (**required**) | **Partial** | LoRA fine-tuning of Qwen3-Embedding-0.6B (556 pairs, 6 PDFs), before/after on 2 held-out PDFs in the log; `scripts/run_adaptation.py` makes it reproducible with a leakage report (it found that only 15 independent held-out questions exist); notebook section 6d | **run notebook section 6d once on Colab** (about 15 minutes) so the before/after on Mizan-lite text is generated from a clean state; report it whatever it shows | the generated table |

**Tally.**

- **Fully satisfied core requirements: 8** (1, 4, 5, 6, 7, 8, 9, 11), of which 9 and 11 carry the unverified caveats stated above.
- **Partially satisfied: 4** (2, 3, 10, 12).
- **Missing: 0.**

**Does the evidence support the core level?** **Not yet.** The core level needs 10 of 12 including model adaptation, and 12 is Partial. It is reached by moving **two more** requirements to Complete, and requirement 12 must be one of them: run section 6d (12), plus one of: run section 7b (3), write the blind set and grade answers (10), or close the comparison gap (2). Doing all of them is the safe plan. Those are one Colab session and about two hours of teammates' time, and the code for each exists and is tested.

**Does the evidence support the advanced level through Responsible AI?** **The implementation and its tests exist; the level does not count until the core level does.** Implemented and tested: injection scan with withheld passages and a no-model refusal path (17 of 17 attacks detected, 0 of 3,819 real chunks falsely flagged), personal-data warnings on upload, insufficient-evidence and citation status shown per pipeline, security and ingestion alerts, a not-legal-advice notice on every screen, privacy-conscious logging (hashes, no text). Not tested: prompt v4 or text that passes the scan on a real model (procedure in `docs/RESPONSIBLE_AI.md` section 5). The other advanced requirements: quantization is used (4-bit NF4, about 2.4 GiB against 8 GiB) but its speed and quality cost was never measured (Partial); deployment is missing.

## 4. Risks and remaining gaps (in priority order)

1. **Adaptation evidence not regenerated from a clean state (requirement 12, mandatory).** Run section 6d. If lite text gives a neutral or negative result, report it; the requirement asks for before/after, not for a gain.
2. **No untouched test set.** Every question set was used to choose something; the blind-set kit exists but is empty. The lite preset was designed after seeing the 77-question ablation.
3. **No human-graded answers.** Correctness, faithfulness and citation support are unmeasured on the current corpora; the LLM judges are unvalidated (one marked every answer correct).
4. **The prompt comparison and every real-generator measurement have not been run on the current code.**
5. **Data licence.** tourism.sa: written permission requested and approved (team record; the approval e-mail is kept by the team); Bureau of Experts terms not verified. (Updated 2026-10-13.)
6. **Stale documents**: `SPEAKING_NOTES.md` and `docs/BRIEFING.md` describe the full preset, the r4 question and numbers from the first notebook run; do not present from them.
7. **The Submission 1 slide** says "16% less text to embed"; measured: 12.5% fewer characters and 32% to 42% fewer tokens to embed. Replace.
8. **Honest limits to state**: single runs; small question sets (hit@4 differences under about 10 points are not detectable); one corpus and one ministry; Qwen-only stack; the PDF alignment was done by one reader.

## 5. What changed in this audit (implemented, each tested)

Version control and backup; `scripts/profile_data.py` (data profile, `docs/data_audit/profile.*`); `scripts/token_analysis.py` (four-level token analysis); `src/safety.py` with the filter wired into `Pipeline.ask`, citations measured against what the model was actually shown, prompt `v4`, upload warnings, UI status rows; monitoring events and two alert rules; `scripts/run_adaptation.py` with a leakage guard and notebook section 6d; a regression test for notebook modules; hand-worked metric tests; `docs/NEEDS_ANALYSIS.md` and `docs/DESIGN_CHOICES.md`; the documents renamed to the requested names. Earlier in the week (also in this repository): monitoring, prompt versions, citation check, blind-set kit, human-grading kit, Responsible AI document, Mizan-lite.
