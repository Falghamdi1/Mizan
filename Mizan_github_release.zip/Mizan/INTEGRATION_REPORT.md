# Final integration, audit and verification report (2026-10-15)

Base: our repository at commit `8b56462` (final interface, Mizan Insights, blind-test results). Incoming interface release from Nasser:
`Mizan_github_updated.zip`. Neither the incoming ZIPs nor the original decks were modified; every comparison was made on an extracted copy
in a separate integration folder. Nothing is committed or pushed: the changes below are **staged** (`git diff --cached`), and the last commit
is still `8b56462`.

## 1. The incoming release

`Mizan_github_updated.zip` (680 MB) has the same SHA-256 as `Mizan_github_release_nasser.zip`, received and compared earlier the same day
(`dbd7ccfaf5ad5fd9b207637e22767b667139f5168bfcc92fee580691925787a6`): it is the same file, so it contains no change beyond that comparison.
It holds a Python 3.14 `.venv`, `.pytest_cache`, sample PDFs, a nested `mizan_repo.zip` and the project tree.

Of the 163 files present in both trees, 146 have the same content as our commit `8b56462` (66 byte-identical, 80 differing only in line
endings) and 17 differ:

| area | our repository (kept) | the release |
|---|---|---|
| interface | `src/ui.py` + `src/i18n.py` + `src/ui_style.py` + `src/backend.py`: four steps, English/Arabic, dark/light, verified citations, Mizan Insights panel, prepared-question evaluation, optional English translation | a different Arabic-only interface (`src/ui.py`, `src/ui_theme.py`, its own `src/backend.py`, `src/contract.py`, `src/verdict.py`) that **removes the Mizan Insights panel** and replaces it with a rule-based verdict box |
| shared modules | unchanged | Arabic labels for the monitoring table (`monitoring.panel_html(lang)`) and upload warnings (`safety.upload_warnings(lang)`), one Arabic upload note in `comparison.py` |
| tests | our Insights session and bilingual interface tests | tests for its interface (`test_app_session.py`, `test_contract.py`, `test_verdict.py`); our Insights session tests removed |
| documents | Insights documented as on the screen | `docs/MIZAN_INSIGHTS.md` says the panel is no longer on the screen; `CONTRACT.md`, `CLAUDE.md` for its interface |
| logs | `logs/` git-ignored | ships `logs/queries.jsonl` (monitoring log of its runs) |

## 2. Integration decisions, item by item

| item in the release | decision | reason |
|---|---|---|
| **Brand mark** (balance scale on a 44 × 44 px tile, radius 13 px, `#0e5a4f`, white strokes 1.7) | **adopted** | it is drawn inline (`icon('scale', 24)`), not an image file; the same paths, viewBox, stroke and tile now form our header mark (`BRAND_MARK` in `src/ui.py`, `.mz-brand .mark` in `src/ui_style.py`); test `test_the_brand_mark_is_the_scale_tile_in_both_languages` |
| `.venv/` in `.gitignore` | **adopted** | a local environment must never be committed |
| interface and verdict box | not adopted | it removes Mizan Insights, which the brief and our documents describe; our interface already covers its layout in both languages |
| "Compare" disabled until a question is typed; button relabelled and disabled while measuring | not adopted | Gradio 6.9 already ignores a second click while a comparison runs (`trigger_mode="once"` is the default for clicks), and an empty question gets an explained message instead of a silently disabled button |
| a Clear button | already present | `mz-clear` |
| accessibility | nothing to take | the release has fewer roles and labels than ours (ours: `role="status"` ×8, `role="alert"` ×2, `role="note"` ×2, `aria-live`, `aria-label` ×3, focus styles, reduced-motion rule, two phone breakpoints) |
| Arabic monitoring and upload strings | not adopted | our interface renders the monitoring table and upload warnings from structured data in both languages through `src/i18n.py` |
| `CONTRACT.md`, `CLAUDE.md` | not adopted | they describe the release's interface |
| `logs/queries.jsonl` | not adopted | run logs are not shipped |

No backend route was added, so no interface control is left without a handler.

## 3. Changes made (changelog)

| change | files | why |
|---|---|---|
| brand mark from the release | `src/ui.py`, `src/ui_style.py`, `tests/test_ui_i18n.py` | section 2 |
| **fixed: an answer or analysis that finished late could restore an older screen** | `src/ui.py`, new `tests/test_ui_event_order.py` | found in a live run with the real models. Two causes. (1) Every event wrote the whole screen state it had read when it started, so a slow event that ended after a newer one put back the older answers or the "being written" panel; the state is now one store per part (answers, panel, translation, upload report) and each event writes only its own. (2) Gradio ignored the trigger of the newer question's analysis while the older one was still running, so the panel stayed "being written"; the chained analysis steps now queue the latest trigger (`always_last`). Both are reproduced by tests that fail on the old code |
| corrected a token figure that the result files do not reproduce | `README.md`, `docs/BLIND_RESULTS_ANALYSIS.md` | "median 1,320 → 1,084 generator input tokens per PDF question" matches no subset of the per-question records; recomputed from `answers_blind_pdf.json`: mean 1,333 → 1,122 (−15.9%), median 1,359 → 1,131. The deck and `EXPERIMENT_RESULTS.md` already used the mean |
| **sample PDFs 46 MB → 0.36 MB** | `data/sample/*.pdf`, `scripts/make_sample_pdfs.py` | the four synthetic PDFs embedded the whole Arial font; fonts are now subset. Checked: the same text on every page, the same pages and corpus fingerprint from `src/ingestion.load_pdfs`, pixel-identical renders, word positions within 0.0001 pt. The final ZIP drops from 26.8 MB to about 2 MB |
| empty gap under the question on a public checkout | `src/ui.py`, `src/ui_style.py` | without the team's prepared questions the empty examples header still took room; it is now hidden when empty, as the empty measured block already was |
| documented a limit of the citation check | `README.md` section 9 | it matches file names only; a citation by regulation title counts as not shown even when that page was shown (seen live). Not changed in code: the reported citation metrics were computed with this rule, and both pipelines are scored by it |
| static cleanup | `src/ablation.py`, `src/comparison.py`, `src/evaluation.py`, `src/monitoring.py`, `src/ui.py`, `scripts/audit/xlsx_profile.py`, `scripts/gen_eval_questions.py`, `scripts/make_report_template.py`, `scripts/run_adaptation.py`, `tests/test_citations.py`, `tests/test_web_corpus.py`, `video/tools/*` | 18 unused imports and variables and one placeholder-free f-string removed (ruff `F`); no undefined names or syntax errors were found; no behaviour changes |
| stale code references | `README.md`, `docs/RESPONSIBLE_AI.md`, `docs/MIZAN_INSIGHTS.md`, `MIZAN_PIPELINE.md` | they named functions that no longer exist (`render_comparison`, `card_stats`, the `Session` class, `ui.add_pdfs`) |
| outdated architecture document | `docs/FINAL_ARCHITECTURE.md` | written 2026-10-10 (reranker missing from `.env`, LoRA pending, development results only); sections 2, 3, 5, 6 rewritten from the code and the blind test, diagram extended with the application layer and Mizan Insights |
| README architecture | `README.md`, `docs/architecture_diagram.png` | diagram redrawn (interface and backend, `comparison.compare`, per-question metrics, Insights and its two inputs), Insights scopes, module table, section 11, the event-order tests in the change checklist |
| Insights documentation | `docs/MIZAN_INSIGHTS.md` | current button names and screen order, panel language, and how the screen keeps late results out |
| hard-coded local paths | `scripts/audit/pdf_profile.py`, `scripts/audit/xlsx_profile.py` | repository root and a folder argument instead of a user folder |
| `.gitignore` | `.gitignore` | `.venv/`, Office lock files, tool caches (`.mypy_cache/`, `.ruff_cache/`, `.ipynb_checkpoints/`), `node_modules/`, `dist/`, `build/`, `*.egg-info/`, OS files, the generated video folders; a duplicate line removed; the updated deck explicitly included |
| GitHub readiness | `docs/PUBLIC_RELEASE_AUDIT.md` | a dated checklist and the steps left before the first push |
| technical design deck | `docs/Mizan_Technical_Design_Final.pptx` | section 4 |
| project video sources | `video/` (scripts, narration text, subtitles, composition, documents; not the media) | rebuild instructions in `video/README.md`; checked: no blind-test question text in these files |

## 4. Technical Design document (Capstone Template 2)

Source: the team's latest filled template, `Mizan_Submission2 intial.pptx` (12 October, 13 slides). Preserved unchanged with the blank
instructor template. Updated copy: **`docs/Mizan_Technical_Design_Final.pptx`** (14 slides, same layouts, fonts, colours and order; OOXML
validation passed; every slide rendered and checked for overflow).

| slide | change |
|---|---|
| 1 Title | Gen AI system wording; "updated to the final implementation" |
| 2 Recap | changes since Submission 2: blind test, results with intervals, LoRA outcome, Mizan Insights, new interface |
| 3 User flow and wireframes | flow updated; the drawn wireframe replaced by a screenshot of the real interface from a live run |
| 4 Functional specifications | F1–F6 with blind-test evidence; **F7 Mizan Insights** and **F8 language, theme, notices** added |
| 5 System architecture | interface and backend layer, Mizan Insights, base embedder; where the generative AI is |
| 6 From input to output | verified citations, hit@4 when gold evidence is known, the checked Insights panel |
| 7 Sequence diagram | Backend lifeline; the Insights exchange and late-result dropping |
| **8 Mizan Insights (new)** | inputs, the two scopes (one question vs aggregate), presentation, what it cannot establish |
| 9 Model choice | blind-test numbers per model; base embedder because LoRA was not shown to help |
| 10–11 Adaptation | prompt versions and the LoRA blind result (+0.014 [−0.072, +0.101]) |
| 12 Data and prompts | the frozen blind set; the Insights prompt and JSON reply |
| 13 Evaluation, monitoring and risks | targets against blind-test results (met and not met), Insights safeguards |
| 14 Work plan | status of every planned task |

Every number on the slides comes from `EXPERIMENT_RESULTS.md` section 0 or `docs/BLIND_RESULTS_ANALYSIS.md`; every confidence interval quoted
in the README, `docs/FINAL_ARCHITECTURE.md`, `SPEAKING_NOTES.md` and the deck was checked by script against the results documents (all found;
the safety intervals of `docs/RESPONSIBLE_AI.md` come from `docs/safety_eval/`).

## 5. Verification actually performed

| check | how | result |
|---|---|---|
| test suite, development environment | `python -m pytest tests` (torch 2.11 CUDA, Gradio 6.9.0) | **423 passed** |
| clean checkout, new environment | staged tree exported with `git checkout-index` into an empty folder; new Python 3.11 venv; `pip install torch` (CPU) and `pip install -r requirements.txt` (resolved to Gradio 6.30.0, transformers 5.19.0, torch 2.14.1, chromadb 1.5.9, sentence-transformers 6.1.0); `pip check` | install and `pip check` clean |
| tests in that environment, public files only | `python -m pytest tests` | **412 passed, 11 skipped** (the skips need the team-only question sets, training pairs and the real corpora); the same on the tree extracted from the final ZIP |
| static checks | `ruff check --select F,E9` | clean (18 findings fixed) |
| corpus from the documented source | `python scripts/fetch_corpus.py` | 8 PDFs downloaded, every SHA-256 matches `data/corpus_manifest.json`; the app reports 8 documents · 159 pages |
| real stack from the clean checkout | `.env` from `.env.example` with the README's evaluated configuration; `python app.py`; Qwen3-Embedding-0.6B + Qwen3-Reranker-0.6B on the GPU, Qwen3-4B through Ollama (100% GPU) | indexes rebuilt exactly as documented: Standard 358 chunks / 77,134 tokens, Mizan-lite 323 / 53,610 (titles on) |
| browser, real models (Gradio 6.9) | question about the tour guide licence term | both answers with citations; Mizan-lite answered "at most three years" from page 8 of the Tour Guide Regulations (the line the screen uses as its example); measured table (Mizan-lite 163 fewer generator tokens) |
| the late-result fault, before and after | the same question asked again while its analysis was being written | before the fix the panel stayed "being written" (one model call, the second analysis never started); after it, the second analysis ran and was shown ("Written by ollama:qwen3:4b… · 2 attempt(s)") |
| translation, language, theme, width | English translation requested; switch to Arabic and dark; back to English; 375 px | translation shown for both answers; Arabic right-to-left with the question, answers and analysis kept; translation back in English; logo 44 × 44 px, `rgb(14, 90, 79)`, radius 13 px, top-right in Arabic; no horizontal overflow at 375 px; no console errors |
| documented offline smoke test, newest libraries | `MIZAN_EMBEDDER=hash MIZAN_LLM_PROVIDER=mock python app.py` in the clean environment (Gradio 6.30.0) | HTTP 200 after about 6 s; synthetic notices shown; an example question gave both answers, the measured comparison and the Insights panel; theme and language switches work; no console errors |
| Mermaid diagrams | rendered with Mermaid 11.4.1 | both render |
| deck | OOXML validator; render of every slide | passed; no overflow |
| secrets, paths, sizes, history | see `docs/PUBLIC_RELEASE_AUDIT.md`, last section | nothing found to remove |

Not verified: the Colab notebook with this exact tree; a real webhook or e-mail alert delivery; the README as rendered by GitHub.

## 6. Known issues and items to confirm

- `data/raw/` on the development machine holds a ninth PDF (`دليل_ترخيص_المرشد_السياحي.pdf`, the name of one of the synthetic samples), so
  the app there shows 9 documents · 162 pages instead of the evaluated 8 · 159. A clean checkout with `scripts/fetch_corpus.py` has the 8.
  Remove that file before a demo on that machine.
- `web/grader_N.csv`: an empty, untracked stray file; it is not staged. Delete it.
- A fresh install resolves to newer libraries than the tested ones (Gradio 6.30 instead of 6.9); the tests pass with both, and
  `requirements-tested.txt` pins the tested versions. The browser checks of the interface were made on Gradio 6.9.
- The git history still contains the files removed for the public release; publish a fresh history (`docs/PUBLIC_RELEASE_AUDIT.md`).
- The project video and its media are not in the repository (size; it shows one blind-test question). Its scripts and documents are under
  `video/`.
- Mizan Insights checks numbers, directions and wording, but a 4B model can still write a misleading sentence that passes.
