"""Score one or more pair files with the (base) embedder, to see how trustworthy they are as training data.

    python -m finetune.pair_diagnostics finetune/pairs.jsonl finetune/pairs_v2.jsonl

Per file (all measured with the embedder in MIZAN_EMBEDDING_MODEL, over the passages of that file):
  recall@1 / @4      does the base model already put the true passage first / in the top 4?
  top-1 other doc    share of queries whose best match is a passage from a DIFFERENT document
  ambiguous          share of queries where another document's passage scores within --margin of the true one:
                     these queries have (nearly) more than one correct passage = false-negative risk in training
  names regulation   share of queries that contain a keyword of their own regulation's topic
  verbatim           share of queries copying a 6-word run from their passage (too easy / lexical shortcut)
Very high recall@1 means the pairs are easy (little to learn); very low with high "ambiguous" means noisy labels.
"""
import argparse
import json
import statistics

import numpy as np

from src.embeddings import get_embedder

DOC_KEYWORDS = [  # filename part -> words a self-identifying question contains (queries are stored Mizan-folded)
    ("Hospitality-Facilities", ["ضيافه", "ضيافة"]),
    ("Travel-and-Tourism-Services", ["سفر"]),
    ("Tourism-Consultation", ["استشار"]),
    ("Tour-Guide", ["ارشاد", "مرشد"]),
    ("Tourist-Visa", ["تاشير", "تأشير"]),
]


def names_regulation(query: str, doc: str) -> bool:
    words = next((ws for key, ws in DOC_KEYWORDS if key in doc), [])
    return any(w in query for w in words)


def ngrams(t: str, n: int = 6) -> set[str]:
    w = t.split()
    return {" ".join(w[i:i + n]) for i in range(len(w) - n + 1)}


def diagnose(path: str, margin: float) -> dict:
    rows = [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]
    passages = sorted({r["passage"] for r in rows})
    idx = {p: i for i, p in enumerate(passages)}
    doc_of = {r["passage"]: r["doc"] for r in rows}
    docs = np.array([doc_of[p] for p in passages])
    E = get_embedder()
    P = E.embed_passages(passages)
    Q = np.stack([E.embed_query(r["query"]) for r in rows])
    S = Q @ P.T
    ranks, other, amb = [], 0, 0
    for i, r in enumerate(rows):
        pos = idx[r["passage"]]
        order = np.argsort(-S[i])
        ranks.append(int(np.where(order == pos)[0][0]) + 1)
        other += docs[order[0]] != r["doc"]
        best_other = S[i][docs != r["doc"]].max() if (docs != r["doc"]).any() else -1
        amb += best_other >= S[i][pos] - margin
    ranks = np.array(ranks)
    n = len(rows)
    return {
        "file": path, "pairs": n, "unique_passages": len(passages), "unique_queries": len({r["query"] for r in rows}),
        "recall@1": float(np.mean(ranks == 1)), "recall@4": float(np.mean(ranks <= 4)),
        "top1_other_doc": other / n, "ambiguous": amb / n,
        "names_regulation": sum(names_regulation(r["query"], r["doc"]) for r in rows) / n,
        "verbatim": sum(bool(ngrams(r["query"]) & ngrams(r["passage"])) for r in rows) / n,
        "median_query_chars": statistics.median(len(r["query_raw"]) for r in rows),
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="+")
    ap.add_argument("--margin", type=float, default=0.02)
    args = ap.parse_args()
    res = [diagnose(f, args.margin) for f in args.files]
    keys = ["pairs", "unique_passages", "unique_queries", "recall@1", "recall@4", "top1_other_doc", "ambiguous",
            "names_regulation", "verbatim", "median_query_chars"]
    print(f"embedder: {get_embedder().name}   margin {args.margin}")
    print(f"{'':<20}" + "".join(f"{r['file'].split('/')[-1][:22]:>24}" for r in res))
    for k in keys:
        print(f"{k:<20}" + "".join(f"{(r[k] if isinstance(r[k], int) else round(r[k], 3)):>24}" for r in res))
    with open("results/pair_diagnostics.json", "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
