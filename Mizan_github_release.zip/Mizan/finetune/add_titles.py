"""Turn a pair file into its 'titled' version: passage -> "<regulation title>\\n<passage>".

    python -m finetune.add_titles --pairs finetune/pairs_v2.jsonl --out finetune/pairs_v2_titled.jsonl --pipeline mizan+repair_lam_alef

Must mirror what Pipeline.build does when MIZAN_CHUNK_TITLE=1 (title goes through the pipeline's own
preprocessing, then a newline, then the chunk), otherwise training and inference see different text.
"""
import argparse
import json

from src.preprocessing import get_config, preprocess_text
from src.titles import topic_of


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pairs", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--pipeline", default="mizan+repair_lam_alef")
    args = ap.parse_args()
    cfg = get_config(args.pipeline)
    n = 0
    with open(args.pairs, encoding="utf-8") as src, open(args.out, "w", encoding="utf-8") as dst:
        for line in src:
            if not line.strip():
                continue
            r = json.loads(line)
            r["passage"] = preprocess_text(topic_of(r["doc"]), cfg) + chr(10) + r["passage"]
            dst.write(json.dumps(r, ensure_ascii=False) + chr(10))
            n += 1
    print(f"wrote {n} titled pairs to {args.out}")


if __name__ == "__main__":
    main()
