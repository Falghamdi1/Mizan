"""Generate (question, passage) training pairs from the corpus with an LLM.

    python -m finetune.make_pairs --pipeline mizan --per-chunk 2 --out finetune/pairs.jsonl

Leakage control: every document that any evaluation question points to (gold_docs in
eval/questions.json) is HELD OUT and never used for training. Train only on the remaining
documents, evaluate on questions about the held-out ones. Use --holdout to add more.

The pairs are built from chunks after the chosen pipeline's preprocessing, because the
fine-tuned embedder will be used on text preprocessed the same way. Questions are stored
raw and preprocessed (what the model sees at query time).

Needs a real LLM (MIZAN_LLM_PROVIDER=ollama with Qwen3-4B, or anthropic/openai). Answers are cached,
so an interrupted run resumes. The generated questions are synthetic: spot-check ~30 by hand.
"""
import argparse
import json
import random
from pathlib import Path

from src.chunking import chunk_pages
from src.config import RAW_DIR, SETTINGS, resolve_questions_path
from src.ingestion import load_pdfs
from src.preprocessing import get_config, preprocess_pages, preprocess_text
from src.rag import call_llm
from src.titles import topic_of

GEN_SYSTEM = (
    "أنت تساعد في بناء مجموعة بيانات لاسترجاع المعلومات. سأعطيك مقطعًا من لائحة رسمية. "
    "اكتب أسئلة عربية واقعية يسألها شخص عادي (سائح أو صاحب منشأة) ويمكن الإجابة عنها من المقطع وحده. "
    "غيّر الصياغة ولا تنسخ عبارات المقطع حرفيًا، ولا تذكر كلمة «المقطع». "
    "مهم: عدة لوائح تتشابه موادها، لذلك يجب أن يذكر كل سؤال موضوع اللائحة المعطاة (مثل الإرشاد السياحي أو "
    "مرافق الضيافة أو خدمات السفر أو الاستشارات السياحية) بشكل طبيعي، بحيث لا يصلح السؤال للائحة أخرى. "
    "أجب بقائمة JSON فقط، مثل: [\"سؤال 1؟\", \"سؤال 2؟\"]"
)


def parse_questions(text: str) -> list[str]:
    try:
        data = json.loads(text[text.index("["): text.rindex("]") + 1])
    except Exception:
        return []
    return [q.strip() for q in data if isinstance(q, str) and len(q.strip()) > 10]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pipeline", default="mizan", help="preprocessing config the embedder will be used with")
    ap.add_argument("--per-chunk", type=int, default=2)
    ap.add_argument("--out", default="finetune/pairs.jsonl")
    ap.add_argument("--holdout", default="", help="extra comma-separated filenames to hold out")
    ap.add_argument("--limit", type=int, default=0, help="max chunks (0 = all), for a quick trial")
    ap.add_argument("--dry-run", action="store_true", help="print split + one prompt, call no LLM")
    args = ap.parse_args()

    cfg = get_config(args.pipeline)
    held = {d for q in json.loads(resolve_questions_path()[0].read_text(encoding="utf-8")) for d in q.get("gold_docs", [])}
    held |= {x.strip() for x in args.holdout.split(",") if x.strip()}
    pages = load_pdfs(RAW_DIR)
    train_pages = [p for p in pages if p.doc not in held]
    print(f"held out (eval) documents: {sorted(held)}")
    print(f"training documents: {sorted({p.doc for p in train_pages})}")
    chunks = chunk_pages(preprocess_pages(train_pages, cfg), SETTINGS.chunk_size, SETTINGS.chunk_overlap)
    random.Random(0).shuffle(chunks)
    if args.limit:
        chunks = chunks[: args.limit]
    print(f"{len(chunks)} chunks to generate questions for")

    def prompt(c):
        return f"اللائحة: {topic_of(c.doc)}\nالمقطع:\n{c.text}\n\nاكتب {args.per_chunk} أسئلة:"

    if args.dry_run:
        print("\n--- example prompt ---\n" + prompt(chunks[0]))
        return
    if SETTINGS.llm_provider == "mock":
        raise SystemExit("Set MIZAN_LLM_PROVIDER (ollama / anthropic / openai) first: the mock LLM cannot write questions.")

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    n = 0
    with open(args.out, "w", encoding="utf-8") as f:
        for i, c in enumerate(chunks, 1):
            for q in parse_questions(call_llm(prompt(c), [], system=GEN_SYSTEM).text)[: args.per_chunk]:
                f.write(json.dumps({"query_raw": q, "query": preprocess_text(q, cfg), "passage": c.text,
                                    "doc": c.doc, "page": c.page, "pipeline": args.pipeline}, ensure_ascii=False) + "\n")
                n += 1
            if i % 25 == 0:
                print(f"  {i}/{len(chunks)} chunks, {n} pairs")
    print(f"wrote {n} pairs to {args.out}")


if __name__ == "__main__":
    main()
