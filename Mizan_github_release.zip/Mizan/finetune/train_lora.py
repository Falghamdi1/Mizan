"""LoRA fine-tuning of Qwen3-Embedding with in-batch-negative contrastive loss (InfoNCE).

    python -m finetune.train_lora --pairs finetune/pairs.jsonl --base Qwen/Qwen3-Embedding-0.6B --out finetune/out/q06

Why this shape:
  * It trains through the SAME SentenceTransformer module that src/embeddings.py uses for inference
    (same tokenizer, left padding, last-token pooling, query instruction), so train and inference match.
  * Only LoRA adapters are trained and saved (small files). Use the result with
        MIZAN_EMBEDDING_MODEL=Qwen/Qwen3-Embedding-0.6B  MIZAN_EMBEDDING_ADAPTER=finetune/out/q06
  * 0.6B: fine on CPU for a smoke test, comfortable on an 8 GB GPU.
    4B: needs a ~16 GB GPU (Colab/Kaggle T4 with --load-4bit, or any bf16 GPU), or an 8 GB GPU with
    --load-4bit --grad-ckpt --batch 4 --max-len 192 (tight). --load-4bit needs bitsandbytes (Linux/Colab).

Larger --batch = more in-batch negatives = usually better, until memory runs out.
Group-by-document is NOT applied: two pairs from the same passage in one batch would be false negatives,
so the loader keeps one pair per passage per batch.
"""
import argparse
import json
import random
from pathlib import Path

import torch
import torch.nn.functional as F
from peft import LoraConfig, TaskType
from sentence_transformers import SentenceTransformer

from src.config import SETTINGS


def load_pairs(path: str) -> list[dict]:
    return [json.loads(line) for line in open(path, encoding="utf-8") if line.strip()]


def batches(pairs: list[dict], bs: int, rng: random.Random):
    """Yield batches with unique passages (no false negatives inside a batch)."""
    pool = pairs[:]
    rng.shuffle(pool)
    while pool:
        batch, seen, rest = [], set(), []
        for p in pool:
            if p["passage"] in seen or len(batch) >= bs:
                rest.append(p)
            else:
                batch.append(p)
                seen.add(p["passage"])
        if len(batch) >= 2:
            yield batch
        if len(rest) == len(pool):
            break
        pool = rest


def save_lora(auto_model, out: Path) -> None:
    """Write the adapter in PEFT format (adapter_config.json + adapter_model.safetensors), the format `load_adapter` reads.
    `save_pretrained` is not used: on Colab (2026-10-13, transformers 5) it wrote the full model and no adapter_config.json, so
    the evaluation found no adapter."""
    from peft import get_peft_model_state_dict
    from safetensors.torch import save_file
    auto_model.peft_config["default"].save_pretrained(str(out))
    state = {k: v.detach().to("cpu").contiguous() for k, v in get_peft_model_state_dict(auto_model).items()}
    save_file(state, str(Path(out) / "adapter_model.safetensors"))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pairs", required=True)
    ap.add_argument("--base", default="Qwen/Qwen3-Embedding-0.6B")
    ap.add_argument("--out", required=True)
    ap.add_argument("--epochs", type=int, default=1)
    ap.add_argument("--batch", type=int, default=8)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--r", type=int, default=16)
    ap.add_argument("--alpha", type=int, default=32)
    ap.add_argument("--temp", type=float, default=0.02, help="softmax temperature (Qwen3-Embedding style)")
    ap.add_argument("--max-len", type=int, default=256)
    ap.add_argument("--max-steps", type=int, default=0, help="stop early (smoke test)")
    ap.add_argument("--grad-ckpt", action="store_true")
    ap.add_argument("--load-4bit", action="store_true", help="QLoRA (bitsandbytes)")
    ap.add_argument("--mask-sim", type=float, default=0.9,
                    help="false-negative masking: in-batch passages whose BASE-model cosine to the true passage "
                         "exceeds this are removed from the softmax (near-duplicate clauses across regulations). 0 = off")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    torch.manual_seed(args.seed)
    rng = random.Random(args.seed)
    cuda = torch.cuda.is_available()
    dtype = torch.bfloat16 if cuda and torch.cuda.is_bf16_supported() else (torch.float16 if cuda else torch.float32)
    model_kwargs = {"torch_dtype": dtype}
    if args.load_4bit:
        from transformers import BitsAndBytesConfig

        model_kwargs["quantization_config"] = BitsAndBytesConfig(
            load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=dtype)
    model = SentenceTransformer(args.base, device="cuda" if cuda else "cpu", model_kwargs=model_kwargs,
                                tokenizer_kwargs={"padding_side": "left"})
    model.max_seq_length = args.max_len
    pairs = load_pairs(args.pairs)
    pidx, base_vecs = {}, None
    if args.mask_sim > 0:  # base-model passage embeddings, computed BEFORE the adapter exists
        uniq = sorted({p["passage"] for p in pairs})
        pidx = {p: i for i, p in enumerate(uniq)}
        with torch.no_grad():
            base_vecs = torch.tensor(model.encode(uniq, normalize_embeddings=True, batch_size=16,
                                                  show_progress_bar=False)).float().to(model.device)
        print(f"false-negative masking on: base cosine > {args.mask_sim} between in-batch passages ({len(uniq)} passages)")
    model.add_adapter(LoraConfig(
        task_type=TaskType.FEATURE_EXTRACTION, r=args.r, lora_alpha=args.alpha, lora_dropout=0.05,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]))
    if args.grad_ckpt:
        model[0].auto_model.gradient_checkpointing_enable()
        model[0].auto_model.enable_input_require_grads()
    params = [p for p in model.parameters() if p.requires_grad]
    for p in params:  # keep LoRA weights in fp32 for stable optimisation (base stays bf16/4-bit)
        p.data = p.data.float()
    print(f"trainable params: {sum(p.numel() for p in params):,}  dtype {dtype}  device {model.device}")
    opt = torch.optim.AdamW(params, lr=args.lr, weight_decay=0.01)
    prefix = f"Instruct: {SETTINGS.query_instruction}\nQuery:"

    def embed(texts: list[str]) -> torch.Tensor:
        tok = model.preprocess(texts) if hasattr(model, "preprocess") else model.tokenize(texts)  # name changed in ST 6
        feats = {k: (v.to(model.device) if torch.is_tensor(v) else v) for k, v in tok.items()}
        return F.normalize(model(feats)["sentence_embedding"].float(), dim=-1)

    print(f"{len(pairs)} pairs; in-batch negatives per query: {args.batch - 1}")
    model.train()
    step = 0
    masked_total = negs_total = 0
    for epoch in range(args.epochs):
        for batch in batches(pairs, args.batch, rng):
            q = embed([prefix + p["query"] for p in batch])
            d = embed([p["passage"] for p in batch])
            logits = q @ d.T / args.temp
            labels = torch.arange(len(batch), device=logits.device)
            if base_vecs is not None:
                ids = torch.tensor([pidx[p["passage"]] for p in batch], device=logits.device)
                near_dup = (base_vecs[ids] @ base_vecs[ids].T > args.mask_sim) & ~torch.eye(
                    len(batch), dtype=torch.bool, device=logits.device)
                logits = logits.masked_fill(near_dup, float("-inf"))  # true passage (diagonal) is never masked
                masked_total += int(near_dup.sum())
                negs_total += len(batch) * (len(batch) - 1)
            loss = (F.cross_entropy(logits, labels) + F.cross_entropy(logits.T, labels)) / 2
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(params, 1.0)
            opt.step()
            step += 1
            if step % 5 == 0 or step == 1:
                print(f"epoch {epoch} step {step} loss {loss.item():.4f}")
            if args.max_steps and step >= args.max_steps:
                break
        if args.max_steps and step >= args.max_steps:
            break
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    save_lora(model[0].auto_model, out)
    frac = masked_total / negs_total if negs_total else 0.0
    print(f"masked {masked_total}/{negs_total} in-batch negatives as near-duplicates ({frac:.1%})")
    (out / "mizan_train.json").write_text(json.dumps(
        {**vars(args), "steps": step, "n_pairs": len(pairs), "masked_negative_fraction": frac}, indent=1))
    print(f"saved LoRA adapter to {out}")


if __name__ == "__main__":
    main()
