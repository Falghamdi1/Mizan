"""Re-express an existing pair file in ANOTHER pipeline's text, keeping the questions identical.

    python -m finetune.remap_pairs --pairs finetune/pairs_v2.jsonl --from-pipeline mizan+repair_lam_alef \
        --to-pipeline baseline --titled --out finetune/pairs_v2_baseline_titled.jsonl

Why: to train an adapter on baseline-preprocessed text without regenerating questions (a new generation run
would change the questions too, confounding the comparison). For each pair we find, on the same document page,
the chunk of the target pipeline with the highest word overlap (pipeline-independent canonicalizer) with the
pair's original passage. Pairs without a good match (overlap < --min-overlap) are dropped and counted.
The query is re-preprocessed with the target pipeline (baseline = whitespace only), from the raw question.
"""
import argparse
import json
import statistics

from src.chunking import chunk_pages
from src.config import RAW_DIR, SETTINGS
from src.ingestion import load_pdfs
from src.preprocessing import canonical_for_eval, get_config, preprocess_pages, preprocess_text
from src.titles import topic_of


def words(t: str) -> set[str]:
    return set(canonical_for_eval(t).split())


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pairs", required=True)
    ap.add_argument("--from-pipeline", default="mizan+repair_lam_alef")
    ap.add_argument("--to-pipeline", default="baseline")
    ap.add_argument("--titled", action="store_true", help="prepend the regulation title (MIZAN_CHUNK_TITLE format)")
    ap.add_argument("--min-overlap", type=float, default=0.5, help="Jaccard on canonical words")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    to_cfg = get_config(args.to_pipeline)
    pages = load_pdfs(RAW_DIR)
    chunks = chunk_pages(preprocess_pages(pages, to_cfg), SETTINGS.chunk_size, SETTINGS.chunk_overlap)
    by_page: dict[tuple, list] = {}
    for c in chunks:
        by_page.setdefault((c.doc, c.page), []).append((c, words(c.text)))

    kept, dropped, scores = 0, 0, []
    with open(args.pairs, encoding="utf-8") as src, open(args.out, "w", encoding="utf-8") as dst:
        for line in src:
            if not line.strip():
                continue
            r = json.loads(line)
            pw = words(r["passage"])
            best, best_j = None, 0.0
            for c, cw in by_page.get((r["doc"], r["page"]), []):
                j = len(pw & cw) / max(1, len(pw | cw))
                if j > best_j:
                    best, best_j = c, j
            if best is None or best_j < args.min_overlap:
                dropped += 1
                continue
            text = best.text
            if args.titled:
                text = preprocess_text(topic_of(r["doc"]), to_cfg) + chr(10) + text
            r.update(passage=text, query=preprocess_text(r["query_raw"], to_cfg), pipeline=args.to_pipeline)
            dst.write(json.dumps(r, ensure_ascii=False) + chr(10))
            kept += 1
            scores.append(best_j)
    print(f"kept {kept}, dropped {dropped} (overlap < {args.min_overlap}); "
          f"median overlap {statistics.median(scores):.2f}, unique passages "
          f"{len({json.loads(l)['passage'] for l in open(args.out, encoding='utf-8')})}")


if __name__ == "__main__":
    main()
