> **STALE (2026-10-10): do not present from this file.** It describes the first PDF-only setup with the full preset, the demo question r4 and numbers that have since been re-measured. Current numbers: `EXPERIMENT_RESULTS.md`; demo: `DEMO_SCRIPT.md`; status: `FINAL_AUDIT.md`.

# Mizan: speaking notes for the meeting

Audience: AI Science Director, Data Director, Data Engineer, BI expert. Length: about 11 minutes plus a 1-minute demo and Q&A.

## The one-sentence message
"We built a small experiment harness for Arabic RAG on real Saudi tourism regulations, using local models. Early evidence says the gain comes from fixing PDF extraction damage and adapting the retriever to the domain, either by fine-tuning the embedder or by adding a reranker, and not from Arabic letter normalization. Here is what we measured, how sure we are, and what we need next."

## What you want from them
1. Agreement that "extraction hygiene + domain adaptation (fine-tuning or reranking)" is a worthwhile direction, instead of the original "Arabic tokenization" framing.
2. A steer on which route to build on: fine-tuned embedder, reranker, or both, given that on this corpus they did not stack.
3. Guidance on evaluation: who should write gold questions, and which answer-quality metric they would trust (our LLM judges disagree and one is too lenient).
4. Compute for the 4B models (Colab/Kaggle/university GPU) and permission to scale the corpus.

## Timeline and slides

| # | Slide / screen | Time | Say |
|---|---|---|---|
| 1 | Question | 0:45 | "Can Arabic-specific preprocessing improve retrieval quality and efficiency of a RAG system? We treat this as a hypothesis to test, not a claim." |
| 2 | Experiment design | 1:15 | One variable at a time, everything else identical: documents, chunking, embedder, top-k, LLM, prompt, temperature 0. Every preprocessing step is a switch, so we can ablate. Models are local (Qwen3-Embedding, Qwen3-Reranker, Qwen3-4B) as the course requires. Fine-tuning is evaluated on **held-out documents**. |
| 3 | What exists today | 0:45 | 8 public Ministry of Tourism regulation PDFs (159 text pages), ingestion with file/page citations, two pipelines, local LLM, evaluation harness with ablations and paired confidence intervals, UI, LoRA fine-tuning, optional second-stage reranker. |
| 4 | Finding 1: the PDFs are damaged | 1:30 | Two defects that affect any Arabic RAG on these files. (a) Kashida/tatweel padding: 13 % of characters in the tour-guide regulation (1,257 of 9,891). (b) The lam-alef ligature is extracted reversed in 1,464 places (`ثلاثة` becomes `ثالثة`, `اللائحة` becomes `الالئحة`). We repair (b) exactly from glyph geometry, with no dictionary guessing. |
| 5 | Finding 2: what actually matters in preprocessing | 1:15 | Ablation table (below). Tatweel removal alone gives most of the gain; lam-alef repair adds a little; letter folding (alef/ya/digits/punctuation) adds nothing consistent. "This is extraction hygiene, not orthographic normalization." |
| 6 | Finding 3: fine-tuning and the interaction | 1:30 | LoRA on 556 LLM-written question-passage pairs from 6 documents, evaluated on the 2 held-out documents. The 2x2 table: fine-tuning helps only on cleaned text; cleaning alone does not help without it. |
| 7 | Finding 4: a reranker is the other route | 1:30 | Embedder returns the top 20, a reranker (Qwen3-Reranker-0.6B) reads question and passage together and keeps the best 4. It repairs weaker setups and finds the two hand-written questions that nothing else found, but adds nothing on top of the best setup. Tables below. |
| 8 | Live demo | 1:00 | `python app.py` (started beforehand). Ask `r3` (both right), `r4` (baseline refuses, cleaned side answers partly), `r5` (baseline answers, cleaned side refuses). The demo shows the preprocessing effect only; the reranker is not enabled in it. |
| 9 | Honest limits | 1:00 | See "Limits" below. Name them before they do. |
| 10 | Next steps and asks | 0:45 | 4B reranker and embedder on a GPU, human-written test set, BM25 baseline, article-aware chunking, then a larger corpus. |

## Numbers to have ready (all measured, one run each)

**Setup:** Qwen3-Embedding-0.6B, chunk titles on, Qwen3-4B answers. Test questions point only to held-out documents. 45 answerable generated questions (LLM-written, **unreviewed**) plus 6 unanswerable, and 9 answerable hand-written questions plus 1 unanswerable.

**2x2, hit@4 / MRR on the 45 generated questions (no reranker)**

| fine-tuned on / text pipeline | baseline text | mizan+repair text |
|---|---|---|
| no fine-tune | 0.667 / 0.522 | 0.600 / 0.543 |
| baseline text | 0.644 / 0.548 | **0.867** / 0.687 |
| mizan text | 0.689 / 0.596 | **0.867** / 0.713 |

**Matched arms, real answers (no reranker):** hit@4 0.644 vs 0.867, difference +0.222 [+0.089, +0.356]; refused an answerable question 27 % vs 9 %; LLM input tokens 1,018 vs 857 (-16 %). On the 9 hand-written questions: 0.778 vs 0.889.

**Which preprocessing steps (hit@4, 45 generated; raw text = 0.644):** tatweel removal only 0.844 (+0.200 [+0.089, +0.333]); lam-alef repair only 0.756 (+0.111 [+0.022, +0.200]); both 0.844; full Mizan + repair 0.867. Tatweel removal also cuts index tokens 29 % (Qwen) to 38 % (e5-small), which is deterministic.

**Reranker: top-20 from the embedder, rerank, keep 4 (hit@4 / MRR, 45 generated)**

| arm | no rerank | with rerank | gold in top-20 |
|---|---|---|---|
| untuned embedder, raw text | 0.667 / 0.522 | 0.756 / 0.578 | 0.822 |
| untuned embedder, cleaned text | 0.600 / 0.543 | 0.756 / 0.624 | 0.933 |
| tuned embedder, raw text | 0.644 / 0.548 | 0.822 / 0.648 | 0.933 |
| tuned embedder, cleaned text | **0.867** / 0.713 | 0.822 / 0.659 | 0.956 |
| 9 hand-written, every arm | 0.667 to 0.889 | **1.000 (9 of 9)** | 1.000 |

Paired bootstrap, rerank minus no rerank, hit@4: untuned raw +0.089 [+0.022, +0.178]; untuned cleaned +0.156 [+0.044, +0.289]; tuned raw +0.178 [+0.022, +0.333]; tuned cleaned -0.044 [-0.133, +0.044] (not distinguishable from zero). With the reranker, cleaned and raw text are indistinguishable (+0.000 [-0.089, +0.089]).

**Candidate count (54 answerable questions, hit@4):** best arm: 0.870 alone, 0.852 at N=10, 0.852 at N=20, 0.815 at N=30. No pair of N values is distinguishable; 30 is slower and no better. Median retrieval time with the reranker: about 0.4 s at N=10, 0.6 to 0.8 s at N=20, 0.9 to 2.5 s at N=30 (noisy single-run medians), against 0.05 to 0.08 s without.

**Reranker with real answers (45 generated + 6 unanswerable):**

| arm | hit@4 | keyword coverage | refused an answerable question | LLM input tokens |
|---|---|---|---|---|
| tuned + cleaned, no rerank | 0.867 | 0.667 | 9 % | 858 |
| tuned + cleaned, rerank | 0.822 | 0.722 | 4 % | 968 |
| tuned + raw, no rerank | 0.644 | 0.537 | 27 % | 1,018 |
| tuned + raw, rerank | 0.822 | 0.693 | 7 % | 1,187 |
| untuned + cleaned, rerank (no fine-tune) | 0.756 | 0.626 | 11 % | 1,020 |

The reranker raises answer quality on the weak arm (tuned + raw: hit@4 +0.178 [+0.022, +0.333], keyword coverage +0.156 [+0.022, +0.289], refusals -0.200 [-0.333, -0.067]) and changes nothing distinguishable on the strong arm. It picks longer passages: LLM input tokens +13 to 17 %.

**From the start of the project:** original untitled baseline hit@4 0.533 (45 generated) / 0.444 (hand-written); best configurations 0.82 to 0.87 / 0.89 to 1.00.

## Say / do not say

Say: "we are testing whether", "early observation", "on this corpus", "the interval excludes zero", "we cannot yet distinguish this from noise", "two routes reach a similar level".

Do not say: "Mizan improves Arabic RAG", "the reranker beats fine-tuning" (they did not stack and were not compared head to head), "faster", "reduces cost", "production ready", "0.87 accuracy" (it is hit@4 retrieval on generated questions, not answer accuracy).

## Limits (say these yourself)
- One run, one corpus (one ministry's regulations, legal register); no confidence intervals across seeds.
- The 45 test questions and the fine-tuning pairs were written by the same LLM in a similar style, so part of the gain may be style learning. The 9 hand-written questions point the same way, but one question moves them by 0.11 and the reranked arms all reach 9 of 9, which saturates that set.
- Generated questions are unreviewed; several have weak or ill-posed references.
- **The LLM judge is unreliable.** Re-scoring with an independent model (Gemma 3 4B) judged every non-refused answer correct (e.g. 43 of 43), while the Qwen judge flagged some; reading the disagreements, Qwen was right on the clear cases. So answer quality is reported mainly through keyword coverage and refusal rates, and a human-graded sample is still missing. We found no sign that Qwen favoured its own answers, but that rests on 8 cases.
- Only 0.6B models so far; the 4B embedder and the 4B reranker are untested. No BM25 baseline. The reranker is the same model family as the embedder.
- Known failure: tour-guide license duration (`r1`) is not retrieved without a reranker; its page has damaged text (displaced digits, several clauses in one chunk).
- Chunk-title mapping is by filename (prototype shortcut).
- LLM latency figures are not comparable across runs (GPU memory contention on an 8 GB laptop card).

## Q&A prepared answers

**AI Science Director**
- *Is the improvement real?* Fine-tuning plus cleaning, and separately a reranker, each lift held-out retrieval with intervals that exclude zero. Cleaning alone and preprocessing alone are not distinguishable from zero. The test set shares a generator with the training pairs, so we need human-written questions to be sure.
- *Why a reranker, and why only the 0.6B?* A reranker reads question and passage together, so it separates near-identical clauses that two independent vectors cannot. The 4B needs about 8 GB in bf16, which does not fit our laptop GPU; it needs 4-bit loading or Colab. The gold passage is in the top 20 for 82 to 96 % of questions but in the top 4 for only 76 to 82 %, so the reranker is now the limit and a stronger one is the obvious next test.
- *Do fine-tuning and reranking stack?* Not on this question set: the best arm is 0.867 alone and 0.822 reranked; the weaker arms rise to about 0.82 with a reranker. The set may be near its ceiling because several generated references are weak.
- *Is a reranker a substitute for fine-tuning?* Possibly: the untuned embedder with a reranker reached 0.756 (11 % refusals) against 0.867 for the tuned embedder alone, but that was not a paired comparison.
- *Leakage?* Every document that a test question points to is excluded from fine-tuning; other documents appear as distractors. Test questions were never used for training. The reranker is not trained on our data at all.
- *Why LoRA, how long?* r=16, 3 epochs, 556 pairs, about 13 minutes on an RTX 3070. It is cheap, so we can iterate.
- *What is the 2x2 telling us?* The text pipeline, not the training text, decides the result; and fine-tuning does nothing on raw text unless a reranker is added.

**Data Director**
- *Data governance?* Only public Ministry of Tourism PDFs; everything runs locally; no data leaves the machine; no API keys.
- *Can this scale to more documents?* Not tested. Each new PDF source needs an extraction check, because these defects are font-specific. The harness reports defects per document.
- *Provenance?* Every answer cites file and page, taken from the PDF metadata, not generated.

**Data Engineer**
- *Extraction robustness?* The lam-alef repair relies on a zero-width glyph signature that exists in these fonts; other PDFs need checking. Scanned pages need OCR (not built). Tables and RTL number order are still partly broken.
- *Cost of the reranker?* Retrieval time goes from about 0.05 s to 0.4 s at 10 candidates and 0.6 to 0.9 s at 20 on a laptop GPU, small next to the 3 to 5 s generation. It adds a second 1.2 GB model to serve, and about 13 to 17 % more LLM input tokens because it prefers longer passages.
- *Reproducibility?* Fixed settings in `.env`, temperature 0, cached LLM answers, corpus sha256 and library versions recorded in every result file, `scripts/fetch_corpus.py`, `scripts/compare_runs.py` for every interval, tests (27), ablation by flag names, results saved as JSON in `results/`.
- *Infra?* Chroma in memory (rebuilds in under a minute), Ollama for the generator, a single consumer 8 GB GPU; running generator, judge, embedder and reranker together exceeds it, so we run them in sequence.

**BI expert**
- *Which metric matters to the business?* Correct, cited answers. We measure retrieval hit rate, keyword coverage and refusal rates; human grading is the missing piece because our LLM judges disagree. Correct refusals on unanswerable questions: 100 % in every arm; refusals of answerable questions fell from 27 % to 9 % with cleaning plus fine-tuning, and to 4 to 7 % with a reranker.
- *Cost/latency?* Cleaned text uses about 28 % fewer LLM input tokens than raw text; a reranker adds 13 to 17 % back. Latency is a few seconds per answer locally; the figures are noisy. These are observations on one run.
- *Can we see the numbers?* Yes: `results/*.md`, the UI metric table, and the README tables.

## Tough questions
- *"So Mizan does not work?"* "The original claim, that Arabic letter normalization helps, is not supported. What works is cleaning extraction damage, mainly kashida, plus domain adaptation of the retriever, either fine-tuning or a reranker. We think that is the more honest and more useful finding."
- *"Why not just use the reranker and skip everything else?"* "On this corpus it gets a weak setup to about 0.82, similar to the best setup without it. But cleaning still saves about 28 % of LLM input tokens, and fine-tuning gives the best first stage for cheaper inference. We want to test the 4B reranker before choosing."
- *"Why not BM25 or hybrid?"* "Not tested yet; it is our next baseline. Normalization usually helps lexical search most, so it could change the picture."
- *"Is 0.87 good?"* "It is hit@4 for retrieval on generated questions, on two held-out documents. It is a promising signal, not an accuracy figure."
- *"What if it was just the question style?"* "That is the main risk and why the next step is a human-written test set. The nine hand-written questions point the same way."
- *"Which LLM judge do you trust?"* "Neither yet. We cross-checked two judges and found one too lenient; the plan is a hand-graded sample, and we report keyword coverage and refusal rates in the meantime."

## Before the meeting
1. Start Ollama; run `python app.py` a minute early and ask one question to warm it up.
2. Keep `results/demo.html` open in a tab as a fallback.
3. Have a teammate review about 20 questions in `eval/questions_large_review.md` and grade the judge sheets (`results/judge_review_A.md`, `results/judge_review_B.md`); if done, say so.
4. Put the 2x2, the ablation and the reranker tables on slides; the README has them.
5. Rehearse the 60-second demo: r3, r4, r5. When showing r4, say the cleaned answer is partial. The demo does not use the reranker.

## 60-second app demo (rehearsed)

Start `python app.py` at least a minute early (index build about 40 s). The four demo questions are cached after one run, so they answer in under half a second; a brand-new question takes about 7 s (two local LLM calls), so do not improvise a new question inside a 60-second recording. The demo configuration in `.env` has no reranker, so it shows the preprocessing effect only.

| Time | Action | Say |
|---|---|---|
| 0:00 | Header and setup strip | "Same documents, chunking, embedder, retrieval and LLM in both columns. Only the text preprocessing differs." |
| 0:08 | Ask `r3` (fee for a 3-year tour-guide license) | "Both answer 1,000 riyals with the page cited. The cleaned side retrieved 734 tokens instead of 1,120 and sent the model 992 instead of 1,394." |
| 0:20 | Ask `r4` (conditions and duration) | "Baseline refuses; the cleaned side answers, but only partly: it lists the license durations and a truncated list of conditions. Better, not complete." |
| 0:36 | Ask `r5` (renewal deadline) | "Now the reverse: baseline finds 60 days on page 8, the cleaned side refuses. The effect is not universal, and this is the kind of case a reranker fixes." |
| 0:50 | Ask `r10` (flight prices) | "Not in the documents, so both refuse. That is the behaviour we want." |
| 0:58 | Close | "One run, a handful of questions: observations, not conclusions." |

Rehearsal notes: skip the "What changes?" tab in the short version (its corpus box is a wall of text). Pick questions from the dropdown by clicking the exact option or typing to filter, because the list opens above the field and a loose click picks a neighbouring question. The difference column is plain arithmetic; the latency row of cached answers shows the originally measured latency.

## 30-second flow in the Colab notebook

The notebook uses the base Qwen3-Embedding-0.6B (no fine-tuned adapter), so its numbers differ from the app demo above. In the run done on the author's laptop (8 GB GPU, generator in 4-bit; the T4 path was not run), retrieval hit@4 on the 51-question set was 0.667 (Standard) vs 0.600 (Mizan), difference -0.067 with an interval that includes zero; retrieved tokens per query fell from 984 to 841. Say exactly that: no difference distinguishable from zero in retrieval, fewer tokens sent.

| Time | Action | Say |
|---|---|---|
| 0:00 | Section 8, question `r3` already rendered | "Same documents, same question, same local model. Only the Arabic preprocessing differs." |
| 0:10 | Point to the two answers, then the evidence cards | "Both answer 1,000 riyals and cite page 16. Mizan sent the model 1,123 input tokens instead of 1,316." |
| 0:20 | Section 9 table | "Over 51 questions retrieval is not distinguishable. Tokens are lower. We do not claim more." |
| 0:28 | Section 9 | "This paragraph is generated from the numbers; it only says higher or lower when the interval excludes zero." |

A fully executed copy from the local run is in `docs/Mizan_notebook_local_run.html` (a fallback if Colab is slow on the day).
