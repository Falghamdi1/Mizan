"""The judge diagnosis counts leniency from stored verdicts (no model)."""
import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def test_summarize_counts_yes_when_facts_are_missing():
    spec = importlib.util.spec_from_file_location("judge_diagnosis", ROOT / "scripts" / "judge_diagnosis.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    rows = [{"judge_correct": 1, "judge_faithful": 1, "keyword_coverage": 1.0, "hit": 1},
            {"judge_correct": 1, "judge_faithful": 1, "keyword_coverage": 0.0, "hit": 0},      # said yes with no key fact and no gold passage
            {"judge_correct": 0, "judge_faithful": 1, "keyword_coverage": 0.0, "hit": 1}]
    s = m.summarize(rows)
    assert s["n"] == 3 and s["yes_rate"] == 2 / 3
    assert (s["low_coverage_n"], s["low_coverage_judged_correct"]) == (2, 1)
    assert (s["no_support_n"], s["no_support_judged_correct"]) == (1, 1)
