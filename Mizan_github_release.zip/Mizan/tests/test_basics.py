import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.chunking import chunk_page
from src.ingestion import Page
from src.preprocessing import (BASELINE, MIZAN, canonical_for_eval, get_config, preprocess_pages,
                               preprocess_text)


def test_baseline_only_whitespace():
    assert preprocess_text("  مَرحبًا   بكم \n\n\n\nنص ", BASELINE) == "مَرحبًا بكم\n\nنص"


def test_mizan_steps():
    out = preprocess_text("الإيــواء ٢٠٠٠ ريال، أَو؟", MIZAN)
    assert out == "الايواء 2000 ريال, او?"


def test_nfkc_presentation_forms_and_no_stray_space():
    assert preprocess_text("ﺍﻟﺗﺟﺩﻳﺩ", MIZAN) == "التجديد"
    assert preprocess_text("ﻳُﻘﺩﱠﻡ", MIZAN) == "يقدم"  # shadda ligature expands to a space under NFKC


def test_ablation_configs():
    assert "remove_diacritics" not in get_config("mizan-no-remove_diacritics").enabled()
    assert get_config("baseline+normalize_alef").enabled() == ["collapse_whitespace", "normalize_alef"]


def test_repeated_header_footer_removed_but_numbered_headings_kept():
    pages = [
        Page("d.pdf", "d", i, chr(10).join(["HEADER", f"المادة {i}", f"فقرة {chr(0x0623 + i)} نص", f"نص آخر {i * 7}", "نص ثالث", f"صفحة {i}"]))
        for i in range(1, 4)
    ]
    out = preprocess_pages(pages, get_config("baseline+remove_repeated_lines"))
    for p in out:
        assert "HEADER" not in p.text and "صفحة" not in p.text and "المادة" in p.text


def test_chunks_stay_inside_page_and_respect_size():
    text = ". ".join(f"جملة رقم {i} تحتوي على كلمات كثيرة لاختبار التقسيم" for i in range(40))
    chunks = chunk_page(Page("d.pdf", "d", 7, text), size=200, overlap=50)
    assert len(chunks) > 3 and all(c.page == 7 and len(c.text) <= 200 for c in chunks)


def test_eval_canonicalizer_is_pipeline_independent():
    assert canonical_for_eval("ﺍﻟﺗﺟﺩﻳﺩ ١٠٠٠ ﻳﻭﻣًﺎ") == canonical_for_eval("التجديد 1000 يوما")


def test_sample_gold_phrases_exist_in_sample_corpus():
    from src.config import SAMPLE_DIR
    from src.evaluation import load_questions
    from src.ingestion import load_pdfs

    corpus = canonical_for_eval(" ".join(p.text for p in load_pdfs(SAMPLE_DIR)))
    for q in load_questions(Path(__file__).resolve().parent.parent / "eval" / "questions.sample.json"):
        for group in q["gold_evidence"]:
            assert any(canonical_for_eval(ph) in corpus for ph in group), (q["id"], group)


def _chars(spec):
    """spec: list of (char, width)"""
    return [{"c": c, "bbox": (0.0, 0.0, w, 10.0)} for c, w in spec]


def test_lam_alef_repair_v1_standalone_swap():
    from src.ingestion import repair_chars
    out, n = repair_chars(_chars([("ث", 3), ("ا", 0), ("ل", 6), ("ث", 5)]))
    assert "".join(out) == "ثلاث" and n == 1


def test_lam_alef_repair_v2_connected_drops_stray_space():
    from src.ingestion import repair_chars
    out, n = repair_chars(_chars([("خ", 6), ("ـ", 2), (" ", 7), ("ا", 0), ("ا", 0), ("ل", 7)]))
    assert "".join(out) == "خـلال" and n == 1


def test_lam_alef_repair_leaves_real_definite_article_alone():
    from src.ingestion import repair_chars
    out, n = repair_chars(_chars([("ا", 3), ("ل", 4), ("ت", 4)]))
    assert "".join(out) == "الت" and n == 0


def test_repair_flag_uses_repaired_text_and_chained_names():
    p = Page("d.pdf", "d", 1, "ثالث", "ثلاث")
    assert preprocess_pages([p], BASELINE)[0].text == "ثالث"
    assert preprocess_pages([p], get_config("baseline+repair_lam_alef"))[0].text == "ثلاث"
    cfg = get_config("baseline+repair_lam_alef+remove_tatweel")
    assert cfg.repair_lam_alef and cfg.remove_tatweel and not cfg.normalize_alef
    assert not MIZAN.repair_lam_alef  # off by default: earlier results stay comparable


def test_mizan_lite_is_the_repair_only_subset_of_mizan():
    from src.preprocessing import MIZAN_LITE
    lite, full = set(MIZAN_LITE.enabled()), set(MIZAN.enabled())
    assert lite < full                                                   # strictly smaller, never a step the full preset lacks
    assert not lite & {"remove_diacritics", "normalize_alef", "normalize_alef_maqsura", "normalize_punctuation",
                       "remove_repeated_lines", "join_broken_lines"}     # no spelling folding, no deleting or reshaping text
    assert {"unicode_nfkc", "remove_tatweel", "remove_invisible_chars"} <= lite
    assert get_config("mizan-lite") is MIZAN_LITE
    assert get_config("mizan-lite+repair_lam_alef").repair_lam_alef and set(get_config("mizan-lite+repair_lam_alef").enabled()) == lite | {"repair_lam_alef"}
    assert get_config("mizan-no-remove_diacritics").enabled() == [f for f in MIZAN.enabled() if f != "remove_diacritics"]   # old names unchanged
    # lite repairs damage but keeps correct spelling and the hamza / alef-maqsura distinctions
    assert preprocess_text("أَلْإِيـــواء ﺍﻟﺗﺟﺩﻳﺩ على", MIZAN_LITE) == "أَلْإِيواء التجديد على"
