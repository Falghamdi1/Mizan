"""Chroma occasionally loses a collection or returns nothing from one that holds chunks (seen with the offline embedder and three collections in one
in-memory client). `search` must heal that by rebuilding the collection from the vectors kept in memory, never score it as a miss, and still fail loudly
when rebuilding does not help."""
import pytest

from src import config, embeddings, retrieval
from src.chunking import Chunk


@pytest.fixture
def index():
    old = config.SETTINGS.embedder
    config.override(embedder="hash")
    embeddings.release()
    chunks = [Chunk(id=f"c{i}", doc="a.pdf", title="a", page=i + 1, index=0, text=t) for i, t in
              enumerate(["مدة سريان الترخيص ثلاث سنوات", "الرسوم مئة ريال", "شروط المرشد السياحي", "تجديد الترخيص خلال ستين يوما"])]
    stats = retrieval.build_index("recover-test", chunks)
    yield stats
    retrieval.drop_index("recover-test")
    config.override(embedder=old)
    embeddings.release()


def test_normal_search_is_unchanged(index):
    r = retrieval.search("recover-test", "مدة الترخيص", 3)
    assert len(r) == 3 and r[0].rank == 1 and all(x.doc == "a.pdf" for x in r)


def test_a_missing_collection_is_rebuilt_from_memory(index):
    retrieval._client().delete_collection(retrieval._collection_name("recover-test"))      # Chroma lost it
    r = retrieval.search("recover-test", "مدة الترخيص", 3)
    assert len(r) == 3


def test_a_collection_that_silently_returns_nothing_is_rebuilt(index, monkeypatch):
    real, calls = retrieval._query, {"n": 0}

    def flaky(col, vector, k):
        calls["n"] += 1
        return {"ids": [[]], "distances": [[]], "documents": [[]], "metadatas": [[]]} if calls["n"] == 1 else real(col, vector, k)
    monkeypatch.setattr(retrieval, "_query", flaky)
    assert len(retrieval.search("recover-test", "مدة الترخيص", 3)) == 3 and calls["n"] == 2


def test_if_rebuilding_does_not_help_it_still_fails_loudly(index, monkeypatch):
    monkeypatch.setattr(retrieval, "_query", lambda col, vector, k: {"ids": [[]], "distances": [[]], "documents": [[]], "metadatas": [[]]})
    with pytest.raises(RuntimeError, match="also after rebuilding"):
        retrieval.search("recover-test", "مدة الترخيص", 3)


def test_an_index_that_was_never_built_raises_the_original_error(index):     # `index` selects the offline embedder: no model download
    with pytest.raises(Exception):
        retrieval.search("never-built", "س", 3)
