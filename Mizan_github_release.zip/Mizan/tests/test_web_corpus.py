"""Tests for the web corpus loaders. Fixtures are synthetic: no network, and no Ministry text in the test suite."""
import importlib.util
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src import config, corpus
from src.web_corpus import (blocks_text, load_web_corpus, parse_definitions, parse_faq, parse_gastat, parse_law,
                            parse_methodologies, parse_news)


def para(text):
    return {"type": "paragraph", "children": [{"text": text, "type": "text"}]}


def bullets(*items):
    return {"type": "list", "format": "ordered", "children": [{"type": "list-item", "children": [{"text": t}]} for t in items]}


def test_blocks_text_joins_paragraphs_and_marks_list_items():
    assert blocks_text([para("مقدمة"), bullets("أ", "ب")]) == "مقدمة\n- أ\n- ب"
    assert blocks_text("  نص   عادي ") == "نص عادي"
    assert blocks_text(None) == ""


def _faq():
    return {"data": [
        {"title": "فئة أولى", "faqs": [
            {"question": "ما الترخيص؟", "answer": [para("الترخيص وثيقة تصدرها الوزارة قبل مزاولة النشاط.")]},
            {"question": "سؤال ثانٍ عن الترخيص؟", "answer": [para("الترخيص وثيقة تصدرها الوزارة قبل مزاولة النشاط.")]},  # same answer
            {"question": "سؤال بلا جواب؟", "answer": []},
        ]},
        {"title": "فئة ثانية", "faqs": [{"question": "كم المدة؟", "answer": [para("سنة واحدة."), bullets("قابلة للتجديد")]}]},
    ]}


def test_faq_indexes_answers_only_and_dedupes_repeated_answers():
    pages, pairs = parse_faq(_faq())
    assert [p.doc for p in pages] == ["faq/فئة أولى", "faq/فئة ثانية"]  # repeated answer indexed once, empty answer dropped
    assert all("ما الترخيص" not in p.text and "كم المدة" not in p.text for p in pages)  # questions are never indexed
    assert len(pairs) == 3
    assert pairs[0]["doc"] == pairs[1]["doc"] and pairs[0]["page"] == pairs[1]["page"] == 1  # both point at the one page
    assert pages[1].text == "سنة واحدة.\n- قابلة للتجديد" and pages[1].text_repaired == pages[1].text


def test_news_prefixes_title_skips_empty_and_dedupes_across_pages():
    a = {"data": [{"id": 1, "date": "2026-01-02", "title": "عنوان", "description": [para("نص الخبر الأول.")]},
                  {"id": 2, "date": "2026-01-01", "title": "بلا نص", "description": []}]}
    b = {"data": [{"id": 1, "date": "2026-01-02", "title": "عنوان", "description": [para("نص الخبر الأول.")]},
                  {"id": 3, "date": "2025-12-31", "title": "ثالث", "description": [para("نص آخر.")]}]}
    pages = parse_news(a, b)
    assert [p.doc for p in pages] == ["news/2026-01-02/1", "news/2025-12-31/3"]
    assert pages[0].text == "عنوان\nنص الخبر الأول."


def test_definitions_and_methodologies_including_table_cards():
    d = {"data": {"cards": [{"label": "السائح", "definition": [para("زائر يبيت ليلة.")]}, {"label": "فارغ", "definition": []}]}}
    assert [p.text for p in parse_definitions(d)] == ["السائح: زائر يبيت ليلة."]
    m = {"data": {"cards": [
        {"number": "01", "card": {"label": "الأهمية", "value": [para("قياس الأداء.")]}, "table": None},
        {"number": "02", "card": None, "table": {"title": "السياحة الوافدة:", "cards": [
            {"label": "تفصيل", "value": [para("رحلات الزوار الدوليين.")]}, {"label": "فارغ", "value": []}]}},
    ]}}
    texts = [p.text for p in parse_methodologies(m)]
    assert texts == ["الأهمية\nقياس الأداء.", "السياحة الوافدة:\nتفصيل: رحلات الزوار الدوليين."]


LAW = """<html><body><nav><p>قائمة الموقع الطويلة جدا لا تدخل في الديباجة أبدا وهي طويلة</p></nav>
<p>بناءً على ما رفعه رئيس الديوان وبعد الاطلاع على الأنظمة ذات الصلة، يقرر مجلس الوزراء الموافقة على النظام المرافق له، وفق الصيغة المرافقة.</p>
<div><h1 class="system_title">نظام الاختبار</h1></div>
<div class="article_item no_alternate"><h3>المادة الأولى</h3><div class="HTMLContainer"><p>يقصد بالألفاظ الآتية:<br/><strong>الوزارة:</strong> وزارة السياحة.</p></div>
<div class="article_btns"></div></div>
<div class="article_item"><h3>المادة الثانية</h3><div class="HTMLContainer"><p>يعمل بالنظام بعد تسعين يوما.</p></div></div>
<div class="d-flex"><p>نموذج الإبلاغ عن خطأ لا يدخل في النص</p></div></body></html>"""


def test_law_pages_per_article_with_preamble_and_without_page_chrome():
    pages = parse_law(LAW, "test-law")
    assert [p.doc for p in pages] == ["law/test-law"] * 3
    assert pages[0].title == "نظام الاختبار" and "ديباجة" in pages[0].text.split("\n")[0]
    assert "قائمة الموقع" not in pages[0].text                      # <nav> is skipped
    assert pages[1].text.startswith("المادة الأولى\n") and "الوزارة: وزارة السياحة." in pages[1].text
    assert pages[2].text == "المادة الثانية\nيعمل بالنظام بعد تسعين يوما."
    assert not any("نموذج الإبلاغ" in p.text for p in pages)       # nothing after the last article leaks in
    assert [p.page for p in pages] == [1, 2, 3]


GASTAT = """<html><body><div>تقرير المنهجية والجودة</div><div>تقرير المنهجية والجودة</div><div>عودة</div>
<div>وصف البيانات</div><div>تعرض النشرة بيانات عن أعداد الحجاج وخصائصهم التفصيلية على مستوى المملكة ومناطقها الإدارية.</div>
<div>• المشتغلون في الأنشطة السياحية.</div>
<div>التصنيفات</div><div>التصنيف الوطني للأنشطة الاقتصادية معتمد على التصنيف الدولي الموحد لجميع الأنشطة الاقتصادية.</div>
<div>مخفي</div><div>يستخدم موقع الويب هذا ملفات تعريف الارتباط</div></body></html>"""


def test_gastat_sections_drop_cookie_banner_and_bullets_become_dashes():
    pages = parse_gastat(GASTAT, "m")
    assert [p.text.split("\n")[0] for p in pages] == ["وصف البيانات", "التصنيفات"]
    assert "- المشتغلون في الأنشطة السياحية." in pages[0].text
    assert not any("ملفات تعريف الارتباط" in p.text for p in pages)
    assert pages[0].title == "تقرير المنهجية والجودة"


def _write_raw(d: Path):
    d.mkdir(parents=True, exist_ok=True)
    (d / "faq.json").write_text(json.dumps(_faq(), ensure_ascii=False), encoding="utf-8")
    (d / "law-test.html").write_text(LAW, encoding="utf-8")


def test_loader_handles_partial_downloads_and_empty_directory(tmp_path):
    with pytest.raises(FileNotFoundError, match="fetch_web_corpus"):
        load_web_corpus(tmp_path)
    _write_raw(tmp_path)
    pages, pairs = load_web_corpus(tmp_path)           # no news, no GASTAT files: still loads
    assert len(pairs) == 3 and {p.doc.split("/")[0] for p in pages} == {"faq", "law"}
    only_law, no_pairs = load_web_corpus(tmp_path, sources=("laws",))
    assert no_pairs == [] and {p.doc for p in only_law} == {"law/test"}


def test_corpus_selection_and_fingerprint(tmp_path, monkeypatch):
    raw = tmp_path / "web"
    _write_raw(raw)
    monkeypatch.setattr(config, "WEB_DIR", raw)
    pages = corpus.load_corpus(tmp_path, kind="web")
    assert len(pages) > 0 and all(not p.doc.endswith(".pdf") for p in pages)
    first = corpus.corpus_fingerprint(tmp_path, kind="web")
    assert first == corpus.corpus_fingerprint(tmp_path, kind="web")
    (raw / "faq.json").write_text(json.dumps({"data": []}), encoding="utf-8")
    assert corpus.corpus_fingerprint(tmp_path, kind="web") != first   # a changed source changes the fingerprint


def test_default_corpus_is_pdf_and_fingerprint_unchanged():
    assert config.CORPUS == "pdf"
    from src.ingestion import corpus_fingerprint
    d = config.RAW_DIR
    if any(d.glob("*.pdf")):
        assert corpus.corpus_fingerprint(d, kind="pdf") == corpus_fingerprint(d)


def test_gold_phrase_is_a_word_boundary_prefix_of_the_answer():
    spec = importlib.util.spec_from_file_location("make_faq_questions", ROOT / "scripts" / "make_faq_questions.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    answer = "أولًا: تقديم طلب الترخيص عن طريق بوابة التراخيص السياحية ثم استكمال المتطلبات الأساسية للترخيص"
    phrase = mod.gold_phrase(answer)
    assert answer.startswith(phrase) and len(phrase) <= mod.PHRASE and not phrase.endswith(" ")
    assert mod.gold_phrase("إجابة قصيرة") == "إجابة قصيرة"


@pytest.mark.skipif(not (ROOT / "eval" / "pdf_faq_alignment.json").exists(), reason="team-only file not present (public clone)")
def test_pdf_alignment_file_is_well_formed():
    spec = importlib.util.spec_from_file_location("make_pdf_questions", ROOT / "scripts" / "make_pdf_questions.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    rows = json.loads(config.PDF_FAQ_ALIGNMENT.read_text(encoding="utf-8"))
    assert len(rows) >= 80 and len({r["key"] for r in rows}) == len(rows)       # one entry per question, no duplicates
    assert all(set(r) == {"key", "category", "phrase"} and len(r["key"]) == 10 and len(r["phrase"].split()) >= 3 for r in rows)
    assert mod.question_key("ما هو نشاط الاستشارات السياحية ؟") == mod.question_key("ما هو نشاط الاستشارات السياحيّة؟")   # keys survive spelling/punctuation variants
    assert mod.question_key("سؤال أول") != mod.question_key("سؤال ثان")
