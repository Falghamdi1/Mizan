"""The screen's events in the orders they really arrive in. Gradio reads an event's inputs when the event starts and writes its outputs when it
ends, so a slow event (the analysis, a translation) can end after a newer one changed the screen. A slow event that ends late must not put
back the screen state it read when it started. These tests run the handlers of the real gr.Blocks with that read-at-start, write-at-end
rule, on the offline pipelines of tests/test_insights_session.py."""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_insights_session as session  # noqa: E402
from test_insights_session import MARINA_Q, T  # noqa: E402

from src import ui  # noqa: E402

gr = pytest.importorskip("gradio")
app = session.app                                          # the same fixture: offline pipelines, fake insights model
OTHER_Q = "What is the licence term?"


class Screen:
    """The values of every component of one browser session, changed only by running the app's own event handlers."""

    def __init__(self, be, folder):
        self.blocks = ui.build_ui(be.state["pages"], be.pipes, be.questions, True, folder)
        self.values = {c._id: getattr(c, "value", None) for c in self.blocks.blocks.values()}
        self.question = next(c for c in self.blocks.blocks.values() if getattr(c, "elem_id", None) == "mz-question")
        self.lang = next(c for c in self.blocks.blocks.values() if type(c).__name__ == "Radio" and c.value == "en")

    def dep(self, name):
        return next(d for d in self.blocks.fns.values() if name in (d.api_name, d.name))

    def start(self, name):
        d = self.dep(name)
        return d, [self.values[c._id] for c in d.inputs]                       # inputs are read when the event starts

    def finish(self, started):
        d, args = started
        out = d.fn(*args)
        out = list(out) if isinstance(out, (tuple, list)) else [out]
        for c, v in zip(d.outputs, out):                                         # outputs are written when it ends; an update without
            if isinstance(v, dict) and v.get("__type__") == "update":           # a value (gr.skip) leaves the component as it is
                if "value" in v:
                    self.values[c._id] = v["value"]
            else:
                self.values[c._id] = v
        return out

    def run(self, name):
        return self.finish(self.start(name))

    def ask(self, question):
        self.values[self.question._id] = question
        return self.run("ask")

    def switch_language(self, lang):
        """The language switch re-renders the whole screen from the stored state, with no model call."""
        self.values[self.lang._id] = lang
        return self.run("relabel")


def results_and_insights(out):
    html = [v for v in out if isinstance(v, str)]
    return next(h for h in html if "mz-cols" in h or "mz-empty" in h), next(h for h in html if 'class="mz mz-ins"' in h)


def test_an_analysis_that_ends_after_a_newer_question_leaves_the_newer_screen(app):
    s = Screen(*app[::2])
    be = s.blocks.backend                                  # the backend the screen uses
    s.ask(MARINA_Q)
    late = s.start("write_insights")                       # the analysis of the first question is being written ...
    s.ask(OTHER_Q)                                         # ... when the user asks again
    s.finish(late)                                         # the first analysis ends: dropped by the backend
    s.run("rerender_insights")
    s.run("write_insights")                                # the analysis of the second question
    s.run("rerender_insights")
    assert be.state["insights"] is not None and be.state["last"]["question"] == OTHER_Q
    results, insights = results_and_insights(s.switch_language("ar"))
    assert OTHER_Q in results and MARINA_Q not in results                 # the stored state is the newer run's
    assert T("ins.loading", "ar") not in insights and "كتبه" in insights  # and its analysis is shown as written, not "being written"


def test_a_translation_that_ends_after_the_analysis_keeps_the_analysis(app):
    s = Screen(*app[::2])
    s.ask(MARINA_Q)
    writing = s.start("write_insights")
    translating = s.start("translate_answers")             # the user asks for the translation while the analysis is being written
    s.finish(writing)
    s.run("rerender_insights")
    s.finish(translating)                                  # the translation ends last
    _, insights = results_and_insights(s.switch_language("en"))
    assert T("ins.loading", "en") not in insights and "Written by" in insights


def test_a_newer_analysis_waits_for_the_running_one_instead_of_being_dropped(app):
    """In the browser, Gradio ignores a trigger of an event that is still running unless its trigger mode says otherwise. The analysis of a
    second question is triggered while the first one's may still be running (a live run on 2026-10-15 kept "being written" for that reason),
    so every chained analysis step queues the latest trigger."""
    s = Screen(*app[::2])
    steps = [d for d in s.blocks.fns.values() if d.name in ("write", "rerender_insights", "regen")]
    assert len(steps) >= 9 and {d.trigger_mode for d in steps} == {"always_last"}
