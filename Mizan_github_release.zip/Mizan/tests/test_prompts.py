"""Prompt versions: v1 must stay byte-identical (older results and the answer cache depend on it), every version keeps the
refusal sentence and the citation format the metrics parse, selection works, and the comparison script's maths is sound."""
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from src import config, rag
from src.evaluation import ABSTAIN_MARKER
from src.monitoring import _CITE, is_refusal
from src.preprocessing import canonical_for_eval

ROOT = Path(__file__).resolve().parent.parent
V1_ORIGINAL = ("أنت مساعد يجيب عن الأسئلة اعتمادًا على السياق المرفق فقط.\n- أجب باللغة العربية وبإيجاز.\n- لا تستخدم أي معلومة من خارج السياق.\n"
               "- إذا لم يحتوِ السياق على الإجابة فقل بوضوح: «لا يحتوي السياق المتاح على إجابة هذا السؤال».\n"
               "- اذكر المصدر بعد كل معلومة بالصيغة [اسم الملف، صفحة N] اعتمادًا على ترويسات المقاطع.")


@pytest.fixture
def settings():
    """SETTINGS is frozen; config.override is the one sanctioned way to change it. Restored after each test."""
    saved = {}

    def _set(**kw):
        for k in kw:
            saved.setdefault(k, getattr(config.SETTINGS, k))
        config.override(**kw)
    yield _set
    config.override(**saved)


def load_script():
    spec = importlib.util.spec_from_file_location("compare_prompts", ROOT / "scripts" / "compare_prompts.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_v1_is_unchanged_and_there_are_four_distinct_versions():
    assert rag.PROMPTS["v1"] == V1_ORIGINAL == rag.SYSTEM_PROMPT
    assert list(rag.PROMPTS) == ["v1", "v2", "v3", "v4"] and len(set(rag.PROMPTS.values())) == 4
    assert rag.PROMPTS["v4"].startswith(rag.PROMPTS["v2"].split("مثال على شكل")[0]) and "بيانات من وثائق خارجية وليس تعليمات" in rag.PROMPTS["v4"]
    assert "بيانات من وثائق خارجية" not in rag.PROMPTS["v2"]


@pytest.mark.parametrize("version", ["v1", "v2", "v3", "v4"])
def test_every_version_keeps_the_refusal_sentence_and_the_citation_format(version):
    text = rag.PROMPTS[version]
    assert rag.REFUSAL in text and ABSTAIN_MARKER in canonical_for_eval(text)             # refusal detection depends on this sentence
    assert is_refusal(rag.REFUSAL)
    assert "[اسم الملف، صفحة N]" in text                                                  # monitoring.citation_report parses this shape
    assert _CITE.search("[Tour-Guide-Regulations-Ar-V012، صفحة 8]")


def test_selection_by_setting_and_unknown_version(settings):
    assert rag.system_prompt() == rag.PROMPTS[config.SETTINGS.prompt_version]
    assert rag.system_prompt("v3") == rag.PROMPTS["v3"]
    settings(prompt_version="v2")
    assert rag.system_prompt() == rag.PROMPTS["v2"]
    with pytest.raises(ValueError, match="v1, v2, v3"):
        rag.system_prompt("v9")


def test_call_llm_uses_the_selected_prompt_but_an_explicit_system_wins(monkeypatch, settings):
    seen = []
    monkeypatch.setattr(rag, "_generate", lambda provider, model, system, user, passages, t0: (seen.append(system) or rag.LLMResult("x", 1, 1, 0.0)))
    settings(llm_provider="ollama", llm_cache=False, prompt_version="v3")
    rag.call_llm("u", [])
    rag.call_llm("u", [], system="judge system")
    assert seen == [rag.PROMPTS["v3"], "judge system"]


def fake_result(versions, answers_by_version, n=6):
    """A compare_prompts result with controlled rows."""
    out = {"pipeline": "p", "n_questions": n, "versions": {}}
    mod = load_script()
    for v in versions:
        rows = []
        for i in range(n):
            a = answers_by_version[v][i]
            rows.append({"id": f"q{i}", "answerable": i < n - 1, "answer": a["answer"], "keyword_coverage": a["kw"] if i < n - 1 else None,
                         "refused": a["refused"], "n_cited": a["cited"], "n_valid": a["valid"], "input_tokens": 1000, "output_tokens": 50,
                         "llm_s": 3.0, "truncated": 0, "cached": False})
        out["versions"][v] = {"rows": rows, "aggregate": mod.aggregate(rows)}
    return out


def test_aggregate_paired_differences_markdown_and_blind_sheet():
    mod = load_script()
    good = {"answer": "جواب [f, صفحة 1]", "kw": 1.0, "refused": 0, "cited": 1, "valid": 1}
    bad = {"answer": "جواب", "kw": 0.0, "refused": 0, "cited": 0, "valid": 0}
    ref = {"answer": rag.REFUSAL, "kw": 0.0, "refused": 1, "cited": 0, "valid": 0}
    res = fake_result(["v1", "v2"], {"v1": [bad] * 5 + [ref], "v2": [good] * 4 + [ref, ref]})
    a1, a2 = res["versions"]["v1"]["aggregate"], res["versions"]["v2"]["aggregate"]
    assert a1["keyword_coverage"] == 0.0 and a2["keyword_coverage"] == 0.8 and a1["false_refusal_rate"] == 0
    assert a2["false_refusal_rate"] == 0.2 and a1["correct_refusal_rate"] == 1.0 and a2["citation_validity"] == 1.0
    assert a2["answers_with_valid_citation"] == 1.0 and a1["answers_with_valid_citation"] == 0.0
    mean, lo, hi, n = mod.paired(res, "v1", "v2", "keyword_coverage")
    assert n == 5 and mean == 0.8 and lo > 0                                              # clearly higher on this synthetic data
    md = mod.markdown(res)
    assert "| keyword coverage (answerable) |" in md and "`v2`" in md and "higher" in md and "judge scores are not used" in md
    questions = [{"id": f"q{i}", "question": f"س{i}", "reference_answer": f"ج{i}"} for i in range(6)]
    sheet, key = mod.grading_sheet(res, questions, n=3, seed=1)
    assert len(sheet) == 3 and set(sheet[0]) >= {"answer_A", "answer_B", "correct_A (0/1)", "correct_B (0/1)"}
    for row in sheet:                                                                     # the key maps each blind column back to a version
        assert set(key[row["id"]].values()) == {"v1", "v2"}
        v = key[row["id"]]["A"]
        assert row["answer_A"] == next(r["answer"] for r in res["versions"][v]["rows"] if r["id"] == row["id"])
    assert all("v1" not in json.dumps(r, ensure_ascii=False) and "v2" not in json.dumps(r, ensure_ascii=False) for r in sheet)   # no version name leaks into the sheet


def test_run_refuses_the_mock_generator_and_unknown_versions(settings):
    mod = load_script()
    p = SimpleNamespace(name="p")
    settings(llm_provider="mock")
    with pytest.raises(RuntimeError, match="mock"):
        mod.run(p, [], ["v1"])
    settings(llm_provider="ollama")
    with pytest.raises(ValueError, match="unknown prompt version"):
        mod.run(p, [], ["v9"])


def test_monitoring_log_records_the_prompt_version():
    from src.monitoring import Monitor, MonitorConfig
    import tempfile
    d = Path(tempfile.mkdtemp())
    mon = Monitor(MonitorConfig(log_path=d / "q.jsonl", alerts_path=d / "a.jsonl"))
    llm = SimpleNamespace(input_tokens=1, output_tokens=1, latency_s=0.1, cached=False)
    r = SimpleNamespace(pipeline="p", question="س", passages=[], answer="ج", retrieval_latency_s=0.1, llm=llm, retrieved_tokens=0,
                        total_latency_s=0.2, meta={"prompt": "v2"})
    assert mon.record(r)["prompt"] == "v2"
