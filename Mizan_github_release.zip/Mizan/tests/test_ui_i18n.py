"""The interface in two languages: every string has both, English mode shows no Arabic interface text, Arabic mode is right-to-left, and
content (answers, passages, citations, measured values) is rendered unchanged in both. Plain dicts in the shape src/backend.py returns:
no model, no index."""
import re
from html import escape

from src import i18n, ui
from src.ui_style import CSS, DARK, LIGHT

ARABIC = re.compile(r"[؀-ۿ]")

INFO = {
    "pipelines": [{"id": "baseline", "kind": "standard", "steps": ["collapse_whitespace"], "chunks": 358, "index_tokens": 77134},
                  {"id": "mizan-lite+repair_lam_alef", "kind": "mizan", "chunks": 323, "index_tokens": 53610,
                   "steps": ["collapse_whitespace", "remove_invisible_chars", "unicode_nfkc", "repair_lam_alef", "remove_tatweel",
                             "normalize_persian_forms", "normalize_digits"]}],
    "corpus": {"documents": 8, "pages": 159, "uploaded": []}, "examples": [{"id": "r1", "label": "Licence term", "question": "Q?"}],
    "settings": {"embedder": "Qwen3-Embedding-0.6B", "reranker": "Qwen3-Reranker-0.6B", "rerank_top_n": 20, "top_k": 4, "chunk_size": 600,
                 "chunk_overlap": 100, "chunk_title": True, "generator": "qwen3:4b", "provider": "ollama", "prompt": "v1"},
    "synthetic": True, "mock": True, "upload_max_mb": 60, "insights_auto": True, "insights_unavailable": False, "can_evaluate": True, "n_prepared": 9,
}


def source(rank, doc, page, relevant, score=0.7):
    return {"rank": rank, "title": "Tour Guide", "title_en": "Tour Guide Regulations", "doc": doc, "page": page, "text": f"Passage {rank} text.",
            "score": score, "rerank": None, "tokens": 120, "relevant": relevant, "withheld": False}


def result(answer_a="The licence lasts three years [guide.pdf, page 8].", answer_b="The licence lasts three years [guide.pdf, page 8]."):
    a = {"id": "baseline", "kind": "standard", "answer": answer_a, "answer_kind": "generated", "abstained": False, "cached": False,
         "evidence": "missing", "evidence_rank": None, "sources": [source(1, "guide.pdf", 9, False), source(2, "other.pdf", 1, False)],
         "tokens": {"retrieved": 1063, "input": 1326, "output": 48}, "latency": {"retrieval_s": 0.86, "generation_s": 3.45},
         "citations": {"cited": 1, "valid": 0, "invalid": 1}, "withheld": 0}
    b = {**a, "id": "mizan-lite+repair_lam_alef", "kind": "mizan", "answer": answer_b, "evidence": "found", "evidence_rank": 2,
         "sources": [source(1, "guide.pdf", 9, False), source(2, "guide.pdf", 8, True)],
         "tokens": {"retrieved": 967, "input": 1231, "output": 47}, "latency": {"retrieval_s": 0.6, "generation_s": 3.51},
         "citations": {"cited": 1, "valid": 1, "invalid": 0}}
    return {"question": "How long does a tour guide licence last?", "gold_source": "prepared", "reference": "Three years.", "phrase": "",
            "pipelines": [a, b], "elapsed_s": 11.8, "run_id": 1, "monitor": None}


PANEL = {"state": "ready", "code": "", "message": "", "evidence": {
    "scope": "single_question", "facts": [{"id": "F11", "text": "Standard: gold evidence NOT found."}, {"id": "F12", "text": "Mizan-lite: found at rank 2."}],
    "not_measured": ["Answer correctness."], "unsupported": ["That either pipeline is better in general."], "notes": [], "documents": 8,
    "pages": 159, "corpus_fp": "29604f14cec0", "uploaded": [], "lang": "en", "blocking": []},
    "result": {"status": "ok", "message": "", "model": "ollama:qwen3:4b", "attempts": 1, "from_cache": False, "input_tokens": 2940,
               "output_tokens": 430, "latency_s": 8.3, "errors": [], "sections": {
                   "overall_finding": {"stance": "insufficient_evidence", "scope": "single_question", "text": "One question is not enough.", "facts": ["F11"]},
                   "key_observations": [{"kind": "observation", "text": "Mizan-lite found the evidence at rank 2.", "facts": ["F12"]}],
                   "trade_offs": [], "recommendation": {"pipeline": "no_recommendation", "conditional": False, "text": "None.", "facts": []},
                   "limitations_and_next_steps": [{"type": "limitation", "text": "One question only."}], "removed": []}}}


def T(key, lang, **kw):
    """An interface string as it appears in the rendered HTML (escaped)."""
    return escape(i18n.t(key, lang, **kw), quote=True)


def chrome_only(html: str) -> str:
    """The interface text: drop tags, and drop content blocks (dir="auto", the documents' own text) which keep their own language."""
    html = re.sub(r'<(\w+)[^>]*dir="auto"[^>]*>.*?</\1>', " ", html, flags=re.S)
    return re.sub(r"<[^>]+>", " ", html)


def test_every_interface_string_exists_in_both_languages():
    assert i18n.missing_translations() == []
    assert [k for k, (en, ar) in i18n.STRINGS.items() if ar and not en] == ["ins.facts_lang"]   # the one note that only Arabic mode needs


def test_english_mode_shows_no_arabic_interface_text():
    res = result()
    parts = [ui.render_brand(INFO, "en"), ui.render_corpus(INFO, "en"), ui.render_notices(INFO, "en"), ui.render_docs(INFO, "en"),
             ui.render_results(res, INFO, "en"), ui.render_results(None, INFO, "en"), ui.render_insights(PANEL, INFO, "en"),
             ui.render_details(INFO, None, "en"), ui.render_footer("en")]
    for html in parts:
        assert not ARABIC.search(chrome_only(html)), chrome_only(html)[:300]


def test_arabic_mode_translates_the_interface_and_keeps_the_content():
    res = result()
    html = ui.render_results(res, INFO, "ar")
    assert T("card.answer", "ar") in html and T("m.title", "ar") in html and T("ev.found", "ar", k=4, r=2) in html
    assert "The licence lasts three years" in html and "1,326" in html and "Passage 2 text." in html       # content and numbers unchanged
    ins = ui.render_insights(PANEL, INFO, "ar")
    assert T("stance.insufficient_evidence", "ar") in ins and T("rec.no_recommendation", "ar") in ins
    assert "One question is not enough." in ins and T("ins.text_lang", "ar") in ins                 # the model's text is shown as written


def test_the_same_result_renders_the_same_measurements_in_both_languages():
    res = result()
    nums = lambda h: re.findall(r"[−+]?\d[\d,]*\.?\d*", chrome_only(h.replace("bdi", "span")))  # noqa: E731
    table = lambda lg: ui.render_measurements(res, lg)  # noqa: E731
    assert nums(table("en")) == nums(table("ar"))


def test_citations_are_marked_with_what_the_code_verified():
    res = result(answer_a="Three years [guide.pdf، صفحة 8].", answer_b="Three years [guide.pdf، صفحة 8].")
    a, b = res["pipelines"]
    assert 'class="mz-cite bad"' in ui.render_answer_text(a, "en")              # page 8 was not among Standard's passages
    assert 'class="mz-cite gold"' in ui.render_answer_text(b, "en")             # page 8 holds the reference evidence for Mizan-lite
    assert "guide.pdf" in ui.render_answer_text(b, "en") and "صفحة" in ui.render_answer_text(b, "en")   # the citation text itself is unchanged


def test_the_summary_states_measurements_and_never_names_a_winner():
    for lang in ("en", "ar"):
        facts = " ".join(ui.summary_facts(result(), 4, lang))
        assert i18n.t("sum.only", lang, name=i18n.t("pipe.mizan", lang)) in facts and T("sum.same_answer", lang) in facts
        assert not re.search(r"\b(wins?|winner|better|best)\b", facts, re.I) and "أفضل من" not in facts and "فاز" not in facts


def test_identical_answers_and_shared_pages_are_reported_as_measured():
    res = result()
    res["pipelines"][0]["evidence"] = "found"
    res["pipelines"][0]["evidence_rank"] = 1
    facts = ui.summary_facts(res, 4, "en")
    assert facts[0].startswith(i18n.t("sum.both_found", "en")) and T("sum.shared", "en", n=1, k=2) in facts
    assert any(f.startswith("Mizan-lite sent 95 fewer tokens") for f in facts)


def test_both_appearances_define_every_token_and_the_css_uses_them():
    assert set(LIGHT) == set(DARK)
    for k in LIGHT:
        assert f"--mz-{k}:" in CSS
    assert ".dark {" in CSS and "prefers-reduced-motion" in CSS


def test_the_translation_button_appears_only_where_it_can_work_and_its_text_is_labelled():
    res = result(answer_a="مدة الترخيص ثلاث سنوات [guide.pdf، صفحة 8].", answer_b="ثلاث سنوات [guide.pdf، صفحة 8].")
    live = {**INFO, "mock": False}
    assert ui.can_translate(res, live, "en") and not ui.can_translate(res, live, "ar") and not ui.can_translate(res, INFO, "en")
    assert not ui.can_translate(result(), live, "en")                                  # English answers need no translation
    tr = {"run_id": 1, "status": "ok", "model": "ollama:qwen3:4b", "texts": {"baseline": "Three years.", "mizan-lite+repair_lam_alef": "Three years, page 8."}}
    html = ui.render_results(res, live, "en", tr)
    assert html.count('class="mz-tr"') == 2 and T("tr.label", "en", model="ollama:qwen3:4b") in html and "Three years, page 8." in html
    assert "مدة الترخيص ثلاث سنوات" in html and not ui.can_translate(res, live, "en", tr)     # the original stays; the button goes once done
    assert 'class="mz-tr"' not in ui.render_results(res, live, "ar", tr)                # Arabic mode shows the answers as written
    assert 'class="mz-tr"' not in ui.render_results(res, live, "en", {**tr, "run_id": 0})   # a translation of an older run is never shown
    failed = ui.render_results(res, live, "en", {"run_id": 1, "status": "failed", "texts": {}, "model": "", "message": "timeout"})
    assert T("tr.failed", "en") in failed and ui.can_translate(res, live, "en", {"run_id": 1, "status": "failed"})   # it can be retried


def test_the_screen_splits_the_answers_from_the_measured_comparison():
    res = result()
    answers, measured = ui.render_results(res, INFO, "en", part="answers"), ui.render_results(res, INFO, "en", part="measured")
    assert "mz-cols" in answers and T("m.title", "en") not in answers and T("sum.title", "en") not in answers
    assert T("m.title", "en") in measured and T("sum.title", "en") in measured and "mz-cols" not in measured
    assert ui.render_results(res, INFO, "en") == answers + measured
    for empty in (None, {"stale": True}, {"error": "Ollama is not running"}):        # nothing measured: step 3 is empty, step 2 explains
        assert ui.render_results(empty, INFO, "en", part="measured") == "" and ui.render_results(empty, INFO, "en", part="answers")


def test_unknown_insights_states_and_failures_are_explained_in_both_languages():
    failed = {**PANEL, "result": {**PANEL["result"], "status": "failed", "sections": None,
                                  "message": "The model's reply did not pass the checks against the evidence in 3 attempt(s)", "errors": ["wrote 'significant'"]}}
    for lang in ("en", "ar"):
        html = ui.render_insights(failed, INFO, lang)
        assert T("ins.failed_checks", lang) in html and T("ins.rejected", lang) in html and "significant" in html
        assert T("ins.none", lang) in ui.render_insights(None, INFO, lang)
        assert T("ins.loading", lang) in ui.render_insights({**PANEL, "state": "loading", "result": None}, INFO, lang)


def test_the_brand_mark_is_the_scale_tile_in_both_languages():
    for lang in ("en", "ar"):
        html = ui.render_brand(INFO, lang)
        assert 'class="mark"' in html and 'viewBox="0 0 24 24"' in html and 'stroke-width="1.7"' in html
        assert T("brand.name", lang) in html
    assert ".mz-brand .mark {" in CSS and "border-radius: 13px" in CSS and "#0e5a4f" in CSS
