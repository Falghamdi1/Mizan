"""The prompt decision rule (docs/ANALYSIS_PLAN.md section 5) on synthetic result files. No model."""
import importlib.util
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture(scope="module")
def dp():
    spec = importlib.util.spec_from_file_location("decide_prompt", ROOT / "scripts" / "decide_prompt.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def rows(valid, cited, refused_answerable=0, n=20):
    out = []
    for i in range(n):
        out.append({"id": f"q{i}", "answerable": True, "refused": i < refused_answerable, "n_valid": valid if i >= refused_answerable else 0,
                    "n_cited": cited if i >= refused_answerable else 0})
    return out


def prompts(v1, v4, tok=(1000, 1200), lat=(6.0, 6.8)):
    mk = lambda r, t, l: {"rows": r, "aggregate": {"mean_input_tokens": t, "median_llm_s": l}}
    return {"versions": {"v1": mk(v1, tok[0], lat[0]), "v4": mk(v4, tok[1], lat[1])}}


def graded(diff):
    return {"paired": {"v4 - v1: accuracy_answerable": None if diff is None else {"diff": diff, "lo": diff - 0.15, "hi": diff + 0.15, "n": 20}}}


def test_switches_when_every_criterion_holds(dp):
    d = dp.decide(prompts(rows(3, 4), rows(5, 5)), graded(0.0), "v1", "v4", accept_cost=True)
    assert d["switch"] and d["decision"] == "v4" and all(c["met"] for c in d["criteria"].values())


def test_keeps_the_baseline_when_citations_miss_the_threshold(dp):
    d = dp.decide(prompts(rows(3, 4), rows(8, 10)), graded(0.1), "v1", "v4", accept_cost=True)     # 0.80 of citations valid
    assert not d["criteria"]["a"]["met"] and d["decision"] == "v1"


def test_keeps_the_baseline_when_correctness_drops_more_than_the_margin(dp):
    d = dp.decide(prompts(rows(3, 4), rows(5, 5)), graded(-0.10), "v1", "v4", accept_cost=True)
    assert not d["criteria"]["b"]["met"] and d["decision"] == "v1"


def test_a_drop_inside_the_margin_is_allowed(dp):
    assert dp.decide(prompts(rows(3, 4), rows(5, 5)), graded(-0.05), "v1", "v4", accept_cost=True)["switch"]


def test_too_many_extra_refusals_keep_the_baseline(dp):
    d = dp.decide(prompts(rows(3, 4), rows(5, 5, refused_answerable=3)), graded(0.0), "v1", "v4", accept_cost=True)
    assert d["criteria"]["c"]["value"] == 3 and not d["criteria"]["c"]["met"] and d["decision"] == "v1"


def test_cost_must_be_accepted_explicitly(dp):
    d = dp.decide(prompts(rows(3, 4), rows(5, 5)), graded(0.0), "v1", "v4", accept_cost=False)
    assert d["criteria"]["a"]["met"] and not d["criteria"]["d"]["met"] and d["decision"] == "v1"
    assert d["criteria"]["d"]["input_token_change"] == pytest.approx(0.2)


def test_without_human_grading_the_decision_is_not_final_and_the_baseline_stays(dp):
    d = dp.decide(prompts(rows(3, 4), rows(5, 5)), graded(None), "v1", "v4", accept_cost=True)
    assert not d["complete"] and d["decision"] == "v1" and "grade the prompt sheet" in d["incomplete_reason"]
    assert "Not final" in dp.markdown(d, "p.json", "g.json")


def test_wilson_interval(dp):
    lo, hi = dp.wilson(29, 30)
    assert 0.80 < lo < 0.84 and hi > 0.98
    assert dp.wilson(0, 0) == (0.0, 0.0)
