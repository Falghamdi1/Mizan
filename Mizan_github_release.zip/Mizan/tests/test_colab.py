"""Tests for the Colab additions: summary logic, generator loading plan, UI helpers, retrieval-only evaluation."""
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src import colab, local_llm
from src.stats import paired_bootstrap


def _run(rows_a, rows_b):
    def pq(vals):
        return [{"id": i, "hit": v, "mrr": v, "precision": v, "keyword_coverage": v, "retrieved_tokens": 100 + 10 * v,
                 "input_tokens": 500, "output_tokens": 50, "retrieval_latency_s": 0.1, "llm_latency_s": 2.0,
                 "total_latency_s": 2.1} for i, v in enumerate(vals)]
    return {"pipelines": {"a": {"per_question": pq(rows_a)}, "b": {"per_question": pq(rows_b)}}}


def test_summary_calls_identical_runs_flat_and_clear_gain_up():
    flat = colab.summary_lines(_run([1, 0] * 20, [1, 0] * 20), _run([1, 0] * 5, [1, 0] * 5), "a", "b")
    assert len(flat["flat"]) == 5 and not flat["up"] and not flat["down"]
    up = colab.summary_lines(_run([0] * 40, [1] * 40), _run([0] * 10, [1] * 10), "a", "b")
    assert len(up["up"]) >= 3 and not up["down"]


def test_summary_warns_when_sample_is_tiny():
    line = colab.paired_line(_run([0] * 5, [1] * 5), "a", "b", "hit", "x")
    assert "too small" in line["text"]


def test_bootstrap_zero_difference_interval_contains_zero():
    mean, lo, hi, n = paired_bootstrap({i: i % 2 for i in range(30)}, {i: (i + 1) % 2 for i in range(30)})
    assert lo < 0 < hi and n == 30


def test_profile_choice_follows_gpu_memory():
    from src import memory

    pick = lambda g: memory.choose_profile("auto", g).name
    assert pick(15.0) == "full"          # T4
    assert pick(22.5) == "full"          # L4
    assert pick(10.0) == "full-4bit"
    assert pick(8.0) == "compact"        # small laptop GPU
    assert pick(0.0) == "cpu"            # no GPU
    assert memory.choose_profile("compact", 40.0).name == "compact"  # an explicit choice is honoured
    assert memory.next_profile(memory.BY_NAME["full"]).name == "full-4bit" and memory.next_profile(memory.BY_NAME["cpu"]) is None


def test_oom_detection_and_cpu_profile_has_no_generator():
    from src import memory

    assert memory.is_oom(RuntimeError("CUDA out of memory. Tried to allocate 2.00 GiB"))
    assert not memory.is_oom(ValueError("something else"))
    cpu = memory.BY_NAME["cpu"]
    assert not cpu.generator and not cpu.reranker


def test_generator_without_gpu_says_how_to_fix_it(monkeypatch):
    torch = pytest.importorskip("torch")
    monkeypatch.setattr(torch.cuda, "is_available", lambda: False)
    local_llm.release()
    with pytest.raises(RuntimeError, match="GPU runtime"):
        local_llm.load("some/model")


def test_hf_provider_errors_become_llm_error(monkeypatch):
    from src import rag

    monkeypatch.setattr(local_llm, "generate", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("CUDA out of memory")))
    with pytest.raises(rag.LLMError, match="4bit"):
        rag.call_llm("prompt-hf-unique", [], provider="hf", model="m")


def test_retrieval_only_run_has_no_answer_metrics():
    from src.evaluation import aggregate

    row = {"answerable": True, "abstained": None, "hit": 1, "llm_cached": False}
    agg = aggregate([row])
    assert agg["false_abstain_rate"] is None


def test_a_free_text_answer_has_no_evidence_check_and_keeps_its_token_counts():
    from src.backend import pipeline_result
    from src.rag import LLMResult, RAGResult

    r = RAGResult("p", "q", "q", [], "x", 0.05, LLMResult("x", 100, 10, 1.5), 0)
    d = pipeline_result("p", r, None, None)
    assert d["evidence"] is None and d["tokens"]["input"] == 100 and d["tokens"]["output"] == 10
    assert d["citations"] == {"cited": 0, "valid": 0, "invalid": 0} and d["latency"]["generation_s"] == 1.5


def test_search_refuses_silent_empty_results(monkeypatch):
    """Chroma once returned nothing for evicted collections; that must raise, not be scored as a miss."""
    from src import retrieval

    class Col:
        def query(self, **k):
            return {"ids": [[]], "distances": [[]], "documents": [[]], "metadatas": [[]]}

        def count(self):
            return 100

    class Client:
        def get_collection(self, name):
            return Col()

    class Emb:
        def embed_query(self, t):
            import numpy as np
            return np.zeros(4)

    monkeypatch.setattr(retrieval, "_client", lambda: Client())
    monkeypatch.setattr(retrieval, "get_embedder", lambda: Emb())
    monkeypatch.setattr(retrieval, "_STORE", {})                    # nothing kept from an earlier test to rebuild from
    with pytest.raises(RuntimeError, match="returned 0 of 4"):
        retrieval.search("baseline", "q", 4)


# ---- the Gradio UI: Add PDF logic and construction (no browser needed) --------------------------------------------
@pytest.fixture()
def corpus(tmp_path):
    import shutil

    from src import config, embeddings
    from src.config import SAMPLE_DIR
    from src.ingestion import load_pdfs
    from src.preprocessing import get_config
    from src.rag import Pipeline

    old = config.SETTINGS.embedder
    config.override(embedder="hash", llm_provider="mock")  # offline, no model download
    embeddings.release()
    for f in sorted(SAMPLE_DIR.glob("*.pdf"))[:2]:
        shutil.copy(f, tmp_path / f.name)
    pages = load_pdfs(tmp_path)
    pipes = {n: Pipeline(get_config(n)) for n in ("baseline", "mizan")}
    for p in pipes.values():
        p.build(pages)
    yield pipes, {"pages": pages}, tmp_path
    config.override(embedder=old)
    embeddings.release()


def _pdf(text: str) -> bytes:
    import pymupdf

    d = pymupdf.open()
    d.new_page().insert_text((72, 100), text)
    return d.tobytes()


def test_add_pdf_reindexes_both_pipelines_and_skips_duplicates(corpus):
    from src.ui import add_pdfs

    pipes, state, folder = corpus
    before = {n: p.index_stats["chunks"] for n, p in pipes.items()}
    msg = add_pdfs({"copy.pdf": next(folder.glob("*.pdf")).read_bytes()}, state, pipes, folder)
    assert "already loaded" in msg and {n: p.index_stats["chunks"] for n, p in pipes.items()} == before
    msg = add_pdfs({"new doc.pdf": _pdf("Tourism license duration is three years and may be renewed.")}, state, pipes, folder)
    assert msg.startswith("Added new_doc.pdf") and "new_doc.pdf" in {p.doc for p in state["pages"]}
    assert all(p.index_stats["chunks"] > before[n] for n, p in pipes.items())


def test_add_pdf_rejects_bad_files_and_keeps_the_corpus(corpus):
    from src.ui import add_pdfs

    pipes, state, folder = corpus
    n_files = len(list(folder.glob("*.pdf")))
    msg = add_pdfs({"notes.txt": b"hello", "broken.pdf": b"%PDF-1.4 garbage"}, state, pipes, folder)
    assert "not a PDF" in msg and ("rejected" in msg or "readable" in msg)
    assert len(list(folder.glob("*.pdf"))) == n_files and {p.doc for p in state["pages"]} == {f.name for f in folder.glob("*.pdf")}


def test_gradio_ui_builds_with_prepared_questions(corpus):
    pytest.importorskip("gradio")
    from src.i18n import t
    from src.ui import PREPARED, build_ui

    pipes, state, folder = corpus
    questions = [{"id": qid, "question": f"سؤال {qid}"} for qid, _ in PREPARED]
    ui = build_ui(state["pages"], pipes, questions, data_dir=folder)
    labels = {x for b in ui.blocks.values() for x in (getattr(b, "value", None), getattr(b, "label", None)) if isinstance(x, str)}
    assert all(label in labels for _, label in PREPARED) and t("docs.add", "en") in labels and t("ask.run", "en") in labels


# ---- responsible-use notices (docs/RESPONSIBLE_AI.md) ---------------------------------------------------------
def test_responsible_use_notice_is_always_shown(corpus):
    from html import escape

    from src import comparison
    from src.backend import MizanBackend
    from src.i18n import t
    from src.ui import render_docs, render_notices, render_results

    pipes, state, folder = corpus
    for synthetic in (False, True):                                  # real or synthetic data: the notice does not depend on it
        assert "not legal or official advice" in comparison.status_alerts(synthetic)       # demo.py's report
        be = MizanBackend(state["pages"], pipes, [], synthetic, folder)
        for lang in ("en", "ar"):
            assert escape(t("notice.verify", lang)) in render_notices(be.info(), lang)      # the app, in either language
    be = MizanBackend(state["pages"], pipes, [], False, folder)
    res, _, _ = be.ask("كم مدة الترخيص؟")
    for lang in ("en", "ar"):
        assert escape(t("res.reminder", lang)) in render_results(res, be.info(), lang)  # every answer screen carries the verify-the-page reminder
        assert "data/raw" in render_docs(be.info(), lang) and escape(t("docs.note", lang)) in render_docs(be.info(), lang)
