"""Monitoring: log format, rolling metrics, each alert rule, cool-down, delivery failures, privacy. Fake clock and notifier: no network."""
import json
from types import SimpleNamespace

import pytest

from src import monitoring
from src.monitoring import Monitor, MonitorConfig, citation_report, is_refusal

REFUSAL = "لا يحتوي السياق المتاح على إجابة هذا السؤال"


def passage(doc="Tour-Guide-Regulations-Ar-V012.pdf", page=8, score=0.8):
    return SimpleNamespace(doc=doc, page=page, score=score)


def result(answer="المدة ثلاث سنوات [Tour-Guide-Regulations-Ar-V012، صفحة 8].", pipeline="baseline", question="كم مدة الترخيص؟",
           passages=None, total=3.0, cached=False, in_tok=900):
    ps = [passage()] if passages is None else passages
    llm = SimpleNamespace(input_tokens=in_tok, output_tokens=40, latency_s=total - 0.5, cached=cached)
    return SimpleNamespace(pipeline=pipeline, question=question, passages=ps, answer=answer, retrieval_latency_s=0.5, llm=llm,
                           retrieved_tokens=700, total_latency_s=total)


class Clock:
    def __init__(self):
        self.t = 1_800_000_000.0

    def __call__(self):
        return self.t


def make(tmp_path, **kw):
    sent = []
    cfg = MonitorConfig(log_path=tmp_path / "q.jsonl", alerts_path=tmp_path / "a.jsonl", **kw)
    clock = Clock()
    mon = Monitor(cfg, clock=clock, notifier=lambda alerts, c: (sent.append([a.key for a in alerts]) or []))
    return mon, sent, clock


def test_citation_report_matches_file_and_page_and_ignores_unretrieved_pages():
    ps = [passage(page=8), passage("Tourist-Visa-Regulations-Ar-V012.pdf", 2)]
    a = ("أ [Tour-Guide-Regulations-Ar-V012.pdf، صفحة 8] ب [Tourist-Visa-Regulations-Ar-V012, page 2] "
         "ج [Tour-Guide-Regulations-Ar-V012، صفحة 9] د [ملف آخر، صفحة ٨]")
    assert citation_report(a, ps) == {"n_cited": 4, "n_valid": 2}                  # extension optional; page 9 and a wrong file are invalid
    assert citation_report("بلا مصدر", ps) == {"n_cited": 0, "n_valid": 0}
    assert citation_report("[Tour-Guide-Regulations-Ar-V012، صفحة ٨]", ps)["n_valid"] == 1   # Arabic-Indic digits


def test_refusal_detection_uses_the_evaluation_marker():
    assert is_refusal("«" + REFUSAL + "»") and is_refusal(REFUSAL + ".")
    assert not is_refusal("المدة ثلاث سنوات")


def test_record_writes_one_json_line_without_text_by_default(tmp_path):
    mon, _, _ = make(tmp_path)
    e = mon.record(result())
    raw = (tmp_path / "q.jsonl").read_text(encoding="utf-8")
    line = json.loads(raw.splitlines()[0])
    assert line == e and line["kind"] == "answer" and line["pipeline"] == "baseline"
    assert line["sources"] == ["Tour-Guide-Regulations-Ar-V012.pdf#8"] and line["n_cited"] == 1 and line["n_valid_cited"] == 1
    assert line["refused"] is False and line["total_s"] == 3.0 and line["top_score"] == 0.8 and line["error"] is None
    assert "كم مدة الترخيص" not in raw and "ثلاث سنوات" not in raw                  # neither question nor answer text is stored
    (tmp_path / "t").mkdir()
    mon2, _, _ = make(tmp_path / "t", log_text=True)
    mon2.record(result())
    assert "كم مدة الترخيص" in (tmp_path / "t" / "q.jsonl").read_text(encoding="utf-8")   # only when asked for


def test_summary_per_pipeline_and_p95(tmp_path):
    mon, _, _ = make(tmp_path)
    for i in range(10):
        mon.record(result(total=1.0 + i))                                           # 1..10 s
    mon.record(result(answer=REFUSAL, pipeline="mizan", total=2.0, passages=[]))
    s = mon.summary()
    assert s["baseline"]["answers"] == 10 and s["baseline"]["p95_s"] == 10.0 and s["baseline"]["p50_s"] == 6.0
    assert s["baseline"]["refusal_rate"] == 0 and s["baseline"]["citation_rate"] == 1.0
    assert s["mizan"]["refusal_rate"] == 1.0 and s["mizan"]["empty_retrievals"] == 1 and s["mizan"]["citation_rate"] is None


def test_each_rule_fires_at_its_threshold_and_not_before(tmp_path):
    mon, _, _ = make(tmp_path, min_queries=5, refusal_rate=0.5, p95_s=10, min_citation_rate=0.5)
    for _ in range(4):
        mon.record(result(answer=REFUSAL, total=30))                                 # four bad answers: below the minimum count
    assert mon.check_alerts() == []
    mon.record(result(answer=REFUSAL, total=30))                                     # fifth: refusal and latency rules now apply
    assert {a.rule for a in mon.check_alerts()} == {"refusals", "latency"}
    for sub in "cre":
        (tmp_path / sub).mkdir()
    mon2, _, _ = make(tmp_path / "c", min_queries=5, min_citation_rate=0.5)
    for _ in range(5):
        mon2.record(result(answer="إجابة بلا مصدر"))
    assert [a.rule for a in mon2.check_alerts()] == ["citations"]
    mon3, _, _ = make(tmp_path / "r")
    mon3.record(result(passages=[]))
    assert [a.rule for a in mon3.check_alerts()] == ["retrieval"]
    mon4, _, _ = make(tmp_path / "e")
    mon4.record_error("mizan", "سؤال", RuntimeError("x"))
    al = mon4.check_alerts()
    assert [a.key for a in al] == ["errors:mizan"] and "failed request" in al[0].message


def test_alerts_are_per_pipeline(tmp_path):
    mon, _, _ = make(tmp_path)
    for _ in range(5):
        mon.record(result(answer=REFUSAL, pipeline="mizan"))
        mon.record(result(pipeline="baseline"))
    assert [a.key for a in mon.check_alerts()] == ["refusals:mizan"]


def test_notify_respects_cooldown_and_writes_the_alert_log(tmp_path):
    mon, sent, clock = make(tmp_path, cooldown_s=300)
    mon.record_error("baseline", "س", RuntimeError())
    assert len(mon.after_answer()) == 1 and sent == [["errors:baseline"]]
    mon.after_answer()
    assert sent == [["errors:baseline"]]                                            # same alert inside the cool-down: not re-sent
    clock.t += 301
    mon.after_answer()
    assert sent == [["errors:baseline"]] * 2                                        # after the cool-down it is sent again
    rows = [json.loads(x) for x in (tmp_path / "a.jsonl").read_text(encoding="utf-8").splitlines()]
    assert len(rows) == 2 and rows[0]["rule"] == "errors" and rows[0]["delivery_failures"] == []


def test_a_failing_notifier_never_breaks_the_caller_and_is_logged(tmp_path):
    def boom(alerts, cfg):
        raise OSError("down")
    cfg = MonitorConfig(log_path=tmp_path / "q.jsonl", alerts_path=tmp_path / "a.jsonl")
    mon = Monitor(cfg, notifier=boom)
    mon.record_error("baseline", "س", RuntimeError())
    assert len(mon.after_answer()) == 1
    assert json.loads((tmp_path / "a.jsonl").read_text(encoding="utf-8"))["delivery_failures"] == ["notifier: OSError"]


def test_deliver_posts_to_the_webhook_and_reports_failures(monkeypatch):
    posted = []

    class Resp:
        def close(self):
            pass
    monkeypatch.setattr(monitoring.urllib.request, "urlopen", lambda req, timeout: posted.append(json.loads(req.data)) or Resp())
    cfg = MonitorConfig(webhook="http://example.invalid/hook")
    a = monitoring.Alert("errors:baseline", "errors", "baseline", "boom")
    assert monitoring.deliver([a], cfg) == [] and "boom" in posted[0]["text"] and posted[0]["text"] == posted[0]["content"]

    def refuse(req, timeout):
        raise OSError("no network")
    monkeypatch.setattr(monitoring.urllib.request, "urlopen", refuse)
    assert monitoring.deliver([a], cfg) == ["webhook: OSError"]


def test_corrupt_log_lines_are_skipped_and_record_never_raises(tmp_path):
    mon, _, _ = make(tmp_path)
    mon.record(result())
    with open(tmp_path / "q.jsonl", "a", encoding="utf-8") as f:
        f.write('{"half written\n')
    assert len(mon.read()) == 1
    assert mon.record(SimpleNamespace()) == {}                                       # a malformed result is swallowed, not raised


def test_config_from_env_and_disable(monkeypatch):
    monkeypatch.setenv("MIZAN_ALERT_REFUSAL_RATE", "0.2")
    monkeypatch.setenv("MIZAN_ALERT_P95_S", "oops")                                  # a bad value falls back to the default
    cfg = MonitorConfig.from_env()
    assert cfg.refusal_rate == 0.2 and cfg.p95_s == 20.0 and cfg.alerts_path.name == "alerts.jsonl"
    monkeypatch.setenv("MIZAN_MONITOR", "0")
    assert not monitoring.enabled()


def test_compare_logs_answers_and_failures_through_the_hook():
    from src.comparison import compare

    class Ok:
        def ask(self, q):
            return result(pipeline="baseline", question=q)

    class Bad:
        def ask(self, q):
            raise RuntimeError("generator down")
    compare({"baseline": Ok()}, "سؤال")
    with pytest.raises(RuntimeError):
        compare({"mizan": Bad()}, "سؤال")
    rows = monitoring.get_monitor().read()
    assert [(r["pipeline"], r["kind"]) for r in rows] == [("baseline", "answer"), ("mizan", "error")]
    html = monitoring.panel_html()
    assert "baseline" in html and "<table" in html


# ---- events, the ingestion and security rules, and a webhook that REALLY executes (local HTTP server, no mock) ----------------
def test_events_raise_ingestion_and_security_alerts(tmp_path):
    mon, sent, _ = make(tmp_path)
    mon.record_event("ingestion_error", "upload", "rejected")
    r = result()
    r.meta = {"withheld": [{"doc": "x.pdf", "page": 3, "patterns": ["ar_ignore_instructions"]}]}
    mon.record(r)
    keys = sorted(a.key for a in mon.check_alerts())
    assert keys == ["ingestion:upload", "security:baseline"]
    raw = (tmp_path / "q.jsonl").read_text(encoding="utf-8")
    assert "x.pdf" not in raw and "ar_ignore" not in raw                                  # events carry a kind and a code, never names or text
    s = mon.summary()
    assert s["upload"]["ingestion_errors"] == 1 and s["baseline"]["injection_withheld"] == 1 and s["baseline"]["answers"] == 1


def test_webhook_alert_is_really_delivered_over_http(tmp_path):
    import threading
    from http.server import BaseHTTPRequestHandler, HTTPServer

    received = []

    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            received.append(json.loads(self.rfile.read(int(self.headers["Content-Length"]))))
            self.send_response(200)
            self.end_headers()

        def log_message(self, *a):
            pass
    server = HTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    try:
        cfg = MonitorConfig(log_path=tmp_path / "q.jsonl", alerts_path=tmp_path / "a.jsonl", webhook=f"http://127.0.0.1:{server.server_port}/hook")
        mon = Monitor(cfg)                                                                 # the real notifier: monitoring.deliver
        mon.record_error("mizan", "سؤال", RuntimeError("generator down"))
        fired = mon.after_answer()
    finally:
        server.shutdown()
    assert [a.rule for a in fired] == ["errors"]
    assert len(received) == 1 and "failed request" in received[0]["text"] and received[0]["text"] == received[0]["content"]
    assert json.loads((tmp_path / "a.jsonl").read_text(encoding="utf-8"))["delivery_failures"] == []


def test_unreachable_webhook_is_recorded_as_a_delivery_failure_not_an_exception(tmp_path):
    cfg = MonitorConfig(log_path=tmp_path / "q.jsonl", alerts_path=tmp_path / "a.jsonl", webhook="http://127.0.0.1:9/hook")      # nothing listens on port 9
    mon = Monitor(cfg)
    mon.record_error("mizan", "سؤال", RuntimeError())
    assert len(mon.after_answer()) == 1
    assert json.loads((tmp_path / "a.jsonl").read_text(encoding="utf-8"))["delivery_failures"][0].startswith("webhook:")
