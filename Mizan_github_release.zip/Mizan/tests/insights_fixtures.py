"""Builders shared by the Mizan Insights tests: documents, pipelines without models, comparisons with chosen outcomes, aggregate results, and a
fake LLM that answers FROM THE EVIDENCE IT IS GIVEN (so a test can show that a changed run reaches the model and changes what comes back).
No model, no network."""
import json
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src import retrieval  # noqa: E402
from src.evaluation import score  # noqa: E402
from src.ingestion import Page, pages_fingerprint  # noqa: E402
from src.preprocessing import get_config  # noqa: E402
from src.rag import LLMResult, RAGResult  # noqa: E402

NAMES = ("baseline", "mizan-lite+repair_lam_alef")
QUESTION = "كم مدة الترخيص للمرشد السياحي؟"
EVIDENCE = "مدة الترخيص ثلاث سنوات"             # the words that answer QUESTION
GOLD = {"id": "t1", "type": "duration", "question": QUESTION, "gold_evidence": [[EVIDENCE]], "gold_docs": ["Tour-Guide.pdf"]}
ANSWER_OK = "مدة الترخيص ثلاث سنوات [Tour-Guide، صفحة 2]."


def pages(extra: dict | None = None) -> list[Page]:
    base = {"Tour-Guide.pdf": ["نص عام عن المرشد السياحي", f"{EVIDENCE} ويجوز تجديده"], "Hospitality.pdf": ["شروط مرافق الإيواء السياحي"]}
    base.update(extra or {})
    return [Page(d, d[:-4], i, t, t) for d, ts in base.items() for i, t in enumerate(ts, start=1)]


def passage(doc, page, rank, text, score_=0.9):
    return retrieval.Retrieved(rank, score_, f"{doc}::{page}", doc, doc, page, text, 40)


HIT = lambda rank=1: passage("Tour-Guide.pdf", 2, rank, f"{EVIDENCE} ويجوز تجديده بطلب")          # noqa: E731 - a passage holding the gold evidence
MISS = lambda rank=1: passage("Hospitality.pdf", 1, rank, "شروط مرافق الإيواء السياحي")            # noqa: E731


def result(name, question, passages, answer, in_tok=1000, out_tok=60, ret_lat=0.5, llm_lat=3.0, cached=False, withheld=None):
    llm = LLMResult(answer, in_tok, out_tok, llm_lat, cached)
    return RAGResult(name, question, question, passages, answer, ret_lat, llm, sum(p.tokens for p in passages),
                     meta={"shown": passages, "withheld": withheld or [], "candidates": passages})


def pipes_for(pg, tokens=(500, 450)):
    fp = pages_fingerprint(pg)
    return {n: SimpleNamespace(name=n, cfg=get_config(n), index_stats={"chunks": 10, "chars": 5000, "tokens": t, "pages_sha256": fp})
            for n, t in zip(NAMES, tokens)}


def comparison(pipes, std, miz, gold=GOLD):
    return {n: {"result": r, "score": score(gold, r) if gold else None} for n, r in zip(pipes, (std, miz))}


def scenario(kind="mizan_wins", question=QUESTION, gold=GOLD, tokens=(1000, 900), extra_docs=None, answer_std=None, answer_miz=None):
    """(pipes, pages, cmp, question, gold) with a chosen outcome: mizan_wins | standard_wins | both_hit | neither_hit."""
    pg = pages(extra_docs)
    pipes = pipes_for(pg)
    hit_std, hit_miz = {"mizan_wins": (0, 1), "standard_wins": (1, 0), "both_hit": (1, 1), "neither_hit": (0, 0)}[kind]
    ps = [HIT(1) if hit_std else MISS(1), MISS(2)]
    pm = [HIT(1) if hit_miz else MISS(1), MISS(2)]
    std = result(NAMES[0], question, ps, answer_std or (ANSWER_OK if hit_std else "لا يوجد جواب واضح [Hospitality، صفحة 1]."), in_tok=tokens[0])
    miz = result(NAMES[1], question, pm, answer_miz or (ANSWER_OK if hit_miz else "لا يوجد جواب واضح [Hospitality، صفحة 1]."), in_tok=tokens[1])
    return pipes, pg, comparison(pipes, std, miz, gold), question, gold


def aggregate(pipes, pg, std_hits, miz_hits, n_unanswerable=0):
    """An evaluate_prepared-shaped result with chosen per-question hits (lists of 0/1, same length)."""
    rows = {n: [] for n in pipes}
    for name, hits in zip(pipes, (std_hits, miz_hits)):
        for i, h in enumerate(hits):
            rows[name].append({"id": f"q{i}", "answerable": True, "hit": h, "mrr": float(h), "precision": 0.25 * h, "first_relevant_rank": 1 if h else None,
                               "candidate_recall": 1, "retrieved_tokens": 400 if name == NAMES[0] else 360, "retrieval_latency_s": 0.5})
        for j in range(n_unanswerable):
            rows[name].append({"id": f"u{j}", "answerable": False, "hit": None, "mrr": None, "precision": None, "first_relevant_rank": None,
                               "candidate_recall": None, "retrieved_tokens": 300, "retrieval_latency_s": 0.5})
    return {"names": list(pipes), "rows": rows, "n_questions": len(rows[NAMES[0]]), "questions_sha256": "ab" * 32, "source": "test questions",
            "corpus_sha256": pages_fingerprint(pg), "created": "2026-10-11T00:00:00"}


# ---------------------------------------------------------------------------------------------------------------
# A fake LLM that reads the evidence in the prompt and answers from it
# ---------------------------------------------------------------------------------------------------------------
def context_of(user_prompt: str) -> dict:
    return json.loads(user_prompt.split("\n")[1])         # line 0 = header, line 1 = the evidence as one line of JSON


def good_reply(ctx: dict) -> dict:
    """A reply that passes validation for ANY evidence: it takes the strongest stance the evidence allows, names the pipeline the evidence
    favours, cites real fact ids and uses no number. Different evidence gives a different reply."""
    allowed = ctx["allowed"]
    scope = sorted(allowed["stance_by_scope"])[0]
    stances = allowed["stance_by_scope"][scope]
    stance = next((s for s in ("mizan_ahead", "standard_ahead", "similar", "mixed") if s in stances), "insufficient_evidence")
    lab = ctx["pipelines"]
    who = {"mizan_ahead": lab["mizan"], "standard_ahead": lab["standard"]}.get(stance)
    ids = [f["id"] for f in ctx["facts"]]
    gold = [f["id"] for f in ctx["facts"] if f["kind"] == "gold"] or ids[:1]
    rec = {"mizan_ahead": "mizan", "standard_ahead": "standard"}.get(stance, "no_recommendation")
    return {"overall_finding": {"scope": scope, "stance": stance, "facts": gold,
                                "text": (f"The evidence favours {who} for this scope." if who else f"The evidence supports the stance {stance} for this scope.")},
            "key_observations": [{"kind": "observation", "text": "Both pipelines were compared on the same documents.", "facts": ids[:1]}],
            "trade_offs": [],
            "recommendation": {"pipeline": rec, "facts": gold,
                               "text": "Use this only for the evaluated documents." if rec != "no_recommendation" else "No pipeline is recommended from this evidence."},
            "limitations_and_next_steps": [{"type": "limitation", "text": "Answer correctness was not measured."},
                                           {"type": "next_step", "text": "Have two people grade the answers."}]}


class FakeLLM:
    """Replaces insights.call_llm. `reply` may be None (use good_reply), a dict, a string, a list of those (one per call), or a function of the context."""

    def __init__(self, reply=None, fail=None):
        self.calls, self.reply, self.fail = [], reply, fail

    def __call__(self, user_prompt, passages, system=None, provider=None, model=None, max_tokens=None, use_cache=True):
        self.calls.append({"user": user_prompt, "system": system, "provider": provider, "model": model, "max_tokens": max_tokens, "use_cache": use_cache})
        if self.fail:
            raise self.fail
        ctx = context_of(user_prompt)
        r = self.reply
        if isinstance(r, list):
            r = r[min(len(self.calls), len(r)) - 1]
        if callable(r):
            r = r(ctx)
        if r is None:
            r = good_reply(ctx)
        return LLMResult(r if isinstance(r, str) else json.dumps(r, ensure_ascii=False), 1500, 300, 4.2)

    def contexts(self):
        return [context_of(c["user"]) for c in self.calls]
