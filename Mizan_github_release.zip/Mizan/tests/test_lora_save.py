"""The LoRA adapter is written in the format `load_adapter` reads (P5 on Colab failed once because save_pretrained wrote the full model)."""
import importlib
import tempfile
from pathlib import Path

import pytest

torch = pytest.importorskip("torch")
transformers = pytest.importorskip("transformers")
peft = pytest.importorskip("peft")


def tiny_model():
    cfg = transformers.Qwen3Config(vocab_size=64, hidden_size=32, intermediate_size=64, num_hidden_layers=2, num_attention_heads=4,
                                   num_key_value_heads=2, head_dim=8, max_position_embeddings=64)
    torch.manual_seed(0)
    return transformers.Qwen3Model(cfg)


def test_saved_adapter_reloads_into_a_fresh_model_with_the_same_outputs():
    train_lora = importlib.import_module("finetune.train_lora")
    model = tiny_model()
    model.add_adapter(peft.LoraConfig(task_type=peft.TaskType.FEATURE_EXTRACTION, r=4, lora_alpha=8,
                                      target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]))
    with torch.no_grad():                                   # make the adapter non-trivial (LoRA B starts at zero)
        for n, p in model.named_parameters():
            if "lora_B" in n:
                p.add_(0.05)
    ids = torch.tensor([[1, 5, 9, 3]])
    model.eval()
    expected = model(input_ids=ids).last_hidden_state
    with tempfile.TemporaryDirectory() as d:
        out = Path(d)
        train_lora.save_lora(model, out)
        assert (out / "adapter_config.json").exists() and (out / "adapter_model.safetensors").exists()
        assert not list(out.glob("model*.safetensors"))       # adapter only, not the full model
        fresh = tiny_model()
        base = fresh(input_ids=ids).last_hidden_state
        fresh.load_adapter(str(out))
        fresh.eval()
        got = fresh(input_ids=ids).last_hidden_state
    assert not torch.allclose(base, expected)
    assert torch.allclose(got, expected, atol=1e-5)
