"""Tests added by the engineering audit: experiment validity, failure handling, reproducibility helpers."""
import re
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))

from src import evaluation, rag, retrieval
from src.config import RAW_DIR, SAMPLE_DIR
from src.ingestion import _page_text, load_pdfs
from src.preprocessing import BASELINE, MIZAN, get_config, preprocess_text
from src.rag import LLMError, LLMResult, RAGResult

TEXT = "الإيــواءُ ٢٠٠٠ ريال، أَو ثالثة؟ ﺍﻟﺗﺟﺩﻳﺩ\nسطر ثانٍ\n\nفقرة 1,000"


def _passage(doc, page, text, rank=1):
    return retrieval.Retrieved(rank, 0.5, f"{doc}::{page}", doc, doc, page, text, 10)


def _result(passages, answer="x"):
    return RAGResult("p", "q", "q", passages, answer, 0.0, LLMResult(answer, 5, 5, 0.1), 10)


# ---- preprocessing: deterministic, idempotent, does not destroy numbers --------------------------------------
@pytest.mark.parametrize("name", ["baseline", "mizan", "mizan+repair_lam_alef", "baseline+remove_tatweel"])
def test_preprocessing_is_idempotent_and_deterministic(name):
    cfg = get_config(name)
    once = preprocess_text(TEXT, cfg)
    assert preprocess_text(once, cfg) == once
    assert preprocess_text(TEXT, cfg) == once


def test_mizan_keeps_every_number():
    digits = lambda t: re.findall(r"\d+", t.translate(str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")))
    assert digits(preprocess_text(TEXT, MIZAN)) == digits(TEXT) == ["2000", "1", "000"]


def test_lossy_folds_are_off_by_default():
    assert not MIZAN.normalize_ta_marbuta and not MIZAN.normalize_hamza_seats and not MIZAN.repair_lam_alef


def test_repair_flag_changes_only_ligatures_not_structure():
    """The repair re-extracts text through a different code path; after baseline cleanup it must equal the normal
    text, otherwise the flag would silently change chunking too (a confound)."""
    import pymupdf

    pdfs = sorted(RAW_DIR.glob("*.pdf"))[:2]
    if not pdfs:
        pytest.skip("no real PDFs in data/raw")
    for f in pdfs:
        for pg in pymupdf.open(f):
            if pg.get_text("text").strip():
                plain, _ = _page_text(pg, repair=False)
                assert preprocess_text(plain, BASELINE) == preprocess_text(pg.get_text("text"), BASELINE)


# ---- scoring: pipeline-independent, document-restricted ---------------------------------------------------
def test_gold_docs_blocks_same_phrase_in_other_document():
    q = {"gold_evidence": [["مدة سريان الترخيص"]], "gold_docs": ["guide.pdf"]}
    wrong = _result([_passage("hospitality.pdf", 1, "مدة سريان الترخيص ثلاث سنوات")])
    right = _result([_passage("hospitality.pdf", 1, "x", 1), _passage("guide.pdf", 8, "مدة سريان الترخيص", 2)])
    assert evaluation.score(q, wrong)["hit"] == 0
    s = evaluation.score(q, right)
    assert s["hit"] == 1 and s["first_relevant_rank"] == 2 and s["mrr"] == 0.5


def test_unanswerable_question_has_no_retrieval_metrics():
    s = evaluation.score({"gold_evidence": []}, _result([_passage("a.pdf", 1, "نص")]))
    assert s["hit"] is None and s["precision"] is None and s["answerable"] is False


def test_refusals_are_graded_by_rule_not_by_llm(monkeypatch):
    monkeypatch.setattr(evaluation, "judge_config", lambda: {"provider": "ollama", "model": "x", "independent": True})
    refusal = _result([], answer="لا يحتوي السياق المتاح على إجابة هذا السؤال.")
    assert evaluation.judge({"gold_evidence": [["a"]], "reference_answer": "r"}, refusal) == {"judge_correct": 0, "judge_faithful": 1}
    assert evaluation.judge({"gold_evidence": [], "reference_answer": "r"}, refusal) == {"judge_correct": 1, "judge_faithful": 1}


# ---- failure handling ------------------------------------------------------------------------------------
def test_missing_api_key_gives_clear_error(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    with pytest.raises(LLMError, match="ANTHROPIC_API_KEY"):
        rag.call_llm("prompt-" + "unique-1", [], provider="anthropic", model="m")


def test_unreachable_local_llm_gives_clear_error(monkeypatch):
    monkeypatch.setenv("OLLAMA_BASE_URL", "http://127.0.0.1:9/v1")
    with pytest.raises(LLMError, match="mock"):
        rag.call_llm("prompt-" + "unique-2", [], provider="ollama", model="m")


def test_corrupt_pdf_is_skipped_but_empty_set_is_an_error(tmp_path):
    (tmp_path / "broken.pdf").write_text("not a pdf")
    with pytest.raises(RuntimeError, match="could be read"):
        load_pdfs(tmp_path)
    good = sorted(SAMPLE_DIR.glob("*.pdf"))[0]
    (tmp_path / good.name).write_bytes(good.read_bytes())
    assert len(load_pdfs(tmp_path)) > 0


# ---- reproducibility helpers -------------------------------------------------------------------------------
def test_paired_bootstrap_known_answer():
    from compare_runs import paired_bootstrap

    mean, lo, hi, n = paired_bootstrap({1: 0, 2: 0, 3: 0}, {1: 1, 2: 1, 3: 1})
    assert (mean, lo, hi, n) == (1.0, 1.0, 1.0, 3)
    assert paired_bootstrap({1: 0}, {2: 1}) is None


def test_metrics_table_difference_is_plain_arithmetic():
    from src.ui_theme import metrics_table

    html = metrics_table([["hit", "0.500", "0.750"], ["tokens", "1000", "800"], ["note", "n/a", "0.1"]], ["a", "b"])
    assert "+0.250" in html and "-200" in html and html.count("–") >= 1


# ---- judge v2: claims are checked by code --------------------------------------------------------------
def _judge_v2(monkeypatch, verdict, answer="يجب أن يكون الحد الأدنى للسن ثلاث سنوات.", reference="ثلاث سنوات", ctx="الحد الأدنى للسن ثلاث سنوات حسب اللائحة"):
    monkeypatch.setenv("MIZAN_JUDGE_PROMPT", "v2")
    monkeypatch.setattr(evaluation, "judge_config", lambda: {"provider": "ollama", "model": "x", "independent": True})
    monkeypatch.setattr(evaluation, "call_llm", lambda *a, **k: type("R", (), {"text": verdict})())
    return evaluation.judge({"question": "q", "reference_answer": reference, "gold_evidence": [["a"]]}, _result([_passage("a.pdf", 1, ctx)], answer=answer))


def test_judge_v2_accepts_a_fact_whose_quote_is_in_the_answer(monkeypatch):
    v = '{"facts":[{"fact":"three years","answer_quote":"ثلاث سنوات"}],"contradicts":0,"support_quote":"الحد الأدنى للسن ثلاث سنوات"}'
    assert _judge_v2(monkeypatch, v) == {"judge_correct": 1, "judge_faithful": 1}


def test_judge_v2_rejects_an_invented_quote(monkeypatch):
    v = '{"facts":[{"fact":"three years","answer_quote":"ثلاث سنوات كاملة من العمل"}],"contradicts":0,"support_quote":"نص غير موجود في السياق"}'
    assert _judge_v2(monkeypatch, v) == {"judge_correct": 0, "judge_faithful": 0}


def test_judge_v2_rejects_a_wrong_number_even_if_the_judge_says_yes(monkeypatch):
    v = '{"facts":[{"fact":"3 years","answer_quote":"سنتين"}],"contradicts":0,"support_quote":""}'
    out = _judge_v2(monkeypatch, v, answer="الحد الأدنى سنتين", reference="3 سنوات")
    assert out["judge_correct"] == 0


def test_judge_v2_unparsable_verdict_is_counted_not_guessed(monkeypatch):
    assert _judge_v2(monkeypatch, "I think it is fine")["judge_failed"] is True
