"""The blind-question form generator (scripts/make_blind_form.py) and its template. The canonicalizer equivalence with the browser was checked by hand
on 269 real and adversarial strings (0 mismatches); here: the data block, the exported tables and the template contract."""
import importlib.util
import json
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture(scope="module")
def mf():
    import sys

    sys.path.insert(0, str(ROOT / "scripts"))
    spec = importlib.util.spec_from_file_location("make_blind_form", ROOT / "scripts" / "make_blind_form.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def test_template_has_one_data_slot_and_no_corpus_text():
    t = (ROOT / "tools" / "blind_question_form.template.html").read_text(encoding="utf-8")
    assert t.count("/*DATA*/") == 1 and "Hospitality" not in t and len(t) < 40_000        # the committed file holds code only


def test_canon_tables_are_json_and_match_the_python_canonicalizer_inputs(mf):
    from src import preprocessing as P

    tables = mf.canon_tables()
    json.dumps(tables)                                                       # serialisable
    assert tables["alef"][str(ord("أ"))] == "ا" and tables["digits"][str(ord("٣"))] == "3"
    assert tables["tatweel"] == "ـ" and tables["diacritics"] == P._DIACRITICS.pattern and tables["marks"] == P._MARKS
    assert all(v is None or isinstance(v, str) for t in ("invisible", "ya", "persian", "ta", "hamza") for v in tables[t].values())
    assert tables["invisible"][str(0x200B)] is None                          # zero-width space is dropped


def test_render_escapes_a_closing_script_tag_and_keeps_arabic(mf):
    data = {"pages": [{"k": "pdf", "d": "a.pdf", "p": 1, "t": "نص </script><b>x</b>"}], "fingerprint": "f", "canon": {}, "dev_questions": [], "quota": {}, "max_docs": 4, "min_words": 3}
    html = mf.render(data, "<script id=data>/*DATA*/</script>")
    assert html.count("</script>") == 1                                       # only the template's own closing tag
    assert "نص" in html and "<\\/script>" in html


def test_generated_output_is_git_ignored():
    gi = (ROOT / ".gitignore").read_text(encoding="utf-8")
    assert "data/blind_form/" in gi
