"""Leakage guard of the model-adaptation experiment: the evaluation questions must come from documents the adapter never trained on."""
import importlib.util
import json
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture(scope="module")
def ad():
    spec = importlib.util.spec_from_file_location("run_adaptation", ROOT / "scripts" / "run_adaptation.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def pairs_file(tmp_path, rows):
    p = tmp_path / "pairs.jsonl"
    p.write_text("\n".join(json.dumps(r, ensure_ascii=False) for r in rows), encoding="utf-8")
    return p


def q(i, docs, text):
    return {"id": i, "question": text, "gold_docs": docs, "gold_evidence": [["x y z"]]}


def test_questions_on_training_documents_are_excluded(ad, tmp_path):
    p = pairs_file(tmp_path, [{"doc": "train.pdf", "query_raw": "سؤال التدريب الأول", "query": "q", "passage": "p"}])
    sets = {"s": [q("a", ["held.pdf"], "سؤال أول"), q("b", ["train.pdf"], "سؤال ثان"), q("c", ["held.pdf", "train.pdf"], "سؤال ثالث")]}
    rep = ad.leakage_report(p, sets)
    assert [x["id"] for x in rep["usable"]["s"]] == ["a"]                                    # a question touching a training document is never used
    assert rep["sets"]["s"]["excluded_because_gold_doc_was_in_training"] == 2 and rep["problems"] == []


def test_a_question_equal_to_a_training_query_stops_the_run(ad, tmp_path):
    p = pairs_file(tmp_path, [{"doc": "train.pdf", "query_raw": "ما مدة الترخيص؟", "query": "ما مدة الترخيص ?", "passage": "p"}])
    rep = ad.leakage_report(p, {"s": [q("a", ["held.pdf"], "ما مدة الترخيص؟")]})
    assert rep["problems"] and rep["usable"]["s"] == [] and rep["sets"]["s"]["equal_to_a_training_query"] == ["a"]


@pytest.mark.skipif(not (ROOT / "finetune" / "pairs_v2.jsonl").exists(), reason="training pairs are local-only")
def test_project_state_hand_written_and_generated_questions_use_only_held_out_documents(ad):
    rep = ad.leakage_report(ad.PAIRS, ad.load_sets())
    assert rep["problems"] == []
    held = {"Tour-Guide-Regulations-Ar-V012.pdf", "Tourist-Visa-Regulations-Ar-V012.pdf"}
    assert not held & set(rep["training_documents"])
    for name in ("generated (45, same LLM family as the pairs)", "hand-written (9)"):
        s = rep["sets"][name]
        assert s["answerable_questions"] == s["all_gold_docs_held_out"] > 0 and s["excluded_because_gold_doc_was_in_training"] == 0
    for qs in rep["usable"].values():
        assert all(set(x["gold_docs"]) <= held for x in qs)


def test_compare_reports_paired_differences(ad):
    def res(h):
        return {"pipelines": {ad.PIPE: {"per_question": [{"id": f"q{i}", "hit": v, "mrr": v} for i, v in enumerate(h)]}}}
    out = ad.compare(res([0, 0, 0, 1, 0, 0]), res([1, 1, 0, 1, 1, 0]), {"set": [{"id": f"q{i}"} for i in range(6)]})
    r = out["set"]["hit"]
    assert (r["before"], r["after"], r["diff"]) == (0.167, 0.667, 0.5) and r["ci"][0] > 0
    assert out["all held-out questions pooled"]["n"] == 6
    md = ad.markdown({"timestamp": "t", "adapter": "a", "leakage": {"x": 1}, "results": out})
    assert "after minus before" in md and "neutral or negative" in md


# ------------------------------------------------------------------ the one-shot blind test (docs/ANALYSIS_PLAN.md, P5)
@pytest.fixture
def blind_env(ad, tmp_path, monkeypatch):
    """A fake project root with a frozen blind PDF set and a stub verify script."""
    (tmp_path / "eval" / "blind_test").mkdir(parents=True)
    (tmp_path / "scripts").mkdir()
    (tmp_path / "scripts" / "make_blind_test.py").write_text("import sys\nprint('ok')\nsys.exit(0)\n", encoding="utf-8")
    (tmp_path / "eval" / "blind_test" / "FROZEN.json").write_text("{}", encoding="utf-8")
    monkeypatch.setattr(ad, "ROOT", tmp_path)
    monkeypatch.setattr(ad, "BLIND_PDF", tmp_path / "eval" / "questions_final_test_pdf.json")
    return tmp_path


def write_blind(env, qs):
    (env / "eval" / "questions_final_test_pdf.json").write_text(json.dumps(qs, ensure_ascii=False), encoding="utf-8")


def test_blind_sets_split_by_training_documents(ad, blind_env, tmp_path):
    p = pairs_file(tmp_path, [{"doc": "train.pdf", "query_raw": "سؤال التدريب الأول", "query": "q", "passage": "p"}])
    write_blind(blind_env, [q("b1", ["held.pdf"], "سؤال اول جديد"), q("b2", ["train.pdf"], "سؤال ثان جديد"), q("b3", ["train.pdf"], "سؤال ثالث جديد"),
                            {"id": "u1", "question": "غير مجاب", "gold_evidence": [], "gold_docs": []}])
    sets = ad.blind_sets(p)
    assert [x["id"] for x in sets["blind PDF, all documents (P5)"]] == ["b1", "b2", "b3"]          # unanswerable left out
    assert [x["id"] for x in sets["blind PDF, documents held out of training (generalisation)"]] == ["b1"]
    assert [x["id"] for x in sets["blind PDF, documents in the training pairs (known corpus)"]] == ["b2", "b3"]


def test_blind_sets_is_empty_when_nothing_is_frozen(ad, tmp_path, monkeypatch):
    monkeypatch.setattr(ad, "ROOT", tmp_path)
    monkeypatch.setattr(ad, "BLIND_PDF", tmp_path / "none.json")
    assert ad.blind_sets(pairs_file(tmp_path, [{"doc": "t.pdf", "query_raw": "x", "query": "x", "passage": "p"}])) == {}


def test_blind_question_equal_to_a_training_query_is_refused(ad, blind_env, tmp_path):
    p = pairs_file(tmp_path, [{"doc": "train.pdf", "query_raw": "ما مدة الترخيص؟", "query": "x", "passage": "p"}])
    write_blind(blind_env, [q("b1", ["held.pdf"], "ما مدة الترخيص؟")])
    with pytest.raises(RuntimeError, match="equal to training queries"):
        ad.blind_sets(p)


def test_a_changed_frozen_set_is_refused(ad, blind_env, tmp_path):
    (blind_env / "scripts" / "make_blind_test.py").write_text("import sys\nprint('CHANGED')\nsys.exit(1)\n", encoding="utf-8")
    write_blind(blind_env, [q("b1", ["held.pdf"], "سؤال")])
    with pytest.raises(RuntimeError, match="changed after it was frozen"):
        ad.blind_sets(pairs_file(tmp_path, [{"doc": "t.pdf", "query_raw": "x", "query": "x", "passage": "p"}]))


def test_markdown_for_the_blind_run_states_the_rule(ad):
    rep = {"timestamp": "t", "adapter": "a", "leakage": {}, "training": {}, "results": {"blind PDF, all documents (P5)": {"n": 3, "hit": {"before": 0.5, "after": 0.7, "diff": 0.2, "ci": [0.0, 0.4]},
                                                                                       "mrr": {"before": 0.4, "after": 0.5, "diff": 0.1, "ci": [-0.1, 0.3]}}}}
    md = ad.markdown(rep, title="Adaptation on the frozen blind set (P5, used once)", guide=False)
    assert "Blind set, used once" in md and "lower bound of the all-documents row is above 0" in md and "Reading guide" not in md
