"""Blind test set tooling: row checks, quotas, freezing and verification. Synthetic documents: no corpus, no models."""
import importlib.util
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture(scope="module")
def mod():
    spec = importlib.util.spec_from_file_location("make_blind_test", ROOT / "scripts" / "make_blind_test.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


DOC = "Tour-Guide-Regulations-Ar-V012.pdf"
OTHER = "Hospitality-Facilities-Regulations-Ar-V012.pdf"
WEBDOC = "faq/نظام السياحة"
TEXT = "يشترط في المرشد السياحي ألا يقل عمره عن ثمانية عشر عامًا وأن يكون حسن السيرة"
GENERIC = "تكون مدة سريان الترخيص ثلاث سنوات"


@pytest.fixture
def index(mod):
    idx = mod.Index.__new__(mod.Index)
    idx.docs = {"pdf": [DOC, OTHER], "web": [WEBDOC]}

    def chunks(texts):
        return {arm: [(d, p, mod.canon(t)) for d, p, t in texts] for arm in mod.ARMS}
    idx.chunks = {"pdf": chunks([(DOC, 8, TEXT), (DOC, 9, GENERIC), (OTHER, 3, GENERIC)]),
                  "web": chunks([(WEBDOC, 6, "أصدرت الوزارة لائحة التفتيش على الأنشطة السياحية لمراقبة الالتزام")])}
    return idx


def row(**kw):
    base = dict(author="A", corpus="pdf", question="ما أقل عمر يقبل لمن يريد العمل مرشدا سياحيا مرخصا؟", answerable="yes", source_doc="Tour-Guide",
                source_page="8", evidence_phrase="ألا يقل عمره عن ثمانية", alt_phrase="", answer_keywords="18|ثمانية عشر",
                reference_answer="ثمانية عشر عاما", type="number", notes="")
    base.update(kw)
    return base


def check(mod, index, rows, monkeypatch, dev=()):
    monkeypatch.setattr(mod, "dev_questions", lambda: list(dev))
    return mod.check_rows(rows, index, "t.csv")


def test_parse_keywords(mod):
    assert mod.parse_keywords("3|ثلاث;سنوات") == [["3", "ثلاث"], "سنوات"] and mod.parse_keywords("") == []


def test_a_good_row_becomes_a_question_with_gold_and_doc(mod, index, monkeypatch):
    qs, errs, warns = check(mod, index, [row()], monkeypatch)
    assert errs == [] and len(qs) == 1
    q = qs[0]
    assert q["gold_docs"] == [DOC] and q["gold_evidence"] == [["ألا يقل عمره عن ثمانية"]] and q["answer_keywords"] == [["18", "ثمانية عشر"]]


@pytest.mark.parametrize("kw, fragment", [
    (dict(corpus="xyz"), "corpus must be"),
    (dict(answerable="maybe"), "yes or no"),
    (dict(question="What is the minimum age?"), "full Arabic sentence"),
    (dict(source_doc="Nowhere"), "not a document"),
    (dict(source_doc="Regulations"), "matches 2 documents"),
    (dict(evidence_phrase="ألا يقل"), "at least 3 words"),
    (dict(evidence_phrase="عبارة غير موجودة في النص أبدا"), "not found"),
    (dict(evidence_phrase="مدة سريان الترخيص ثلاث", source_doc="Tour-Guide"), "occurs in 2 documents"),
    (dict(reference_answer=""), "reference_answer is required"),
])
def test_bad_rows_are_rejected_with_a_reason(mod, index, monkeypatch, kw, fragment):
    if "occurs in 2" in fragment:
        monkeypatch.setattr(mod, "MAX_DOCS", 1)                       # the tiny synthetic corpus has only two documents
    qs, errs, _ = check(mod, index, [row(**kw)], monkeypatch)
    assert qs == [] and any(fragment in e for e in errs), errs


def test_phrase_missing_in_one_arm_is_rejected_and_named(mod, index, monkeypatch):
    index.chunks["pdf"]["baseline"] = [(d, p, t.replace(mod.canon("ثمانية"), "")) for d, p, t in index.chunks["pdf"]["baseline"]]
    qs, errs, _ = check(mod, index, [row()], monkeypatch)
    assert qs == [] and "not inside one chunk of every arm" in errs[0] and "baseline" in errs[0]


def test_duplicates_and_development_overlap(mod, index, monkeypatch):
    dev = [{"id": "r2", "question": row()["question"], "set": "questions.json", "phrases": [mod.canon("ألا يقل عمره عن ثمانية")]}]
    qs, errs, _ = check(mod, index, [row()], monkeypatch, dev=dev)
    assert qs == [] and "identical to the development question r2" in errs[0]
    two = [row(), row()]
    assert "same question as" in check(mod, index, two, monkeypatch)[1][0]
    other = row(question="كم يجب أن يبلغ عمر المرشد السياحي المرخص حتى يقبل طلبه؟")
    qs, errs, warns = check(mod, index, [other], monkeypatch, dev=dev)
    assert len(qs) == 1 and any("gold phrase of the development question r2" in w for w in warns)


def test_unanswerable_rows(mod, index, monkeypatch):
    ok = row(answerable="no", source_doc="", source_page="", evidence_phrase="", answer_keywords="", type="unanswerable",
             question="هل تغطي اللوائح أسعار الفنادق في باريس خلال الصيف؟", reference_answer="")
    qs, errs, _ = check(mod, index, [ok], monkeypatch)
    assert errs == [] and qs[0]["gold_evidence"] == [] and qs[0]["gold_docs"] == [] and qs[0]["reference_answer"] == "غير مذكور في الوثائق."
    bad = dict(ok, source_doc=DOC)
    assert "no source_doc" in check(mod, index, [bad], monkeypatch)[1][0]


def test_warnings_for_a_phrase_that_repeats_the_question_or_the_wrong_page(mod, index, monkeypatch):
    qs, errs, warns = check(mod, index, [row(source_page="9", question="ما معنى ألا يقل عمره عن ثمانية عشر عاما للمرشد؟")], monkeypatch)
    assert errs == [] and any("not on page 9" in w for w in warns) and any("repeats the question" in w for w in warns)


def make_questions(mod, per_author=15):
    qs = []
    for a in "ABC":
        for i in range(per_author):
            ans = i >= 2
            qs.append({"corpus": "pdf" if i % 2 == 0 else "web", "author": a, "type": "number" if i % 4 == 0 else "direct",
                       "question": f"سؤال {a} {i}", "gold_evidence": [["x y z"]] if ans else [], "gold_docs": [DOC] if ans else [],
                       "answer_keywords": [], "reference_answer": "r", "needs_review": False})
    return qs


def test_quotas(mod):
    assert mod.quota_problems(make_questions(mod)) == []
    few = make_questions(mod, per_author=10)
    probs = mod.quota_problems(few)
    assert any("need at least 15" in p for p in probs) and any("in total" in p for p in probs)
    assert any("questions from 2 author" in p for p in mod.quota_problems([q for q in make_questions(mod) if q["author"] != "C"]))


def test_freeze_verify_and_refuse_to_refreeze(mod, tmp_path, monkeypatch):
    from src import corpus
    (tmp_path / "eval").mkdir()
    out = {"pdf": tmp_path / "eval" / "questions_final_test_pdf.json", "web": tmp_path / "eval" / "questions_final_test_web.json"}
    monkeypatch.setattr(mod, "OUT", out)
    monkeypatch.setattr(mod, "FROZEN", tmp_path / "FROZEN.json")
    monkeypatch.setattr(mod, "BLIND_DIR", tmp_path)
    monkeypatch.setattr(mod, "ROOT", tmp_path)
    monkeypatch.setattr(corpus, "corpus_fingerprint", lambda *a, **k: "fp")
    assert mod.verify() == ["not frozen yet: run --build"]
    meta = mod.freeze(make_questions(mod))
    assert sum(f["questions"] for f in meta["files"].values()) == 45 and meta["corpus_fingerprints"] == {"pdf": "fp", "web": "fp"}
    qs = json.loads(out["pdf"].read_text(encoding="utf-8"))
    assert qs[0]["id"] == "blind-pdf-001" and "corpus" not in qs[0] and qs[0]["author"] == "A"
    assert mod.verify() == []
    out["pdf"].write_text("[]", encoding="utf-8")                      # someone edits the frozen file
    assert "has changed" in mod.verify()[0]
    with pytest.raises(SystemExit, match="already frozen"):
        mod.freeze(make_questions(mod))
    assert mod.freeze(make_questions(mod), force=True)["files"]


def test_build_refuses_unmet_quotas_unless_skipped_and_records_the_skip(mod, tmp_path, monkeypatch):
    from src import corpus
    (tmp_path / "eval").mkdir()
    monkeypatch.setattr(mod, "OUT", {k: tmp_path / "eval" / f"questions_final_test_{k}.json" for k in ("pdf", "web")})
    monkeypatch.setattr(mod, "FROZEN", tmp_path / "FROZEN.json")
    monkeypatch.setattr(mod, "BLIND_DIR", tmp_path)
    monkeypatch.setattr(mod, "ROOT", tmp_path)
    monkeypatch.setattr(corpus, "corpus_fingerprint", lambda *a, **k: "fp")
    few = make_questions(mod, per_author=10)
    monkeypatch.setattr(mod, "Index", lambda: None)
    monkeypatch.setattr(mod, "check_rows", lambda rows, index, source: (few, [], []))
    monkeypatch.setattr(mod, "read_csv", lambda path: [{}])
    (tmp_path / "joint.csv").write_text("x", encoding="utf-8")
    monkeypatch.setattr(sys, "argv", ["make_blind_test.py", "--build"])
    assert mod.main() == 1 and not (tmp_path / "FROZEN.json").exists()          # quotas unmet: refused
    monkeypatch.setattr(sys, "argv", ["make_blind_test.py", "--build", "--skip-quota"])
    assert mod.main() == 0
    meta = json.loads((tmp_path / "FROZEN.json").read_text(encoding="utf-8"))
    assert any("need at least 15" in p for p in meta["quota_skipped"]) and mod.verify() == []
    monkeypatch.setattr(mod, "check_rows", lambda rows, index, source: (few, ["t.csv line 2: bad phrase"], []))
    (tmp_path / "FROZEN.json").unlink()
    assert mod.main() == 1 and not (tmp_path / "FROZEN.json").exists()          # a row error still blocks, even with --skip-quota


def test_template_and_examples_are_valid_csv_with_the_expected_columns(mod):
    for name in ("template.csv", "examples.csv"):
        header = (ROOT / "eval" / "blind_test" / name).read_text(encoding="utf-8-sig").splitlines()[0].split(",")
        assert header == mod.COLUMNS
    assert len(mod.read_csv(ROOT / "eval" / "blind_test" / "examples.csv")) == 3
