"""Keep tests from writing to the real logs/ folder: every test gets its own monitoring log."""
import os

# A test must never download a model: with these flags an accidental call to a real embedder fails fast instead of fetching gigabytes.
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
# The developer's .env must not change what the tests run: a reranker or adapter configured there would make tests load real models.
# (python-dotenv never overrides a variable that is already set, so these win over .env.)
os.environ.setdefault("MIZAN_RERANKER", "")
os.environ.setdefault("MIZAN_EMBEDDING_ADAPTER", "")

import pytest  # noqa: E402


@pytest.fixture(autouse=True)
def _isolated_monitoring_log(tmp_path, monkeypatch):
    from src import monitoring
    monkeypatch.setenv("MIZAN_MONITOR_LOG", str(tmp_path / "queries.jsonl"))
    monitoring.reset_monitor()
    yield
    monitoring.reset_monitor()
