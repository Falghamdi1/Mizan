"""Gold-phrase survival (scripts/gold_survival.py): hand-worked cases with synthetic pages. No models, no real corpora."""
import importlib.util
from pathlib import Path

import pytest

from src.ingestion import Page

ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture(scope="module")
def gs():
    spec = importlib.util.spec_from_file_location("gold_survival", ROOT / "scripts" / "gold_survival.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def pages(text, repaired=""):
    return [Page(doc="a.pdf", title="a", page=1, text=text, text_repaired=repaired)]


def q(*groups, docs=None, qid="q1"):
    d = {"id": qid, "question": "?", "gold_evidence": [list(g) for g in groups]}
    if docs:
        d["gold_docs"] = docs
    return d


def run(gs, pipeline, text, question, repaired=""):
    return gs.survival([question], gs.build_chunks(pages(text, repaired), pipeline))[question["id"]]


def test_kashida_breaks_strict_but_not_canonical_and_lite_repairs_it(gs):
    text = "مدة الترخيص ثــلاث ســنوات قابلة للتجديد"           # kashida inside two words
    question = q(["ثلاث سنوات"])
    base = run(gs, "baseline", text, question)
    lite = run(gs, "mizan-lite+repair_lam_alef", text, question)
    assert base == {"strict_any": 0.0, "strict_cov": 0.0, "canon_any": 1.0, "canon_cov": 1.0}
    assert lite == {"strict_any": 1.0, "strict_cov": 1.0, "canon_any": 1.0, "canon_cov": 1.0}


def test_lam_alef_repair_uses_the_repaired_text_only_in_the_repairing_pipeline(gs):
    damaged, repaired = "مدة الترخيص ثالث سنوات", "مدة الترخيص ثلاث سنوات"
    question = q(["ثلاث سنوات"])
    assert run(gs, "baseline", damaged, question, repaired)["strict_any"] == 0.0
    assert run(gs, "mizan-lite+repair_lam_alef", damaged, question, repaired)["strict_any"] == 1.0
    assert run(gs, "mizan-lite", damaged, question, repaired)["strict_any"] == 0.0     # no repair flag: raw text


def test_coverage_counts_evidence_groups_and_any_needs_one(gs):
    text = "الرسوم ألف ريال. المدة ثلاث سنوات"
    r = run(gs, "baseline", text, q(["ألف ريال"], ["خمس سنوات"]))
    assert r["strict_any"] == 1.0 and r["strict_cov"] == 0.5 and r["canon_cov"] == 0.5


def test_alternative_phrases_in_one_group_count_once(gs):
    r = run(gs, "baseline", "المدة سنتان", q(["ثلاث سنوات", "سنتان"]))
    assert r["strict_cov"] == 1.0


def test_gold_docs_restrict_where_evidence_may_be_found(gs):
    text = "الرسوم ألف ريال"
    assert run(gs, "baseline", text, q(["ألف ريال"], docs=["a.pdf"]))["strict_any"] == 1.0
    assert run(gs, "baseline", text, q(["ألف ريال"], docs=["other.pdf"]))["strict_any"] == 0.0


def test_unanswerable_questions_are_left_out(gs):
    chunks = gs.build_chunks(pages("نص"), "baseline")
    assert gs.survival([{"id": "u", "question": "?", "gold_evidence": []}], chunks) == {}


def test_strict_is_not_a_quality_measure_it_also_drops_when_a_pipeline_normalises_the_gold_surface_form(gs):
    """Caveat recorded in the script docstring: a gold phrase copied from raw text with Arabic-Indic digits is verbatim in the raw
    index and not in a digit-normalising one, although retrieval is unaffected (canonical stays 1.0)."""
    text = "الغرامة ١٠٠٠ ريال"
    question = q(["١٠٠٠ ريال"])
    base = run(gs, "baseline", text, question)
    lite = run(gs, "mizan-lite+repair_lam_alef", text, question)
    assert base["strict_any"] == 1.0 and lite["strict_any"] == 0.0 and lite["canon_any"] == 1.0


def test_summary_reports_paired_difference_to_the_first_pipeline(gs):
    per = {"base": {f"q{i}": {"strict_any": 0.0, "strict_cov": 0.0, "canon_any": 1.0, "canon_cov": 1.0} for i in range(20)},
           "new": {f"q{i}": {"strict_any": 1.0, "strict_cov": 1.0, "canon_any": 1.0, "canon_cov": 1.0} for i in range(20)}}
    rows = gs.summarize(per)
    assert rows["base"]["strict_any"] == 0.0 and rows["new"]["strict_any"] == 1.0
    d = rows["new"]["strict_any_diff"]
    assert d["mean"] == 1.0 and d["low"] == 1.0 and d["n"] == 20
    assert rows["new"]["canon_any_diff"]["mean"] == 0.0 and "strict_any_diff" not in rows["base"]
