"""Both Colab notebooks write the project's modules to disk from their own cells. A module that imports a file the notebook does not write
works here and crashes on Colab: this test finds that class of bug (it caught `safety`, `corpus` and an empty `__init__`)."""
import ast
import importlib.util
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
# The three older notebooks embed the team's question files, which are not in the public repository: their builders need those files,
# so these tests run only where the files are (the team's machines) and are skipped in a public clone.
PRIVATE = pytest.mark.skipif(not (ROOT / "eval" / "questions.json").exists(), reason="team-only question files not present (public clone)")


# Imports that sit inside functions the web-evaluation notebook never calls (the Gradio helpers of src/colab.py), so it does not write those files.
LAZY_UI_ONLY = {("build_web_notebook", "src/colab.py"): {"src/ui.py", "src/ui_theme.py", "src/ui_style.py", "src/i18n.py", "src/backend.py"}}


def builder(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / "scripts" / f"{name}.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def imported_project_files(path: Path) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    found = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            if node.level == 1 and path.parent.name == "src":              # from . import x / from .x import y
                if node.module:
                    found.add(f"src/{node.module.split('.')[0]}.py")
                else:
                    found |= {f"src/{a.name}.py" for a in node.names}
            elif node.level == 0 and node.module and node.module.split(".")[0] in ("src", "finetune"):   # from src.x import y
                parts = node.module.split(".")
                found.add("/".join(parts) + ".py" if len(parts) > 1 else f"{parts[0]}/__init__.py")
                if len(parts) == 1:                                           # from src import x, y
                    found |= {f"{parts[0]}/{a.name}.py" for a in node.names if (ROOT / parts[0] / f"{a.name}.py").exists()}
    return {f for f in found if (ROOT / f).exists()}


@PRIVATE
@pytest.mark.parametrize("name", ["build_notebook", "build_web_notebook", "build_final_notebook"])
def test_every_module_a_notebook_needs_is_written_by_the_notebook(name):
    mod = builder(name)
    written = {p for p, _ in mod.MODULES} | {"src/__init__.py"}
    missing = {}
    for rel in sorted(p for p, _ in mod.MODULES if p.endswith(".py")):
        # imports inside functions are included (ast.walk), because Colab executes them too
        need = imported_project_files(ROOT / rel) - written - LAZY_UI_ONLY.get((name, rel), set())
        if need:
            missing[rel] = sorted(need)
    assert missing == {}, missing


@PRIVATE
@pytest.mark.parametrize("name", ["build_notebook", "build_web_notebook", "build_final_notebook"])
def test_no_empty_file_is_written_with_an_empty_body(name):
    mod = builder(name)
    for rel, _ in mod.MODULES:
        assert (ROOT / rel).exists(), rel


@pytest.mark.skipif(not (ROOT / "Mizan_Final_Colab.ipynb").exists(), reason="generated notebook not present (public clone)")
def test_final_notebook_code_cells_are_valid_python_and_every_step_has_a_switch():
    """The final notebook can only be run once on the frozen blind set, so it must not contain a typo. Cell magics are stripped before parsing."""
    import json

    nb = json.loads((ROOT / "Mizan_Final_Colab.ipynb").read_text(encoding="utf-8"))
    for i, c in enumerate(nb["cells"]):
        if c["cell_type"] != "code":
            continue
        src = "".join(c["source"])
        if src.startswith("%%writefile"):
            continue
        body = "\n".join(line for line in src.splitlines() if not line.lstrip().startswith(("%", "!")))
        ast.parse(body, filename=f"final-notebook cell {i}")
    text = "\n".join("".join(c["source"]) for c in nb["cells"])
    for switch in ("RUN_ADAPTATION", "RUN_RETRIEVAL", "RUN_ANSWERS", "BLIND_OK", 'PROMPT = "v1"'):
        assert switch in text, switch
    assert '"scripts/make_blind_test.py", "--verify"' in text            # the freeze is verified before any blind result is produced
