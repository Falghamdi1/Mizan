"""Third-person adjudication: the sheet is blind and in the grading form's format, and merge maps the form's export back. Synthetic data."""
import csv
import importlib.util
import json
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


@pytest.fixture(scope="module")
def hg():
    return module("human_grading", ROOT / "scripts" / "human_grading.py")


@pytest.fixture(scope="module")
def adj():
    return module("prepare_adjudication", ROOT / "scripts" / "prepare_adjudication.py")


REFUSAL = "لا يحتوي السياق المتاح على إجابة هذا السؤال"


@pytest.fixture
def sheets(hg, tmp_path):
    """Two arms, 4 answerable + 2 unanswerable questions, graded by two graders with three disagreements and one empty cell."""
    pq = {arm: [{"id": f"q{i}", "question": f"سؤال {i}", "answerable": i < 4, "answer": (f"إجابة رقم {i} {k}" if i < 4 else REFUSAL),
                 "retrieved": [{"doc": "d.pdf", "page": i + 1}]} for i in range(6)] for k, arm in enumerate(("alpha", "beta"))}
    res = tmp_path / "res.json"
    res.write_text(json.dumps({"run": {}, "pipelines": {a: {"per_question": r} for a, r in pq.items()}}, ensure_ascii=False), encoding="utf-8")
    qf = tmp_path / "q.json"
    qf.write_text(json.dumps([{"id": f"q{i}", "question": f"سؤال {i}", "reference_answer": f"مرجع {i}"} for i in range(6)], ensure_ascii=False), encoding="utf-8")
    d = hg.make(res, ["alpha", "beta"], 4, 2, 0, tmp_path / "grading", str(qf))
    key = json.loads((d / "KEY.json").read_text(encoding="utf-8"))
    rows = list(csv.DictReader(open(d / "grader_1.csv", encoding="utf-8-sig")))
    g = {1: [dict(r) for r in rows], 2: [dict(r) for r in rows]}
    for n in (1, 2):
        for r in g[n]:
            for L in "AB":
                r[f"correct_{L} (0/1)"] = "1"
                r[f"supported_{L} (0/1, not for refusals)"] = "" if REFUSAL in r[f"answer_{L}"] else "1"
            r["better (A, B or tie)"] = "tie"
    ans = [r for r in g[1] if key["rows"][r["id"]]["answerable"]]
    a, b, c = ans[0]["id"], ans[1]["id"], ans[2]["id"]
    row = lambda n, qid: next(r for r in g[n] if r["id"] == qid)
    row(2, a)["correct_A (0/1)"] = "0"                       # disagreement on correct
    row(2, b)["correct_B (0/1)"] = ""                        # one grader left a cell empty
    row(1, c)["better (A, B or tie)"], row(2, c)["better (A, B or tie)"] = "A", "B"     # pick disagreement
    paths = {}
    for n in (1, 2):
        paths[n] = tmp_path / f"g{n}.csv"
        with open(paths[n], "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0]))
            w.writeheader()
            w.writerows(g[n])
    return d, key, paths, (a, b, c)


def test_only_disputed_or_empty_cells_go_to_the_adjudicator_and_the_sheet_is_blind(adj, sheets):
    d, key, paths, (a, b, c) = sheets
    sheet, key_rows, cells, arms = adj.build({"x": (d / "KEY.json", paths[1], paths[2])}, seed=1)
    assert sorted((x["item_id"], x["endpoint"], x["type"]) for x in cells) == sorted([(a, "correct", "g1=1,g2=0"), (b, "correct", "g2_empty"),
                                                                                       (c, "pairwise_pick", "g1=A,g2=B")])
    assert len(sheet) == 3 and all(r["id"].startswith("adj-") for r in sheet)
    assert list(sheet[0])[:3] == ["id", "question", "reference_answer"] and "correct_A (0/1)" in sheet[0]   # the grading form's columns
    assert all(r[k] == "" for r in sheet for k in r if k.startswith(("correct_", "supported_", "better")))  # nothing pre-filled
    assert adj.leaks(sheet, arms["x"]) == []
    assert {k["item_id"] for k in key_rows} == {a, b, c} and set(adj.KEY_COLUMNS) == set(key_rows[0])
    leaky = [dict(r) for r in sheet]
    leaky[0]["answer_B"] += " (beta)"
    leaky[1]["sources_A"] = "results/final_blind/x"
    assert any("beta" in m for m in adj.leaks(leaky, arms["x"])) and any("results/" in m for m in adj.leaks(leaky, arms["x"]))


def test_merge_maps_the_forms_export_back_through_the_key(adj, hg, sheets, tmp_path):
    d, key, paths, (a, b, c) = sheets
    sheet, key_rows, _, _ = adj.build({"x": (d / "KEY.json", paths[1], paths[2])}, seed=1)
    inp, keyp = adj.write(sheet, key_rows, tmp_path / "adjudication")
    arm_of = {k["adjudication_id"]: {"A": k["true_pipeline_A"], "B": k["true_pipeline_B"]} for k in key_rows}
    out = list(csv.DictReader(open(inp, encoding="utf-8-sig")))
    for r in out:                                            # the adjudicator: alpha's answers right, beta's wrong, alpha better
        for L in "AB":
            r[f"correct_{L} (0/1)"] = "1" if arm_of[r["id"]][L] == "alpha" else "0"
        r["better (A, B or tie)"] = next(L for L in "AB" if arm_of[r["id"]][L] == "alpha")
    outp = tmp_path / "adjudication" / "p3_adjudication_output.csv"
    with open(outp, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(out[0]))
        w.writeheader()
        w.writerows(out)
    before = hg.merge(d, paths[1], paths[2])
    assert before["unresolved_disagreements"] == 1 and before["incomplete_cells"] == 1
    rep = hg.merge(d, paths[1], paths[2], outp, keyp)
    assert rep["problems"] == [] and rep["unresolved_disagreements"] == 0 and rep["incomplete_cells"] == 0
    assert rep["adjudicated_cells_used"] == 2
    arm_a = key["rows"][a]["map"]["A"]["arm"]                # the disputed cell takes the adjudicator's value for that arm
    assert rep["per_arm"][arm_a]["answerable_graded"] == 4
    assert rep["preference"]["wins"]["alpha"] == 1 and rep["preference"]["undecided"] == 0
    assert "Cells decided by the adjudicator: 2" in (d / "human_grading_report.md").read_text(encoding="utf-8")
