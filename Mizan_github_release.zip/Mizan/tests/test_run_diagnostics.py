"""scripts/run_diagnostics.py on small synthetic result files. No model."""
import importlib.util
import json
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture(scope="module")
def rd():
    spec = importlib.util.spec_from_file_location("run_diagnostics", ROOT / "scripts" / "run_diagnostics.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def arm(hit, tokens, chunks, lat, qids=("a", "b", "c", "d")):
    return {"index": {"chunks": chunks, "chars": chunks * 100, "tokens": tokens},
            "aggregate": {"hit": sum(hit) / len(hit), "mrr": 0.5, "retrieved_tokens": 100},
            "per_question": [{"id": q, "hit": h, "candidate_recall": h, "first_stage_hit": h, "retrieval_latency_s": lat + 0.0 * i}
                             for i, (q, h) in enumerate(zip(qids, hit))]}


def write(path, base, lite, corpus="x"):
    path.write_text(json.dumps({"run": {"corpus_sha256": corpus},
                                "pipelines": {"baseline": base, "mizan-lite+repair_lam_alef": lite}}), encoding="utf-8")


def test_pct_and_percentile(rd):
    assert rd.pct(60, 100) == "-40.0%" and rd.pct(1, 0) == "n/a"
    assert rd.percentile([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 0.95) == 10 and rd.percentile([], 0.5) != rd.percentile([], 0.5)   # nan


def test_index_cost_pool_latency_and_pairing(rd, tmp_path):
    f = tmp_path / "lite-e5-small-pdf.json"
    write(f, arm([0, 0, 1, 0], 1000, 100, 1.0), arm([1, 1, 1, 0], 600, 90, 0.8))
    cost = rd.index_cost([f])[0]
    assert (cost["tokens"], cost["tokens_base"], cost["chunks"], cost["chunks_base"]) == (600, 1000, 90, 100)
    pool = {r["metric"]: r for r in rd.pool([f])}
    assert pool["hit"]["standard"] == 0.25 and pool["hit"]["arm"] == 0.75 and pool["hit"]["diff"] == 0.5 and pool["hit"]["n"] == 4
    lat = rd.latency_paired([f])[0]
    assert lat["n"] == 3 and lat["standard_mean"] == pytest.approx(1.0) and lat["arm_mean"] == pytest.approx(0.8) and lat["diff"] == pytest.approx(-0.2)
    assert rd.latency([f])[0]["median"] == 1.0


def test_reproduce_flags_identical_and_different_values_and_corpus(rd, tmp_path):
    now, then, other = tmp_path / "now", tmp_path / "then", tmp_path / "other"
    for d in (now, then, other):
        d.mkdir()
    base, lite = arm([0, 1, 1, 0], 100, 10, 1.0), arm([1, 1, 1, 0], 90, 9, 1.0)
    write(now / "lite-e5-small-pdf.json", base, lite, corpus="same")
    write(then / "lite-e5-small-pdf.json", base, lite, corpus="same")
    changed = arm([0, 1, 0, 0], 100, 10, 1.0)
    write(other / "lite-e5-small-pdf.json", changed, lite, corpus="different")
    same = rd.reproduce(now, [then])
    assert same and all(r["identical"] and r["same_corpus"] for r in same)
    diff = rd.reproduce(now, [other])
    assert any(not r["identical"] and not r["same_corpus"] for r in diff)       # differs, but on another corpus: not comparable


def test_step_tally_reads_the_bootstrap_labels(rd, tmp_path):
    (tmp_path / "ablations-pdf.md").write_text(
        "Retrieval-only ablations, 77 answerable questions, paired bootstrap vs `baseline` (n.d. = interval includes zero).\n\n"
        "| variant | chunks | retrieved tokens | hit@k | Δhit [95% CI] | MRR | ΔMRR [95% CI] |\n|---|---|---|---|---|---|---|\n"
        "| `baseline` | 358 | 1021 | 0.623 | reference | 0.439 | reference |\n"
        "| `baseline+a` | 358 | 1000 | 0.60 | -0.05 [-0.10, -0.01] lower | 0.4 | +0.0 [-0.1, 0.1] n.d. |\n"
        "| `baseline+b` | 358 | 1000 | 0.70 | +0.08 [+0.01, +0.15] higher | 0.5 | +0.0 [-0.1, 0.1] n.d. |\n"
        "| `baseline+c` | 358 | 1000 | 0.62 | +0.00 [-0.04, +0.04] n.d. | 0.4 | +0.0 [-0.1, 0.1] n.d. |\n", encoding="utf-8")
    t = rd.step_tally(tmp_path)[0]
    assert (t["reference"], t["variants"], t["higher"], t["lower"], t["n.d."]) == ("baseline", 3, 1, 1, 1)
    assert t["steps"]["lower"][0][0] == "baseline+a" and t["steps"]["higher"][0][0] == "baseline+b"
