"""Citation check: parsing and matching (src/citations.py) and how the evaluation scores it (src/evaluation.py)."""
from types import SimpleNamespace

import pytest

from src import citations
from src.evaluation import aggregate, render_markdown, score

DOC_A = "Tour-Guide-Regulations-Ar-V012.pdf"
DOC_B = "Tourist-Visa-Regulations-Ar-V012.pdf"
REFUSAL = "لا يحتوي السياق المتاح على إجابة هذا السؤال"


def psg(doc, page, text="نص", rank=1):
    return SimpleNamespace(doc=doc, page=page, text=text, rank=rank, tokens=10, score=0.5, first_stage_rank=rank, rerank_score=None)


def result(answer, passages):
    llm = SimpleNamespace(input_tokens=100, output_tokens=20, latency_s=1.0, cached=False)
    return SimpleNamespace(pipeline="p", question="س", passages=passages, answer=answer, retrieval_latency_s=0.1, llm=llm,
                           retrieved_tokens=30, total_latency_s=1.1, meta={})


def test_parse_accepts_arabic_and_latin_forms():
    a = "أ [ملف-1، صفحة 8] ب [file-2, page 3] ج [file-3، ص ٤] د [file-4 ، صفحه 5]"
    assert citations.parse(a) == [("ملف-1", 8), ("file-2", 3), ("file-3", 4), ("file-4", 5)]
    assert citations.parse("لا توجد مصادر [1] و (صفحة 3)") == []
    assert citations.parse(None) == []


def test_check_matches_file_and_page_not_just_the_file():
    ps = [psg(DOC_A, 8), psg(DOC_A, 9), psg(DOC_B, 2)]
    c = citations.check(f"[{DOC_A}، صفحة 8] و [{DOC_B}، صفحة 2] و [{DOC_A}، صفحة 30] و [مستند وهمي، صفحة 2]", ps)
    assert (c["n_cited"], c["n_valid"], c["n_invalid"]) == (4, 2, 2) and c["matched"] == [0, 2]


def test_file_names_may_drop_the_extension_or_be_shortened_but_not_be_too_short():
    ps = [psg(DOC_A, 8)]
    assert citations.check("[Tour-Guide-Regulations-Ar-V012، صفحة 8]", ps)["n_valid"] == 1      # no extension
    assert citations.check("[Tour-Guide-Regulations، صفحة 8]", ps)["n_valid"] == 1             # shortened, long enough
    assert citations.check("[Tour، صفحة 8]", ps)["n_valid"] == 0                                # too short to trust
    web = [psg("news/2026-07-07/3385", 1), psg("law/tourism-law", 3)]
    assert citations.check("[news/2026-07-07/3385، صفحة 1] [tourism-law، صفحة 3] [3386، صفحة 1]", web)["n_valid"] == 2


def test_two_chunks_of_the_same_page_are_both_matched():
    ps = [psg(DOC_A, 8), psg(DOC_A, 8), psg(DOC_B, 2)]
    assert citations.check(f"[{DOC_A}، صفحة 8]", ps)["matched"] == [0, 1]


Q = {"id": "q1", "question": "س", "gold_evidence": [["مدة الترخيص ثلاث سنوات"]], "gold_docs": [DOC_A]}
GOLD = psg(DOC_A, 8, "تكون مدة الترخيص ثلاث سنوات من تاريخ الإصدار", 1)
OTHER = psg(DOC_A, 9, "أحكام عامة لا علاقة لها", 2)
WRONG_DOC = psg(DOC_B, 2, "مدة الترخيص ثلاث سنوات", 3)          # right words in a document that cannot be relevant (gold_docs)


@pytest.mark.parametrize("answer, expect", [
    (f"المدة ثلاث سنوات [{DOC_A}، صفحة 8].", dict(citation_present=1, invalid_citation=0, citation_valid_share=1.0, cites_gold=1)),
    (f"المدة ثلاث سنوات [{DOC_A}، صفحة 9].", dict(citation_present=1, invalid_citation=0, citation_valid_share=1.0, cites_gold=0)),   # real page, wrong passage
    (f"المدة ثلاث سنوات [{DOC_B}، صفحة 2].", dict(citation_present=1, invalid_citation=0, citation_valid_share=1.0, cites_gold=0)),   # cites a passage from a non-gold doc
    (f"المدة ثلاث سنوات [{DOC_A}، صفحة 40].", dict(citation_present=1, invalid_citation=1, citation_valid_share=0.0, cites_gold=0)),  # fabricated page
    (f"[{DOC_A}، صفحة 8] [{DOC_A}، صفحة 40]", dict(citation_present=1, invalid_citation=1, citation_valid_share=0.5, cites_gold=1)),
    ("المدة ثلاث سنوات", dict(citation_present=0, invalid_citation=0, citation_valid_share=None, cites_gold=0)),                      # no marker at all
])
def test_score_citation_fields(answer, expect):
    s = score(Q, result(answer, [GOLD, OTHER, WRONG_DOC]))
    for k, v in expect.items():
        assert s[k] == v, (k, s[k], v)


def test_refusals_and_retrieval_only_runs_are_not_scored_for_citations():
    for ans in (REFUSAL, "", "   "):
        s = score(Q, result(ans, [GOLD]))
        assert s["citation_present"] is None and s["cites_gold"] is None and s["invalid_citation"] is None


def test_unanswerable_question_gets_citation_fields_but_no_gold_comparison():
    q = {"id": "u1", "question": "س", "gold_evidence": []}
    s = score(q, result(f"جواب [{DOC_A}، صفحة 8]", [GOLD]))
    assert s["citation_present"] == 1 and s["cites_gold"] is None


def test_aggregate_and_report_include_citation_rows_and_survive_old_result_files():
    rows = []
    for i, (ans, ps) in enumerate([(f"[{DOC_A}، صفحة 8]", [GOLD]), (f"[{DOC_A}، صفحة 9]", [GOLD, OTHER]), ("بلا مصدر", [GOLD]),
                                   (f"[{DOC_A}، صفحة 40]", [GOLD]), (REFUSAL, [GOLD])]):
        s = score(Q, result(ans, ps))
        s.update(id=f"q{i}", answerable=True)
        rows.append(s)
    a = aggregate(rows)
    assert a["n_answers_checked_for_citation"] == 4                         # the refusal is excluded
    assert a["citation_present"] == 0.75 and a["invalid_citation"] == 0.25
    assert a["cites_gold"] == 0.25 and a["cites_gold_given_hit"] == 0.25   # 1 of 4 checked answers cites the gold passage; all 4 had it retrieved
    res = {"synthetic_data": False, "synthetic_questions": False, "settings": {"embedder": "st", "embedding_model": "m", "chunk_size": 600,
           "chunk_overlap": 100, "top_k": 4, "llm_provider": "ollama", "llm_model": "x"}, "judge": None, "run": {},
           "pipelines": {"baseline": {"aggregate": {**a, "n_questions": 5, "n_answerable": 5}, "index": {"chunks": 1, "chars": 1, "tokens": 1}}}}
    md = render_markdown(res)
    assert "Answers citing the passage with the gold evidence" in md
    old = {k: v for k, v in a.items() if not k.startswith(("cite", "citation", "invalid", "n_answers"))}
    res["pipelines"]["baseline"]["aggregate"] = {**old, "n_questions": 5, "n_answerable": 5}
    assert "n/a" in render_markdown(res)                                    # an older result file renders; the new rows say n/a
