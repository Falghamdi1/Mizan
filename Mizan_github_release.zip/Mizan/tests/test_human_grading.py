"""Human grading tool: blind sheets, label parsing, agreement, adjudication, per-arm results and judge validation. Synthetic data only."""
import csv
import importlib.util
import json
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture(scope="module")
def hg():
    spec = importlib.util.spec_from_file_location("human_grading", ROOT / "scripts" / "human_grading.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def eval_result(n_ans=6, n_unans=2):
    """Two pipelines; answers are distinguishable so blinding can be tested; judge says 'correct' for every answerable answer."""
    pq = {"alpha": [], "beta": []}
    for name in pq:
        for i in range(n_ans + n_unans):
            ans = i < n_ans
            pq[name].append({"id": f"q{i}", "question": f"سؤال {i}", "answerable": ans, "answer": f"إجابة {name} {i}" if ans else "لا يحتوي السياق المتاح على إجابة هذا السؤال",
                             "retrieved": [{"doc": "d.pdf", "page": i + 1}], "judge_correct": 1,                                  # a judge that approves everything, like the lenient one we met
                             "keyword_coverage": 1.0 if (ans and name == "alpha") else 0.0})
    return {"run": {"questions_file": "unused.json"}, "pipelines": {n: {"per_question": rows} for n, rows in pq.items()}}


@pytest.fixture
def questions(tmp_path):
    p = tmp_path / "q.json"
    p.write_text(json.dumps([{"id": f"q{i}", "question": f"سؤال {i}", "reference_answer": f"مرجع {i}"} for i in range(8)], ensure_ascii=False), encoding="utf-8")
    return str(p)


def write(tmp_path, result):
    p = tmp_path / "res.json"
    p.write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")
    return p


def make(hg, tmp_path, questions, **kw):
    out = tmp_path / "grading"
    hg.make(write(tmp_path, eval_result()), ["alpha", "beta"], kw.get("n", 6), kw.get("u", 2), kw.get("seed", 0), out, questions)
    return out


def read(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def fill(path, grades, out):
    """grades: {(qid, letter): (correct, supported)}; writes a graded copy of the sheet."""
    rows = read(path)
    for r in rows:
        for L in "AB":
            c, s = grades.get((r["id"], L), ("", ""))
            r[f"correct_{L} (0/1)"], r[f"supported_{L} (0/1, not for refusals)"] = str(c), str(s)
    with open(out, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    return out


def test_sheets_are_blind_identical_and_the_key_maps_back(hg, tmp_path, questions):
    out = make(hg, tmp_path, questions)
    g1, g2 = read(out / "grader_1.csv"), read(out / "grader_2.csv")
    assert g1 == g2 and len(g1) == 8
    text = (out / "grader_1.csv").read_text(encoding="utf-8-sig")
    assert all("alpha" not in c and "beta" not in c for c in g1[0])                                    # arm names are not in the header
    assert "KEY" not in text and "map" not in text
    key = json.loads((out / "KEY.json").read_text(encoding="utf-8"))
    for r in g1:
        for L in "AB":
            arm = key["rows"][r["id"]]["map"][L]["arm"]
            if key["rows"][r["id"]]["answerable"]:
                assert r[f"answer_{L}"] == f"إجابة {arm} {r['id'][1:]}"                                   # the key recovers which arm wrote which column
    orders = {tuple(key["rows"][i]["map"][L]["arm"] for L in "AB") for i in key["rows"]}
    assert len(orders) == 2                                                                              # the A/B order really varies between rows
    assert [r["reference_answer"] for r in g1][0].startswith("مرجع")


def test_make_is_deterministic_and_validates_its_inputs(hg, tmp_path, questions):
    a = make(hg, tmp_path, questions, seed=3)
    b = tmp_path / "again"
    hg.make(tmp_path / "res.json", ["alpha", "beta"], 6, 2, 3, b, questions)
    assert (a / "grader_1.csv").read_bytes() == (b / "grader_1.csv").read_bytes()
    with pytest.raises(SystemExit, match="not in the result file"):
        hg.make(tmp_path / "res.json", ["alpha", "nope"], 6, 2, 0, tmp_path / "x", questions)
    with pytest.raises(SystemExit, match="at least two"):
        hg.make(tmp_path / "res.json", ["alpha"], 6, 2, 0, tmp_path / "y", questions)
    empty = eval_result()
    for p in empty["pipelines"].values():
        for r in p["per_question"]:
            r["answer"] = ""
    with pytest.raises(SystemExit, match="retrieval-only"):
        hg.make(write(tmp_path, empty), ["alpha", "beta"], 6, 2, 0, tmp_path / "z", questions)


def test_prompt_version_result_files_work_too(hg, tmp_path, questions):
    res = {"versions": {v: {"rows": [{"id": f"q{i}", "answerable": i < 3, "answer": f"{v} جواب {i}", "keyword_coverage": 0.0} for i in range(4)]}
                        for v in ("v1", "v2", "v3")}}
    out = tmp_path / "pg"
    hg.make(write(tmp_path, res), ["v1", "v2", "v3"], 3, 1, 0, out, questions)
    rows = read(out / "grader_1.csv")
    assert len(rows) == 4 and "answer_C" in rows[0]


def test_kappa_and_label_parsing(hg):
    assert hg.kappa([1, 1, 0, 0], [1, 0, 0, 0]) == pytest.approx(0.5)
    assert hg.kappa([1, 1], [1, 1]) is None and hg.kappa([], []) is None
    assert [hg.parse_label(x) for x in ("1", " نعم", "Y", "0", "لا", "", "2")] == [1, 1, 1, 0, 0, None, None]


def test_merge_agreement_adjudication_and_per_arm_results(hg, tmp_path, questions):
    out = make(hg, tmp_path, questions)
    key = json.loads((out / "KEY.json").read_text(encoding="utf-8"))
    letter_of = lambda qid, arm: next(L for L, v in key["rows"][qid]["map"].items() if v["arm"] == arm)
    g1, g2 = {}, {}
    for qid, info in key["rows"].items():
        for arm, correct in (("alpha", 1), ("beta", 0)):                       # alpha is right on every answerable question, beta never
            L = letter_of(qid, arm)
            val = (correct if info["answerable"] else 1)
            g1[(qid, L)] = (val, "" if not info["answerable"] else 1)
            g2[(qid, L)] = (val, "" if not info["answerable"] else 1)
    # one disagreement: grader 2 gives alpha a 0 on q0
    L0 = letter_of("q0", "alpha")
    g2[("q0", L0)] = (0, 1)
    s1, s2 = fill(out / "grader_1.csv", g1, tmp_path / "g1.csv"), fill(out / "grader_2.csv", g2, tmp_path / "g2.csv")
    rep = hg.merge(out, s1, s2)
    assert rep["problems"] == [] and rep["unresolved_disagreements"] == 1 and len(rep["disagreements"]) == 1
    assert rep["agreement"]["correct"]["percent"] == pytest.approx(15 / 16) and 0 < rep["agreement"]["correct"]["kappa"] < 1
    assert rep["per_arm"]["alpha"]["answerable_graded"] == 5                    # q0 is unresolved and left out
    assert rep["per_arm"]["alpha"]["accuracy_answerable"] == 1.0 and rep["per_arm"]["beta"]["accuracy_answerable"] == 0.0
    assert rep["per_arm"]["alpha"]["correct_on_unanswerable"] == 1.0
    diff = rep["paired"]["beta - alpha: accuracy_answerable"]
    assert diff["diff"] == -1.0 and diff["hi"] < 0                              # beta clearly lower, paired over the 5 resolved questions
    # adjudication resolves it
    adj = fill(out / "grader_1.csv", {("q0", L0): (1, 1)}, tmp_path / "adj.csv")
    rep2 = hg.merge(out, s1, s2, adj)
    assert rep2["unresolved_disagreements"] == 0 and rep2["per_arm"]["alpha"]["answerable_graded"] == 6
    md = (out / "human_grading_report.md").read_text(encoding="utf-8")
    assert "Agreement between the graders" in md and "Disagreements to adjudicate" in md


def test_judge_and_keyword_scores_are_validated_against_the_human_labels(hg, tmp_path, questions):
    out = make(hg, tmp_path, questions)
    key = json.loads((out / "KEY.json").read_text(encoding="utf-8"))
    grades = {}
    for qid, info in key["rows"].items():
        for L, v in info["map"].items():
            grades[(qid, L)] = ((1 if v["arm"] == "alpha" else 0) if info["answerable"] else 1, "")
    s1, s2 = fill(out / "grader_1.csv", grades, tmp_path / "a.csv"), fill(out / "grader_2.csv", grades, tmp_path / "b.csv")
    rep = hg.merge(out, s1, s2)
    v = rep["validation_of_automatic_scores"]
    assert v["llm_judge"]["agreement"] == pytest.approx(10 / 16)                                       # approves beta's six wrong answers too
    assert v["keyword_coverage>=0.5"]["agreement"] == 1.0                                                   # the keyword score matches the humans here
    assert "must not be quoted as accuracy" in (out / "human_grading_report.md").read_text(encoding="utf-8")


def test_bad_cells_are_reported_not_silently_dropped(hg, tmp_path, questions):
    out = make(hg, tmp_path, questions)
    s = fill(out / "grader_1.csv", {("q0", "A"): ("maybe", "")}, tmp_path / "bad.csv")
    rep = hg.merge(out, s, s)
    assert any("'maybe' is not 0/1" in p for p in rep["problems"])
    assert rep["incomplete_cells"] > 0                                          # everything left empty is counted as incomplete


# ---- pick A or B ----------------------------------------------------------------------------------------
def _picks_sheet(hg, tmp_path, questions, who, key, picks):
    """Copy grader_1's sheet, fill the correctness cells with 1 and the pick column from picks {qid: 'arm name' | 'tie' | raw text}."""
    out = tmp_path / "grading"
    rows = read(out / "grader_1.csv")
    for r in rows:
        for L in "AB":
            r[f"correct_{L} (0/1)"] = "1"
        v = picks.get(r["id"], "")
        if v in ("alpha", "beta"):                       # pick by arm name: find the letter the key gave that arm
            v = next(L for L in "AB" if key["rows"][r["id"]]["map"][L]["arm"] == v)
        r[hg.PICK_COL] = v
    p = tmp_path / f"{who}.csv"
    with open(p, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    return p


def test_the_pick_column_exists_for_two_arms_only(hg, tmp_path, questions):
    out = make(hg, tmp_path, questions)
    assert hg.PICK_COL in read(out / "grader_1.csv")[0]
    res = {"versions": {v: {"rows": [{"id": f"q{i}", "answerable": True, "answer": f"{v} جواب {i}", "keyword_coverage": 0.0} for i in range(3)]} for v in ("v1", "v2", "v3")}}
    hg.make(write(tmp_path, res), ["v1", "v2", "v3"], 3, 0, 0, tmp_path / "three", questions)
    assert hg.PICK_COL not in read(tmp_path / "three" / "grader_1.csv")[0]


def test_picks_are_mapped_back_to_arms_counted_and_tested(hg, tmp_path, questions):
    out = make(hg, tmp_path, questions)
    key = json.loads((out / "KEY.json").read_text(encoding="utf-8"))
    ans_ids = [i for i, v in key["rows"].items() if v["answerable"]]
    picks = {i: "beta" for i in ans_ids[:5]} | {ans_ids[5]: "alpha"} | {i: "tie" for i, v in key["rows"].items() if not v["answerable"]}
    g1 = _picks_sheet(hg, tmp_path, questions, "g1", key, picks)
    g2 = _picks_sheet(hg, tmp_path, questions, "g2", key, picks | {ans_ids[0]: "alpha"})       # one disagreement
    rep = hg.merge(out, g1, g2)
    pr = rep["preference"]
    assert pr["undecided"] == 1 and pr["wins"] == {"alpha": 1, "beta": 4} and pr["ties"] == 2
    assert pr["grader_agreement"]["n"] == 8 and pr["grader_agreement"]["percent"] == 7 / 8
    adj = _picks_sheet(hg, tmp_path, questions, "adj", key, {ans_ids[0]: "beta"})
    rep = hg.merge(out, g1, g2, adj)["preference"]
    assert rep["wins"] == {"alpha": 1, "beta": 5} and rep["undecided"] == 0
    assert rep["sign_test_p"] == pytest.approx(0.21875)                                          # 2 * P(X <= 1), X ~ Bin(6, 0.5)
    assert "Which answer is better" in (out / "human_grading_report.md").read_text(encoding="utf-8")


def test_a_bad_pick_is_reported(hg, tmp_path, questions):
    out = make(hg, tmp_path, questions)
    key = json.loads((out / "KEY.json").read_text(encoding="utf-8"))
    g1 = _picks_sheet(hg, tmp_path, questions, "g1", key, {"q0": "maybe"})
    rep = hg.merge(out, g1, g1)
    assert any("not A, B or tie" in p for p in rep["problems"])


def test_sign_test_and_pick_parsing(hg):
    assert hg.sign_test(0, 0) is None and hg.sign_test(5, 0) == pytest.approx(0.0625) and hg.sign_test(3, 3) == 1.0
    assert [hg.parse_pick(v, "AB") for v in ("a", " B ", "TIE", "تعادل", "", "C", "AB")] == ["A", "B", "tie", "tie", None, None, None]
    assert hg.multi_kappa(["A", "B", "tie", "A"], ["A", "B", "tie", "A"]) == 1.0
