"""Metrics checked against small examples worked out by hand (so the definitions in the documents are what the code computes)."""
from types import SimpleNamespace

import pytest

from src.evaluation import aggregate, score
from src.stats import paired_bootstrap


def p(rank, text, doc="a.pdf", page=1, first_stage_rank=None):
    return SimpleNamespace(rank=rank, text=text, doc=doc, page=page, tokens=10, score=0.5, first_stage_rank=first_stage_rank or rank, rerank_score=None)


def result(passages, answer="", cands=None):
    llm = SimpleNamespace(input_tokens=100, output_tokens=10, latency_s=1.0, cached=False)
    return SimpleNamespace(passages=passages, answer=answer, meta={"candidates": cands or passages}, llm=llm, retrieved_tokens=sum(x.tokens for x in passages),
                           retrieval_latency_s=0.1, total_latency_s=1.1)


def test_hit_mrr_precision_and_coverage_by_hand():
    # top-4: ranks 1 and 4 contain the gold phrase; rank 2 and 3 do not.
    ps = [p(1, "غير ذي صلة"), p(2, "نص آخر"), p(3, "مدة الترخيص ثلاث سنوات"), p(4, "مدة الترخيص ثلاث سنوات مرة أخرى")]
    q = {"id": "x", "question": "س", "gold_evidence": [["مدة الترخيص ثلاث سنوات"]]}
    s = score(q, result(ps))
    assert s["hit"] == 1 and s["first_relevant_rank"] == 3 and s["mrr"] == pytest.approx(1 / 3)        # first relevant at rank 3
    assert s["precision"] == pytest.approx(2 / 4) and s["coverage"] == 1.0                                # 2 of 4 relevant; the one evidence group is found


def test_coverage_with_two_evidence_groups_and_gold_docs():
    ps = [p(1, "أ ب ج"), p(2, "د هـ و", doc="other.pdf")]
    q = {"id": "x", "question": "س", "gold_docs": ["a.pdf"], "gold_evidence": [["أ ب ج"], ["د هـ و"]]}
    s = score(q, result(ps))
    assert s["coverage"] == 0.5                                              # the second phrase is only in a document that cannot be relevant
    assert s["hit"] == 1 and s["precision"] == 0.5


def test_a_miss_scores_zero_everywhere():
    q = {"id": "x", "question": "س", "gold_evidence": [["عبارة غير موجودة"]]}
    s = score(q, result([p(1, "نص"), p(2, "نص آخر")]))
    assert (s["hit"], s["mrr"], s["precision"], s["first_relevant_rank"]) == (0, 0.0, 0.0, None)


def test_two_stage_diagnostics_first_stage_hit_and_candidate_recall():
    # the reranker moved the gold passage from first-stage rank 6 up to rank 1: it is in the candidates, not in the first-stage top 2
    gold = p(1, "مدة الترخيص ثلاث سنوات", first_stage_rank=6)
    other = p(2, "نص", first_stage_rank=1)
    cands = [other, gold] + [p(9 + i, "x", first_stage_rank=3 + i) for i in range(4)]
    s = score({"id": "x", "question": "س", "gold_evidence": [["مدة الترخيص ثلاث سنوات"]]}, result([gold, other], cands=cands))
    assert s["hit"] == 1 and s["candidate_recall"] == 1 and s["first_stage_hit"] == 0


def test_keyword_coverage_and_abstention():
    q = {"id": "x", "question": "س", "gold_evidence": [["x y z"]], "answer_keywords": [["3", "ثلاث"], "سنوات"]}
    assert score(q, result([p(1, "x y z")], answer="المدة ثلاث فقط"))["keyword_coverage"] == 0.5          # one of two keyword groups present
    assert score(q, result([p(1, "x y z")], answer="ثلاث سنوات"))["keyword_coverage"] == 1.0
    s = score(q, result([p(1, "x y z")], answer="لا يحتوي السياق المتاح على إجابة هذا السؤال"))
    assert s["abstained"] is True and s["citation_present"] is None


def test_aggregate_false_and_correct_abstain_rates():
    rows = [{"answerable": True, "abstained": True}, {"answerable": True, "abstained": False}, {"answerable": True, "abstained": False},
            {"answerable": False, "abstained": True}, {"answerable": False, "abstained": False}]
    a = aggregate(rows)
    assert a["false_abstain_rate"] == pytest.approx(1 / 3) and a["correct_abstain_rate"] == 0.5 and a["n_answerable"] == 3 and a["n_questions"] == 5


def test_paired_bootstrap_known_cases():
    x = {f"q{i}": 0.0 for i in range(10)}
    y = {f"q{i}": 1.0 for i in range(10)}
    assert paired_bootstrap(x, y) == (1.0, 1.0, 1.0, 10)                      # every question improves by exactly 1: no uncertainty
    mean, lo, hi, n = paired_bootstrap({"a": 0, "b": 0, "c": 0, "d": 0}, {"a": 1, "b": 0, "c": 0, "d": 0})
    assert mean == 0.25 and lo == 0 and hi > 0 and n == 4                      # one of four improved: the interval includes zero
    assert paired_bootstrap({"a": 1}, {"b": 1}) is None                       # no shared question: not measurable
    assert paired_bootstrap(x, y) == paired_bootstrap(x, y)                   # seeded: repeatable
