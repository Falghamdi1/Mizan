# Team handoff (2026-10-10): what exists, who owns what, what is left

Three people, one pipeline. The code is finished for the capstone; what remains is **running things on Colab, writing the blind questions, grading answers, and presenting**. Dates: **Sun 11 Oct** Submission 2 (technical design, Template 2); **Wed 14 Oct** final (Template 3 presentation, demo, source code, README, one-page individual report each). Assessment is individual: each of you must be able to explain the whole project (section 6).

Roles are the ones you proposed (Person 1 RAG and system, Person 2 Arabic NLP and evaluation, Person 3 UI, demo and product). Decide who is who; the file ownership below stops two people editing the same core file.

## 1. The pipeline and its interfaces

| Stage | File and function | Contract |
|---|---|---|
| Ingestion | `src/ingestion.py` `load_pdfs`; `src/web_corpus.py` `load_web_corpus`; `src/corpus.py` `load_corpus(dir, kind)` | `Page(doc, title, page, text, text_repaired)`; fingerprints for every corpus |
| Preprocessing | `src/preprocessing.py` `get_config(name)`, `preprocess_text` | pipelines are named: `baseline`, `mizan`, `mizan-lite`, `<preset>+<flag>`; only this differs between arms |
| Chunking | `src/chunking.py` `chunk_pages` | 600 characters, overlap 100, never across a page |
| Embeddings, index | `src/embeddings.py`, `src/retrieval.py` | Chroma, cosine; optional LoRA adapter (`MIZAN_EMBEDDING_ADAPTER`) |
| Reranking | `src/rerank.py` | top-20 to top-4 with Qwen3-Reranker-0.6B (optional) |
| Safety filter | `src/safety.py` `filter_passages` | withholds instruction-like passages from the model |
| Generation | `src/rag.py` `Pipeline.ask`, `call_llm`, `PROMPTS` v1 to v4, `MIZAN_PROMPT` | returns `RAGResult(answer, passages, meta["shown"], meta["withheld"], tokens, latencies)` |
| Citations | `src/citations.py` `check` | `[file, page N]` against the passages shown |
| Monitoring | `src/monitoring.py` `Monitor` | log, rules, alerts, webhook/e-mail |
| Evaluation | `src/evaluation.py` `run_eval`, `score`; `src/stats.py` | hit, MRR, precision, first-stage hit, candidate recall, tokens, citation metrics, paired bootstrap |
| Comparison and UI | `src/comparison.py` `compare`; `src/ui.py` `build_ui`; `app.py` | side by side; works with the mock generator so UI work never waits for a GPU |
| Adaptation | `finetune/`, `scripts/run_adaptation.py` | LoRA on the embedder; leakage report; before/after |
| Evidence tools | `scripts/profile_data.py`, `scripts/token_analysis.py`, `scripts/compare_prompts.py`, `scripts/human_grading.py`, `scripts/make_blind_test.py` | see `FINAL_CHECKLIST.md` for the order |

## 2. File ownership (only the owner edits; ask before touching another's file)

| Owner | Files |
|---|---|
| Person 1 | `src/rag.py`, `src/config.py`, `src/ingestion.py`, `src/chunking.py`, `src/embeddings.py`, `src/retrieval.py`, `src/rerank.py`, `src/local_llm.py`, `src/safety.py`, `src/monitoring.py`, `src/citations.py`, `finetune/`, `scripts/run_adaptation.py`, `.env.example`, `requirements*.txt` |
| Person 2 | `src/preprocessing.py` (read only: do not change presets), `src/evaluation.py`, `src/stats.py`, `src/web_corpus.py`, `eval/`, `scripts/profile_data.py`, `token_analysis.py`, `compare_prompts.py`, `human_grading.py`, `make_blind_test.py`, `make_*_questions.py`, `tests/`, `docs/EXPERIMENT_LOG.md`, `EXPERIMENT_RESULTS.md`, `docs/DATA_AUDIT.md` |
| Person 3 | `src/ui.py`, `src/ui_theme.py`, `src/comparison.py`, `app.py`, `demo.py`, `scripts/build_notebook.py`, `build_web_notebook.py`, `README.md`, `COLAB_README.md`, `DEMO_SCRIPT.md`, `docs/RESPONSIBLE_AI.md`, `docs/NEEDS_ANALYSIS.md`, `docs/DESIGN_CHOICES.md`, slides |

Hard rule for the last days: **nobody edits `PreprocessConfig`, `MIZAN_LITE`, a development question file, or any result file after it is quoted.** Notebooks are generated: edit the builder, rebuild with `python scripts/build_notebook.py` and `python scripts/build_web_notebook.py`, never the `.ipynb`. After every change run `python -m pytest tests` (170 pass today).

## 3. Person 1: RAG and system engineering

| # | Task | Acceptance (how others verify) |
|---|---|---|
| 1 | Run **`Mizan_Arabic_RAG_Optimization.ipynb`** on a Colab T4 (Run all). Fix anything that breaks. Save the executed copy to `results/final/`. | executed `.ipynb` with outputs and no error cells; stage-timing table present; a side-by-side answer with sources visible. (Offline smoke test with no models already passes: 47 cells, 0 errors; this is the real-model run.) |
| 2 | **Prompt comparison:** the same notebook's section 7b runs all four prompt versions (v1 to v4) on the same retrieved passages; save the result and the blind grading sheet | `results/prompts-*.md` with the table; the sheet and key written |
| 3 | **Monitoring, real delivery:** put a Discord or Slack webhook in `.env` (`MIZAN_ALERT_WEBHOOK`), ask five out-of-scope questions, capture the alert | a message arrives; `logs/alerts.jsonl` shows `delivery_failures: []`; screenshot for the slides |
| 4 | **Adaptation:** run **`Mizan_Web_Evaluation_Colab.ipynb`** section 6d (`scripts/run_adaptation.py --train`, about 15 minutes). Save the adapter to Drive. | `results/adaptation-*.md` with the leakage report and the three question sets; adapter in `finetune/out/q06_lite/` |
| 5 | **Injection test with the real model:** follow `docs/RESPONSIBLE_AI.md` section 5, step 1 (an uploaded PDF with an attack, with and without prompt v4) | the outcome written into `docs/EXPERIMENT_LOG.md`, whichever way it goes |
| 6 | Tag the repository (`git tag freeze-1`) when everyone's work is merged; zip `data/web/raw` | tag exists; the zip's fingerprint is `b3871676ff02…` |
| 7 (optional) | Quantization: the same 30 questions with `MIZAN_HF_QUANT=4bit` and `none`: memory, tokens per second, keyword coverage | a four-row table |

Do not build: a hosted deployment, BM25/hybrid, a new chunker, the 4B reranker, query rewriting.

## 4. Person 2: Arabic NLP, preprocessing and evaluation

| # | Task | Acceptance |
|---|---|---|
| 1 | **Blind test set.** Coordinate the three people (`eval/blind_test/README.md`); each writes 15 to 20 questions **before seeing results**, `--check` until clean, a teammate reads 5 rows each; then `python scripts/make_blind_test.py --build` and note the hashes in the README. Rebuild the web notebook so it contains the frozen files | `eval/questions_final_test_{pdf,web}.json` and `eval/blind_test/FROZEN.json`; `--verify` passes; about 45 to 60 questions |
| 2 | **Final comparison:** run the web notebook once on the frozen corpus (upload `data/web/html_for_colab.zip` so the laws are present); section 6e evaluates the blind set once | `results/blind_test.csv`; corpus fingerprint in the result equals `b3871676ff02…`; otherwise reject the run |
| 3 | **Human grading** (with one more person): after Person 1 produces answers, `python scripts/human_grading.py make results/<answers>.json --arms ...`, two people grade ~30 questions with `eval/human_grading/RUBRIC.md`, then `merge` | `human_grading_report.md`: kappa, per-arm accuracy with a paired interval, and whether the judge and keyword score can be trusted |
| 4 | **Review the 77 PDF alignments** with a second person (not the author of the preprocessing): 25 entries each of `eval/pdf_faq_alignment.json` against the PDFs | the number changed reported; questions rebuilt with `scripts/make_pdf_questions.py` |
| 5 | Update `EXPERIMENT_RESULTS.md` **from the files only**: blind-set numbers, adaptation, prompt comparison, human grades | every number traceable to a file in `results/` |

Do not build: new preprocessing steps, more ablations, changes to lite, more generated questions, an LLM judge for correctness.

## 5. Person 3: UI, demo and product

| # | Task | Acceptance |
|---|---|---|
| 1 | **Submission 2 deck (Sunday):** build Template 2 from `docs/NEEDS_ANALYSIS.md` (user flow, wireframe, 7 functional specs with acceptance criteria, component and sequence diagrams) and `docs/DESIGN_CHOICES.md` (services compared, tools chosen), prompt v1 as the first template, metrics with target numbers (`FINAL_CHECKLIST.md`), work plan | a teammate can redraw each diagram from the code |
| 2 | **Done (sent and approved).** **Send the data-permission request** (`DataDesk@mt.gov.sa` or tourism.sa/ar/ucc/new-case) and keep the sources and licences table in the README accurate | email sent; date noted in the README |
| 3 | **Demo:** follow `DEMO_SCRIPT.md`; choose the three questions by the rule there **after** a real-model rehearsal; record a 2 to 3 minute fallback video | video exists before Tuesday night |
| 4 | **Responsible AI pre-demo tests** (`docs/RESPONSIBLE_AI.md` section 5) with Person 1: record the outcomes | results table in the document |
| 5 | **Slides (Template 3) and individual reports:** numbers only from `EXPERIMENT_RESULTS.md`; fix the Submission 1 claim "16% less text to embed" (measured: 12.5% fewer characters, 32% to 42% fewer tokens); the three one-page reports | every figure on a slide appears in `EXPERIMENT_RESULTS.md` |
| 6 | README as a tutorial for another developer | a person outside the team can run `pytest` and the demo from it |

Do not build: a hosted deployment (unless everything else is done), a new design, extra pages.

## 6. Everyone must be able to explain

Why kashida matters (12.3% of PDF characters, 30% of tokens) and what Mizan-lite keeps and drops; what a paired interval is and why "n.d." is not "equal"; why the headline gain is for a weak embedder and why a reranker hides it; what was fine-tuned, on what, with which held-out documents, and why only 15 independent held-out questions exist; what the blind set is and why it may be used once; what the monitor alerts on and what the injection filter does and does not do; why the token saving is real for the generator's input but not shown to lower latency; what the project does **not** show (answer quality by humans, strong embedders, clean text, other corpora).

## 7. Integration dependencies

Person 1's Colab run produces answers → Person 2/3 grade and show them; Person 2's frozen blind set → the web notebook rebuild (Person 3 owns the builder: ask them to rebuild, do not edit it); Person 1's adaptation result → `EXPERIMENT_RESULTS.md` (Person 2); Person 1's alert screenshot and Person 3's demo rehearsal share one real-model Colab session: schedule them one after the other.
