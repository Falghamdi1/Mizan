"""Arabic narration with Chatterbox Multilingual (Resemble AI, MIT licence), run locally on the GPU.

Run it with the separate TTS environment (see video/README.md), not the project's:

    <tts-venv>/python video/tools/tts_chatterbox.py OUTDIR [--ids a1,b1] [--takes 3] [--ref voice.wav]
        [--exaggeration 0.45] [--cfg 0.5] [--temperature 0.7]

Each line of video/narration/lines.json is spoken from its `tts` field. Long lines are split at punctuation and the
pieces joined with short pauses (longer after a full stop or colon), so the model never reads a very long input.
Several takes per line can be written (<id>.take<N>.wav, one seed each); asr_check.py then picks the clearest.
"""
import argparse
import json
import re
import sys
from pathlib import Path

import numpy as np
import soundfile as sf
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from audio_edit import fade_edges  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
PAUSE_AFTER = {".": 0.30, "؟": 0.30, "?": 0.30, ":": 0.20, "،": 0.08, ",": 0.08, "؛": 0.16}


def pieces(text: str, limit: int = 110) -> list[tuple[str, float]]:
    """Split at punctuation into (piece, pause after) pairs; join short neighbours back up to `limit` characters."""
    parts = [p for p in re.split(r"(?<=[\.؟\?:،,؛])\s+", text.strip()) if p]
    out: list[tuple[str, float]] = []
    for p in parts:
        pause = PAUSE_AFTER.get(p[-1], 0.0)
        if out and len(out[-1][0]) + len(p) < limit and out[-1][1] < 0.3:
            out[-1] = (out[-1][0] + " " + p, pause)
        else:
            out.append((p, pause))
    return out


def trim(wav: np.ndarray, sr: int, thresh: float = 0.01) -> np.ndarray:
    """Cut leading and trailing near-silence (keeps 40 ms either side) and fade both ends, so a phrase never starts or
    stops on a non-zero sample (the 2026-10-14 takes did, which is heard as a click where the inserted pause begins).

    This does NOT remove the model's end-of-utterance artifacts (hum, buzz, clicks after the last word): they are often
    as loud as quiet speech, and an automatic level rule cut real words when tested (f3 «لا فرق», e2, f2, f5). Review
    every new take with chunk_ends.py and list the cut points in narration/repair_cuts.json (see video/README.md)."""
    idx = np.where(np.abs(wav) > thresh)[0]
    if not len(idx):
        return wav
    pad = int(0.04 * sr)
    return fade_edges(wav[max(0, idx[0] - pad): idx[-1] + pad], sr)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("out")
    ap.add_argument("--ids", default="")
    ap.add_argument("--lines", default=str(ROOT / "narration" / "lines.json"))
    ap.add_argument("--takes", type=int, default=1)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--ref", default="")
    ap.add_argument("--exaggeration", type=float, default=0.45)
    ap.add_argument("--cfg", type=float, default=0.5)
    ap.add_argument("--temperature", type=float, default=0.7)
    a = ap.parse_args()

    from chatterbox.mtl_tts import ChatterboxMultilingualTTS

    lines = {l["id"]: l for l in json.loads(Path(a.lines).read_text(encoding="utf-8"))["lines"]}
    want = [x for x in a.ids.split(",") if x] or list(lines)
    model = ChatterboxMultilingualTTS.from_pretrained(device="cuda" if torch.cuda.is_available() else "cpu")
    sr = model.sr
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    for lid in want:
        for take in range(a.takes):
            torch.manual_seed(a.seed + take)
            np.random.seed(a.seed + take)
            chunks = []
            for text, pause in pieces(lines[lid]["tts"]):
                kw = dict(language_id="ar", exaggeration=a.exaggeration, cfg_weight=a.cfg, temperature=a.temperature)
                if a.ref:
                    kw["audio_prompt_path"] = a.ref
                w = model.generate(text, **kw).squeeze(0).cpu().numpy()
                chunks += [trim(w, sr), np.zeros(int(pause * sr), dtype=np.float32)]
            wav = np.concatenate(chunks).astype(np.float32)
            name = f"{lid}.wav" if a.takes == 1 else f"{lid}.take{take}.wav"
            sf.write(out / name, wav, sr)
            print(name, round(len(wav) / sr, 2), "s", flush=True)


if __name__ == "__main__":
    main()
