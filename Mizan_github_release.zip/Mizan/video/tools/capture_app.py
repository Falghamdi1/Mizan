"""Capture real footage of the running Mizan app (headless Chrome, DevTools protocol) for the project video.

    python video/tools/capture_app.py --url http://127.0.0.1:7860 --out video/capture

Everything saved is the app's own rendering at 2x pixel density: full-page screenshots, element crops, and the question
being typed into the real text box, one frame per two characters. Nothing is drawn or edited here.
"""
import argparse
import base64
import json
import shutil
import subprocess
import tempfile
import time
import urllib.request
from pathlib import Path

import websocket

CHROME = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
W, H, DPR = 1440, 900, 2

BLIND_Q = "خلال كم يومًا من صدور الترخيص يجب على المرفق طلب شهادة التصنيف، وماذا يحدث إذا انقضت المدة دون أن يتقدم بالطلب؟"
BLIND_PHRASE = "الترخيص التقدم للوزارة بطلب الحصول على شهادة"       # blind-pdf-012's gold evidence (eval/questions_final_test_pdf.json)
FREE_Q = "هل يجوز للمرشد السياحي العمل لدى أكثر من منشأة؟"


class CDP:
    def __init__(self, url):
        self.ws = websocket.create_connection(url, timeout=900, suppress_origin=True)
        self.i = 0

    def __call__(self, method, **params):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": params}))
        while True:
            m = json.loads(self.ws.recv())
            if m.get("id") == self.i:
                if "error" in m:
                    raise RuntimeError(f"{method}: {m['error']}")
                return m.get("result", {})

    def js(self, expr):
        return self("Runtime.evaluate", expression=expr, awaitPromise=True, returnByValue=True).get("result", {}).get("value")

    def wait(self, expr, timeout=900, step=0.5):
        t0 = time.time()
        while time.time() - t0 < timeout:
            if self.js(expr):
                return True
            time.sleep(step)
        raise TimeoutError(expr)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="http://127.0.0.1:7860")
    ap.add_argument("--out", default="video/capture")
    ap.add_argument("--port", type=int, default=9350)
    a = ap.parse_args()
    out = Path(a.out)
    (out / "typing").mkdir(parents=True, exist_ok=True)
    prof = tempfile.mkdtemp(prefix="mizan-cap-")
    proc = subprocess.Popen([CHROME, "--headless=new", f"--remote-debugging-port={a.port}", f"--user-data-dir={prof}", "--no-first-run",
                             "--hide-scrollbars", "--force-color-profile=srgb", f"--window-size={W},{H}", "about:blank"],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    log = {}
    try:
        for _ in range(60):
            try:
                page = next(t for t in json.load(urllib.request.urlopen(f"http://127.0.0.1:{a.port}/json")) if t["type"] == "page")
                break
            except Exception:
                time.sleep(0.3)
        c = CDP(page["webSocketDebuggerUrl"])
        c("Page.enable")
        c("Runtime.enable")

        def metrics(height=H):
            c("Emulation.setDeviceMetricsOverride", width=W, height=int(height), deviceScaleFactor=DPR, mobile=False)

        def full_height():
            return c.js("Math.ceil(Math.max(document.documentElement.scrollHeight, document.body.scrollHeight))")

        def shot(name, clip=None, fmt="png", quality=92):
            kw = dict(format=fmt, captureBeyondViewport=False)
            if fmt == "jpeg":
                kw["quality"] = quality
            if clip:
                kw["clip"] = {**clip, "scale": 1}
            data = c("Page.captureScreenshot", **kw)["data"]
            p = out / name
            p.write_bytes(base64.b64decode(data))
            return p

        def rect(sel):
            return c.js(f"(e => e && (r => ({{x: r.left + scrollX, y: r.top + scrollY, width: r.width, height: r.height}}))(e.getBoundingClientRect()))"
                        f"(document.querySelector({json.dumps(sel)}))")

        def full_page(name):
            metrics(full_height())
            time.sleep(0.8)
            c.js("window.scrollTo(0, 0); true")
            p = shot(name)
            return p

        def element(name, sel, pad=10):
            r = rect(sel)
            if not r:
                print("missing", sel)
                return None
            return shot(name, {"x": max(0, r["x"] - pad), "y": max(0, r["y"] - pad), "width": r["width"] + 2 * pad, "height": r["height"] + 2 * pad})

        def set_text(sel, text):
            c.js(f"(t => {{ t.focus(); t.value = {json.dumps(text)}; t.dispatchEvent(new Event('input', {{bubbles: true}})); }})"
                 f"(document.querySelector({json.dumps(sel)})); true")

        def insights_done():
            return "!!document.querySelector('.mz-ins') && !document.querySelector('.mz-ins .mz-loading')"

        def results_for(q):
            probe = json.dumps(q[:18])
            return (f"(() => {{ const s = document.querySelector('.mz-results .mz-qstrip'); "
                    f"return !!s && s.innerText.includes({probe}) && !!document.querySelector('.mz-results .mz-cols'); }})()")

        metrics()
        c("Page.navigate", url=a.url)
        c.wait("document.readyState === 'complete'", 60)
        c.js("localStorage.setItem('mizan.lang', 'ar'); localStorage.setItem('mizan.theme', 'dark'); true")
        c("Page.reload")
        time.sleep(1)
        c.wait("!!document.querySelector('#mz-run') && document.documentElement.lang === 'ar'", 60)
        time.sleep(2)
        shot("01_home_ar_dark.png")
        log["corpus"] = c.js("(document.querySelector('.mz-corpus') || document.querySelector('#mz-corpuscol') || {}).innerText")

        # the question, typed into the real text box; one frame per two characters
        metrics(H)
        qr = rect("#mz-question")
        card = c.js("(e => { const r = (e.closest('.mz-card') || e).getBoundingClientRect();"
                    " return {x: r.left + scrollX, y: r.top + scrollY, width: r.width, height: r.height}; })"
                    "(document.querySelector('#mz-question'))")
        frame = 0
        for i in list(range(0, len(BLIND_Q) + 1, 2)) + [len(BLIND_Q)]:
            set_text("#mz-question textarea", BLIND_Q[:i])
            time.sleep(0.03)
            shot(f"typing/{frame:04d}.jpg", {"x": card["x"], "y": card["y"], "width": card["width"], "height": card["height"]}, fmt="jpeg")
            frame += 1
        log["typing_frames"] = frame
        log["question_box"] = qr

        # the optional evidence phrase (marks the reference passage and lets Insights measure relevance)
        c.js("(b => b && b.click())(document.querySelector('#mz-phrase-acc .label-wrap, #mz-phrase-acc button')); true")
        c.wait("!!document.querySelector('#mz-phrase textarea, #mz-phrase input')", 10)
        set_text("#mz-phrase textarea, #mz-phrase input", BLIND_PHRASE)
        time.sleep(0.6)
        shot("02_question_ready.png")

        # compare: the real run, with its loading state
        t0 = time.time()
        c.js("document.querySelector('#mz-run').click(); true")
        time.sleep(1.2)
        c.js("(e => e && e.scrollIntoView({block: 'start'}))(document.querySelector('#mz-run')); true")
        time.sleep(0.4)
        shot("03_loading.png")
        c.wait(results_for(BLIND_Q), 900)
        log["answers_seconds"] = round(time.time() - t0, 1)
        time.sleep(1.5)
        c.js("window.scrollTo(0, 0); true")
        full_page("04_results_full_ar_dark.png")
        element("05_answers_ar_dark.png", ".mz-results")
        element("06_measured_ar_dark.png", ".mz-measured")
        log["answers"] = c.js("[...document.querySelectorAll('.mz-ans')].map(a => a.innerText.slice(0, 400))")
        log["summary"] = c.js("(document.querySelector('.mz-summary') || {}).innerText")
        time.sleep(2)
        c.wait(insights_done(), 900, 1)
        log["insights_seconds"] = round(time.time() - t0, 1)
        time.sleep(1.5)
        full_page("07_full_with_insights_ar_dark.png")
        element("08_insights_blind_ar_dark.png", ".mz-ins")
        log["insights_blind"] = c.js("(document.querySelector('.mz-ins') || {}).innerText")

        # the same results in English and light: the language and the appearance switch without a new run
        c.js("[...document.querySelectorAll('.mz-seg input')].find(i => i.value === 'en').click(); true")
        c.wait("document.documentElement.lang === 'en'", 20)
        time.sleep(2.5)
        c.js("[...document.querySelectorAll('.mz-seg input')].find(i => i.value === 'light').click(); true")
        time.sleep(1.5)
        full_page("09_results_full_en_light.png")
        element("10_answers_en_light.png", ".mz-results")
        c.js("[...document.querySelectorAll('.mz-seg input')].find(i => i.value === 'ar').click(); true")
        c.wait("document.documentElement.lang === 'ar'", 20)
        c.js("[...document.querySelectorAll('.mz-seg input')].find(i => i.value === 'dark').click(); true")
        time.sleep(2.5)

        # a prepared example where the two pipelines tie
        metrics(H)
        c.js("window.scrollTo(0, 0); true")
        c.js("document.querySelectorAll('#mz-examples button')[2].click(); true")       # renewal deadline (r5)
        time.sleep(1)
        c.wait("(document.querySelector('#mz-question textarea') || {}).value !== " + json.dumps(BLIND_Q), 30)
        r5_q = c.js("document.querySelector('#mz-question textarea').value")
        c.wait(results_for(r5_q), 900)
        time.sleep(2)
        c.wait(insights_done(), 900, 1)
        time.sleep(1.5)
        full_page("11_full_r5_ar_dark.png")
        element("12_insights_r5_ar_dark.png", ".mz-ins")
        element("13_answers_r5_ar_dark.png", ".mz-results")
        log["insights_r5"] = c.js("(document.querySelector('.mz-ins') || {}).innerText")

        # a free question without an evidence phrase
        metrics(H)
        c.js("window.scrollTo(0, 0); true")
        set_text("#mz-phrase textarea, #mz-phrase input", "")
        set_text("#mz-question textarea", FREE_Q)
        time.sleep(0.5)
        c.js("document.querySelector('#mz-run').click(); true")
        time.sleep(1)
        c.wait(results_for(FREE_Q), 900)
        time.sleep(2)
        c.wait(insights_done(), 900, 1)
        time.sleep(1.5)
        full_page("14_full_free_ar_dark.png")
        element("15_insights_free_ar_dark.png", ".mz-ins")
        element("16_answers_free_ar_dark.png", ".mz-results")
        log["insights_free"] = c.js("(document.querySelector('.mz-ins') || {}).innerText")
        log["answers_free"] = c.js("[...document.querySelectorAll('.mz-ans')].map(a => a.innerText.slice(0, 400))")
    finally:
        (out / "capture_log.json").write_text(json.dumps(log, ensure_ascii=False, indent=1), encoding="utf-8")
        proc.terminate()
        try:
            proc.wait(5)
        except Exception:
            proc.kill()
        shutil.rmtree(prof, ignore_errors=True)
    print("done")


if __name__ == "__main__":
    main()
