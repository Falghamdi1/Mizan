"""Show where each generated phrase (TTS chunk) ends, to place repair cuts precisely.

    python video/tools/chunk_ends.py video/narration/takes --out video/audit/chunks

In the raw takes the pauses inserted between chunks are exact digital silence, so every chunk can be found exactly.
For each chunk: its span in the take and in the video, Whisper's word timings for the chunk (where the last word
ends), and a zoomed plot of its last 1.6 s (waveform, spectrogram, level) with a 0.1 s grid, six chunks per sheet.
"""
import argparse
import json
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy.signal import resample_poly

ROOT = Path(__file__).resolve().parents[1]


def chunks(x, sr, min_zero=0.05):
    """Spans between runs of exact zeros (the inserted pauses)."""
    z = x == 0.0
    out, i, n = [], 0, len(x)
    run = int(min_zero * sr)
    while i < n:
        while i < n and z[i]:
            i += 1
        if i >= n:
            break
        j = i
        while j < n:
            if z[j]:
                k = j
                while k < n and z[k]:
                    k += 1
                if k - j >= run or k >= n:
                    break
                j = k
            else:
                j += 1
        out.append((i, j))
        i = j
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("takes")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    tl = json.loads((ROOT / "narration" / "timeline.json").read_text(encoding="utf-8"))
    tempo = tl["tempo"]
    starts = {l["id"]: l["start"] for l in tl["lines"]}
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)

    import torch
    from transformers import pipeline
    asr = pipeline("automatic-speech-recognition", model="openai/whisper-large-v3-turbo", torch_dtype=torch.float16,
                   device="cuda:0" if torch.cuda.is_available() else "cpu")
    rows = []
    for lid in starts:
        x, sr = sf.read(str(Path(a.takes) / f"{lid}.wav"), dtype="float32")
        for k, (s, e) in enumerate(chunks(x, sr)):
            seg = x[s:e]
            x16 = resample_poly(seg, 16000, sr).astype(np.float32)
            try:
                res = asr({"raw": x16, "sampling_rate": 16000}, return_timestamps="word",
                          generate_kwargs={"language": "arabic", "task": "transcribe"})
                words = [(c["text"].strip(), c["timestamp"][0], c["timestamp"][1]) for c in res["chunks"]]
            except Exception as ex:                                   # word timing is guidance only
                words = [("?", None, None)]
                print("word timing failed", lid, k, ex)
            last_end = max([w[2] for w in words if w[2] is not None] or [None]) if words else None
            rows.append({"line": lid, "chunk": k, "take_start": round(s / sr, 3), "take_end": round(e / sr, 3),
                         "video_start": round(starts[lid] + s / sr / tempo, 3), "video_end": round(starts[lid] + e / sr / tempo, 3),
                         "last_word_end": None if last_end is None else round(s / sr + last_end, 3), "words": words})
    (out / "chunks.json").write_text(json.dumps(rows, ensure_ascii=False, indent=1), encoding="utf-8")

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    per = 6
    for sheet in range(0, len(rows), per):
        group = rows[sheet: sheet + per]
        fig, axes = plt.subplots(len(group), 2, figsize=(18, 2.6 * len(group)), gridspec_kw={"width_ratios": [1, 1]})
        axes = np.atleast_2d(axes)
        for ax2, r in zip(axes, group):
            x, sr = sf.read(str(Path(a.takes) / f"{r['line']}.wav"), dtype="float32")
            t1 = r["take_end"]
            t0 = max(r["take_start"], t1 - 1.6)
            seg = x[int(t0 * sr): int(t1 * sr)]
            t = t0 + np.arange(len(seg)) / sr
            win = int(0.02 * sr)
            lvl = 20 * np.log10(np.sqrt(np.convolve(seg ** 2, np.ones(win) / win, "same")) + 1e-7)
            ax2[0].plot(t, seg, lw=0.4, color="#333")
            ax2[0].plot(t, (lvl + 80) / 80, lw=0.8, color="#2a9d8f")
            ax2[0].set_ylim(-1, 1.05)
            ax2[1].specgram(seg, NFFT=512, Fs=sr, noverlap=448, xextent=(t0, t1), cmap="magma", vmin=-130, vmax=-20)
            ax2[1].set_ylim(0, 8000)
            for axx in ax2:
                axx.set_xticks(np.arange(np.ceil(t0 * 10) / 10, t1, 0.1), minor=True)
                axx.grid(True, which="minor", axis="x", lw=0.3, color="#888")
                if r["last_word_end"]:
                    axx.axvline(r["last_word_end"], color="#ef476f", lw=1.2, ls="--")
            last = r["words"][-1][0] if r["words"] else ""
            ax2[0].set_title(f"{r['line']} chunk {r['chunk']}  take {r['take_start']:.2f}-{r['take_end']:.2f}s  "
                             f"(video {r['video_start']:.2f}-{r['video_end']:.2f})  last word ends ~{r['last_word_end']}", fontsize=9)
            ax2[1].set_title(f"last word heard: {last[::-1] if last else ''}", fontsize=9)
        fig.tight_layout()
        fig.savefig(out / f"sheet{sheet // per + 1:02d}.png", dpi=70)
        plt.close(fig)
    print(len(rows), "chunks;", (len(rows) + per - 1) // per, "sheets in", out)
    for r in rows:
        print(r["line"], r["chunk"], r["take_start"], r["take_end"], "last word end", r["last_word_end"],
              "tail", None if r["last_word_end"] is None else round(r["take_end"] - r["last_word_end"], 3))


if __name__ == "__main__":
    main()
