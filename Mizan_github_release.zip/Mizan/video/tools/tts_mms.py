"""Baseline voice for comparison only: Meta MMS-TTS Arabic (facebook/mms-tts-ara, CC-BY-NC 4.0).

    python video/tools/tts_mms.py OUTDIR --ids a1,b1,d3
"""
import argparse
import json
from pathlib import Path

import soundfile as sf
import torch
from transformers import AutoTokenizer, VitsModel

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("out")
    ap.add_argument("--ids", default="")
    a = ap.parse_args()
    lines = {l["id"]: l for l in json.loads((ROOT / "narration" / "lines.json").read_text(encoding="utf-8"))["lines"]}
    want = [x for x in a.ids.split(",") if x] or list(lines)
    tok = AutoTokenizer.from_pretrained("facebook/mms-tts-ara")
    model = VitsModel.from_pretrained("facebook/mms-tts-ara")
    torch.manual_seed(0)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    for lid in want:
        with torch.no_grad():
            wav = model(**tok(lines[lid]["tts"], return_tensors="pt")).waveform[0].numpy()
        sf.write(out / f"{lid}.wav", wav, model.config.sampling_rate)
        print(lid, round(len(wav) / model.config.sampling_rate, 2), "s")


if __name__ == "__main__":
    main()
