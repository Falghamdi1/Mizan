"""Check a rendered video's soundtrack against the narration plan (no listening involved; a person should still watch it).

    python video/tools/verify_render.py video/mizan_project_video_ar.mp4

1. Music bed level: RMS of the mix where the narration is silent vs where it speaks (bed under speech is ducked).
2. Sync: Whisper large-v3-turbo transcribes the rendered audio with timestamps; for every narration line, the first
   transcribed segment that starts inside it must begin within 0.6 s of the planned start (and so of its subtitle).
"""
import json
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np
import soundfile as sf

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    video = Path(sys.argv[1])
    tl = json.loads((ROOT / "narration" / "timeline.json").read_text(encoding="utf-8"))
    wav = Path(tempfile.mkdtemp()) / "a.wav"
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(video), "-ac", "1", "-ar", "16000", str(wav)], check=True)
    x, sr = sf.read(str(wav), dtype="float32")
    speech = np.zeros(len(x), bool)
    for l in tl["lines"]:
        speech[int(l["start"] * sr): int(l["end"] * sr)] = True
    def db(v):
        return 20 * np.log10(np.sqrt(np.mean(v ** 2)) + 1e-9)
    gaps = x[~speech][int(1.5 * sr): -int(2.0 * sr)]          # skip the fade-in and fade-out
    print(f"RMS in narration: {db(x[speech]):.1f} dBFS; in gaps (music bed alone): {db(gaps):.1f} dBFS")

    import torch
    from transformers import pipeline
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from asr_check import cer, norm
    asr = pipeline("automatic-speech-recognition", model="openai/whisper-large-v3-turbo", torch_dtype=torch.float16,
                   device="cuda:0" if torch.cuda.is_available() else "cpu")
    lines = {l["id"]: l for l in json.loads((ROOT / "narration" / "lines.json").read_text(encoding="utf-8"))["lines"]}
    win = int(0.02 * sr)
    rows, worst = [], 0.0
    for l in tl["lines"]:
        a = max(0, int((l["start"] - 0.5) * sr))
        seg = x[a: int((l["end"] + 0.3) * sr)]
        rms = np.sqrt(np.convolve(seg ** 2, np.ones(win) / win, mode="same"))
        on = np.argmax(20 * np.log10(rms + 1e-9) > -34)              # first moment the voice rises above the bed
        offset = (a + on) / sr - l["start"]
        heard = asr({"raw": x[int((l["start"] - 0.1) * sr): int((l["end"] + 0.2) * sr)], "sampling_rate": sr},
                    generate_kwargs={"language": "arabic", "task": "transcribe"})["text"].strip()
        c = cer(norm(lines[l["id"]]["tts"]), norm(heard))
        worst = max(worst, abs(offset))
        rows.append({"id": l["id"], "planned_start": l["start"], "voice_onset_offset_s": round(offset, 3), "heard": heard, "cer_raw": round(c, 3)})
        sys.stdout.buffer.write(f"{l['id']}  plan {l['start']:6.2f}  onset {offset:+.2f}s  | {heard}\n".encode("utf-8"))
    print(f"largest onset offset: {worst:.2f} s over {len(rows)} lines")
    (ROOT / "narration" / "render_check.json").write_text(json.dumps({"lines": rows}, ensure_ascii=False, indent=1),
                                                          encoding="utf-8")


if __name__ == "__main__":
    main()
