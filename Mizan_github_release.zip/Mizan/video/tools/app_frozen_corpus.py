"""Run the real Mizan app on exactly the 8 Ministry PDFs of the evaluation (data/corpus_manifest.json), for screen capture.

    python video/tools/app_frozen_corpus.py [--port 7860]

data/raw may hold extra files added through the app; this copies only the manifest's PDFs to a temporary folder and
points the app there, so the footage shows the evaluated document set (8 documents, 159 pages). Nothing in data/ changes.
Settings come from .env exactly as for `python app.py`.
"""
import argparse
import json
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=7860)
    a = ap.parse_args()
    from src import config

    manifest = json.loads((ROOT / "data" / "corpus_manifest.json").read_text(encoding="utf-8"))
    names = [d["file"] for d in manifest["files"]]
    tmp = Path(tempfile.mkdtemp(prefix="mizan-frozen-"))
    for n in names:
        shutil.copy2(config.RAW_DIR / n, tmp / n)
    config.RAW_DIR = tmp                                  # resolve_data_dir() reads this at call time
    from src.comparison import load_pipelines
    from src.evaluation import load_questions
    from src.ui import build_ui, launch_kwargs

    print(f"Frozen corpus: {len(names)} PDFs in {tmp}")
    pages, pipes, synthetic = load_pipelines(config.DEMO_PIPELINES)
    print(f"{len({p.doc for p in pages})} documents, {len(pages)} pages")
    ui = build_ui(pages, pipes, load_questions(config.resolve_questions_path()[0], missing_ok=True), synthetic, data_dir=tmp)
    ui.launch(server_name="127.0.0.1", server_port=a.port, **launch_kwargs())


if __name__ == "__main__":
    main()
