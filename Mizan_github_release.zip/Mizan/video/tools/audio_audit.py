"""Audit the narration for audible defects (no listening; signal analysis plus spectrograms for visual review).

    python video/tools/audio_audit.py video/narration/narration.wav --out video/audit/before

The narration track has the video's exact timing (lines laid out by assemble_narration.py, music-free). For every
spoken piece (stretch of audio between silences) it reports:

  edge      the piece starts or ends on a non-zero sample instead of fading: a hard cut, heard as a click
  tail      a short burst of sound after the last word of the piece, separated by a gap: a TTS end-of-utterance
            artifact (breath, crackle, garble) that the original trimming kept
  transient a sudden broadband burst above 5 kHz inside speech (crack, click, glitch)

and draws one spectrogram per narration line with the pieces and the flagged moments marked.
"""
import argparse
import json
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy.signal import butter, sosfilt

ROOT = Path(__file__).resolve().parents[1]


def frames(x, sr, win=0.02, hop=0.005):
    w, h = int(win * sr), int(hop * sr)
    if len(x) < w:
        x = np.pad(x, (0, w - len(x)))
    n = 1 + max(0, (len(x) - w) // h)
    idx = np.arange(w)[None, :] + h * np.arange(n)[:, None]
    return x[idx], h


def pieces(x, sr, floor=1e-4, min_gap=0.04):
    """Contiguous non-silent regions (the narration pauses are digital silence)."""
    loud = np.abs(x) > floor
    out, i, n, gap = [], 0, len(x), int(min_gap * sr)
    while i < n:
        if not loud[i]:
            i += 1
            continue
        j = i
        last = i
        while j < n and (j - last) < gap:
            if loud[j]:
                last = j
            j += 1
        out.append((i, last + 1))
        i = j
    return out


def island_features(seg, sr):
    f, _ = frames(seg, sr, 0.03, 0.01)
    if not len(f):
        return {"flatness": 1.0, "centroid": 0.0, "voiced": 0.0}
    spec = np.abs(np.fft.rfft(f * np.hanning(f.shape[1]), axis=1)) + 1e-9
    freqs = np.fft.rfftfreq(f.shape[1], 1 / sr)
    flat = np.exp(np.mean(np.log(spec), axis=1)) / np.mean(spec, axis=1)
    cen = (spec * freqs).sum(1) / spec.sum(1)
    voiced = []
    for fr in f:                                    # normalised autocorrelation peak in the 70-400 Hz pitch range
        fr = fr - fr.mean()
        ac = np.correlate(fr, fr, "full")[len(fr) - 1:]
        lo, hi = int(sr / 400), int(sr / 70)
        voiced.append(ac[lo:hi].max() / (ac[0] + 1e-9) if ac[0] > 0 else 0)
    return {"flatness": round(float(np.median(flat)), 3), "centroid": round(float(np.median(cen))), "voiced": round(float(np.mean(np.array(voiced) > 0.5)), 2)}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("wav")
    ap.add_argument("--out", required=True)
    ap.add_argument("--timeline", default=str(ROOT / "narration" / "timeline.json"))
    a = ap.parse_args()
    x, sr = sf.read(a.wav, dtype="float32", always_2d=True)
    x = x.mean(axis=1)
    tl = json.loads(Path(a.timeline).read_text(encoding="utf-8"))
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)

    def line_of(t):
        for l in tl["lines"]:
            if l["start"] - 0.3 <= t <= l["end"] + 0.3:
                return l["id"]
        return "-"

    hp = sosfilt(butter(4, 5000, "highpass", fs=sr, output="sos"), x)
    flags, report = [], []
    for (s, e) in pieces(x, sr):
        seg = x[s:e]
        peak = float(np.abs(seg).max()) + 1e-9
        t0, t1 = s / sr, e / sr
        lid = line_of((t0 + t1) / 2)
        head = float(np.abs(seg[: int(0.003 * sr)]).max()) / peak
        tail = float(np.abs(seg[-int(0.003 * sr):]).max()) / peak
        if head > 0.02:
            flags.append({"line": lid, "time": round(t0, 3), "kind": "edge", "where": "start", "level": round(head, 3)})
        if tail > 0.02:
            flags.append({"line": lid, "time": round(t1, 3), "kind": "edge", "where": "end", "level": round(tail, 3)})
        # islands of sound inside the piece, at -42 dB below the piece's 20 ms peak
        fr, hop = frames(seg, sr)
        db = 20 * np.log10(np.sqrt((fr ** 2).mean(1)) + 1e-9)
        on = db > db.max() - 42
        isl, k = [], 0
        while k < len(on):
            if on[k]:
                m = k
                while m < len(on) and on[m]:
                    m += 1
                isl.append([k, m])
                k = m
            else:
                k += 1
        merged = []
        for i0, i1 in isl:                          # gaps shorter than 40 ms are part of the same island
            if merged and (i0 - merged[-1][1]) * hop / sr < 0.04:
                merged[-1][1] = i1
            else:
                merged.append([i0, i1])
        isls = [{"start": round(t0 + i0 * hop / sr, 3), "end": round(t0 + i1 * hop / sr + 0.02, 3)} for i0, i1 in merged]
        for j, il in enumerate(isls):
            a_ = min(len(seg) - 1, max(0, int((il["start"] - t0) * sr)))
            b_ = min(len(seg), max(a_ + 1, int((il["end"] - t0) * sr)))
            il.update(island_features(seg[a_:b_], sr))
            il["dur"] = round(il["end"] - il["start"], 3)
            il["peak_db"] = round(float(20 * np.log10(np.abs(seg[a_:b_]).max() / peak + 1e-9)), 1)
        if len(isls) > 1:
            last = isls[-1]
            gap = last["start"] - isls[-2]["end"]
            if last["dur"] < 0.4 and gap > 0.03:
                flags.append({"line": lid, "time": last["start"], "kind": "tail", "dur": last["dur"], "gap": round(gap, 3),
                              "peak_db": last["peak_db"], "flatness": last["flatness"], "voiced": last["voiced"], "centroid": last["centroid"]})
        # broadband transients inside speech
        h = hp[s:e]
        hf, hhop = frames(h, sr, 0.005, 0.0025)
        hdb = 20 * np.log10(np.sqrt((hf ** 2).mean(1)) + 1e-9)
        k = int(0.15 / (hhop / sr))
        for i in range(len(hdb)):
            ctx = np.median(hdb[max(0, i - k): i + k])
            if hdb[i] > ctx + 20 and hdb[i] > 20 * np.log10(peak) - 40:
                t = t0 + i * hhop / sr
                if not flags or flags[-1].get("kind") != "transient" or t - flags[-1]["time"] > 0.05:
                    flags.append({"line": lid, "time": round(t, 3), "kind": "transient", "rise_db": round(float(hdb[i] - ctx), 1)})
        report.append({"line": lid, "start": round(t0, 3), "end": round(t1, 3), "islands": isls})
    (out / "audit.json").write_text(json.dumps({"flags": flags, "pieces": report}, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"{len(report)} pieces, {len(flags)} flags: " + ", ".join(f"{k} {sum(f['kind'] == k for f in flags)}" for k in ("edge", "tail", "transient")))
    for f in flags:
        print(json.dumps(f, ensure_ascii=False))

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    for l in tl["lines"]:
        a0, a1 = l["start"] - 0.25, l["end"] + 0.35
        seg = x[int(a0 * sr): int(a1 * sr)]
        fig, ax = plt.subplots(2, 1, figsize=(16, 5.2), sharex=True, gridspec_kw={"height_ratios": [1, 2.4]})
        t = a0 + np.arange(len(seg)) / sr
        ax[0].plot(t, seg, lw=0.4, color="#333")
        ax[0].set_ylim(-1, 1)
        ax[1].specgram(seg, NFFT=1024, Fs=sr, noverlap=896, xextent=(a0, a1), cmap="magma", vmin=-130, vmax=-20)
        ax[1].set_ylim(0, 11000)
        for p in report:
            if a0 <= p["start"] <= a1:
                for axx in ax:
                    axx.axvline(p["start"], color="#2a9d8f", lw=0.8)
                    axx.axvline(p["end"], color="#e76f51", lw=0.8)
        for f in flags:
            if a0 <= f["time"] <= a1:
                for axx in ax:
                    axx.axvline(f["time"], color={"edge": "#ffd166", "tail": "#ef476f", "transient": "#06d6a0"}[f["kind"]], lw=1.6, ls="--")
                ax[0].text(f["time"], 0.85, f["kind"], fontsize=8, color="#c00")
        ax[0].set_title(f"{l['id']}  {l['start']:.2f}-{l['end']:.2f} s   (green = piece start, red = piece end, dashed = flagged)", fontsize=10)
        ax[1].set_xlabel("video time (s)")
        fig.tight_layout()
        fig.savefig(out / f"{l['id']}.png", dpi=72)
        plt.close(fig)
    print("spectrograms in", out)


if __name__ == "__main__":
    main()
