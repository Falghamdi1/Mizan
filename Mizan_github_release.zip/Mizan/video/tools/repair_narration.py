"""Repair the final narration track in place-of-time: edit only the artifact regions, leave every other sample as it was.

    python video/tools/repair_narration.py --narration video/narration/narration.wav --takes video/narration/takes \
        --timeline video/narration/timeline.json --cuts video/narration/repair_cuts.json --out-dir video/narration/clean

The cut points in repair_cuts.json are in raw-take time. The exact sample where each line starts in narration.wav is
recomputed with place_narration.layout (checked against the original), and a take time t maps to line_start + t / tempo
(the tempo filter is linear to within a few milliseconds; every cut has at least 40 ms of margin after the speech).
At each cut the audio fades out over 30 ms and is silent until the end of that generated phrase (the next digital
pause). Phrase edges that start or stop on a non-zero sample get a 5 ms fade-in or a 15 ms fade-out. Nothing else
changes and the file keeps its exact length.
"""
import argparse
import json
import shutil
import sys
from pathlib import Path

import numpy as np
import soundfile as sf

sys.path.insert(0, str(Path(__file__).resolve().parent))
from audio_edit import _ramp, find_chunks  # noqa: E402
from place_narration import layout  # noqa: E402

SILENT = 2e-5


def silent_runs(x: np.ndarray, sr: int, min_len: float = 0.04) -> list[tuple[int, int]]:
    q = np.abs(x) < SILENT
    out, i, n, m = [], 0, len(x), int(min_len * sr)
    while i < n:
        if q[i]:
            j = i
            while j < n and q[j]:
                j += 1
            if j - i >= m:
                out.append((i, j))
            i = j
        else:
            i += 1
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--narration", required=True)
    ap.add_argument("--takes", required=True)
    ap.add_argument("--timeline", required=True)
    ap.add_argument("--cuts", required=True)
    ap.add_argument("--out-dir", required=True)
    a = ap.parse_args()
    x, sr = sf.read(a.narration, dtype="float32")
    tl = json.loads(Path(a.timeline).read_text(encoding="utf-8"))
    raw, spans = layout(Path(a.takes), tl)
    gain = 0.89 / float(np.abs(raw).max())
    if len(raw) != len(x) or float(np.abs(raw * gain - x).max()) > 1e-4:
        raise SystemExit("layout does not reproduce the narration; stopping")
    start = {lid: (s, n) for lid, s, n in spans}
    y = x.copy()
    runs = silent_runs(x, sr)
    log = []
    cuts = json.loads(Path(a.cuts).read_text(encoding="utf-8"))["cuts"]
    for c in cuts:
        s, n = start[c["line"]]
        at = s + int(round(c["cut"] / tl["tempo"] * sr))
        take, tsr = sf.read(str(Path(a.takes) / f"{c['line']}.wav"), dtype="float32")
        chs = find_chunks(take, tsr)
        ch = chs[c["chunk"]]                                                      # exact phrase span in the raw take
        if not (ch[0] / tsr < c["cut"] < ch[1] / tsr):
            raise SystemExit(f"cut {c} is outside its phrase")
        # silence through the inserted pause: up to just before the next phrase, or to the end of the line, so no
        # millisecond of the original hard-cut ending survives
        if c["chunk"] + 1 < len(chs):
            end = s + int(round(chs[c["chunk"] + 1][0] / tsr / tl["tempo"] * sr)) - int(0.01 * sr)
        else:
            end = s + n
        if end <= at:
            raise SystemExit(f"cut {c} lands in silence")
        pre = x[max(s, at - int(0.03 * sr)): at]
        f = min(int(c.get("fade", 0.05) * sr), end - at)
        y[at: at + f] *= _ramp(f)[::-1]
        y[at + f: end] = 0.0
        log.append({"line": c["line"], "chunk": c["chunk"], "video_time": round(at / sr, 3), "silenced_until": round(end / sr, 3),
                    "removed_s": round((end - at) / sr, 3), "removed_peak": round(float(np.abs(x[at:end]).max()), 4),
                    "level_before_cut_dbfs": round(float(20 * np.log10(np.sqrt(np.mean(pre ** 2)) + 1e-9)), 1),
                    "artifact": c["artifact"]})
    # phrase edges: fade any start or stop that is not already at zero
    edges = 0
    for r0, r1 in runs:
        for (k, kind) in ((r0, "end"), (r1, "start")):
            if kind == "end" and k > 0 and abs(y[k - 1]) > 1e-3:
                m = min(int(0.015 * sr), k)
                y[k - m: k] *= _ramp(m)[::-1]
                edges += 1
            if kind == "start" and k < len(y) and abs(y[k]) > 1e-3:
                m = min(int(0.005 * sr), len(y) - k)
                y[k: k + m] *= _ramp(m)
                edges += 1
    od = Path(a.out_dir)
    od.mkdir(parents=True, exist_ok=True)
    sf.write(str(od / "narration.wav"), y, sr)
    shutil.copy2(a.timeline, od / "timeline.json")
    changed = np.abs(y - x) > 1e-6
    (od / "repair_log.json").write_text(json.dumps({"cuts": log, "edge_fades": edges,
                                                   "samples_changed": int(changed.sum()), "samples_total": len(x)},
                                                  ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"{len(log)} artifact cuts, {edges} edge fades; {changed.sum()} of {len(x)} samples changed "
          f"({changed.sum() / sr:.2f} s); length unchanged")
    for e in log:
        print(f"  {e['line']}#{e['chunk']}  {e['video_time']:7.3f}-{e['silenced_until']:7.3f} s  removed {e['removed_s']:.3f} s "
              f"(peak {e['removed_peak']:.3f}); level just before cut {e['level_before_cut_dbfs']} dBFS")


if __name__ == "__main__":
    main()
