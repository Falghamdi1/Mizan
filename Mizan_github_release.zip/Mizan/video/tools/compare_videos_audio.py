"""Compare the soundtracks of two renders of the same video (original vs repaired).

    python video/tools/compare_videos_audio.py ORIGINAL.mp4 REPAIRED.mp4 --log video/narration/clean/repair_log.json

  alignment      cross-correlation offset of the two soundtracks (must be 0 ms: the repair moved nothing)
  untouched      level difference over the stretches the repair did not touch (narration plus the shared music bed)
  repaired       level in each repaired window before and after, and the 5-8 kHz energy (where the clicks and buzz were)
"""
import argparse
import json
import subprocess
import tempfile
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy.signal import butter, correlate, sosfilt

SR = 48000


def decode(p: str) -> np.ndarray:
    tmp = Path(tempfile.mkdtemp()) / "a.wav"
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", p, "-ac", "1", "-ar", str(SR), "-c:a", "pcm_f32le", str(tmp)], check=True)
    x, _ = sf.read(str(tmp), dtype="float32")
    return x


def db(v: np.ndarray) -> float:
    return float(20 * np.log10(np.sqrt(np.mean(v ** 2)) + 1e-10))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("a")
    ap.add_argument("b")
    ap.add_argument("--log", required=True)
    args = ap.parse_args()
    a, b = decode(args.a), decode(args.b)
    n = min(len(a), len(b))
    a, b = a[:n], b[:n]
    w = slice(int(20 * SR), int(30 * SR))
    c = correlate(b[w], a[w], mode="full", method="fft")
    lag = int(np.argmax(c)) - (len(a[w]) - 1)
    print(f"lengths {len(a) / SR:.3f} s / {len(b) / SR:.3f} s; alignment offset {lag / SR * 1000:+.2f} ms")
    cuts = json.loads(Path(args.log).read_text(encoding="utf-8"))["cuts"]
    touched = np.zeros(n, bool)
    for cu in cuts:
        touched[int(cu["video_time"] * SR): int((cu["silenced_until"] + 0.6) * SR)] = True   # +0.6 s: the bed's ducking recovers
    print(f"untouched audio: {db(a[~touched]):.2f} dB vs {db(b[~touched]):.2f} dB (difference {db(b[~touched]) - db(a[~touched]):+.2f} dB); "
          f"correlation {np.corrcoef(a[~touched], b[~touched])[0, 1]:.4f}")
    hp = butter(4, [5000, 8000], "bandpass", fs=SR, output="sos")
    ah, bh = sosfilt(hp, a), sosfilt(hp, b)
    print("repaired windows (video time): level before -> after, 5-8 kHz energy before -> after")
    for cu in cuts:
        s, e = int(cu["video_time"] * SR), int(cu["silenced_until"] * SR)
        print(f"  {cu['line']}#{cu['chunk']} {cu['video_time']:7.2f}-{cu['silenced_until']:7.2f}  "
              f"{db(a[s:e]):6.1f} -> {db(b[s:e]):6.1f} dB   hf {db(ah[s:e]):6.1f} -> {db(bh[s:e]):6.1f} dB")


if __name__ == "__main__":
    main()
