"""Write the narration script (Arabic, with English and timecodes) and the scene outline from the final timeline.

    python video/tools/write_docs.py

Outputs video/narration/script_ar.md and video/OUTLINE.md, both generated from video/narration/timeline.json so they
always match the rendered video.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TL = json.loads((ROOT / "narration" / "timeline.json").read_text(encoding="utf-8"))
L = {l["id"]: l for l in TL["lines"]}
SCENES = [
    ("hook", "المشكلة · The problem", "a1", "A real line from the Tour Guide Regulations (p. 8) turns from «لا تزيد» into «ال تزيد» as the PDF extractor delivers it; a second real line shows its kashida in gold, and a bar fills to 29.7% (21,109 of 71,046 tokens)."),
    ("reveal", "الفكرة · The idea", "b1", "The app's balance-scale mark settles; name and Gen AI tagline; the same system built twice: documents, questions, models and prompt equal, text preprocessing the only difference."),
    ("pipeline", "كيف يعمل · How it works", "c1", "Two preprocessing lanes (Standard: whitespace only; Mizan-lite: lam-alef, kashida, invisible marks, NFKC, digit and letter forms) merge into one shared chain: chunking, Qwen3-Embedding-0.6B (20 candidates), Qwen3-Reranker-0.6B (top 4), Qwen3-4B-Instruct base model; the prompt v1 rules and a checked citation."),
    ("demo", "المنتج · The product", "d1", "Real footage of the app on the 8 evaluated PDFs: the blind question pdf-012 typed into the question box, the evidence phrase, the comparison; Standard answers 60 days from another regulation (p. 6), Mizan-lite 180 days from the right page (p. 13), then the retrieved passage that holds the reference evidence (rank 3)."),
    ("insights", "Mizan Insights", "e1", "The real Insights panel for that question: facts computed by code, the model's explanation, the check; the verdict 'not enough evidence on this question' with no recommendation; three real questions with the same verdict."),
    ("results", "النتائج · Results", "f1", "Frozen blind test (266 questions): hit@4 PDF 68.1% → 79.7% (+11.6 pts [+2.9, +21.7], titles off; with titles +4.3, n.d.), web 72.9% → 73.6%; PDF index −31.8% embedding tokens; blind human grading with intervals against the −10 no-loss margin; refusals 20/24 → 23/24; LoRA +22.2 on style-matched dev questions but +1.4 [−7.2, +10.1] on blind questions."),
    ("close", "الخلاصة · Takeaway", "g1", "Three takeaways, the scale mark, «نقيسُ، ولا نفترض.» and the team."),
]


def tc(t: float) -> str:
    return f"{int(t // 60)}:{t % 60:04.1f}"


def main() -> None:
    lines = json.loads((ROOT / "narration" / "lines.json").read_text(encoding="utf-8"))["lines"]
    out = ["# Mizan project video: Arabic narration script", "",
           f"Final duration {tc(TL['duration'])} ({TL['duration']:.1f} s). Voice: Chatterbox Multilingual (local, MIT) with a ClArTTS reference "
           f"(CC BY 4.0); tempo ×{TL['tempo']}. Times are when each line starts and ends in the video.", "",
           "| # | time | Arabic (spoken) | English subtitle |", "|---|---|---|---|"]
    for i, l in enumerate(lines, 1):
        t = L[l["id"]]
        out.append(f"| {i} | {tc(t['start'])}–{tc(t['end'])} | {l['ar']} | {l['en']} |")
    out += ["", "## Recording plan for a human narrator", "",
            "If a team member records the narration instead: read the Arabic column line by line, calmly, at about the pace of the "
            "synthetic voice; leave a short breath between lines. Save one WAV per line as video/narration/takes/<id>.wav (ids a1 … g2, "
            "in the order above), then rebuild (video/README.md, steps 4–7). The timeline, subtitles and visuals follow the new "
            "recording automatically; check the subtitles still match the words you said."]
    (ROOT / "narration" / "script_ar.md").write_text("\n".join(out) + "\n", encoding="utf-8")

    starts = [L[s[2]]["start"] for s in SCENES] + [TL["duration"]]
    o = ["# Scene outline", "", f"Total {tc(TL['duration'])}. Scene times are when the scene's narration starts.", "",
         "| scene | time | what is shown |", "|---|---|---|"]
    for k, (sid, name, first, desc) in enumerate(SCENES):
        a = starts[k] - (0.8 if k else starts[k])
        o.append(f"| {name} | {tc(max(0, a))}–{tc(starts[k + 1] - 0.8 if k + 1 < len(SCENES) else TL['duration'])} | {desc} |")
    (ROOT / "OUTLINE.md").write_text("\n".join(o) + "\n", encoding="utf-8")
    print("wrote script_ar.md and OUTLINE.md")


if __name__ == "__main__":
    main()
