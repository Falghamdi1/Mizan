"""Before/after spectrograms around each repaired moment of the narration (video time).

    python video/tools/before_after.py OUT_DIR video/narration/narration.wav video/narration/clean/narration.wav \
        video/narration/clean/repair_log.json
"""
import json
import sys
from pathlib import Path

import matplotlib
import numpy as np
import soundfile as sf

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402


def main() -> None:
    out, a_path, b_path, log_path = Path(sys.argv[1]), sys.argv[2], sys.argv[3], sys.argv[4]
    out.mkdir(parents=True, exist_ok=True)
    a, sr = sf.read(a_path, dtype="float32")
    b, _ = sf.read(b_path, dtype="float32")
    cuts = json.loads(Path(log_path).read_text(encoding="utf-8"))["cuts"]
    per = 5
    for k in range(0, len(cuts), per):
        group = cuts[k:k + per]
        fig, axes = plt.subplots(len(group), 2, figsize=(18, 2.7 * len(group)))
        axes = np.atleast_2d(axes)
        for ax2, c in zip(axes, group):
            t0, t1 = c["video_time"] - 1.0, max(c["silenced_until"] + 0.25, c["video_time"] + 0.6)
            for ax, x, name in ((ax2[0], a, "before"), (ax2[1], b, "after")):
                seg = x[int(t0 * sr): int(t1 * sr)]
                ax.specgram(seg + 1e-9, NFFT=1024, Fs=sr, noverlap=960, xextent=(t0, t1), cmap="magma", vmin=-130, vmax=-20)
                ax.set_ylim(0, 9000)
                tt = t0 + np.arange(len(seg)) / sr
                ax.plot(tt, 4500 + seg * 4000, lw=0.3, color="#9fd")
                ax.axvline(c["video_time"], color="#ef476f", lw=1)
                ax.set_title(f"{name}  {c['line']}#{c['chunk']}  cut at {c['video_time']:.2f} s (video)", fontsize=9)
        fig.tight_layout()
        fig.savefig(out / f"cuts_{k // per + 1}.png", dpi=66)
        plt.close(fig)
    print("written to", out)


if __name__ == "__main__":
    main()
