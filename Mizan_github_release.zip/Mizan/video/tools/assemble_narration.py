"""Assemble the narration: pick the clearest take of each line, lay the lines out on the video timeline, and write the
subtitle cues. Run with the project Python after asr_check.py has scored every take.

    python video/tools/assemble_narration.py TAKES_DIR --scores scores.json [--tempo 1.0]

Writes video/narration/narration.wav (48 kHz), video/narration/timeline.json (line and cue times) and
video/subtitles/mizan_project_video_en.srt. The take with the lowest character error (Arabic words only) wins; on a tie
the shorter one. Subtitle chunks are split at a natural English break and timed at the nearest real pause in the audio.
"""
import argparse
import json
import re
import subprocess
import tempfile
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy.signal import resample_poly

ROOT = Path(__file__).resolve().parents[1]
SR = 48000
LEAD_IN = 0.8
GAP_IN_SCENE = 0.28
GAP_SCENE = {"reveal": 0.9, "pipeline": 0.7, "demo": 1.3, "insights": 0.7, "results": 0.8, "close": 0.9}
EXTRA_AFTER = {"a2": 0.4, "a3": 0.3, "b2": 0.2, "c3": 0.3, "d1": 1.1, "d2": 0.8, "e2": 2.3, "f1": 0.4, "f2": 0.4,
               "f3": 0.4, "f4": 1.6, "f5": 1.2, "f6": 0.4, "g1": 0.3}
TAIL = 3.2
MAX_CHARS = 84          # two subtitle lines of about 42 characters


def load(path: Path, tempo: float) -> np.ndarray:
    if abs(tempo - 1.0) > 1e-3:
        tmp = Path(tempfile.mkdtemp()) / "t.wav"
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(path), "-filter:a", f"atempo={tempo}", str(tmp)], check=True)
        path = tmp
    x, sr = sf.read(str(path), dtype="float32", always_2d=True)
    x = x.mean(axis=1)
    g = np.gcd(sr, SR)
    return resample_poly(x, SR // g, sr // g).astype(np.float32)


def pauses(x: np.ndarray, min_len: float = 0.12, thresh: float = 0.012) -> list[float]:
    """Centres of silent stretches (seconds from the start of the line)."""
    win = int(0.01 * SR)
    env = np.sqrt(np.convolve(x ** 2, np.ones(win) / win, mode="same"))
    quiet = env < thresh
    out, start = [], None
    for i, q in enumerate(quiet):
        if q and start is None:
            start = i
        elif not q and start is not None:
            if (i - start) / SR >= min_len and start > 0:
                out.append((start + i) / 2 / SR)
            start = None
    return out


def split_en(text: str) -> list[str]:
    """Split a long subtitle at the break nearest the middle (sentence end, semicolon, colon, comma)."""
    if len(text) <= MAX_CHARS:
        return [text]
    mid = len(text) / 2
    best = None
    for m in re.finditer(r"[.;:,—](\s)", text):
        pos = m.start(1)
        score = abs(pos - mid) - (8 if text[m.start()] in ".;:" else 0) + (100 if min(pos, len(text) - pos) < 25 else 0)
        if best is None or score < best[0]:
            best = (score, pos)
    if best is None:
        sp = [m.start() for m in re.finditer(" ", text)]
        best = (0, min(sp, key=lambda p: abs(p - mid)))
    a, b = text[:best[1]].strip(), text[best[1]:].strip()
    return split_en(a) + split_en(b)


def srt_time(t: float) -> str:
    ms = int(round(t * 1000))
    return f"{ms // 3600000:02d}:{ms // 60000 % 60:02d}:{ms // 1000 % 60:02d},{ms % 1000:03d}"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("takes")
    ap.add_argument("--scores", required=True)
    ap.add_argument("--tempo", type=float, default=1.0)
    ap.add_argument("--out-dir", default=str(ROOT / "narration"), help="where narration.wav and timeline.json go")
    ap.add_argument("--srt", default=str(ROOT / "subtitles" / "mizan_project_video_en.srt"))
    a = ap.parse_args()
    lines = json.loads((ROOT / "narration" / "lines.json").read_text(encoding="utf-8"))["lines"]
    scores = {s["id"]: s for s in json.loads(Path(a.scores).read_text(encoding="utf-8"))["lines"]}

    t = LEAD_IN
    track = [np.zeros(int(LEAD_IN * SR), np.float32)]
    timeline, cues, prev_scene = [], [], None
    for ln in lines:
        lid = ln["id"]
        takes = sorted(Path(a.takes).glob(f"{lid}.take*.wav")) or [Path(a.takes) / f"{lid}.wav"]
        ranked = sorted(takes, key=lambda p: (scores.get(p.stem, {}).get("cer", 9), sf.info(str(p)).duration))
        best = ranked[0]
        if prev_scene is not None and ln["scene"] != prev_scene:
            gap = GAP_SCENE.get(ln["scene"], 0.9)
            track.append(np.zeros(int(gap * SR), np.float32))
            t += gap
        x = load(best, a.tempo)
        dur = len(x) / SR
        start = t
        track.append(x)
        t += dur
        chunks = split_en(ln["en"])
        ps = pauses(x)
        bounds = [0.0]
        total_chars = sum(len(c) for c in chunks)
        acc = 0
        for c in chunks[:-1]:
            acc += len(c)
            target = dur * acc / total_chars
            bounds.append(min(ps, key=lambda p: abs(p - target)) if ps else target)
        bounds.append(dur)
        for i, c in enumerate(chunks):
            cues.append({"line": lid, "start": round(start + bounds[i], 3), "end": round(start + bounds[i + 1], 3), "text": c})
        timeline.append({"id": lid, "scene": ln["scene"], "start": round(start, 3), "end": round(t, 3), "take": best.name,
                         "pauses": [round(p, 3) for p in ps],
                         "cer": scores.get(best.stem, {}).get("cer"), "ar": ln["ar"], "en": ln["en"]})
        gap = GAP_IN_SCENE + EXTRA_AFTER.get(lid, 0.0)
        track.append(np.zeros(int(gap * SR), np.float32))
        t += gap
        prev_scene = ln["scene"]
    track.append(np.zeros(int(TAIL * SR), np.float32))
    t += TAIL
    audio = np.concatenate(track)
    peak = float(np.abs(audio).max())
    audio = audio / peak * 0.89 if peak > 0 else audio
    out_dir = Path(a.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    sf.write(str(out_dir / "narration.wav"), audio, SR)
    # subtitles never overlap and stay at least 1.2 s on screen when the next one allows it
    for i, c in enumerate(cues):
        nxt = cues[i + 1]["start"] if i + 1 < len(cues) else t
        c["end"] = round(min(max(c["end"] + 0.25, c["start"] + 1.2), nxt - 0.04), 3)
    json.dump({"duration": round(t, 3), "tempo": a.tempo, "lines": timeline, "cues": cues},
              open(out_dir / "timeline.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    Path(a.srt).parent.mkdir(parents=True, exist_ok=True)
    srt = "\n".join(f"{i}\n{srt_time(c['start'])} --> {srt_time(c['end'])}\n{c['text']}\n" for i, c in enumerate(cues, 1))
    Path(a.srt).write_text(srt, encoding="utf-8")
    print(f"narration {t:.1f} s, {len(timeline)} lines, {len(cues)} subtitle cues")
    for ln in timeline:
        print(f"  {ln['id']}  {ln['start']:6.2f}-{ln['end']:6.2f}  {ln['take']}  cer {ln['cer']}")


if __name__ == "__main__":
    main()
