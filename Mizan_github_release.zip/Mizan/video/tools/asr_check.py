"""Intelligibility check for synthetic Arabic narration: transcribe each WAV with Whisper large-v3-turbo (local, MIT)
and compare with the sentence the voice was asked to say.

    python video/tools/asr_check.py DIR [--ids a1,a2] [--json out.json]

DIR holds <id>.wav files named after the line ids in video/narration/lines.json. The score is the character error rate
after a light Arabic normalisation (no diacritics, one alef, ya/ta-marbuta folded, punctuation removed), so it measures
whether the words come through, not how natural the voice sounds: that still needs a human listener.
"""
import argparse
import json
import re
import sys
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy.signal import resample_poly

ROOT = Path(__file__).resolve().parents[1]
DIAC = re.compile(r"[ؐ-ًؚ-ٰٟۖ-ۭـ]")
PUNCT = re.compile(r"[^\w\s]|_")


def norm(s: str) -> str:
    s = DIAC.sub("", s)
    s = re.sub("[إأآٱ]", "ا", s).replace("ى", "ي").replace("ة", "ه").replace("ؤ", "و").replace("ئ", "ي")
    s = PUNCT.sub(" ", s.lower())
    return re.sub(r"\s+", " ", s).strip()


def cer(ref: str, hyp: str) -> float:
    r, h = ref.replace(" ", ""), hyp.replace(" ", "")
    prev = list(range(len(h) + 1))
    for i, rc in enumerate(r, 1):
        cur = [i]
        for j, hc in enumerate(h, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (rc != hc)))
        prev = cur
    return prev[-1] / max(1, len(r))


def load16k(path: Path) -> np.ndarray:
    x, sr = sf.read(str(path), dtype="float32", always_2d=True)
    x = x.mean(axis=1)
    if sr != 16000:
        g = np.gcd(sr, 16000)
        x = resample_poly(x, 16000 // g, sr // g).astype("float32")
    return x


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("dir")
    ap.add_argument("--ids", default="")
    ap.add_argument("--lines", default=str(ROOT / "narration" / "lines.json"))
    ap.add_argument("--json", default="")
    a = ap.parse_args()
    import torch
    from transformers import pipeline

    lines = {l["id"]: l for l in json.loads(Path(a.lines).read_text(encoding="utf-8"))["lines"]}
    want = [x for x in a.ids.split(",") if x] or [p.stem for p in sorted(Path(a.dir).glob("*.wav")) if p.stem.split(".")[0] in lines]
    asr = pipeline("automatic-speech-recognition", model="openai/whisper-large-v3-turbo",
                   torch_dtype=torch.float16, device="cuda:0" if torch.cuda.is_available() else "cpu")
    out, total_err, total_len = [], 0.0, 0
    for lid in want:
        wav = Path(a.dir) / f"{lid}.wav"
        x = load16k(wav)
        hyp = asr({"raw": x, "sampling_rate": 16000}, generate_kwargs={"language": "arabic", "task": "transcribe"})["text"]
        line = lines[lid.split(".")[0]]
        ref_text = line["tts"]
        for frag in line.get("asr_skip", []):          # English terms and numbers: Whisper writes them in Latin or digits
            ref_text = ref_text.replace(frag, " ")
        ref = norm(ref_text)
        hyp_ar = norm(" ".join(w for w in hyp.split() if not re.search(r"[A-Za-z0-9٠-٩%]", w)))
        for frag in line.get("asr_skip", []):                # the same terms when Whisper wrote them in Arabic letters
            hyp_ar = hyp_ar.replace(norm(frag), " ")
        for alt in ("بي دي اف", "مئتين وسته وستين", "عشرين", "اربعه", "ستين", "مئه وثمانون", "ثمانين بالمئه", "ثمانيه وستين",
                    "بواحد وثلاثين فاصله ثمانيه بالمئه", "لورا", "ميزان انسايتس"):
            if alt in norm(ref_text) or any(alt in norm(f) for f in line.get("asr_skip", [])):
                hyp_ar = hyp_ar.replace(alt, " ")
        c = cer(ref, re.sub(r"\s+", " ", hyp_ar).strip())
        total_err += c * len(ref.replace(" ", ""))
        total_len += len(ref.replace(" ", ""))
        out.append({"id": lid, "seconds": round(len(x) / 16000, 2), "cer": round(c, 3), "heard": hyp.strip()})
        sys.stdout.buffer.write(f"{lid}  {len(x) / 16000:5.2f}s  CER {c:.3f}  | {hyp.strip()}\n".encode("utf-8"))
    summary = {"lines": out, "cer_overall": round(total_err / max(1, total_len), 3)}
    sys.stdout.buffer.write(f"overall CER {summary['cer_overall']:.3f}\n".encode("utf-8"))
    if a.json:
        Path(a.json).write_text(json.dumps(summary, ensure_ascii=False, indent=1), encoding="utf-8")


if __name__ == "__main__":
    main()
