"""Look for defects inside spoken phrases (the tail artifacts are handled by repair_narration.py).

    <tts-venv>/python video/tools/scan_inside.py video/narration/clean/narration.wav

  pitch jump   two voiced 10 ms frames in a row whose F0 differs by more than ~70 % (an octave break or a "crack")
  zero gap     a run of exactly-zero samples shorter than 40 ms inside speech whose next sample is not near zero
               (an abrupt restart, heard as a click)
  clip         samples at or above 0.99 of full scale
"""
import json
import sys
from pathlib import Path

import librosa
import numpy as np
import soundfile as sf

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    x, sr = sf.read(sys.argv[1], dtype="float32")
    tl = json.loads((ROOT / "narration" / "timeline.json").read_text(encoding="utf-8"))
    out = []
    print("clipped samples:", int((np.abs(x) >= 0.99).sum()))
    # zero gaps inside speech
    z = x == 0.0
    i, n = 0, len(x)
    while i < n:
        if z[i]:
            j = i
            while j < n and z[j]:
                j += 1
            if 0 < i and j < n and int(0.002 * sr) <= (j - i) < int(0.04 * sr) and abs(x[j]) > 0.01:
                out.append({"kind": "zero gap", "time": round(i / sr, 3), "len_ms": round((j - i) / sr * 1000, 1), "restart": round(float(x[j]), 3)})
            i = j
        else:
            i += 1
    # pitch jumps per line
    for l in tl["lines"]:
        s, e = int(l["start"] * sr), int(l["end"] * sr)
        seg = librosa.resample(x[s:e], orig_sr=sr, target_sr=16000)
        f0, vflag, vprob = librosa.pyin(seg, fmin=65, fmax=400, sr=16000, frame_length=1024, hop_length=160)
        for k in range(1, len(f0)):
            if vflag[k] and vflag[k - 1] and vprob[k] > 0.5 and vprob[k - 1] > 0.5:
                r = f0[k] / f0[k - 1]
                if r > 1.7 or r < 1 / 1.7:
                    out.append({"kind": "pitch jump", "line": l["id"], "time": round(l["start"] + k * 160 / 16000, 3),
                                "from_hz": round(float(f0[k - 1])), "to_hz": round(float(f0[k]))})
    for o in out:
        print(json.dumps(o, ensure_ascii=False))
    print(len(out), "findings")


if __name__ == "__main__":
    main()
