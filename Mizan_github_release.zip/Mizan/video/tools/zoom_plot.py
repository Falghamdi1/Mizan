"""Zoomed waveform + spectrogram of take windows, with a fine grid, for placing cuts by eye.

    python video/tools/zoom_plot.py OUT.png TAKES_DIR id:t0:t1 [id:t0:t1 ...] [--cuts id:t ...]
"""
import sys
from pathlib import Path

import matplotlib
import numpy as np
import soundfile as sf

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402


def main() -> None:
    out, takes, rest = sys.argv[1], Path(sys.argv[2]), sys.argv[3:]
    cuts = {}
    if "--cuts" in rest:
        k = rest.index("--cuts")
        for c in rest[k + 1:]:
            lid, t = c.split(":")
            cuts.setdefault(lid, []).append(float(t))
        rest = rest[:k]
    wins = [(w.split(":")[0], float(w.split(":")[1]), float(w.split(":")[2])) for w in rest]
    fig, axes = plt.subplots(len(wins), 2, figsize=(18, 2.5 * len(wins)))
    axes = np.atleast_2d(axes)
    for ax2, (lid, t0, t1) in zip(axes, wins):
        x, sr = sf.read(str(takes / f"{lid}.wav"), dtype="float32")
        seg = x[int(t0 * sr): int(t1 * sr)]
        t = t0 + np.arange(len(seg)) / sr
        win = int(0.01 * sr)
        lvl = 20 * np.log10(np.sqrt(np.convolve(seg ** 2, np.ones(win) / win, "same")) + 1e-7)
        ax2[0].plot(t, seg, lw=0.4, color="#333")
        ax2[0].plot(t, (lvl + 80) / 80, lw=0.8, color="#2a9d8f")
        ax2[0].set_ylim(-1, 1.05)
        ax2[1].specgram(seg, NFFT=512, Fs=sr, noverlap=480, xextent=(t0, t1), cmap="magma", vmin=-130, vmax=-20)
        ax2[1].set_ylim(0, 8000)
        for axx in ax2:
            axx.set_xticks(np.arange(np.ceil(t0 * 20) / 20, t1, 0.05), minor=True)
            axx.grid(True, which="minor", axis="x", lw=0.3, color="#999")
            for c in cuts.get(lid, []):
                axx.axvline(c, color="#ef476f", lw=1.4)
        ax2[0].set_title(f"{lid}  {t0:.2f}-{t1:.2f} s (take time; grid 0.05 s; green = level, 0 dB at top)", fontsize=9)
    fig.tight_layout()
    fig.savefig(out, dpi=70)


if __name__ == "__main__":
    main()
