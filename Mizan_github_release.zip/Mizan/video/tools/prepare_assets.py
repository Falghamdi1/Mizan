"""Turn the captured footage into composition assets (no pixel of the app is altered; only cropping, scaling, encoding).

    python video/tools/prepare_assets.py

Reads video/capture/, writes video/composition/assets/shots/ and video/composition/assets/typing.mp4, and records where
the typing clip sits on the home screenshot (found by matching the empty question card), in shots/placement.json.
"""
import json
import subprocess
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
CAP = ROOT / "capture"
OUT = ROOT / "composition" / "assets"
SHOTS = {
    "home": "01_home_ar_dark.png",
    "ready": "02_question_ready.png",
    "loading": "03_loading.png",
    "answers": "05_answers_ar_dark.png",
    "measured": "06_measured_ar_dark.png",
    "insights": "08_insights_blind_ar_dark.png",
    "en_light": "09_results_full_en_light.png",
    "ins_r5": "12_insights_r5_ar_dark.png",
    "ins_free": "15_insights_free_ar_dark.png",
    "answers_r5": "13_answers_r5_ar_dark.png",
    "answers_free": "16_answers_free_ar_dark.png",
}
CROP = {"en_light": (0, 0, 2880, 3200)}        # the English page down to the answers; the rest is not shown


def locate(big: np.ndarray, small: np.ndarray, step: int = 4) -> tuple[int, int]:
    """Top-left of `small` inside `big` by sum of absolute differences, coarse then fine."""
    bh, bw = big.shape
    sh, sw = small.shape
    s = small[::step, ::step]
    best = (1e18, 0, 0)
    for y in range(0, bh - sh, step):
        for x in range(0, bw - sw, step):
            d = np.abs(big[y:y + sh:step, x:x + sw:step] - s).mean()
            if d < best[0]:
                best = (d, x, y)
    _, x0, y0 = best
    best = (1e18, x0, y0)
    for y in range(max(0, y0 - step), min(bh - sh, y0 + step) + 1):
        for x in range(max(0, x0 - step), min(bw - sw, x0 + step) + 1):
            d = np.abs(big[y:y + sh, x:x + sw] - small).mean()
            if d < best[0]:
                best = (d, x, y)
    return best[1], best[2]


def main() -> None:
    (OUT / "shots").mkdir(parents=True, exist_ok=True)
    sizes = {}
    for key, name in SHOTS.items():
        im = Image.open(CAP / name).convert("RGB")
        if key in CROP:
            im = im.crop(CROP[key])
        im.save(OUT / "shots" / f"{key}.jpg", quality=93, subsampling=0)
        sizes[key] = im.size
    # where the typing frames sit on the home screenshot (the first frame is the empty card)
    home = np.asarray(Image.open(CAP / SHOTS["home"]).convert("L"), dtype=np.float32)
    first = np.asarray(Image.open(CAP / "typing" / "0000.jpg").convert("L"), dtype=np.float32)
    x, y = locate(home[::2, ::2], first[::2, ::2])
    x, y = x * 2, y * 2
    fh, fw = first.shape
    err = float(np.abs(home[y:y + fh, x:x + fw] - first).mean())
    n = len(list((CAP / "typing").glob("*.jpg")))
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-framerate", "20", "-i", str(CAP / "typing" / "%04d.jpg"),
                    "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "14", "-preset", "slow", "-movflags", "+faststart",
                    str(OUT / "typing.mp4")], check=True)
    place = {"sizes": sizes, "typing": {"x": x, "y": y, "w": fw, "h": fh, "frames": n, "fps": 20, "seconds": n / 20,
                                        "match_error": round(err, 2)}}
    (OUT / "shots" / "placement.json").write_text(json.dumps(place, indent=1), encoding="utf-8")
    print(json.dumps(place, indent=1))


if __name__ == "__main__":
    main()
