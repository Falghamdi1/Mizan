"""Transcribe every narration line in two versions of the track and show them side by side (are all words still there?).

    python video/tools/compare_lines.py video/narration/narration.wav video/narration/clean/narration.wav
"""
import json
import sys
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy.signal import resample_poly

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from asr_check import cer, norm  # noqa: E402


def main() -> None:
    import torch
    from transformers import pipeline
    a_path, b_path = sys.argv[1], sys.argv[2]
    tl = json.loads((ROOT / "narration" / "timeline.json").read_text(encoding="utf-8"))
    asr = pipeline("automatic-speech-recognition", model="openai/whisper-large-v3-turbo", torch_dtype=torch.float16,
                   device="cuda:0" if torch.cuda.is_available() else "cpu")
    tracks = []
    for p in (a_path, b_path):
        x, sr = sf.read(p, dtype="float32", always_2d=True)
        x = x.mean(1)
        tracks.append(resample_poly(x, 16000, sr).astype(np.float32) if sr != 16000 else x)
    rows, same = [], 0
    for l in tl["lines"]:
        s, e = int((l["start"] - 0.1) * 16000), int((l["end"] + 0.25) * 16000)
        t = [asr({"raw": tr[s:e], "sampling_rate": 16000}, generate_kwargs={"language": "arabic", "task": "transcribe"})["text"].strip()
             for tr in tracks]
        d = cer(norm(t[0]), norm(t[1]))
        same += d == 0
        rows.append({"id": l["id"], "before": t[0], "after": t[1], "difference_cer": round(d, 3)})
        sys.stdout.buffer.write(f"{l['id']}  diff {d:.3f}\n  before: {t[0]}\n  after : {t[1]}\n".encode("utf-8"))
    print(f"{same} of {len(rows)} lines transcribed identically")
    (Path(b_path).parent / "transcripts_before_after.json").write_text(json.dumps(rows, ensure_ascii=False, indent=1), encoding="utf-8")


if __name__ == "__main__":
    main()
