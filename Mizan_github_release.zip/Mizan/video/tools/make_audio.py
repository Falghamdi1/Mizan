"""Final soundtrack: narration + an original, quiet music bed generated here + a few soft accents. No external audio.

    <tts-venv>/python video/tools/make_audio.py

Reads video/narration/narration.wav and timeline.json; writes video/composition/assets/audio/mix.wav (48 kHz stereo).
The bed is a slow four-chord pad (sine and soft triangle partials, low-passed), ducked by about 9 dB under speech.
Accents: a low swell under the name reveal and two short soft ticks on the main numbers. The mix is normalised to
-16 LUFS integrated with peaks kept under -1.5 dBFS.
"""
import json
from pathlib import Path

import numpy as np
import pyloudnorm as pyln
import soundfile as sf
from scipy.signal import lfilter

ROOT = Path(__file__).resolve().parents[1]
SR = 48000
CHORDS = [  # D minor colour, gentle: Dm9, Bbmaj7, Fmaj7(add9), C(add9)/E
    [146.83, 220.00, 261.63, 329.63, 349.23],
    [116.54, 233.08, 293.66, 349.23, 440.00],
    [174.61, 220.00, 261.63, 329.63, 392.00],
    [164.81, 196.00, 261.63, 293.66, 392.00],
]
CHORD_S = 8.0


def lowpass(x: np.ndarray, cutoff: float) -> np.ndarray:
    """One-pole low-pass (run twice for a gentle 12 dB/octave slope)."""
    a = np.exp(-2 * np.pi * cutoff / SR)
    return lfilter([1 - a], [1, -a], x).astype(np.float32)


def pad(duration: float) -> np.ndarray:
    n = int(duration * SR)
    t = np.arange(n) / SR
    out = np.zeros((n, 2), np.float32)
    k = 0
    start = 0.0
    while start < duration:
        notes = CHORDS[k % len(CHORDS)]
        seg_len = CHORD_S + 3.0
        a, b = int(start * SR), min(n, int((start + seg_len) * SR))
        tt = t[a:b] - start
        env = np.minimum(1, tt / 2.5) * np.minimum(1, np.maximum(0, (seg_len - tt) / 3.0))
        for j, f in enumerate(notes):
            for ch, det in ((0, -0.6), (1, 0.6)):
                ff = f + det * (1 + j * 0.15)
                ph = 2 * np.pi * ff * tt + j * 1.3
                tone = np.sin(ph) + 0.18 * np.sin(3 * ph) / 3 + 0.08 * np.sin(5 * ph) / 5
                lfo = 0.85 + 0.15 * np.sin(2 * np.pi * (0.07 + 0.013 * j) * tt + j)
                out[a:b, ch] += (tone * env * lfo * (0.9 if j == 0 else 0.55)).astype(np.float32)
        start += CHORD_S
        k += 1
    for ch in range(2):
        out[:, ch] = lowpass(lowpass(out[:, ch], 1400.0), 1400.0)
    return out / np.abs(out).max()


def envelope(x: np.ndarray, smooth: float = 0.25) -> np.ndarray:
    """Speech level, smoothed so the bed eases down and back up rather than pumping."""
    k = np.exp(-1 / (smooth * SR))
    fwd = lfilter([1 - k], [1, -k], np.abs(x))
    return np.maximum(fwd, lfilter([1 - k], [1, -k], np.abs(x)[::-1])[::-1])


def swell(n: int) -> np.ndarray:
    t = np.arange(n) / SR
    f = 70 + 30 * t / t[-1]
    env = np.minimum(1, t / 0.8) * np.exp(-np.maximum(0, t - 0.8) / 1.2)
    return (np.sin(2 * np.pi * np.cumsum(f) / SR) * env).astype(np.float32)


def tick(n: int) -> np.ndarray:
    t = np.arange(n) / SR
    rng = np.random.default_rng(3)
    noise = rng.standard_normal(n).astype(np.float32)
    body = np.sin(2 * np.pi * 1850 * t) * 0.6 + noise * 0.25
    return (lowpass(body.astype(np.float32), 3500.0) * np.exp(-t / 0.018)).astype(np.float32)


def main() -> None:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--narration-dir", default=str(ROOT / "narration"), help="folder with narration.wav and timeline.json")
    ap.add_argument("--out", default=str(ROOT / "composition" / "assets" / "audio" / "mix.wav"))
    args = ap.parse_args()
    nd = Path(args.narration_dir)
    tl = json.loads((nd / "timeline.json").read_text(encoding="utf-8"))
    voice, sr = sf.read(str(nd / "narration.wav"), dtype="float32")
    assert sr == SR
    dur = len(voice) / SR
    bed = pad(dur + 0.1)[: len(voice)]
    duck = envelope(voice)
    duck = duck / max(1e-6, duck.max())
    gain = 10 ** (-(9.0 * np.clip(duck * 3, 0, 1)) / 20)            # about -9 dB while someone speaks
    fade = np.minimum(1, np.arange(len(bed)) / (2.5 * SR)) * np.minimum(1, (len(bed) - np.arange(len(bed))) / (4.0 * SR))
    bed = bed * (gain * fade)[:, None] * 10 ** (-23 / 20)           # bed sits about 23 dB under full scale before ducking
    mix = np.stack([voice, voice], axis=1) + bed
    starts = {l["id"]: l["start"] for l in tl["lines"]}
    for at, kind, level in ((starts["b1"] - 0.5, "swell", -20), (starts["f1"] + 1.4, "tick", -24), (starts["f4"] + 0.6, "tick", -24)):
        s = swell(int(2.6 * SR)) if kind == "swell" else tick(int(0.12 * SR))
        a = int(at * SR)
        b = min(len(mix), a + len(s))
        mix[a:b] += (s[: b - a] * 10 ** (level / 20))[:, None]
    meter = pyln.Meter(SR)
    loud = meter.integrated_loudness(mix)
    mix = pyln.normalize.loudness(mix, loud, -16.0)
    peak = np.abs(mix).max()
    if peak > 10 ** (-1.5 / 20):
        mix = mix / peak * 10 ** (-1.5 / 20)
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    sf.write(args.out, mix.astype(np.float32), SR, subtype="PCM_16")
    print(f"mix {dur:.1f} s, loudness before {loud:.1f} LUFS, after {meter.integrated_loudness(mix):.1f} LUFS, "
          f"peak {20 * np.log10(np.abs(mix).max()):.1f} dBFS")


if __name__ == "__main__":
    main()
