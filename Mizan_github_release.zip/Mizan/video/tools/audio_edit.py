"""Small, exact audio edits shared by the TTS generator and the repair tool. Nothing here changes a clip's length.

  find_chunks      spans between the digital-silence pauses inserted between generated phrases
  cut_tail         keep a phrase up to `cut` seconds, fade out over `fade` seconds, then digital silence
  fade_edges       short raised-cosine fade-in and fade-out at a phrase's first and last samples (no hard cuts)

An automatic "drop the tail after the last word" rule was tried and rejected: tested against the hand-placed cuts it
would have removed real words (f3 «لا فرق», and the ends of e2, f2, f5). Tail artifacts are removed by reviewed cut
points (narration/repair_cuts.json), proposed with chunk_ends.py.
"""
import numpy as np


def find_chunks(x: np.ndarray, sr: int, min_zero: float = 0.05) -> list[tuple[int, int]]:
    z = x == 0.0
    out, i, n, run = [], 0, len(x), int(min_zero * sr)
    while i < n:
        while i < n and z[i]:
            i += 1
        if i >= n:
            break
        j = i
        while j < n:
            if z[j]:
                k = j
                while k < n and z[k]:
                    k += 1
                if k - j >= run or k >= n:
                    break
                j = k
            else:
                j += 1
        out.append((i, j))
        i = j
    return out


def _ramp(n: int) -> np.ndarray:
    return (0.5 - 0.5 * np.cos(np.linspace(0, np.pi, n))).astype(np.float32)


def fade_edges(seg: np.ndarray, sr: int, fade_in: float = 0.005, fade_out: float = 0.015) -> np.ndarray:
    seg = seg.copy()
    a, b = min(len(seg), int(fade_in * sr)), min(len(seg), int(fade_out * sr))
    if a > 1:
        seg[:a] *= _ramp(a)
    if b > 1:
        seg[-b:] *= _ramp(b)[::-1]
    return seg


def cut_tail(seg: np.ndarray, sr: int, cut: float, fade: float = 0.03) -> np.ndarray:
    """`cut` is in seconds from the start of `seg`. Same length in, same length out."""
    seg = seg.copy()
    c = int(cut * sr)
    f = int(fade * sr)
    if c >= len(seg):
        return seg
    end = min(len(seg), c + f)
    seg[c:end] *= _ramp(end - c)[::-1]
    seg[end:] = 0.0
    return seg
