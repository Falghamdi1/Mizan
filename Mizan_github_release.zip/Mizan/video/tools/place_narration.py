"""Rebuild narration.wav from repaired takes with the original video's exact sample layout and gain.

    python video/tools/place_narration.py --original-takes video/narration/takes --repaired-takes video/narration/takes_clean \
        --original video/narration/narration.wav --timeline video/narration/timeline.json --out-dir video/narration/clean

Repairs must not move anything on screen. assemble_narration.py lays lines out back to back with fixed gaps, so a line
whose tempo-stretched length changes by a few milliseconds (the tempo filter does that when a take's end changes) would
shift every later line. Here the layout is recomputed from the ORIGINAL takes (same constants, same arithmetic), checked
sample-for-sample against the original narration.wav, and each repaired line is placed at its original sample with its
original length (only trailing silence is padded or trimmed). The original gain is reused, so loudness is unchanged.
"""
import argparse
import json
import shutil
import sys
from pathlib import Path

import numpy as np
import soundfile as sf

sys.path.insert(0, str(Path(__file__).resolve().parent))
import assemble_narration as an  # noqa: E402


def layout(takes: Path, tl: dict) -> tuple[np.ndarray, list[tuple[str, int, int]]]:
    """Unnormalised narration and (id, start, length) per line, exactly as assemble_narration.py builds them."""
    parts = [np.zeros(int(an.LEAD_IN * an.SR), np.float32)]
    pos, spans, prev = len(parts[0]), [], None
    for l in tl["lines"]:
        if prev is not None and l["scene"] != prev:
            g = np.zeros(int(an.GAP_SCENE.get(l["scene"], 0.9) * an.SR), np.float32)
            parts.append(g)
            pos += len(g)
        x = an.load(takes / f"{l['id']}.wav", tl["tempo"])
        spans.append((l["id"], pos, len(x)))
        parts.append(x)
        pos += len(x)
        g = np.zeros(int((an.GAP_IN_SCENE + an.EXTRA_AFTER.get(l["id"], 0.0)) * an.SR), np.float32)
        parts.append(g)
        pos += len(g)
        prev = l["scene"]
    parts.append(np.zeros(int(an.TAIL * an.SR), np.float32))
    return np.concatenate(parts), spans


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--original-takes", required=True)
    ap.add_argument("--repaired-takes", required=True)
    ap.add_argument("--original", required=True)
    ap.add_argument("--timeline", required=True)
    ap.add_argument("--out-dir", required=True)
    a = ap.parse_args()
    tl = json.loads(Path(a.timeline).read_text(encoding="utf-8"))
    orig, _ = sf.read(a.original, dtype="float32")
    raw, spans = layout(Path(a.original_takes), tl)
    gain = 0.89 / float(np.abs(raw).max())
    rebuilt = raw * gain
    err = float(np.abs(rebuilt[: len(orig)] - orig).max()) if len(rebuilt) == len(orig) else None
    print(f"layout check: rebuilt {len(rebuilt)} samples vs original {len(orig)}; max sample difference {err}")
    if err is None or err > 1e-4:
        raise SystemExit("the recomputed layout does not reproduce the original narration; not writing anything")
    out = np.zeros_like(orig)
    changes = []
    for lid, s, n in spans:
        x = an.load(Path(a.repaired_takes) / f"{lid}.wav", tl["tempo"])
        if len(x) > n and np.abs(x[n:]).max() > 1e-3:
            raise SystemExit(f"{lid}: trimming to the original length would cut sound")
        out[s:s + n] = (x[:n] if len(x) >= n else np.pad(x, (0, n - len(x)))) * gain
        if len(x) != n:
            changes.append(f"{lid} {(len(x) - n) / an.SR * 1000:+.1f} ms")
    od = Path(a.out_dir)
    od.mkdir(parents=True, exist_ok=True)
    sf.write(str(od / "narration.wav"), out, an.SR)
    shutil.copy2(a.timeline, od / "timeline.json")
    print(f"wrote {od / 'narration.wav'}: {len(out)} samples (identical length), original gain {gain:.4f}")
    print("stretched-length differences absorbed in trailing silence:", ", ".join(changes) or "none")


if __name__ == "__main__":
    main()
