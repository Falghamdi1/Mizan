"""Generate video/composition/index.html (HyperFrames) from the narration timeline and the captured footage.

    python video/tools/build_composition.py

Every scene is timed from video/narration/timeline.json (line starts, ends and the pauses inside each line), so the
visuals follow the voice. Numbers on screen are written here once, each with its source in video/README.md.
"""
import json
import shutil
from html import escape
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
COMP = ROOT / "composition"
TL = json.loads((ROOT / "narration" / "timeline.json").read_text(encoding="utf-8"))
LINES = {l["id"]: l for l in TL["lines"]}
TTS = {l["id"]: l["tts"] for l in json.loads((ROOT / "narration" / "lines.json").read_text(encoding="utf-8"))["lines"]}
PLACE = json.loads((COMP / "assets" / "shots" / "placement.json").read_text(encoding="utf-8"))
T = TL["duration"]
FPS = 30
FRAME = (120, 118, 1680, 812)          # x, y, w, h of the footage window

C_STD, C_MZ, C_GOLD = "#a3b0c4", "#6cc4bd", "#e9c46a"


def S(i):
    return LINES[i]["start"]


def E(i):
    return LINES[i]["end"]


def cue(i, phrase=None, frac=None):
    """When the narrator reaches `phrase` in line i: its share of the spoken text, snapped to the nearest real pause."""
    ln = LINES[i]
    dur = ln["end"] - ln["start"]
    if phrase is not None:
        text = TTS[i]
        k = text.find(phrase)
        if k < 0:
            raise KeyError(f"{phrase!r} not in {i}")
        frac = k / len(text)
    guess = frac * dur
    near = [p for p in ln.get("pauses", []) if abs(p - guess) < 0.9]
    t = (min(near, key=lambda p: abs(p - guess)) + 0.08) if near else guess
    return round(ln["start"] + t, 3)


def r(x):
    return round(x, 3)


# ---------------------------------------------------------------------------------------------------------------------
# timeline (JavaScript) helpers
# ---------------------------------------------------------------------------------------------------------------------
JS: list[str] = []


def j(s):
    JS.append(s)


def fin(sel, t, d=0.7, y=26, x=0, ease="power3.out"):
    j(f"tl.fromTo({sel!r}, {{opacity: 0, y: {y}, x: {x}}}, {{opacity: 1, y: 0, x: 0, duration: {d}, ease: '{ease}'}}, {r(t)});")


def fout(sel, t, d=0.45):
    j(f"tl.to({sel!r}, {{opacity: 0, duration: {d}, ease: 'power2.in'}}, {r(t)});")


def show(sel, t):
    j(f"tl.set({sel!r}, {{opacity: 1}}, {r(t)});")


def hide(sel, t):
    j(f"tl.set({sel!r}, {{opacity: 0}}, {r(t)});")


def cam_xy(size, region):
    """Transform that fits `region` (x, y, w, h in image pixels) into the footage window, centred."""
    fw, fh = FRAME[2], FRAME[3]
    x, y, w, h = region
    s = min(fw / w, fh / h)
    tx = -x * s + (fw - w * s) / 2
    ty = -y * s + (fh - h * s) / 2
    return round(tx, 2), round(ty, 2), round(s, 5)


def cam_set(sel, size, region, t):
    x, y, s = cam_xy(size, region)
    j(f"tl.set({sel!r}, {{x: {x}, y: {y}, scale: {s}}}, {r(t)});")


def cam_to(sel, size, region, t, d=1.4, ease="power2.inOut"):
    x, y, s = cam_xy(size, region)
    j(f"tl.to({sel!r}, {{x: {x}, y: {y}, scale: {s}, duration: {d}, ease: '{ease}'}}, {r(t)});")


def count(sel, t, to, d=1.2, decimals=0, prefix="", suffix="", sep=True):
    j(f"(function(){{ var o = {{v: 0}}; var el = document.querySelector({sel!r}); "
      f"tl.to(o, {{v: {to}, duration: {d}, ease: 'power2.out', onUpdate: function(){{ var v = o.v.toFixed({decimals}); "
      f"if ({'true' if sep else 'false'}) v = Number(v).toLocaleString('en-US', {{minimumFractionDigits: {decimals}, maximumFractionDigits: {decimals}}}); "
      f"el.textContent = {prefix!r} + v + {suffix!r}; }} }}, {r(t)}); }})();")


def en(text, cls="en"):
    return f'<span class="{cls}" dir="ltr">{escape(text)}</span>'


def ar(text):
    return escape(text)


# ---------------------------------------------------------------------------------------------------------------------
# scene windows
# ---------------------------------------------------------------------------------------------------------------------
X = 0.5   # crossfade overlap
SCENES = [
    ("s1", 0.0, S("b1") - 0.6),
    ("s2", S("b1") - 0.6, S("c1") - 0.5),
    ("s3", S("c1") - 0.5, S("d1") - 1.2),
    ("s4", S("d1") - 1.2, S("e1") - 0.45),
    ("s5", S("e1") - 0.45, S("f1") - 0.5),
    ("r1", S("f1") - 0.5, S("f2") - 0.4),
    ("r2", S("f2") - 0.4, S("f4") - 0.4),
    ("r3", S("f4") - 0.4, S("f5") - 0.4),
    ("r4", S("f5") - 0.4, S("f6") - 0.4),
    ("r5", S("f6") - 0.4, S("g1") - 0.6),
    ("s7", S("g1") - 0.6, T),
]
WIN = {k: (a, b) for k, a, b in SCENES}
CHAPTERS = [("01", "المشكلة", "The problem", "s1"), ("02", "الفكرة", "The idea", "s2"), ("03", "كيف يعمل", "How it works", "s3"),
            ("04", "المنتج", "The product", "s4"), ("05", "Mizan Insights", "", "s5"), ("06", "النتائج", "Results", "r1"),
            ("07", "الخلاصة", "Takeaway", "s7")]


def clip(sid, inner, track):
    a, b = WIN[sid]
    end = b + (X if sid != "s7" else 0)
    return (f'<div class="clip" id="{sid}" data-start="{r(a)}" data-duration="{r(end - a)}" data-track-index="{track}">'
            f'<div class="inner" id="{sid}-in">{inner}</div></div>')


def scene_fades():
    for sid, a, b in SCENES:
        if sid != "s1":
            j(f"tl.fromTo('#{sid}-in', {{opacity: 0}}, {{opacity: 1, duration: 0.45, ease: 'power1.out'}}, {r(a + 0.32)});")
        if sid != "s7":
            j(f"tl.to('#{sid}-in', {{opacity: 0, duration: 0.32, ease: 'power1.in'}}, {r(b)});")


# ---------------------------------------------------------------------------------------------------------------------
# the logo (the app's own balance-scale mark, drawn larger; beam and pans can settle)
# ---------------------------------------------------------------------------------------------------------------------
def logo(idp, w=300):
    return (f'<svg id="{idp}" class="logo" viewBox="0 0 40 28" width="{w}" height="{round(w * 0.7)}" aria-hidden="true">'
            f'<rect x="19" y="5" width="2" height="19" rx="1" fill="#edece7" opacity=".45"/>'
            f'<rect x="13" y="24" width="14" height="2.4" rx="1.2" fill="#edece7" opacity=".45"/>'
            f'<g id="{idp}-beam" class="beam">'
            f'<line id="{idp}-bar" x1="5" y1="5" x2="35" y2="5" stroke="{C_MZ}" stroke-width="2.4" stroke-linecap="round" pathLength="1"/>'
            f'<path d="M6 5 2.5 15M6 5l3.5 10M34 5l-3.5 10M34 5l3.5 10" stroke="#edece7" stroke-width="1" opacity=".5"/>'
            f'<path d="M1.5 15h9a4.5 4.5 0 0 1-9 0z" fill="none" stroke="{C_STD}" stroke-width="1.6"/>'
            f'<path d="M29.5 15h9a4.5 4.5 0 0 1-9 0z" fill="rgba(108,196,189,.25)" stroke="{C_MZ}" stroke-width="1.6"/></g>'
            f'<circle cx="20" cy="5" r="2.6" fill="{C_MZ}"/></svg>')


def kash(text):
    """Colour every kashida (U+0640) so the padding is visible; the word shapes are not touched."""
    return "".join(f'<span class="k">{c}</span>' if c == "ـ" else escape(c) for c in text)


# ---------------------------------------------------------------------------------------------------------------------
# scenes
# ---------------------------------------------------------------------------------------------------------------------
def scene_hook():
    off, ext = "لا تزيد مدة سريان الترخيص", "ال تزيد مدة سريان الترخيص"
    k_line = "يجـب أن يحتـوي الترخيـص علـى بيانـات المرخـص لـه"
    html = f"""
<div class="abs center" id="h-src" style="top:250px">{ar("لائحة الإرشاد السياحي · صفحة 8")} <span class="dot">·</span> {en("Tour Guide Regulations, page 8", "en muted")}</div>
<div class="abs center tag teal" id="h-tag-off" style="top:330px">{ar("النص الرسمي")} {en("official text", "en")}</div>
<div class="abs center tag gold" id="h-tag-ext" style="top:330px">{ar("كما يصل بعد استخراجه من PDF")} {en("as extracted from the PDF", "en")}</div>
<div class="abs center hook" id="h-off" style="top:392px"><span class="ok">لا</span> {ar(off[3:])}</div>
<div class="abs center hook" id="h-ext" style="top:392px"><span class="bad">ال</span> {ar(ext[3:])}</div>
<div class="abs" id="h-scan" style="top:380px; left:1500px"></div>
<div class="abs center" id="h-lost" style="top:600px"><span class="pill gold">{ar("ضاعت أداة النفي")} {en("the negation is gone")}</span></div>
<div class="abs center muted" id="k-cap" style="top:200px">{ar("سطرٌ آخر من الصفحة نفسها، كما استُخرج")} <span class="dot">·</span> {en("another line from the same page, as extracted", "en muted")}</div>
<div class="abs center hook2" id="k-line" style="top:262px">{kash(k_line)}</div>
<div class="abs" id="k-bar" style="top:520px; left:310px; width:1300px">
  <div class="kb-top"><span class="kb-big" id="k-pct">0%</span><span class="kb-lbl">{ar("من رموز النص المستخرج حروفُ تطويل")} {en("of the extracted text's tokens are kashida", "en muted")}</span></div>
  <div class="kb-track"><div class="kb-fill" id="k-fill"></div></div>
  <div class="kb-foot mono">21,109 / 71,046 tokens · 8 Ministry PDFs · Qwen3 tokenizer</div>
</div>"""
    a1, a3 = S("a1"), S("a3")
    fin("#h-src", a1 - 0.3, 0.8, 14)
    fin("#h-tag-off", a1 + 0.2, 0.7, 12)
    fin("#h-off", a1 + 0.1, 1.0, 30)
    swap = cue("a2", "صارت")
    j(f"tl.fromTo('#h-scan', {{opacity: 0, x: 0}}, {{opacity: 1, duration: 0.15}}, {r(swap - 0.55)});")
    j(f"tl.to('#h-scan', {{x: -1080, duration: 0.75, ease: 'power1.inOut'}}, {r(swap - 0.5)});")
    j(f"tl.to('#h-scan', {{opacity: 0, duration: 0.2}}, {r(swap + 0.2)});")
    fout("#h-off", swap - 0.2, 0.35)
    fout("#h-tag-off", swap - 0.2, 0.3)
    j(f"tl.fromTo('#h-ext', {{opacity: 0}}, {{opacity: 1, duration: 0.35}}, {r(swap - 0.1)});")
    fin("#h-tag-ext", swap + 0.05, 0.5, 10)
    fin("#h-lost", cue("a2", "فضاعَ") - 0.1, 0.6, 16)
    for s in ("#h-src", "#h-tag-ext", "#h-ext", "#h-lost"):
        fout(s, a3 - 0.55, 0.4)
    fin("#k-cap", a3 - 0.25, 0.6, 10)
    fin("#k-line", a3 - 0.15, 0.8, 20)
    j(f"tl.to('#k-line .k', {{color: '{C_GOLD}', textShadow: '0 0 18px rgba(233,196,106,.65)', duration: 0.6, stagger: 0.04}}, {r(a3 + 0.5)});")
    fin("#k-bar", a3 + 0.7, 0.6, 18)
    third = cue("a3", "ثُلثِ")
    j(f"tl.fromTo('#k-fill', {{width: '0%'}}, {{width: '29.7%', duration: 1.1, ease: 'power2.out'}}, {r(third - 0.2)});")
    count("#k-pct", third - 0.2, 29.7, 1.1, 1, "", "%", False)
    return html


def scene_reveal():
    chips = [("يجيب من الوثائق الرسمية", "answers from the official documents"), ("يستشهد بالملف والصفحة", "cites file and page"),
             ("يعمل محليًّا بنماذج مفتوحة", "runs locally on open models")]
    rows = [("الوثائق", "documents"), ("الأسئلة", "questions"), ("النماذج", "models"), ("الموجِّه", "prompt")]
    row_html = "".join(
        f'<div class="crow" id="cr{i}" style="top:{392 + i * 74}px"><span class="cv std">=</span>'
        f'<span class="cl">{ar(a)} {en(e, "en muted")}</span><span class="cv mz">=</span></div>' for i, (a, e) in enumerate(rows))
    html = f"""
<div class="abs center" id="rv-logo-wrap" style="top:150px">{logo("rv-logo", 330)}</div>
<div class="abs center" id="rv-name" style="top:385px"><span class="name">مِيزان</span></div>
<div class="abs center" id="rv-latin" style="top:585px"><span class="latin" dir="ltr">MIZAN</span></div>
<div class="abs center" id="rv-tag" style="top:660px"><span class="tagline">{ar("نظام ذكاء اصطناعي توليدي متكامل، يجيب من وثائق لوائح السياحة السعودية")}</span></div>
<div class="abs center" id="rv-tag-en" style="top:728px">{en("A complete Gen AI system that answers from Saudi tourism-regulation documents", "en muted big")}</div>
<div class="abs center" id="rv-chips" style="top:812px">{"".join(f'<span class="chip" id="rvc{i}">{ar(a)} {en(e, "en muted")}</span>' for i, (a, e) in enumerate(chips))}</div>
<div class="abs" id="cmp" style="top:0; left:0; width:1920px; height:1080px">
  <div class="chead std" id="ch-std" style="top:300px; left:1240px">□ {ar("القياسي")} {en("Standard", "en")}</div>
  <div class="chead mz" id="ch-mz" style="top:300px; left:180px">◆ {ar("ميزان-لايت")} {en("Mizan-lite", "en")}</div>
  {row_html}
  <div class="crow diff" id="cr-diff" style="top:700px"><span class="cv std big">{ar("ينظّف المسافات فقط")} {en("whitespace only", "en")}</span>
  <span class="cl">{ar("معالجة النص قبل الفهرسة")} {en("text preprocessing", "en muted")}</span>
  <span class="cv mz big">{ar("يُصلح تلف الاستخراج")} {en("repairs extraction damage", "en")}</span></div>
  <div class="abs center" id="cr-only" style="top:842px"><span class="pill gold">{ar("الفرق الوحيد")} {en("the only difference")}</span></div>
</div>"""
    b1, b2 = S("b1"), S("b2")
    j(f"tl.fromTo('#rv-logo-bar', {{strokeDasharray: 1, strokeDashoffset: 1}}, {{strokeDashoffset: 0, duration: 0.9, ease: 'power2.inOut'}}, {r(b1 - 0.45)});")
    fin("#rv-logo-wrap", b1 - 0.5, 0.9, 20)
    j(f"tl.fromTo('#rv-logo-beam', {{rotation: -7, svgOrigin: '20 5'}}, {{rotation: 0, svgOrigin: '20 5', duration: 1.6, ease: 'elastic.out(1, 0.55)'}}, {r(b1 - 0.1)});")
    fin("#rv-name", b1 + 0.15, 0.9, 30)
    fin("#rv-latin", b1 + 0.45, 0.8, 12)
    fin("#rv-tag", cue("b1", "نظامَ"), 0.8, 18)
    fin("#rv-tag-en", cue("b1", "نظامَ") + 0.25, 0.8, 14)
    for i in range(3):
        fin(f"#rvc{i}", cue("b1", "يُجيبُ") + 0.2 + i * 0.22, 0.6, 14)
    for s in ("#rv-name", "#rv-latin", "#rv-tag", "#rv-tag-en", "#rv-chips"):
        fout(s, b2 - 0.5, 0.4)
    j(f"tl.to('#rv-logo-wrap', {{y: -95, scale: 0.62, duration: 0.8, ease: 'power3.inOut'}}, {r(b2 - 0.45)});")
    fin("#ch-std", b2 - 0.1, 0.6, 14)
    fin("#ch-mz", b2 + 0.05, 0.6, 14)
    same = cue("b2", "بالوثائقِ")
    for i in range(4):
        fin(f"#cr{i}", same - 0.2 + i * 0.28, 0.5, 12)
    only = cue("b2", "والفرقُ")
    fin("#cr-diff", only - 0.1, 0.7, 18)
    fin("#cr-only", only + 0.5, 0.6, 12)
    j(f"tl.to('#rv-logo-beam', {{rotation: 4, svgOrigin: '20 5', duration: 1.2, ease: 'power2.inOut'}}, {r(only + 0.2)});")
    return html


def scene_pipeline():
    chips = [("إصلاح «لا»", "lam-alef"), ("حذف التطويل", "kashida"), ("الرموز الخفية", "invisible marks"),
             ("توحيد Unicode", "NFKC"), ("الأرقام والحروف", "digits, letter forms")]
    nodes = [("تقطيع", "Chunking", "600 chars · overlap 100"), ("Qwen3-Embedding-0.6B", "يجد 20 مقطعًا مرشّحًا", "20 candidates"),
             ("Qwen3-Reranker-0.6B", "يختار أفضل 4", "keeps the best 4"), ("Qwen3-4B-Instruct", "النموذج الأساسي", "base model · 4-bit · local")]
    nh = []
    for i, (a, b, c) in enumerate(nodes):
        x = 1200 - 250 - i * 282
        top = f'<div class="n-t mono">{escape(a)}</div>' if i else f'<div class="n-t">{ar(a)} {en(b, "en muted")}</div>'
        mid = f'<div class="n-m">{ar(b)}</div>' if i else ""
        nh.append(f'<div class="node" id="n{i}" style="left:{x}px; top:300px">{top}{mid}<div class="n-s en muted" dir="ltr">{escape(c)}</div></div>')
        if i:
            nh.append(f'<div class="arrow" id="na{i}" style="left:{x + 250}px; top:376px"></div>')
    html = f"""
<div class="lane std" id="ln-std" style="left:1290px; top:192px; width:510px; height:214px">
  <div class="l-h">□ {ar("القياسي")} {en("Standard", "en")}</div>
  <div class="l-b">{ar("ينظّف المسافات فقط")} {en("whitespace only", "en muted")}</div>
  <div class="l-x">{ar("ال تزيد")} · {kash("يجـب أن يحتـوي")}</div>
</div>
<div class="lane mz" id="ln-mz" style="left:1290px; top:424px; width:510px; height:452px">
  <div class="l-h">◆ {ar("ميزان-لايت")} {en("Mizan-lite", "en")}</div>
  <div class="l-chips">{"".join(f'<span class="chip sm" id="pc{i}">{ar(a)} {en(b, "en muted")}</span>' for i, (a, b) in enumerate(chips))}</div>
  <div class="l-x" id="mz-bad">{ar("ال تزيد")} · {kash("يجـب أن يحتـوي")}</div>
  <div class="l-x good" id="mz-good">{ar("لا تزيد")} · {ar("يجب أن يحتوي")}</div>
</div>
<div class="bus" id="bus" style="left:1236px; top:298px; height:322px"></div>
<div class="abs" id="sh-head" style="left:104px; top:206px; width:1096px">{ar("بعدها يتطابق المساران")} {en("from here, identical in both pipelines · one index per pipeline", "en muted")}</div>
{"".join(nh)}
<div class="card" id="pr-card" style="left:640px; top:512px; width:560px; height:330px">
  <div class="c-h">{ar("الموجِّه")} {en("prompt v1 · our design · 4 versions compared", "en muted")}</div>
  <div class="q">«{ar("اعتمادًا على السياق المرفق فقط")}»</div>
  <div class="q">«{ar("اذكر المصدر … بالصيغة [اسم الملف، صفحة N]")}»</div>
  <div class="q">«{ar("لا يحتوي السياق المتاح على إجابة هذا السؤال")}»</div>
</div>
<div class="card" id="ans-card" style="left:104px; top:512px; width:506px; height:330px">
  <div class="c-h">{ar("الإجابة مع الاستشهاد")} {en("answer + citation", "en muted")}</div>
  <div class="cite">[Hospitality-Facilities-Regulations-Ar-V012.pdf، صفحة 13]</div>
  <div class="c-ok">✓ {ar("الكود يتحقق أن الصفحة كانت ضمن ما رآه النموذج")}</div>
  <div class="c-ok en muted" dir="ltr">code checks the cited page was among the passages shown</div>
</div>"""
    c1, c2, c3 = S("c1"), S("c2"), S("c3")
    fin("#ln-std", c1 - 0.2, 0.7, 20)
    fin("#ln-mz", cue("c1", "أمّا") - 0.2, 0.7, 20)
    rep = cue("c1", "فيُصلِحُ")
    chip_t = [rep + i * 0.32 for i in range(5)]
    for i, t in enumerate(chip_t):
        fin(f"#pc{i}", t - 0.1, 0.45, 10)
    fout("#mz-bad", chip_t[-1] + 0.5, 0.4)
    j(f"tl.fromTo('#mz-good', {{opacity: 0}}, {{opacity: 1, duration: 0.5}}, {r(chip_t[-1] + 0.6)});")
    j(f"tl.fromTo('#bus', {{scaleY: 0, transformOrigin: '50% 0%'}}, {{scaleY: 1, duration: 0.5, ease: 'power2.out'}}, {r(c2 - 0.3)});")
    fin("#sh-head", c2 - 0.1, 0.6, 12)
    nt = [c2 + 0.2, cue("c2", "نموذجُ تضمينٍ"), cue("c2", "ومُعيدُ ترتيبٍ"), cue("c2", "والنموذجُ")]
    for i, t in enumerate(nt):
        fin(f"#n{i}", t - 0.1, 0.55, 0, 30)
        if i:
            j(f"tl.fromTo('#na{i}', {{scaleX: 0, transformOrigin: '100% 50%'}}, {{scaleX: 1, duration: 0.35}}, {r(t - 0.25)});")
        j(f"tl.fromTo('#n{i}', {{borderColor: '{C_MZ}'}}, {{borderColor: '#2c3331', duration: 1.2, immediateRender: false}}, {r(t + 0.5)});")
    fin("#pr-card", c3 - 0.15, 0.7, 20)
    fin("#ans-card", cue("c3", "أو يعتذر") - 0.2, 0.7, 20)
    return html


def footage_frame(fid, layers, label=""):
    return (f'<div class="frame" id="{fid}" style="left:{FRAME[0]}px; top:{FRAME[1]}px; width:{FRAME[2]}px; height:{FRAME[3]}px">'
            f'{layers}</div>' + (f'<div class="flabel" id="{fid}-lbl">{label}</div>' if label else ""))


def cam_layer(cid, img, size, extra=""):
    return (f'<div class="cam" id="{cid}" style="width:{size[0]}px; height:{size[1]}px">'
            f'<img src="assets/shots/{img}.jpg" width="{size[0]}" height="{size[1]}" alt="">{extra}</div>')


def box(bid, x, y, w, h, color=C_MZ):
    return f'<div class="hl" id="{bid}" style="left:{x}px; top:{y}px; width:{w}px; height:{h}px; border-color:{color}"></div>'


def scene_demo():
    sz = PLACE["sizes"]
    home, ready, loading, answers, enl = (tuple(sz[k]) for k in ("home", "ready", "loading", "answers", "en_light"))
    ty = PLACE["typing"]
    frames = "".join(f'<img class="tf" id="tf{i}" src="assets/typing/{i:04d}.jpg" style="left:{ty["x"]}px; top:{ty["y"]}px" '
                     f'width="{ty["w"]}" height="{ty["h"]}" alt="">' for i in range(ty["frames"]))
    layers = (cam_layer("cam-home", "home", home, frames)
              + cam_layer("cam-ready", "ready", ready, box("hl-run", 1640, 1396, 860, 108, C_MZ))
              + cam_layer("cam-load", "loading", loading)
              + cam_layer("cam-ans", "answers", answers,
                          box("hl-std", 1102, 452, 1050, 120, "#e5806b") + box("hl-stdx", 1102, 760, 1050, 50, "#e5806b")
                          + box("hl-mz", 140, 452, 912, 120, C_MZ) + box("hl-gold", 22, 1282, 1042, 156, C_MZ)))
    label = (f'<span class="live">●</span> {ar("التطبيق الحقيقي، يعمل محليًّا")} '
             f'{en("the real app, running locally · Ollama + open Qwen3 models · 8 documents · 159 pages", "en muted")}')
    html = footage_frame("fr4", layers, label) + f"""
<div class="note" id="n-std" style="right:136px; top:134px"><span class="sw std"></span>{ar("القياسي: 60 يومًا، من لائحة أخرى (ص 6)")} {en("Standard: 60 days, from another regulation (p. 6)", "en muted")}</div>
<div class="note" id="n-mz" style="left:136px; top:134px"><span class="sw mz"></span>{ar("ميزان-لايت: 180 يومًا، من الصفحة الصحيحة (ص 13)")} {en("Mizan-lite: 180 days, from the right page (p. 13)", "en muted")}</div>
<div class="note" id="n-gold" style="left:136px; top:134px"><span class="sw mz"></span>{ar("المقطع الذي يحمل الدليل المرجعي، في المرتبة 3")} {en("the passage holding the reference evidence, rank 3", "en muted")}</div>"""
    d2 = S("d2")
    a = WIN["s4"][0]
    fin("#fr4", a + 0.05, 0.8, 24)
    fin("#fr4-lbl", a + 0.4, 0.6, 10)
    cam_set("#cam-home", home, (0, 0, 2880, 1800), a)
    ask = S("d1")
    cam_to("#cam-home", home, (1180, 360, 1420, 1060), ask - 0.55, 0.9)
    t0 = ask + 0.4
    show("#tf0", t0 - 0.2)
    fps = 24
    for i in range(1, ty["frames"]):
        show(f"#tf{i}", t0 + i / fps)
        hide(f"#tf{i - 1}", t0 + i / fps + 0.01)
    t_typed = t0 + ty["frames"] / fps
    # the evidence phrase was then entered (real, next capture) and the comparison started
    cam_set("#cam-ready", ready, (1180, 360, 1420, 1060), t_typed + 0.2)
    j(f"tl.fromTo('#cam-ready', {{opacity: 0}}, {{opacity: 1, duration: 0.35}}, {r(t_typed + 0.2)});")
    cam_to("#cam-ready", ready, (1180, 640, 1420, 1000), t_typed + 0.45, 0.8)
    j(f"tl.fromTo('#hl-run', {{opacity: 0, scale: 1.08}}, {{opacity: 1, scale: 1, duration: 0.35, ease: 'power2.out'}}, {r(t_typed + 0.95)});")
    t_load = t_typed + 1.55
    cam_set("#cam-load", loading, (300, 120, 2280, 760), t_load)
    show("#cam-load", t_load)
    hide("#cam-ready", t_load + 0.02)
    hide("#cam-home", t_load + 0.02)
    t_ans = t_load + 0.7
    cam_set("#cam-ans", answers, (0, 0, 2168, 980), t_ans)
    show("#cam-ans", t_ans)
    hide("#cam-load", t_ans + 0.02)
    cam_to("#cam-ans", answers, (1080, 330, 1088, 520), d2 - 0.2, 1.2)
    j(f"tl.fromTo(['#hl-std', '#hl-stdx'], {{opacity: 0}}, {{opacity: 1, duration: 0.4, stagger: 0.3}}, {r(d2 + 0.9)});")
    fin("#n-std", d2 + 1.1, 0.5, 10)
    mz = cue("d2", "أمّا")
    fout("#n-std", mz - 0.3, 0.3)
    fout("#fr4-lbl", d2 - 0.2, 0.3)
    cam_to("#cam-ans", answers, (0, 330, 1088, 520), mz - 0.2, 1.2)
    j(f"tl.fromTo('#hl-mz', {{opacity: 0}}, {{opacity: 1, duration: 0.4}}, {r(mz + 0.9)});")
    fin("#n-mz", mz + 1.0, 0.5, 10)
    t_gold = max(mz + 2.6, E("d2") - 1.4)
    fout("#n-mz", t_gold - 0.2, 0.3)
    cam_to("#cam-ans", answers, (0, 880, 1088, 640), t_gold, 1.1)
    j(f"tl.fromTo('#hl-gold', {{opacity: 0}}, {{opacity: 1, duration: 0.4}}, {r(t_gold + 0.8)});")
    fin("#n-gold", t_gold + 0.9, 0.5, 10)
    return html


def crop_card(cid, img, size, region, w, label_ar, label_en):
    x, y, cw, ch = region
    s = w / cw
    h = round(ch * s)
    return (f'<div class="tri" id="{cid}">'
            f'<div class="tri-l">{ar(label_ar)}<div>{en(label_en, "en muted")}</div></div>'
            f'<div class="tri-img" style="width:{w}px; height:{h}px"><img src="assets/shots/{img}.jpg" '
            f'style="width:{round(size[0] * s)}px; height:{round(size[1] * s)}px; left:{round(-x * s)}px; top:{round(-y * s)}px" alt=""></div></div>')


def scene_insights():
    sz = PLACE["sizes"]
    ins = tuple(sz["insights"])
    layers = cam_layer("cam-ins", "insights", ins,
                       box("hl-facts", 18, 1494, 2058, 82) + box("hl-fchips", 1560, 706, 172, 62)
                       + box("hl-obs", 1060, 668, 1030, 104) + box("hl-prov", 1020, 1340, 1062, 94)
                       + box("hl-find", 18, 236, 2058, 238, C_GOLD) + box("hl-rec", 1050, 920, 1040, 200, C_GOLD))
    steps = [("الكود يحسب الحقائق", "code computes the facts (F1–F19)"), ("النموذج يكتب الشرح", "the model writes the explanation"),
             ("يُفحص الشرح قبل عرضه", "the explanation is checked before it is shown")]
    cap = "".join(f'<div class="step" id="st{i}"><span class="num">{i + 1}</span>{ar(a)} {en(b, "en muted")}</div>'
                  for i, (a, b) in enumerate(steps))
    tri = "".join([
        crop_card("tri0", "insights", ins, (18, 236, 2058, 238), 1300, "ميزان-لايت وحده وجد الدليل", "only Mizan-lite found the evidence"),
        crop_card("tri1", "ins_r5", tuple(sz["ins_r5"]), (18, 236, 2058, 288), 1300, "الإجابتان متطابقتان", "both gave the same answer"),
        crop_card("tri2", "ins_free", tuple(sz["ins_free"]), (18, 236, 2058, 238), 1300, "لا دليل مرجعي للسؤال", "no reference evidence"),
    ])
    html = footage_frame("fr5", layers) + f"""
<div class="steps" id="steps">{cap}</div>
<div class="abs" id="tri-wrap" style="left:140px; top:140px; width:1640px">
  <div class="tri-h">{ar("ثلاثة أسئلة حقيقية، والحكم نفسه: الأدلة غير كافية من سؤالٍ واحد")}</div>
  <div class="tri-h2">{en("Three real questions, one verdict: not enough evidence to judge from a single question", "en muted")}</div>
  <div class="tri-row">{tri}</div>
</div>"""
    e2 = S("e2")
    a = WIN["s5"][0]
    fin("#fr5", a + 0.05, 0.8, 24)
    cam_set("#cam-ins", ins, (0, 0, 2092, 1590), a)
    t_f, t_c = cue("e1", "بحقائقَ"), cue("e1", "ويُفحَصُ")
    t_m = max(t_f + 1.1, (t_f + t_c) / 2)
    cam_to("#cam-ins", ins, (0, 470, 2092, 1130), t_f - 0.3, 1.0)
    fin("#st0", t_f - 0.1, 0.5, 10)
    j(f"tl.fromTo(['#hl-facts', '#hl-fchips'], {{opacity: 0}}, {{opacity: 1, duration: 0.4, stagger: 0.25}}, {r(t_f + 0.4)});")
    fout("#hl-facts", t_m - 0.3, 0.3)
    fout("#hl-fchips", t_m - 0.3, 0.3)
    fin("#st1", t_m - 0.1, 0.5, 10)
    j(f"tl.fromTo('#hl-obs', {{opacity: 0}}, {{opacity: 1, duration: 0.4}}, {r(t_m + 0.4)});")
    cam_to("#cam-ins", ins, (600, 1150, 1492, 460), t_c - 0.3, 1.0)
    fout("#hl-obs", t_c - 0.3, 0.3)
    fin("#st2", t_c - 0.1, 0.5, 10)
    j(f"tl.fromTo('#hl-prov', {{opacity: 0}}, {{opacity: 1, duration: 0.4}}, {r(t_c + 0.4)});")
    fout("#steps", e2 - 0.35, 0.3)
    fout("#hl-prov", e2 - 0.35, 0.3)
    cam_to("#cam-ins", ins, (900, 560, 1192, 300), e2 - 0.3, 1.0)
    j(f"tl.to('#hl-obs', {{opacity: 1, duration: 0.4}}, {r(e2 + 0.5)});")
    judge = cue("e2", "لكنّه")
    fout("#hl-obs", judge - 0.3, 0.3)
    cam_to("#cam-ins", ins, (0, 200, 2092, 960), judge - 0.3, 1.1)
    j(f"tl.fromTo(['#hl-find', '#hl-rec'], {{opacity: 0}}, {{opacity: 1, duration: 0.4, stagger: 0.5}}, {r(judge + 0.5)});")
    t_tri = E("e2") + 0.35
    fout("#fr5", t_tri - 0.1, 0.4)
    fin("#tri-wrap", t_tri + 0.15, 0.6, 18)
    for i in range(3):
        fin(f"#tri{i}", t_tri + 0.3 + i * 0.22, 0.5, 16)
    return html


def eyebrow(idp):
    return (f'<div class="eyebrow" id="{idp}">{ar("الاختبار المغلق")} <span class="dot">·</span> '
            f'{en("frozen blind test · Qwen3-Embedding-0.6B + Qwen3-Reranker-0.6B · top 4 · one run", "en muted")}</div>')


def scene_r1():
    html = eyebrow("r1-eb") + f"""
<div class="abs center" id="r1-n" style="top:205px"><span class="mega teal" id="r1-num" dir="ltr">0</span></div>
<div class="abs center" id="r1-l" style="top:470px"><span class="h2">{ar("سؤالًا مغلقًا")}</span> {en("blind questions, written by the team", "en muted big")}</div>
<div class="abs" id="r1-pdf" style="left:1000px; top:600px; width:560px"><div class="blk"><div class="blk-n mono">93</div>
  <div class="blk-t">{ar("من ملفات PDF، منها 69 لها إجابة")}</div><div class="blk-e en muted" dir="ltr">PDF · 69 answerable</div></div></div>
<div class="abs" id="r1-web" style="left:360px; top:600px; width:560px"><div class="blk"><div class="blk-n mono">173</div>
  <div class="blk-t">{ar("من صفحات الويب، منها 140 لها إجابة")}</div><div class="blk-e en muted" dir="ltr">Web · 140 answerable</div></div></div>
<div class="abs center" id="r1-chips" style="top:812px"><span class="chip">{ar("جُمِّدت ببصمة SHA-256 قبل أي تشغيل")} {en("hashed and frozen before any run", "en muted")}</span><span class="chip">{ar("خطة تحليل مسجّلة مسبقًا")} {en("pre-registered analysis plan", "en muted")}</span></div>"""
    f1 = S("f1")
    fin("#r1-eb", WIN["r1"][0] + 0.2, 0.6, 10)
    fin("#r1-n", f1 - 0.1, 0.6, 20)
    count("#r1-num", f1, 266, 1.4, 0, "", "", False)
    fin("#r1-l", f1 + 0.6, 0.6, 14)
    fin("#r1-pdf", f1 + 1.2, 0.6, 16)
    fin("#r1-web", f1 + 1.45, 0.6, 16)
    fin("#r1-chips", f1 + 2.0, 0.6, 12)
    return html


def bar(bid, x, val, color, label):
    h = round(360 * val / 100)
    return (f'<div class="vbar" id="{bid}" style="left:{x}px; top:{770 - h}px; height:{h}px; background:{color}"></div>'
            f'<div class="vval mono" id="{bid}-v" style="left:{x - 20}px; top:{770 - h - 54}px">{val:.1f}%</div>'
            f'<div class="vlab" id="{bid}-l" style="left:{x - 30}px; top:782px">{label}</div>')


def scene_r2():
    html = eyebrow("r2-eb") + f"""
<div class="abs center" id="r2-t" style="top:150px"><span class="h2">{ar("وجد الدليل الصحيح ضمن أفضل 4 مقاطع")}</span>
  <div>{en("Found the right evidence in the top 4 passages (hit@4)", "en muted big")}</div></div>
<div class="legend" id="r2-leg" style="left:120px; top:162px"><span class="sw std"></span>{en("Standard", "en")} <span class="sw mz"></span>{en("Mizan-lite", "en")}</div>
<div class="axis" style="left:240px; top:770px; width:1440px"></div>
{bar("b-pdf-s", 1340, 68.1, C_STD, ar("القياسي"))}{bar("b-pdf-m", 1110, 79.7, C_MZ, ar("ميزان-لايت"))}
{bar("b-web-s", 650, 72.9, C_STD, ar("القياسي"))}{bar("b-web-m", 420, 73.6, C_MZ, ar("ميزان-لايت"))}
<div class="grp" id="g-pdf" style="left:1060px; top:828px; width:520px">{ar("ملفات PDF")} {en("n = 69", "mono muted")}</div>
<div class="grp" id="g-web" style="left:370px; top:828px; width:520px">{ar("الويب")} {en("n = 140", "mono muted")}</div>
<div class="delta" id="d-pdf" style="left:1080px; top:268px; width:480px"><div class="d-big teal" dir="ltr">+11.6 pts</div>
  <div class="d-ci mono">95% CI [+2.9, +21.7] · pre-specified setting</div></div>
<div class="delta" id="d-web" style="left:390px; top:268px; width:480px"><div class="d-big std" dir="ltr">+0.7 pts</div>
  <div class="d-ci mono">CI [+0.0, +2.1] · {ar("غير مميّز إحصائيًّا")}</div></div>
<div class="foot" id="d-titles" style="left:960px; top:878px; width:720px">{ar("مع عناوين اللوائح يضيق الفرق:")} <span class="num" dir="ltr">81.2% → 85.5% (+4.3)</span> {ar("غير مميّز")}
  {en("with regulation titles: 81.2% → 85.5%, +4.3, not distinguishable", "en muted")}</div>"""
    f2, f3 = S("f2"), S("f3")
    fin("#r2-eb", WIN["r2"][0] + 0.2, 0.5, 10)
    fin("#r2-t", f2 - 0.2, 0.6, 14)
    fin("#r2-leg", f2, 0.5, 10)
    fin("#g-pdf", f2 + 0.2, 0.5, 10)
    for b, t in (("b-pdf-s", cue("f2", "مقابلَ") - 0.4), ("b-pdf-m", f2 + 0.6)):
        j(f"tl.fromTo('#{b}', {{scaleY: 0, transformOrigin: '50% 100%'}}, {{scaleY: 1, duration: 0.9, ease: 'power3.out'}}, {r(t)});")
        fin(f"#{b}-v", t + 0.5, 0.4, 10)
        fin(f"#{b}-l", t, 0.4, 0)
    fin("#d-pdf", cue("f2", "مقابلَ") + 0.6, 0.6, 14)
    fin("#d-titles", cue("f2", "ويضيقُ") - 0.1, 0.6, 10)
    fin("#g-web", f3 - 0.1, 0.5, 10)
    for b, t in (("b-web-s", f3), ("b-web-m", f3 + 0.25)):
        j(f"tl.fromTo('#{b}', {{scaleY: 0, transformOrigin: '50% 100%'}}, {{scaleY: 1, duration: 0.9, ease: 'power3.out'}}, {r(t)});")
        fin(f"#{b}-v", t + 0.5, 0.4, 10)
        fin(f"#{b}-l", t, 0.4, 0)
    fin("#d-web", f3 + 0.9, 0.6, 14)
    return html


def scene_r3():
    html = eyebrow("r3-eb") + f"""
<div class="abs center" id="r3-n" style="top:190px"><span class="mega teal" id="r3-num" dir="ltr">0%</span></div>
<div class="abs center" id="r3-l" style="top:452px"><span class="h2">{ar("رموز التضمين في فهرس ملفات PDF")}</span>
  <div>{en("embedding tokens in the PDF index · 8 regulations", "en muted big")}</div></div>
<div class="hb-row" id="hb-s" style="top:620px"><span class="hb-name">□ {ar("القياسي")}</span><div class="hb-track"><div class="hb" id="hb-s-b" style="width:1100px; background:{C_STD}"></div></div><span class="hb-v mono">72,706</span></div>
<div class="hb-row" id="hb-m" style="top:700px"><span class="hb-name">◆ {ar("ميزان-لايت")}</span><div class="hb-track"><div class="hb" id="hb-m-b" style="width:{round(1100 * 49619 / 72706)}px; background:{C_MZ}"></div></div><span class="hb-v mono">49,619</span></div>
<div class="abs center" id="r3-sub" style="top:778px">{ar("ومدخل النموذج لكل سؤال من ملفات")} <span class="num" dir="ltr">PDF</span> <span class="dot">·</span> <span class="num" dir="ltr">1,333 → 1,122 tokens (−15.9%)</span>
  <div>{en("generator input per PDF question", "en muted")}</div></div>
<div class="abs center foot2" id="r3-dis" style="top:892px">{en("Same content in fewer tokens (kashida removed). No latency or cost saving is claimed. With chunk titles the index is −30.5%.", "en muted")}</div>"""
    f4 = S("f4")
    fin("#r3-eb", WIN["r3"][0] + 0.2, 0.5, 10)
    fin("#r3-n", f4 + 0.1, 0.5, 20)
    count("#r3-num", f4 + 0.2, 31.8, 1.2, 1, "−", "%", False)
    fin("#r3-l", f4 + 0.5, 0.6, 14)
    fin("#hb-s", f4 + 0.7, 0.5, 10)
    fin("#hb-m", f4 + 0.85, 0.5, 10)
    j(f"tl.fromTo('#hb-m-b', {{width: 1100}}, {{width: {round(1100 * 49619 / 72706)}, duration: 1.0, ease: 'power3.inOut'}}, {r(f4 + 1.15)});")
    fin("#r3-sub", f4 + 1.8, 0.6, 12)
    fin("#r3-dis", f4 + 2.2, 0.6, 8)
    return html


def interval_plot(pid, rows, lo, hi, margin=None, width=1140, left=300, top=420, row_h=150):
    """Differences with 95% intervals on a shared axis (points, Mizan-lite minus Standard)."""
    def X(v):
        return left + (v - lo) / (hi - lo) * width
    ticks = "".join(f'<div class="tick" style="left:{X(v):.0f}px; top:{top - 40}px">{v:+d}</div>' if v else
                    f'<div class="tick zero" style="left:{X(v):.0f}px; top:{top - 40}px">0</div>' for v in range(lo, hi + 1, 5))
    out = [f'<div class="ip" id="{pid}" dir="ltr"><div class="ip-axis" style="left:{left}px; width:{width}px; top:{top - 8}px"></div>{ticks}',
           f'<div class="ip-zero" style="left:{X(0):.0f}px; top:{top - 10}px; height:{row_h * len(rows) + 10}px"></div>']
    if margin is not None:
        out.append(f'<div class="ip-margin" style="left:{X(margin):.0f}px; top:{top - 10}px; height:{row_h * len(rows) + 10}px"></div>'
                   f'<div class="ip-mlab" style="left:{X(margin) - 150:.0f}px; top:{top + row_h * len(rows) + 6}px">no-loss margin −10</div>')
    for i, (rid, point, a, b, color, lab_ar, lab_en, badge, badge_color) in enumerate(rows):
        y = top + 50 + i * row_h
        out.append(f'<div class="ip-row" id="{rid}">'
                   f'<div class="ip-lab" style="left:{left}px; top:{y - 52}px; width:{width}px" dir="rtl">{ar(lab_ar)} <span class="en muted">{escape(lab_en)}</span></div>'
                   f'<div class="ip-ci" style="left:{X(a):.0f}px; width:{X(b) - X(a):.0f}px; top:{y}px; background:{color}"></div>'
                   f'<div class="ip-pt" style="left:{X(point) - 13:.0f}px; top:{y - 11}px; background:{color}"></div>'
                   f'<div class="ip-val mono" style="left:{X(point) - 160:.0f}px; top:{y + 20}px">{point:+.1f} [{a:+.1f}, {b:+.1f}]</div>'
                   f'<div class="ip-badge" style="left:{left + width + 30}px; top:{y - 26}px; border-color:{badge_color}; color:{badge_color}" dir="rtl">{badge}</div></div>')
    out.append("</div>")
    return "".join(out)


def scene_r4():
    rows = [("ip-web", 2.9, -0.7, 7.1, C_MZ, "الويب", "web, n = 140 · correct 77.9% → 80.7%", f'{ar("لا خسارة")} {en("no loss")}', C_MZ),
            ("ip-pdf", 1.4, -10.1, 13.0, C_STD, "ملفات PDF", "PDF, n = 69 · correct 75.4% → 76.8%", f'{ar("غير مميّز")} {en("not distinguishable")}', C_STD)]
    html = eyebrow("r4-eb") + f"""
<div class="abs center" id="r4-t" style="top:150px"><span class="h2">{ar("تقييم بشري أعمى للإجابات")}</span>
  <div>{en("Blind human grading: two team graders, a third settled 79 disagreements · κ 0.65 (PDF) / 0.79 (web)", "en muted")}</div></div>
<div class="abs" id="r4-ax" style="left:300px; top:322px; width:1140px; text-align:center">{en("difference in correct answers, points · Mizan-lite − Standard", "en muted")}</div>
{interval_plot("ip4", rows, -15, 15, margin=-10, top=430, row_h=170)}
<div class="abs center" id="r4-ref" style="top:842px">{ar("ورفضٌ صحيح لأسئلة PDF لا جواب لها في الوثائق:")} <span class="num" dir="ltr">20/24 → 23/24</span>
  <div>{en("correct refusals of unanswerable PDF questions", "en muted")}</div></div>"""
    f5 = S("f5")
    fin("#r4-eb", WIN["r4"][0] + 0.2, 0.5, 10)
    fin("#r4-t", f5 - 0.1, 0.6, 14)
    fin("#ip4", f5 + 0.4, 0.6, 10)
    fin("#r4-ax", f5 + 0.4, 0.6, 6)
    fin("#ip-web", cue("f5", "لا خسارةَ") - 0.1, 0.6, 10)
    fin("#ip-pdf", cue("f5", "وفرقُ") - 0.1, 0.6, 10)
    fin("#r4-ref", min(cue("f5", "وفرقُ") + 1.3, E("f5") - 0.4), 0.6, 10)
    return html


def scene_r5():
    rows = [("ip-dev", 22.2, 6.7, 37.8, C_GOLD, "أسئلة تطوير بأسلوب بيانات التدريب", "development questions in the training style, n = 45",
             f'{ar("تحسّن")} {en("gain")}', C_GOLD),
            ("ip-blind", 1.4, -7.2, 10.1, C_STD, "الأسئلة المغلقة من ملفات PDF", "blind PDF questions, n = 69",
             f'{ar("لم تثبت فائدة")} {en("not shown")}', C_STD)]
    html = eyebrow("r5-eb") + f"""
<div class="abs center" id="r5-t" style="top:150px"><span class="h2">{ar("ضبط نموذج التضمين بـ LoRA")}</span>
  <div>{en("LoRA fine-tuning of Qwen3-Embedding · hit@4 difference, points (adapter − base)", "en muted big")}</div></div>
{interval_plot("ip5", rows, -10, 40, top=430, row_h=170)}
<div class="abs center" id="r5-v" style="top:820px"><span class="pill">{ar("التحسّن لم يصمد على الأسئلة المغلقة، فبقي النموذج الأساسي")} {en("the gain did not hold on blind questions: base model kept")}</span></div>"""
    f6 = S("f6")
    fin("#r5-eb", WIN["r5"][0] + 0.2, 0.5, 10)
    fin("#r5-t", f6 - 0.1, 0.6, 14)
    fin("#ip5", f6 + 0.3, 0.6, 10)
    fin("#ip-dev", f6 + 0.6, 0.6, 10)
    fin("#ip-blind", f6 + 1.4, 0.6, 10)
    fin("#r5-v", cue("f6", "فأبقينا") - 0.1, 0.6, 10)
    return html


def scene_close():
    rows = [("✓", "يساعد حيث يتلف النص", "helps where the text is damaged: PDF retrieval +11.6 points", C_MZ),
            ("=", "ولا يضرّ حيث يسلم", "does no harm where it is clean: web, no difference", C_STD),
            (logo("tk-logo", 70), "والنتائج من اختبارٍ مغلق", "results from a frozen blind test, with 95% intervals", C_GOLD)]
    rh = "".join(f'<div class="take" id="tk{i}" style="top:{318 + i * 150}px"><span class="tk-i" style="color:{c}">{s}</span>'
                 f'<div class="tk-t"><div class="tk-a">{ar(a)}</div>{en(b, "en muted big")}</div></div>' for i, (s, a, b, c) in enumerate(rows))
    html = rh + f"""
<div class="abs center" id="cl-logo" style="top:170px">{logo("cl-svg", 230)}</div>
<div class="abs center" id="cl-motto" style="top:345px"><span class="motto">نقيسُ، ولا نفترض.</span></div>
<div class="abs center" id="cl-motto-en" style="top:500px">{en("We measure. We don't assume.", "en big2")}</div>
<div class="abs center" id="cl-team" style="top:640px"><span class="team">فيصل الغامدي · أحمد الفائدة · ناصر الخليوي</span></div>
<div class="abs center" id="cl-team-en" style="top:700px">{en("Faisal Alghamdi · Ahmad Al Faida · Nasser Alkhaliwi", "en muted big")}</div>
<div class="abs center" id="cl-org" style="top:770px">{ar("أكاديمية طويق · مشروع تخرّج في الذكاء الاصطناعي التوليدي · 2026")} {en("Tuwaiq Academy · Gen AI capstone", "en muted")}</div>
<div class="abs" id="cl-black" style="left:0; top:0; width:1920px; height:1080px; background:#000"></div>"""
    g1, g2 = S("g1"), S("g2")
    for i in range(3):
        fin(f"#tk{i}", g1 + 0.2 + i * 0.9, 0.6, 16)
    for i in range(3):
        fout(f"#tk{i}", g2 - 0.5, 0.35)
    fin("#cl-logo", g2 - 0.2, 0.8, 16)
    j(f"tl.fromTo('#cl-svg-beam', {{rotation: -6, svgOrigin: '20 5'}}, {{rotation: 0, svgOrigin: '20 5', duration: 1.8, ease: 'elastic.out(1, 0.5)'}}, {r(g2)});")
    fin("#cl-motto", g2, 0.9, 24)
    fin("#cl-motto-en", g2 + 0.5, 0.8, 14)
    fin("#cl-team", E("g2") + 0.3, 0.7, 12)
    fin("#cl-team-en", E("g2") + 0.5, 0.7, 12)
    fin("#cl-org", E("g2") + 0.8, 0.7, 10)
    j(f"tl.fromTo('#cl-black', {{opacity: 0}}, {{opacity: 1, duration: 1.0, ease: 'power1.in'}}, {r(T - 1.1)});")
    return html


# ---------------------------------------------------------------------------------------------------------------------
# chrome: chapter label, progress, subtitles
# ---------------------------------------------------------------------------------------------------------------------
def chrome():
    labels, segs = [], []
    for i, (num, a, e, sid) in enumerate(CHAPTERS):
        labels.append(f'<div class="chap" id="chap{i}"><span class="c-n mono">{num}</span><span class="c-a">{ar(a)}</span>'
                      + (en(e, "en muted") if e else "") + "</div>")
        segs.append(f'<div class="seg"><div class="seg-f" id="seg{i}"></div></div>')
    for i, (num, a, e, sid) in enumerate(CHAPTERS):
        start = WIN[sid][0]
        end = WIN[CHAPTERS[i + 1][3]][0] if i + 1 < len(CHAPTERS) else T
        j(f"tl.fromTo('#chap{i}', {{opacity: 0, y: 8}}, {{opacity: 1, y: 0, duration: 0.5, ease: 'power2.out'}}, {r(start + 0.25)});")
        if i + 1 < len(CHAPTERS):
            j(f"tl.to('#chap{i}', {{opacity: 0, duration: 0.3}}, {r(end - 0.05)});")
        j(f"tl.fromTo('#seg{i}', {{scaleX: 0, transformOrigin: '100% 50%'}}, {{scaleX: 1, duration: {r(end - start)}, ease: 'none'}}, {r(start)});")
    j(f"tl.to(['#top', '#prog'], {{opacity: 0, duration: 0.6}}, {r(S('g2') - 0.4)});")
    return (f'<div id="top"><div id="chaps">{"".join(labels)}</div>'
            f'<div id="mark">{logo("mk", 46)}<span class="mk-ar">مِيزان</span><span class="mk-en" dir="ltr">Mizan</span></div></div>'
            f'<div id="prog">{"".join(segs)}</div>')


def subtitles():
    out = []
    for i, c in enumerate(TL["cues"]):
        out.append(f'<div class="sub" id="sub{i}" dir="ltr"><span>{escape(c["text"])}</span></div>')
        show(f"#sub{i}", c["start"])
        hide(f"#sub{i}", c["end"])
    return f'<div id="subs">{"".join(out)}</div>'


CSS = """
@font-face { font-family: "PlexAr"; src: url("assets/fonts/IBMPlexSansArabic-Light.ttf"); font-weight: 300; }
@font-face { font-family: "PlexAr"; src: url("assets/fonts/IBMPlexSansArabic-Regular.ttf"); font-weight: 400; }
@font-face { font-family: "PlexAr"; src: url("assets/fonts/IBMPlexSansArabic-Medium.ttf"); font-weight: 500; }
@font-face { font-family: "PlexAr"; src: url("assets/fonts/IBMPlexSansArabic-SemiBold.ttf"); font-weight: 600; }
@font-face { font-family: "PlexAr"; src: url("assets/fonts/IBMPlexSansArabic-Bold.ttf"); font-weight: 700; }
@font-face { font-family: "Amiri"; src: url("assets/fonts/Amiri-Regular.ttf"); font-weight: 400; }
@font-face { font-family: "Amiri"; src: url("assets/fonts/Amiri-Bold.ttf"); font-weight: 700; }
@font-face { font-family: "PlexMono"; src: url("assets/fonts/IBMPlexMono-Regular.ttf"); font-weight: 400; }
@font-face { font-family: "PlexMono"; src: url("assets/fonts/IBMPlexMono-Medium.ttf"); font-weight: 500; }
@font-face { font-family: "PlexMono"; src: url("assets/fonts/IBMPlexMono-SemiBold.ttf"); font-weight: 600; }
html, body { margin: 0; background: #0f1211; }
#root { position: relative; width: 100%; height: 100%; overflow: hidden; background: #0f1211; color: #edece7;
        font-family: "PlexAr", sans-serif; direction: rtl; font-size: 34px; }
.clip, .inner { position: absolute; inset: 0; }
.abs { position: absolute; }
.center { left: 0; right: 0; text-align: center; }
.en { direction: ltr; unicode-bidi: isolate; font-family: "PlexAr", sans-serif; font-size: 0.82em; }
.mono { font-family: "PlexMono", monospace; direction: ltr; unicode-bidi: isolate; }
.muted { color: #9ea7a3; }
.big { font-size: 30px; }
.big2 { font-size: 46px; color: #c9cec9; }
.dot { color: #6f7874; margin: 0 10px; }
.teal { color: #6cc4bd; }
.std { color: #a3b0c4; }
.gold { color: #e9c46a; }
/* chrome */
#top { position: absolute; left: 96px; right: 96px; top: 34px; height: 48px; }
#chaps { position: absolute; right: 0; top: 0; height: 48px; width: 1000px; }
.chap { position: absolute; right: 0; top: 4px; display: flex; gap: 16px; align-items: baseline; opacity: 0; font-size: 28px; white-space: nowrap; }
.c-n { color: #6cc4bd; font-size: 22px; }
.c-a { font-weight: 600; }
#mark { position: absolute; left: 0; top: 0; display: flex; align-items: center; gap: 12px; direction: rtl; color: #c9cec9; }
.mk-ar { font-weight: 700; font-size: 28px; }
.mk-en { font-size: 22px; color: #9ea7a3; letter-spacing: .12em; }
#prog { position: absolute; left: 96px; right: 96px; top: 92px; height: 3px; display: flex; gap: 8px; }
.seg { flex: 1; background: #1f2624; border-radius: 2px; overflow: hidden; }
.seg-f { width: 100%; height: 100%; background: #6cc4bd; }
#subs { position: absolute; left: 0; right: 0; bottom: 40px; height: 120px; }
.sub { position: absolute; left: 160px; right: 160px; bottom: 0; text-align: center; opacity: 0; }
.sub span { display: inline-block; max-width: 1480px; padding: 10px 26px 12px; border-radius: 12px; background: rgba(6, 8, 8, .82);
            color: #f6f5f1; font-size: 35px; line-height: 1.38; font-weight: 500; font-family: "PlexAr", sans-serif; }
/* hook */
.hook { font-family: "Amiri", serif; font-size: 132px; font-weight: 700; line-height: 1.25; opacity: 0; }
.hook .ok { color: #6cc4bd; }
.hook .bad { color: #e9c46a; }
.hook2 { font-family: "Amiri", serif; font-size: 100px; font-weight: 400; line-height: 1.35; opacity: 0; }
.hook2 .k { color: inherit; }
.tag { font-size: 32px; font-weight: 600; opacity: 0; }
.tag.teal { color: #6cc4bd; } .tag.gold { color: #e9c46a; }
#h-src, #k-cap { font-size: 30px; color: #c9cec9; opacity: 0; }
#h-scan { width: 6px; height: 230px; border-radius: 3px; background: #e9c46a; box-shadow: 0 0 30px 6px rgba(233,196,106,.45); opacity: 0; }
.pill { display: inline-block; padding: 12px 30px; border-radius: 999px; border: 2px solid #3a4441; font-size: 32px; font-weight: 500; }
.pill.gold { border-color: #e9c46a; color: #e9c46a; background: rgba(233,196,106,.08); }
#h-lost, #k-bar { opacity: 0; }
.kb-top { display: flex; align-items: baseline; gap: 28px; margin-bottom: 18px; }
.kb-big { font-size: 110px; font-weight: 600; color: #e9c46a; font-family: "PlexAr", sans-serif; direction: ltr; }
.kb-lbl { font-size: 36px; }
.kb-track { height: 36px; border-radius: 8px; background: #252b29; overflow: hidden; display: flex; }
.kb-fill { height: 100%; width: 0%; background: #e9c46a; }
.kb-foot { margin-top: 14px; font-size: 22px; color: #6f7874; }
/* reveal */
.name { font-size: 176px; font-weight: 700; line-height: 1.05; }
.latin { font-size: 40px; letter-spacing: .5em; color: #9ea7a3; font-family: "PlexAr", sans-serif; }
.tagline { font-size: 44px; font-weight: 500; }
.chip { display: inline-flex; gap: 12px; align-items: baseline; padding: 12px 26px; margin: 0 10px; border-radius: 999px;
        border: 1.5px solid #34403c; background: #151a19; font-size: 28px; }
.chip.sm { font-size: 22px; padding: 6px 16px; margin: 5px 0 5px 8px; }
#rv-logo-wrap, #rv-name, #rv-latin, #rv-tag, #rv-tag-en, #rv-chips .chip { opacity: 0; }
.chead { position: absolute; width: 500px; text-align: center; font-size: 40px; font-weight: 700; opacity: 0; }
.chead.std { color: #a3b0c4; } .chead.mz { color: #6cc4bd; }
.crow { position: absolute; left: 180px; width: 1560px; height: 62px; display: flex; align-items: center; justify-content: space-between;
        border-bottom: 1px solid #222a28; opacity: 0; }
.crow .cv { width: 500px; text-align: center; font-size: 38px; color: #6f7874; }
.crow .cl { font-size: 34px; text-align: center; flex: 1; }
.crow.diff { height: 112px; border: 2px solid #e9c46a; border-radius: 16px; background: rgba(233,196,106,.06); }
.crow.diff .cv { font-size: 32px; } .crow.diff .cv.std { color: #a3b0c4; } .crow.diff .cv.mz { color: #6cc4bd; }
.crow.diff .cl { font-weight: 600; color: #e9c46a; }
#cr-only { opacity: 0; }
/* pipeline */
.lane { position: absolute; border-radius: 18px; border: 1.5px solid #2c3331; background: #141918; padding: 20px 24px; box-sizing: border-box; opacity: 0; }
.lane.std .l-h { color: #a3b0c4; } .lane.mz .l-h { color: #6cc4bd; } .lane.mz { border-color: rgba(108,196,189,.45); }
.l-h { font-size: 32px; font-weight: 700; margin-bottom: 8px; }
.l-b { font-size: 28px; margin-bottom: 12px; }
.l-x { font-family: "Amiri", serif; font-size: 40px; color: #c9cec9; position: absolute; bottom: 16px; right: 24px; }
.l-x .k, #k-line .k { color: inherit; }
.lane .l-x .k { color: #e9c46a; }
.l-x.good { color: #6cc4bd; opacity: 0; }
.l-chips { display: flex; flex-wrap: wrap; }
.l-chips .chip { opacity: 0; }
.bus { position: absolute; width: 4px; background: #3a4441; border-radius: 2px; }
#sh-head { font-size: 32px; font-weight: 600; opacity: 0; }
.node { position: absolute; width: 250px; height: 184px; border-radius: 16px; border: 2px solid #2c3331; background: #151a19;
        padding: 18px 16px; box-sizing: border-box; opacity: 0; }
.n-t { font-size: 27px; font-weight: 600; color: #edece7; margin-bottom: 10px; }
.n-t.mono { font-size: 21px; color: #6cc4bd; }
.n-m { font-size: 30px; font-weight: 500; margin-bottom: 6px; }
.n-s { font-size: 21px; }
.arrow { position: absolute; width: 32px; height: 4px; background: #3a4441; }
.card { position: absolute; border-radius: 18px; border: 1.5px solid #2c3331; background: #141918; padding: 22px 26px; box-sizing: border-box; opacity: 0; }
.c-h { font-size: 28px; font-weight: 700; margin-bottom: 14px; }
.q { font-family: "Amiri", serif; font-size: 29px; color: #c9cec9; margin-bottom: 10px; line-height: 1.5; }
.cite { direction: rtl; font-size: 19px; padding: 10px 14px; border-radius: 8px; border: 1.5px solid #6cc4bd; color: #d8efec;
        background: rgba(108,196,189,.10); margin-bottom: 16px; display: inline-block; font-family: "PlexAr", sans-serif; }
.c-ok { font-size: 25px; color: #6cc4bd; margin-bottom: 6px; }
.c-ok.en { color: #9ea7a3; font-size: 21px; }
/* footage */
.frame { position: absolute; overflow: hidden; border-radius: 16px; border: 1.5px solid #2c3331; background: #121615; opacity: 0; }
.cam { position: absolute; left: 0; top: 0; transform-origin: 0 0; }
.cam img { position: absolute; left: 0; top: 0; display: block; }
#cam-ready, #cam-load, #cam-ans { opacity: 0; }
.tf { opacity: 0; }
.hl { position: absolute; border: 6px solid; border-radius: 14px; box-shadow: 0 0 0 9999px rgba(0,0,0,0); opacity: 0; box-sizing: border-box; }
.flabel { position: absolute; left: 136px; top: 862px; padding: 10px 18px; border-radius: 10px; background: rgba(8,10,10,.86);
          font-size: 24px; opacity: 0; border: 1px solid #2c3331; }
.live { color: #6cc4bd; font-size: 18px; }
.note { position: absolute; padding: 14px 22px; border-radius: 12px; background: rgba(8,10,10,.9); border: 1.5px solid #2c3331;
        font-size: 28px; opacity: 0; max-width: 820px; }
.sw { display: inline-block; width: 18px; height: 18px; border-radius: 4px; margin-left: 12px; vertical-align: middle; }
.sw.std { background: #a3b0c4; } .sw.mz { background: #6cc4bd; transform: rotate(45deg); }
.steps { position: absolute; left: 120px; top: 862px; width: 1680px; display: flex; gap: 22px; justify-content: flex-start; }
.step { padding: 10px 20px; border-radius: 12px; background: rgba(8,10,10,.9); border: 1.5px solid #2c3331; font-size: 26px; opacity: 0; }
.step .num { display: inline-block; width: 34px; height: 34px; border-radius: 50%; background: #6cc4bd; color: #0f1211; text-align: center;
             font-weight: 700; margin-left: 12px; font-size: 22px; line-height: 34px; }
#tri-wrap { opacity: 0; }
.tri-h { font-size: 44px; font-weight: 700; text-align: center; }
.tri-h2 { text-align: center; margin: 6px 0 28px; font-size: 28px; }
.tri-row { display: flex; flex-direction: column; gap: 30px; }
.tri { opacity: 0; display: flex; gap: 34px; align-items: center; }
.tri-l { width: 306px; font-size: 30px; font-weight: 600; }
.tri-l .en { font-size: 22px; font-weight: 400; }
.tri-img { position: relative; overflow: hidden; border-radius: 12px; border: 1.5px solid #3a4441; }
.tri-img img { position: absolute; }
/* results */
.eyebrow { position: absolute; left: 0; right: 0; top: 118px; text-align: center; font-size: 24px; color: #9ea7a3; opacity: 0; }
.eyebrow .en { font-size: 22px; }
.mega { font-size: 250px; font-weight: 600; line-height: 1; font-family: "PlexAr", sans-serif; }
.h2 { font-size: 54px; font-weight: 700; }
#r1-n, #r1-l, #r1-pdf, #r1-web, #r1-chips { opacity: 0; }
.blk { border: 1.5px solid #2c3331; border-radius: 18px; padding: 22px; text-align: center; background: #141918; }
.blk-n { font-size: 64px; color: #edece7; }
.blk-t { font-size: 30px; }
.blk-e { font-size: 22px; }
#r2-t, #r3-n, #r3-l, #r3-sub, #r3-dis, #r4-t, #r4-ax, #r4-ref, #r5-t, #r5-v, #d-titles { opacity: 0; }
.legend { position: absolute; font-size: 26px; display: flex; align-items: center; gap: 10px; direction: ltr; opacity: 0; }
.legend .sw { margin: 0 6px 0 18px; }
.axis { position: absolute; height: 2px; background: #3a4441; }
.vbar { position: absolute; width: 170px; border-radius: 10px 10px 0 0; }
.vval { position: absolute; width: 210px; text-align: center; font-size: 36px; opacity: 0; }
.vlab { position: absolute; width: 230px; text-align: center; font-size: 26px; color: #c9cec9; opacity: 0; }
.grp { position: absolute; text-align: center; font-size: 32px; font-weight: 600; opacity: 0; }
.delta { position: absolute; text-align: center; opacity: 0; }
.d-big { font-size: 64px; font-weight: 700; font-family: "PlexAr", sans-serif; }
.d-ci { font-size: 22px; color: #9ea7a3; }
.foot { position: absolute; text-align: center; font-size: 26px; color: #c9cec9; }
.num { font-family: "PlexMono", monospace; direction: ltr; unicode-bidi: isolate; color: #edece7; margin: 0 6px; }
.foot .en { display: block; font-size: 22px; }
.foot2 .en { font-size: 22px; }
.hb-row { position: absolute; left: 200px; width: 1520px; display: flex; align-items: center; gap: 26px; opacity: 0; }
.hb-name { width: 260px; font-size: 32px; font-weight: 600; }
.hb-track { width: 1100px; height: 46px; display: flex; }
.hb { height: 100%; border-radius: 8px; }
.hb-v { font-size: 30px; }
.ip { position: absolute; left: 0; top: 0; width: 1920px; height: 1080px; opacity: 0; }
.ip-axis { position: absolute; height: 2px; background: #3a4441; }
.tick { position: absolute; width: 60px; margin-left: -30px; text-align: center; font-family: "PlexMono", monospace; font-size: 22px; color: #6f7874; }
.tick.zero { color: #edece7; }
.ip-zero { position: absolute; width: 2px; background: #edece7; opacity: .7; }
.ip-margin { position: absolute; width: 0; border-left: 2px dashed #e5806b; }
.ip-mlab { position: absolute; width: 300px; text-align: center; font-family: "PlexMono", monospace; font-size: 22px; color: #e5806b; }
.ip-row { position: absolute; left: 0; top: 0; }
.ip-lab { position: absolute; font-size: 34px; font-weight: 600; text-align: right; }
.ip-lab .en { font-size: 24px; font-weight: 400; margin-right: 14px; }
.ip-ci { position: absolute; height: 8px; margin-top: -4px; border-radius: 4px; }
.ip-pt { position: absolute; width: 30px; height: 30px; border-radius: 50%; border: 3px solid #0f1211; box-sizing: border-box; }
.ip-val { position: absolute; width: 320px; text-align: center; font-size: 25px; color: #c9cec9; white-space: nowrap; }
.ip-badge { position: absolute; padding: 8px 20px; border-radius: 999px; border: 2px solid; font-size: 27px; white-space: nowrap; }
/* close */
.take { position: absolute; left: 420px; right: 420px; display: flex; align-items: center; gap: 36px; opacity: 0; }
.tk-i { font-size: 64px; width: 90px; text-align: center; font-weight: 700; }
.tk-t .en { display: block; }
.tk-a { font-size: 58px; font-weight: 700; white-space: nowrap; line-height: 1.25; }
#cl-logo, #cl-motto, #cl-motto-en, #cl-team, #cl-team-en, #cl-org, #cl-black { opacity: 0; }
.motto { font-size: 124px; font-weight: 700; }
.team { font-size: 38px; font-weight: 600; }
#cl-org { font-size: 26px; color: #c9cec9; }
"""


def main() -> None:
    body = []
    scene_fades()
    body.append(clip("s1", scene_hook(), 1))
    body.append(clip("s2", scene_reveal(), 2))
    body.append(clip("s3", scene_pipeline(), 1))
    body.append(clip("s4", scene_demo(), 2))
    body.append(clip("s5", scene_insights(), 1))
    body.append(clip("r1", scene_r1(), 2))
    body.append(clip("r2", scene_r2(), 1))
    body.append(clip("r3", scene_r3(), 2))
    body.append(clip("r4", scene_r4(), 1))
    body.append(clip("r5", scene_r5(), 2))
    body.append(clip("s7", scene_close(), 1))
    top = chrome()
    subs = subtitles()
    dst = COMP / "assets" / "typing"
    dst.mkdir(parents=True, exist_ok=True)
    for p in sorted((ROOT / "capture" / "typing").glob("*.jpg")):
        shutil.copy2(p, dst / p.name)
    html = f"""<!doctype html>
<html lang="ar">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=1920, height=1080" />
<title>Mizan · مِيزان — project video</title>
<script src="assets/vendor/gsap.min.js"></script>
<style>{CSS}</style>
</head>
<body>
<div id="root" data-composition-id="mizan" data-width="1920" data-height="1080" data-duration="{r(T)}" data-fps="{FPS}">
{"".join(body)}
{top}
{subs}
<audio id="mix" src="assets/audio/mix.wav" data-start="0" data-duration="{r(T)}" data-track-index="20" data-volume="1"></audio>
</div>
<script>
var tl = gsap.timeline({{ paused: true }});
{chr(10).join(JS)}
window.__timelines["mizan"] = tl;
</script>
</body>
</html>
"""
    (COMP / "index.html").write_text(html, encoding="utf-8")
    print(f"index.html: {T:.1f} s, {len(JS)} timeline statements, {len(TL['cues'])} subtitle cues")


if __name__ == "__main__":
    main()
