"""Repair the narration takes without changing their length: cut the listed TTS tail artifacts and fade every chunk edge.

    python video/tools/repair_takes.py video/narration/takes video/narration/takes_clean --cuts video/narration/repair_cuts.json

The originals are read, never written. Each output take has exactly the same number of samples as its original.
Use these takes for a full rebuild (assemble_narration.py). To repair an existing render without moving anything,
use repair_narration.py instead: the tempo stretch can change a repaired line's length by a few milliseconds.
"""
import argparse
import json
import sys
from pathlib import Path

import numpy as np
import soundfile as sf

sys.path.insert(0, str(Path(__file__).resolve().parent))
from audio_edit import cut_tail, fade_edges, find_chunks  # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("dst")
    ap.add_argument("--cuts", required=True)
    a = ap.parse_args()
    src, dst = Path(a.src), Path(a.dst)
    if src.resolve() == dst.resolve():
        raise SystemExit("refusing to overwrite the original takes")
    dst.mkdir(parents=True, exist_ok=True)
    cuts = {(c["line"], c["chunk"]): c for c in json.loads(Path(a.cuts).read_text(encoding="utf-8"))["cuts"]}
    used = set()
    for p in sorted(src.glob("*.wav")):
        x, sr = sf.read(str(p), dtype="float32")
        y = x.copy()
        for k, (s, e) in enumerate(find_chunks(x, sr)):
            seg = x[s:e]
            c = cuts.get((p.stem, k))
            if c:
                if not (s / sr < c["cut"] < e / sr):
                    raise SystemExit(f"cut {c} outside chunk {p.stem}#{k} ({s / sr:.2f}-{e / sr:.2f})")
                seg = cut_tail(seg, sr, c["cut"] - s / sr, c.get("fade", 0.05))
                used.add((p.stem, k))
            y[s:e] = fade_edges(seg, sr)
        assert len(y) == len(x)
        sf.write(str(dst / p.name), y, sr, subtype="FLOAT")
        removed = float(np.sqrt(np.mean((x - y) ** 2)))
        print(f"{p.stem}: {len(find_chunks(x, sr))} chunks, cut {sum(1 for k in cuts if k[0] == p.stem)}, "
              f"length {len(x) / sr:.3f} s unchanged, removed RMS {removed:.4f}")
    missing = set(cuts) - used
    if missing:
        raise SystemExit(f"cuts not applied: {sorted(missing)}")


if __name__ == "__main__":
    main()
