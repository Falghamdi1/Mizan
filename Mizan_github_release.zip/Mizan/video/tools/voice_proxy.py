"""Two listener-free proxies for how native a synthetic Arabic voice sounds (they do not replace listening):

  p_ar      Whisper's language-identification probability that the clip is Arabic (a strong foreign accent lowers it)
  logprob   mean log-probability of Whisper's own Arabic transcript tokens (mumbled or odd sounds lower it)

    python video/tools/voice_proxy.py DIR [DIR ...]
"""
import sys
from pathlib import Path

import numpy as np
import torch
from transformers import WhisperForConditionalGeneration, WhisperProcessor

sys.path.insert(0, str(Path(__file__).resolve().parent))
from asr_check import load16k  # noqa: E402

MODEL = "openai/whisper-large-v3-turbo"


def main() -> None:
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    proc = WhisperProcessor.from_pretrained(MODEL)
    model = WhisperForConditionalGeneration.from_pretrained(MODEL, torch_dtype=torch.float16).to(dev).eval()
    tok = proc.tokenizer
    from transformers.models.whisper.tokenization_whisper import LANGUAGES
    lang_ids = {f"<|{c}|>": tok.convert_tokens_to_ids(f"<|{c}|>") for c in LANGUAGES}
    sot = tok.convert_tokens_to_ids("<|startoftranscript|>")
    for d in sys.argv[1:]:
        pa, lp = [], []
        for wav in sorted(Path(d).glob("*.wav")):
            feats = proc(load16k(wav), sampling_rate=16000, return_tensors="pt").input_features.to(dev, torch.float16)
            with torch.no_grad():
                logits = model(input_features=feats, decoder_input_ids=torch.tensor([[sot]], device=dev)).logits[0, -1].float()
                ids = torch.tensor(list(lang_ids.values()), device=dev)
                probs = torch.softmax(logits[ids], dim=0)
                p_ar = float(probs[list(lang_ids).index("<|ar|>")])
                gen = model.generate(feats, language="arabic", task="transcribe", output_scores=True, return_dict_in_generate=True,
                                     max_new_tokens=200)
                sc = model.compute_transition_scores(gen.sequences, gen.scores, normalize_logits=True)[0].float().cpu().numpy()
            pa.append(p_ar)
            lp.append(float(np.mean(sc[np.isfinite(sc)])))
            print(f"{Path(d).name:12} {wav.stem:6} p_ar {p_ar:.3f}  logprob {lp[-1]:.3f}")
        print(f"== {Path(d).name}: mean p_ar {np.mean(pa):.3f}, mean logprob {np.mean(lp):.3f}\n")


if __name__ == "__main__":
    main()
