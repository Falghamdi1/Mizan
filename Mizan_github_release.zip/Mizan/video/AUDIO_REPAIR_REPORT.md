# Narration audio repair (2026-10-15)

| | |
|---|---|
| Repaired video | `video/mizan_project_video_ar_final_clean.mp4` (139.7 s, 1920×1080, 30 fps; AAC 48 kHz stereo 192 kb/s) |
| Original, untouched | `video/mizan_project_video_ar.mp4` (SHA-256 `0d4b6df2…d30ff`, same as before the repair) |
| Backup of the original sources | `video/backup_v1/` (takes, narration, mix, composition, subtitles, picks, timeline, checksums) |

## How the defects were found

Nobody listened to the audio during this work: I cannot hear. The defects were found by analysing the narration
track (music-free, video timing) and confirmed visually:

- `tools/audio_audit.py`: hard edges, short bursts after the last word, and broadband transients, plus a spectrogram of every line (`audit/before/`).
- `tools/chunk_ends.py`: every generated phrase, where Whisper hears its last word end, and a zoomed plot of its final 1.6 s (`audit/chunks/`).
- `tools/zoom_plot.py`: 0.05 s-grid zooms to place each cut (`audit/zoom1.png`).

**Cause: TTS generation, kept by the stitching.**
- Chatterbox often continues past the last word of a phrase: a hum or drone, a buzz, a garbled syllable, isolated clicks.
- The generator trimmed each phrase only at the last sample above 1 % of full scale. That kept these artifacts and often stopped them abruptly where the inserted pause began.
- None came from encoding, the music bed, transitions or the AAC encode: the same artifacts are in the raw takes.
- They sit exactly where the user heard them, "immediately after certain words or sentences".

## Defects and repairs

Times are video timecodes. Each repair keeps the speech up to just after the last word's natural decay, then fades out (12–50 ms) and silences the artifact through to the next phrase. The music bed continues underneath, so there is no hole in the ambience. No word, line or timing was changed; nothing was regenerated.

| # | Time | After the word | What was there | Removed |
|---|---|---|---|---|
| 1 | 0:04.0 | «السياحة» (a1) | click at 0:04.2 and 0.8 s of low noise | 0.78 s |
| 2 | 0:09.9 | «ال تزيد» (a2) | 0.4 s of hum | 0.43 s |
| 3 | 0:11.3 | «النفي» (a2) | garbled bursts and an abrupt stop | 1.03 s |
| 4 | 0:16.4 | «الرموز» (a3) | hum ending in an abrupt stop | 0.64 s |
| 5 | 0:24.5 | «السياحة» (b1) | small burst and noise | 0.65 s |
| 6 | 0:31.4 | «العربي» (b2) | burst and a 2–3 kHz hum | 0.72 s |
| 7 | 0:35.3 | «فقط» (c1) | click and 1.3 s of garble | 1.26 s |
| 8 | 0:39.2 | «الاستخراج» (c1) | noise and a click | 0.74 s |
| 9 | **0:45.9** | «مقطعًا» (c2) | **loud broadband noise burst** (crack, up to 0.8 of full scale) | 0.74 s |
| 10 | 0:50.5 | «منها» (c2) | 1.2 s of hum ending abruptly | 1.20 s |
| 11 | 0:55.5 | «يعتذر» (c3) | hum, hiss and a click | 0.75 s |
| 12 | **1:01.1** | «التصنيف؟» (d1) | **two clicks and a loud burst** (up to 0.89 of full scale) | 1.10 s |
| 13 | 1:07.7 | «أخرى» (d2) | low hum, abrupt stop | 0.50 s |
| 14 | 1:12.5 | «يومًا» (d2) | 2 kHz drone, abrupt stop | 0.72 s |
| 15 | 1:20.1 | «عرضه» (e1) | click and hum | 0.54 s |
| 16 | 1:41.0 | «وستّين» (f2) | short spike | 0.06 s |
| 17 | 1:50.2 | «الثلث» (f4) | pop and noise | 0.36 s |
| 18 | **2:09.6** | «يسلم» (g1) | **loud periodic buzz** (0.54 of full scale) | 1.10 s |
| 19 | **2:13.7** | «نفترض» (g2, final line) | **2.3 s of drone and buzz ending in a hard stop** | 2.32 s |

The bold rows are the loudest; they are most likely the "cracks" and "strange noises" you heard.

**Checked and left alone, because they are speech:**
- the "t" release of «لايت» at 1:09.5;
- «وستّين» at 1:40.6;
- the decay of «إحصائيًّا» at 1:58.2;
- the fricatives and plosives the transient detector flags inside words (س, ص, ك).

**Not found:**
- clipping (0 samples at full scale);
- pitch breaks inside words (pYIN pitch track, no jump above 70 %);
- abrupt restarts after silence inside phrases.

## What was changed

- **Narration repair:** `tools/repair_narration.py` edits the final narration track at the exact samples where each line sits in the video.
  - The cut points are in `narration/repair_cuts.json`, with the reason for each.
  - It recomputes the original layout and checks it against the original `narration.wav` (max difference 3·10⁻⁵).
  - 15.2 s of the 139.7 s were edited; every other sample is unchanged. The result is `narration/clean/narration.wav`, plus `repair_log.json`.
- **Mix:** `tools/make_audio.py --narration-dir narration/clean` rebuilt the mix with the same music bed, ducking and −16 LUFS target. The mixer reproduces the original mix bit for bit from the original narration, so the only difference is the repair.
- **Final file:** the clean mix is placed under the original video stream with `ffmpeg -c:v copy`. The picture is **bit-identical** (same video MD5), so visuals, animations, transitions and burned-in subtitles cannot have moved.
- **Root cause in the generator:** `tools/tts_chatterbox.py` now fades both ends of every generated phrase, so phrases can no longer stop on a hard edge.
  - An automatic "cut whatever follows the last word" rule was tested and rejected. Against the hand-placed cuts it would have removed real words (f3 «لا فرق», and the ends of e2, f2 and f5).
  - New takes therefore need the reviewed step: run `chunk_ends.py`, set cut points in `repair_cuts.json`, then run `repair_takes.py`.
  - `narration/takes_clean/` holds the repaired takes for any future full rebuild.

## Verification of the final file (actually performed)

| Check | Result |
|---|---|
| Duration, streams | 139.7 s; H.264 1920×1080 30 fps (4,191 frames, identical); AAC LC 48 kHz stereo |
| Picture | video stream MD5 identical to the original |
| Sync | soundtrack cross-correlation with the original: 0.00 ms offset; every narration line starts within 0.07 s of its subtitle (b1 −0.29 s is the swell accent before the line, as before) |
| Untouched audio | outside the repaired windows: +0.02 dB, correlation 0.9996 with the original (AAC re-encode) |
| Repaired windows | 5–8 kHz energy (clicks, buzz) down to the bed's floor (about −100 dB); the worst four: −34 → −103 dB, −47 → −104, −70 → −105, −72 → −105; spectrograms in `audit/final_mp4_before_after.png` and `audit/before_after/` |
| Words | Whisper transcribes all 20 lines of the repaired soundtrack exactly as before (19 identical; c2 differs by «تري»/«ثري», the same sound) |
| Loudness | −16.3 LUFS integrated (was −16.4), loudness range 6.2 LU, peak −1.5 dBFS, no clipping |
| Re-audit | 0 hard edges (was 6, including the 0.85-of-full-scale hard stop at the very end); the 3 remaining "tail" flags are the speech sounds listed above |
| Start and end | unchanged: the music fades in over the first 0.8 s; the final 2.3 s drone under the closing card is gone, so the ending is the music bed fading out with the picture |

**Not verified:** a listening test. All checks above are measurements and spectrograms. Please listen once on headphones, especially at 0:45.9, 1:01.1, 2:09.6 and 2:13.7, before using the video.

If anything still sounds wrong, note its timecode. The fix is one more line in `narration/repair_cuts.json`, then rerun:

```bash
python video/tools/repair_narration.py --narration video/narration/narration.wav --takes video/narration/takes --timeline video/narration/timeline.json --cuts video/narration/repair_cuts.json --out-dir video/narration/clean
```

```bash
.venv-tts/Scripts/python video/tools/make_audio.py --narration-dir video/narration/clean --out video/narration/clean/mix.wav
```

```bash
ffmpeg -y -i video/mizan_project_video_ar.mp4 -i video/narration/clean/mix.wav -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 192k -movflags +faststart video/mizan_project_video_ar_final_clean.mp4
```
