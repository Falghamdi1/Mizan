# Scene outline

Total 2:19.7. Scene times are when the scene's narration starts.

| scene | time | what is shown |
|---|---|---|
| المشكلة · The problem | 0:00.0–0:17.9 | A real line from the Tour Guide Regulations (p. 8) turns from «لا تزيد» into «ال تزيد» as the PDF extractor delivers it; a second real line shows its kashida in gold, and a bar fills to 29.7% (21,109 of 71,046 tokens). |
| الفكرة · The idea | 0:17.9–0:32.7 | The app's balance-scale mark settles; name and Gen AI tagline; the same system built twice: documents, questions, models and prompt equal, text preprocessing the only difference. |
| كيف يعمل · How it works | 0:32.7–0:57.6 | Two preprocessing lanes (Standard: whitespace only; Mizan-lite: lam-alef, kashida, invisible marks, NFKC, digit and letter forms) merge into one shared chain: chunking, Qwen3-Embedding-0.6B (20 candidates), Qwen3-Reranker-0.6B (top 4), Qwen3-4B-Instruct base model; the prompt v1 rules and a checked citation. |
| المنتج · The product | 0:57.6–1:14.4 | Real footage of the app on the 8 evaluated PDFs: the blind question pdf-012 typed into the question box, the evidence phrase, the comparison; Standard answers 60 days from another regulation (p. 6), Mizan-lite 180 days from the right page (p. 13), then the retrieved passage that holds the reference evidence (rank 3). |
| Mizan Insights | 1:14.4–1:28.5 | The real Insights panel for that question: facts computed by code, the model's explanation, the check; the verdict 'not enough evidence on this question' with no recommendation; three real questions with the same verdict. |
| النتائج · Results | 1:28.5–2:04.0 | Frozen blind test (266 questions): hit@4 PDF 68.1% → 79.7% (+11.6 pts [+2.9, +21.7], titles off; with titles +4.3, n.d.), web 72.9% → 73.6%; PDF index −31.8% embedding tokens; blind human grading with intervals against the −10 no-loss margin; refusals 20/24 → 23/24; LoRA +22.2 on style-matched dev questions but +1.4 [−7.2, +10.1] on blind questions. |
| الخلاصة · Takeaway | 2:04.0–2:19.7 | Three takeaways, the scale mark, «نقيسُ، ولا نفترض.» and the team. |
