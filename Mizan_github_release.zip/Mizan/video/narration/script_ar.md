# Mizan project video: Arabic narration script

Final duration 2:19.7 (139.7 s). Voice: Chatterbox Multilingual (local, MIT) with a ClArTTS reference (CC BY 4.0); tempo ×1.35. Times are when each line starts and ends in the video.

| # | time | Arabic (spoken) | English subtitle |
|---|---|---|---|
| 1 | 0:00.8–0:05.0 | هذا سطرٌ حقيقيٌّ من لائحةٍ لوزارة السياحة. | This is a real line from a Ministry of Tourism regulation. |
| 2 | 0:05.3–0:12.5 | وهكذا يصل إلى النموذج بعد استخراجه من ملف PDF: «لا تزيد» صارت «ال تزيد»، فضاع النفي. | This is how the model receives it after PDF extraction: “does not exceed” turned into “al tazid”, and the negation is gone. |
| 3 | 0:13.2–0:17.3 | وحروف التطويل وحدها تملأ قرابة ثلث الرموز. | Stretched kashida letters alone fill almost a third of the tokens. |
| 4 | 0:18.7–0:25.4 | بنينا «ميزان»: نظامَ ذكاءٍ اصطناعيٍّ توليديٍّ متكاملًا، يجيب من وثائق لوائح السياحة. | We built Mizan: a complete Gen AI system that answers from tourism regulations. |
| 5 | 0:25.7–0:32.3 | وبنيناه مرتين بالوثائق والنماذج نفسها، والفرق الوحيد: معالجة النص العربي. | We built it twice, with the same documents and models. The only difference: how the Arabic text is processed. |
| 6 | 0:33.5–0:40.2 | القياسي ينظّف المسافات فقط، أما ميزان-لايت فيُصلح تلف الاستخراج. | Standard only cleans whitespace. Mizan-lite repairs the extraction damage. |
| 7 | 0:40.5–0:51.7 | ثم يتطابق المساران: نموذج تضمين يجد عشرين مقطعًا، ومُعيد ترتيب يختار أربعة، والنموذج الأساسي Qwen3-4B يكتب الإجابة منها، | From there the paths are identical: an embedding model finds 20 passages, a reranker keeps 4, and the base model, Qwen3-4B, writes the answer from them, |
| 8 | 0:52.0–0:56.5 | بموجِّهٍ صمّمناه كي يستشهد بالصفحة أو يعتذر. | with a prompt we designed so that it cites the page or declines. |
| 9 | 0:58.4–1:02.4 | نسأل ميزان: متى يطلب المرفق شهادة التصنيف؟ | We ask Mizan: when must a facility request its classification certificate? |
| 10 | 1:03.8–1:13.4 | القياسي لم يجد الدليل، فأجاب بستين يومًا من لائحةٍ أخرى. أما ميزان-لايت فوجد الصفحة الصحيحة: مئةٌ وثمانون يومًا. | Standard missed the evidence and answered 60 days, from another regulation. Mizan-lite found the right page: 180 days. |
| 11 | 1:15.2–1:20.8 | ثم يشرح Mizan Insights الفرق بحقائق يحسبها الكود، ويُفحص الشرح قبل عرضه. | Then Mizan Insights explains the difference from facts computed by code, and the explanation is checked before it is shown. |
| 12 | 1:21.1–1:25.9 | هنا وجد ميزان-لايت وحده الدليل، لكنه لا يحكم من سؤالٍ واحد. | Here only Mizan-lite found the evidence, but it won't judge from a single question. |
| 13 | 1:29.3–1:33.0 | ثم اختبرناه على ٢٦٦ سؤالًا مغلقًا. | Then we tested it on 266 blind questions. |
| 14 | 1:33.7–1:43.6 | في ملفات PDF وجد ميزان-لايت الدليل الصحيح في ٨٠٪ من الأسئلة مقابل ٦٨٪، ويضيق الفرق مع عناوين اللوائح. | On PDFs, Mizan-lite found the right evidence for 80% of questions, against 68%; the gap narrows when regulation titles are added. |
| 15 | 1:44.3–1:46.6 | وعلى نصوص الويب السليمة: لا فرق. | On clean web text: no difference. |
| 16 | 1:47.2–1:50.7 | وفهرس ملفات PDF أصغر بنحو الثلث. | And the PDF index is about a third smaller. |
| 17 | 1:52.6–1:58.5 | وفي التقييم البشري الأعمى: لا خسارة على الويب، وفرق PDF غير مميّز إحصائيًّا. | In blind human grading: no loss on the web; the PDF difference is not statistically distinguishable. |
| 18 | 1:60.0–2:03.2 | ولم يُثبت ضبط LoRA فائدة، فأبقينا النموذج الأساسي. | LoRA fine-tuning showed no benefit, so we kept the base model. |
| 19 | 2:04.8–2:10.9 | الخلاصة: إصلاح النص العربي يساعد حيث يتلف، ولا يضرّ حيث يسلم. | The takeaway: repairing Arabic text helps where it is damaged, and does no harm where it is clean. |
| 20 | 2:11.5–2:16.2 | ميزان: نقيس، ولا نفترض. | Mizan: we measure; we don't assume. |

## Recording plan for a human narrator

If a team member records the narration instead: read the Arabic column line by line, calmly, at about the pace of the synthetic voice; leave a short breath between lines. Save one WAV per line as video/narration/takes/<id>.wav (ids a1 … g2, in the order above), then rebuild (video/README.md, steps 4–7). The timeline, subtitles and visuals follow the new recording automatically; check the subtitles still match the words you said.
