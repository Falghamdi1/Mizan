# Safety evaluation data

Frozen labelled texts for `scripts/safety_eval.py` (model-free safeguards in `src/safety.py`). Results: `docs/safety_eval/before.md` and `after.md`; discussion: `docs/RESPONSIBLE_AI.md` section 4c.

| file | rows | what it holds |
|---|---|---|
| `attacks.jsonl` | 128 | 87 in-scope attacks (literal Arabic and English orders, role tags, cosmetic disguises, attacks hidden in realistic text) and 41 out-of-scope ones (paraphrase, other languages, encoded or homoglyph text, splitting, goal hijacking, exfiltration, misinformation) |
| `benign.jsonl` | 60 | ordinary regulation-style sentences that contain trigger words in a legitimate use; true label "not an attack" |
| `pii.jsonl` | 56 | personal-data positives with a category and format variants, look-alike negatives, and out-of-scope positives (bare ID numbers, cards, passports) |

Every file has a `dev` and a `heldout` half. **Protocol:** the files were written, hashed and run once on the unchanged scan ("before"); only the `dev` half was then used to change `src/safety.py`. The held-out half is a check, not an independent red team: the same author wrote both halves and knew the patterns. Held-out numbers after the change are reported next to the "before" numbers and are no longer untouched. Held-out misses were deliberately not fixed.

sha256 (also enforced by `tests/test_safety_eval.py`):

```
attacks.jsonl  8f273ef867b08fc74625794fac50b7e2f93711ea6fd06033e914d4fdae4a97ad
benign.jsonl   f0d0143f00c1e2600f5c9327df9f79a024d2071aae0ee12c84b82c9567835157
pii.jsonl      44b73c45e447a948619f9a57fd9d163445207379582039ea142d506c0d1c6edb
```

Invisible characters inside the texts are stored as `\uXXXX` escapes so they survive editors. Do not edit a frozen file: add a new file and a new hash instead. The attack texts are generic and public-knowledge strings; none targets a real system.
