# Grading rubric for generated answers

You will grade answers from a RAG system for Arabic questions about Saudi tourism regulations. You do not know which system or setting produced which answer, and you should not try to guess. Grade **alone**; do not talk to the other grader until both of you have finished.

## What you get

A CSV (open in Excel or Google Sheets, UTF-8) with one row per question: the question, a **reference answer** written from the source, and for each column A, B (C) the system's **answer**, the **sources** it was shown (`file#page`), and two empty columns to fill. Columns A/B/C are shuffled from row to row.

**Easier than the spreadsheet:** open `tools/grading_form.html` in a browser, choose your own `grader_N.csv`, and click through the rows (one question, the reference answer and the answers side by side, right to left). Your marks are saved in the browser as you go, and the form exports the same CSV with your labels filled in. It runs offline; nothing is uploaded. Never open `KEY.json`.

## Column 1: `correct_X` (every row)

**Answerable question** (the reference answer states a fact). Write **1** if the answer gives the key fact(s) of the reference answer correctly: the right number, duration, amount, date, condition or list item. Extra correct detail is fine. Write **0** if it:
- gives a different number, duration, amount or condition than the reference;
- leaves out the key fact (a vague or partial answer is **0**; write "partial" in `comment`);
- says the documents do not contain the answer (a refusal of an answerable question is **0**);
- mixes in a fact from the wrong regulation.

**Unanswerable question** (the reference says it is not in the documents). Write **1** if the answer says the documents do not contain it (any wording) and does not invent an answer. Write **0** if it gives a confident answer.

Do not grade style, length, spelling or whether the answer is polite. Do not use your own knowledge to overrule the reference answer; if you think the reference is wrong, write 0 or 1 by the reference and describe the problem in `comment` (we will fix the question).

## Column 2: `supported_X` (non-refusal answers only; leave empty for refusals)

Open the cited source (the `[file, page N]` in the answer, or `sources_X`) at that page. Write **1** if the page really says what the answer claims. Write **0** if the page does not say it, the citation points at the wrong page or file, or there is no usable citation. This is slower: grade it for every row if you can, otherwise for at least the first 15 rows (leave the rest empty). Both graders should grade the same rows.

## Column 3: `better (A, B or tie)` (two-arm sheets only)

After you graded both answers, say which one a user would prefer: write **A**, **B** or **tie**. Prefer the answer that is more correct, then the one that is better supported by its cited page. Write **tie** when they are equally good or equally bad (both right, both wrong, both refuse). Ignore length and style. This is a second view next to the 0/1 marks (people agree more on "which is better" than on absolute marks); the merge reports wins, ties and an exact sign test. It does not replace `correct_X`.

## Values and mistakes

Only `1` or `0` (also accepted: yes/no, y/n, نعم/لا). Anything else is reported as a problem. Do not edit other columns and do not reorder rows.

## After grading

The team merges both sheets: `python scripts/human_grading.py merge <folder> --grader1 g1.csv --grader2 g2.csv`. It prints where you disagree. Discuss only those cells, fill them in a copy of the sheet (`adjudicated.csv`, with only the agreed cells filled), and merge again with `--adjudicated`. Kappa below about 0.6 means the rubric was read differently: discuss what differed before trusting any number.

## Declaration

"I graded without knowing which system produced which answer, alone, following this rubric."
