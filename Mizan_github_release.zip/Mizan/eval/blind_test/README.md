# Blind test set: how to write your questions

**Purpose.** The capstone brief says to keep a test set that is never used for training or for choosing settings. This is that set. It is written by the three of us, by hand, **before anyone looks at results for these questions**, frozen with a hash, and used **once** for the final Standard vs Mizan comparison. If it is used to choose anything (a prompt, a preset, a threshold, an adapter), it is spent and the result no longer counts.

**Deadline:** Saturday 10 October, noon. **Size:** 15 to 20 questions each, about 45 to 60 in total.

## Rules (read them all)

1. **Blind.** Do not open `results/`, `EXPERIMENT_RESULTS.md`, the executed notebooks, the Colab outputs or the UI answers to *your* questions while writing. You may read the documents. The checker only compares your evidence phrase with the document text; it never runs a model, so it cannot tell you what the system will find.
2. **Your own words.** Write the question the way a business owner or a clerk would ask it. Do not copy a Ministry FAQ question or a development question (the checker rejects identical ones and warns about near copies). Use different vocabulary from the passage for at least a third of your questions (paraphrase), so retrieval cannot win by matching words.
3. **Name the subject.** Several regulations contain near-identical clauses (licence term, renewal days, fee tables). Say which activity you mean ("ترخيص الإرشاد السياحي", "مرفق الضيافة") so the gold document is unambiguous.
4. **Evidence phrase.** 3 to 8 contiguous words copied from **one sentence on one page** that answers the question. Not the whole answer. It must not just repeat your question (the checker warns). For a **PDF**, read the page in the PDF itself and type the phrase as you see it; avoid words containing lam-alef (ال / لا sequences) and stretched letters, because the extracted text is damaged there. If the checker says the phrase is not in every arm, choose another phrase from the same sentence. For **web** text copy from `data/web/corpus_readable_web.txt`.
5. **Unanswerable questions** (at least 2 each): plausible tourism questions the documents do not answer (fees of another country, an hotel price, a rule from a regulation we do not have). Search the dump for the key words first; if the answer is there, it is not unanswerable.
6. **Mix.** Across your questions: at least 5 answerable on PDF, 5 answerable on web, 2 unanswerable, 3 numbers/durations/fees. Use the other types too (condition, list, procedure, paraphrase).
7. **No editing after the freeze.** Once `--build` has written `FROZEN.json`, nobody edits the files. A mistake found later is reported as a limitation, not fixed.
8. **Second reader.** After your file passes `--check`, a teammate reads 5 of your rows against the source and writes `ok` or a problem in the `notes` column. Wrong gold evidence in a blind set is worse than none.

## Steps

**Easier than editing the CSV by hand:** `python scripts/make_blind_form.py` writes `data/blind_form/blind_question_form.html`. Open it in a browser: the documents are on the left (with a search box), your question on the right, and the evidence phrase is checked live against the document text with the same canonicalizer as the evaluation (it warns about a phrase that is not in the document, is too generic, repeats your question, or copies a development question). It shows no result of any pipeline. Download your CSV from the form and continue with `--check` below, which stays the authority. The generated file contains the corpus text: do not share it.

```
python scripts/make_blind_test.py --init yourname            # creates eval/blind_test/yourname.csv (header only)
python scripts/make_blind_test.py --dump-corpus web          # writes data/web/corpus_readable_web.txt (stays local, git-ignored)
python scripts/make_blind_test.py --check eval/blind_test/yourname.csv    # as often as you like
```

Open the CSV in Excel or Google Sheets (UTF-8, Arabic right-to-left) or in a text editor. Columns:

| column | what to write |
|---|---|
| `author` | your name (same on every row) |
| `corpus` | `pdf` or `web` (the question is answered from one of them) |
| `question` | the Arabic question |
| `answerable` | `yes` or `no` |
| `source_doc` | answerable only. PDF: the file name, any unique part works (`Tour-Guide`). Web: the document id from the dump header (`faq/الإرشاد السياحي`, `law/tourism-law`, `news/2026-07-07/3385`, `definitions`) |
| `source_page` | the page number (PDF) or page in the dump header (web). Optional, but the checker warns if the phrase is elsewhere |
| `evidence_phrase` | answerable only: see rule 4 |
| `alt_phrase` | optional: a second wording of the same evidence (either one counts) |
| `answer_keywords` | words the correct answer must contain. `;` separates required keywords, `|` separates acceptable alternatives: `3|ثلاث;سنوات` |
| `reference_answer` | a one-sentence correct answer written from the source (for human graders). For unanswerable rows: `غير مذكور في الوثائق.` |
| `type` | `direct`, `number`, `duration`, `fee`, `condition`, `list`, `procedure`, `paraphrase`, `unanswerable` |
| `notes` | anything; the second reader writes here |

`examples.csv` shows three rows copied from the **development** set (so they are examples only, not part of the blind set; files named `template.csv` and `examples.csv` are ignored).

## When everyone is done (Person 2 runs this)

```
python scripts/make_blind_test.py --check                   # every contributor file, quota report
python scripts/make_blind_test.py --build                   # checks, then freezes: writes eval/questions_final_test_{pdf,web}.json and FROZEN.json
python scripts/make_blind_test.py --verify                  # before the final run: nothing has changed
```

Commit or zip the frozen files and write the two hashes (from `FROZEN.json`) in the README. Evaluate PDF questions with `MIZAN_CORPUS=pdf` and web questions with `MIZAN_CORPUS=web` (never mixed in one index: the FAQ answers would be valid evidence for PDF questions).

## Declaration (each author, as a line in the pull request or chat)

"I wrote my questions before looking at any result for them, in my own words, from the documents. I did not use the blind questions to try any pipeline, prompt or setting."

## Known limits of this set, to state when presenting it

Written by the people who built the system (not independent users); small (about 50 questions: only differences of roughly 10 points or more will be visible); evidence phrases must exist in the text of every arm, which excludes passages whose extraction is too damaged for the baseline, so the set slightly understates what Mizan repairs; unanswerable questions are few.
