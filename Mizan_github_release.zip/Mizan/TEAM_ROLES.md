# Team roles

> **Final week (9 to 14 October):** the concrete task list, file ownership and acceptance criteria are in [TEAM_HANDOFF.md](TEAM_HANDOFF.md). This page keeps the general rules.

Three people, three areas that meet at clear interfaces. Each person can work without editing the others' files.

| | Person 1: RAG / System Engineer | Person 2: Arabic NLP / Experiment Engineer | Person 3: Product / UI / Demo Engineer |
|---|---|---|---|
| **Owns** | the pipeline that is the same for both arms | the one thing that differs, and how it is measured | everything a viewer sees and the story told with it |
| **Files** | `src/ingestion.py`, `chunking.py`, `embeddings.py`, `retrieval.py`, `rerank.py`, `rag.py`, `local_llm.py`, `config.py`, `finetune/` | `src/preprocessing.py`, `evaluation.py`, `stats.py`, `colab.py` (summary), `eval/`, `scripts/` (check_gold, compare_runs, gen_eval_questions), `tests/`, `docs/EXPERIMENT_LOG.md` | `src/ui.py`, `ui_theme.py`, `comparison.py`, `app.py`, `demo.py`, the notebook (`scripts/build_notebook.py`), `COLAB_README.md`, `README.md`, `SPEAKING_NOTES.md` |
| **Work** | PDF ingestion and parsing (RTL order, presentation forms, scans), chunking, embeddings, Chroma, retrieval, local LLM integration, source/page citations, the standard pipeline, model loading and memory | Arabic preprocessing and its justification, experimental design (one variable), the evaluation set and gold evidence, retrieval and answer evaluation, token and latency measurement, ablations (`mizan-no-<flag>`, `baseline+<flag>`), reading the results honestly | Gradio UI and UX, the side-by-side comparison, metrics display, evidence/source display, demo mode and the 60-second flow, the Colab notebook, documentation, deployment preparation |

Person 3 is not only the "UI person". They own the complete user-facing experiment: what is shown, what is *not* claimed on the screen, and whether the demo can be explained in a minute.

## Rules that keep the experiment credible

1. **One variable.** Person 1 changes nothing that differs between the arms; if a setting must differ, it is written in README section 10 first.
2. **Independent gold evidence.** The person who designs the preprocessing (Person 2) should not be the only author of the gold phrases, otherwise the test can quietly fit the normaliser. Person 1 or 3 reviews every gold phrase against the PDF (`python scripts/check_gold.py` checks that each phrase occurs; it cannot check that it is the right evidence).
3. **Numbers come from files.** Anything quoted in README, notes or slides comes from a `results/eval-*.json` or the notebook output, never from memory. `python scripts/compare_runs.py` regenerates every confidence interval.
4. **Negative results stay in.**

## Interfaces

| Component | Needs from others | Contract |
|---|---|---|
| Preprocessing | nothing | `preprocess_text(text, cfg)`, `preprocess_pages(pages, cfg)`; pure functions; `pytest tests` |
| Ingestion | nothing | `load_pdfs(dir) -> list[Page(doc, title, page, text, text_repaired)]` |
| Chunking, embeddings, index | `Page` list | `Pipeline(cfg).build(pages)`, `Pipeline.ask(question) -> RAGResult` |
| Local LLM | a prompt | `call_llm(prompt, passages)`; providers `hf` (Colab), `ollama`, `mock`; no key for any of the three |
| Evaluation | questions JSON + pipelines | `run_eval(names, pipelines=..., questions_path=..., retrieve_only=...)`; schema in `src/evaluation.py` |
| UI | built pipelines | `build_ui(pages, pipes, questions)`; works with the mock LLM, so UI work never waits for a GPU |

## Suggested order

1. Person 1: `python scripts/fetch_corpus.py`, then check the extraction diagnostics per document; open the notebook on a T4 runtime and confirm it runs top to bottom.
2. Person 2: review `eval/questions.json` and the generated `eval/questions_large.json` (the `needs_review` flags); run the one-step ablations.
3. Person 3: rehearse the 60-second flow in `SPEAKING_NOTES.md` against the notebook's section 8 and the UI; check Arabic rendering on the presenting machine.
4. All: agree on which claims are allowed on the slide (see README "Validity threats").
