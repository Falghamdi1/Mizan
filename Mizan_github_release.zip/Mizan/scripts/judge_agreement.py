"""Compare two LLM judges on the SAME answers, and build a sheet for human grading.

    python scripts/judge_agreement.py results/eval-A.json results/eval-B.json --pipeline mizan+repair_lam_alef

Both result files must come from the same pipeline/questions with the same generated answers (answers are cached,
so re-running with a different MIZAN_JUDGE_MODEL reproduces them). Prints agreement and Cohen's kappa for
judge_correct and judge_faithful, and writes results/judge_review.md: every disagreement plus a random sample of
agreements, each with an empty "human" column. Human grades are the only way to know which judge (if either) is right.
"""
import argparse
import json
import random
from pathlib import Path


def kappa(a: list[int], b: list[int]) -> float | None:
    n = len(a)
    if n == 0:
        return None
    po = sum(x == y for x, y in zip(a, b)) / n
    pa1, pb1 = sum(a) / n, sum(b) / n
    pe = pa1 * pb1 + (1 - pa1) * (1 - pb1)
    return None if pe == 1 else (po - pe) / (1 - pe)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("run_a")
    ap.add_argument("run_b")
    ap.add_argument("--pipeline", required=True)
    ap.add_argument("--out", default="results/judge_review.md")
    ap.add_argument("--sample", type=int, default=12, help="extra agreeing items to include for human grading")
    args = ap.parse_args()
    A, B = (json.loads(Path(f).read_text(encoding="utf-8")) for f in (args.run_a, args.run_b))
    ra = {r["id"]: r for r in A["pipelines"][args.pipeline]["per_question"]}
    rb = {r["id"]: r for r in B["pipelines"][args.pipeline]["per_question"]}
    legacy = {"provider": "ollama", "model": "qwen3:4b-instruct-2507-q4_K_M (same model as the generator; older run)"}
    ja, jb = A.get("judge") or legacy, B.get("judge") or legacy
    print(f"judge A: {ja.get('provider')}:{ja.get('model')}   judge B: {jb.get('provider')}:{jb.get('model')}")
    # Refusals are graded by rule in src/evaluation.judge, so they say nothing about judge agreement: exclude them.
    refused = {i for i, r in ra.items() if r.get("abstained")}
    print(f"{len(refused)} refusals excluded; comparing substantive answers only")
    same_answers = sum(ra[i]["answer"] == rb[i]["answer"] for i in ra if i in rb)
    print(f"{same_answers}/{len(ra)} answers identical between the runs (must be all of them)")
    rows_out = []
    for key in ("judge_correct", "judge_faithful"):
        ids = [i for i in ra if i in rb and i not in refused
               and ra[i].get(key) is not None and rb[i].get(key) is not None]
        a = [ra[i][key] for i in ids]
        b = [rb[i][key] for i in ids]
        agree = sum(x == y for x, y in zip(a, b)) / len(ids) if ids else float("nan")
        k = kappa(a, b)
        print(f"{key:<16} n={len(ids):<3} agreement {agree:.0%}   kappa {('n/a' if k is None else f'{k:.2f}')}   "
              f"A says 1: {sum(a)}/{len(a)}   B says 1: {sum(b)}/{len(b)}")
        for i in ids:
            rows_out.append((i, key, ra[i][key], rb[i][key]))
    dis = [(i, k, x, y) for i, k, x, y in rows_out if x != y]
    ag = [(i, k, x, y) for i, k, x, y in rows_out if x == y]
    random.Random(0).shuffle(ag)
    picked = dis + ag[: args.sample]
    lines = ["# Judge review sheet", "",
             f"Judge A = `{ja.get('model')}`, judge B = `{jb.get('model')}`; pipeline `{args.pipeline}`. "
             "Grade each row yourself from the question, reference answer and model answer: 1 = correct / faithful, 0 = not. "
             "For faithfulness, open the cited page in the PDF. Disagreements come first.", "",
             "| id | criterion | A | B | question | reference answer | model answer | human |", "|---|---|---|---|---|---|---|---|"]
    for i, k, x, y in picked:
        r = ra[i]
        lines.append(f"| {i} | {k.replace('judge_', '')} | {x} | {y} | {r['question']} | "
                     f"{(r.get('reference_answer') or '')} | {r['answer'].replace(chr(10), ' ')} | ☐ |")
    Path(args.out).write_text("\n".join(lines), encoding="utf-8")
    print(f"wrote {args.out} with {len(dis)} disagreements + {min(args.sample, len(ag))} agreements")


if __name__ == "__main__":
    main()
