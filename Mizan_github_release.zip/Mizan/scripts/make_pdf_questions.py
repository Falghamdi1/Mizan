"""Build PDF-based evaluation questions: data/web/questions_pdf.json.

The questions are the Ministry's own FAQ questions (written by the Ministry, not by us or an LLM). `eval/pdf_faq_alignment.json`
says, for the FAQ questions whose answer is stated in one of the 8 regulation PDFs, which phrase of the PDF text is the evidence.
That alignment was made by reading each FAQ answer next to the best-matching PDF passages (a lexical search proposed candidates,
the phrase was chosen by hand), so it is a judgement and `needs_review` is set on every question: a second person should check it.
The alignment file holds only PDF phrases and hashes of the questions, no FAQ text; the FAQ text is fetched by
scripts/fetch_web_corpus.py and stays local.

    python scripts/make_pdf_questions.py            # write the question file, print what was kept and why the rest was dropped

A question is kept only if its phrase is found (after the fixed evaluation canonicalizer) in a chunk of at least one PDF for BOTH
pipelines' chunking, and in at most MAX_DOCS PDFs (a phrase repeated in every regulation would make the gold meaningless).
Evaluate on the PDF corpus only (MIZAN_CORPUS=pdf): the FAQ answers themselves would be correct evidence if they were indexed.
"""
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src.chunking import chunk_pages  # noqa: E402
from src.config import PDF_FAQ_ALIGNMENT, PDF_FAQ_QUESTIONS, RAW_DIR, SETTINGS, WEB_DIR  # noqa: E402
from src.ingestion import load_pdfs  # noqa: E402
from src.preprocessing import canonical_for_eval, get_config, preprocess_pages  # noqa: E402
from src.web_corpus import load_web_corpus  # noqa: E402

MAX_DOCS = 4
PIPELINES = ("baseline", "mizan+repair_lam_alef")


def question_key(question: str) -> str:
    return hashlib.sha1(canonical_for_eval(question).encode("utf-8")).hexdigest()[:10]


def chunk_texts(pages, name: str) -> dict[str, list[str]]:
    chunks = chunk_pages(preprocess_pages(pages, get_config(name)), SETTINGS.chunk_size, SETTINGS.chunk_overlap)
    out: dict[str, list[str]] = {}
    for c in chunks:
        out.setdefault(c.doc, []).append(canonical_for_eval(c.text))
    return out


def main() -> int:
    _, pairs = load_web_corpus(WEB_DIR, sources=("faq",))
    faq = {question_key(p["question"]): p for p in pairs}
    align = json.loads(PDF_FAQ_ALIGNMENT.read_text(encoding="utf-8"))
    pages = load_pdfs(RAW_DIR)
    index = {n: chunk_texts(pages, n) for n in PIPELINES}
    questions, dropped = [], []
    for a in align:
        pair = faq.get(a["key"])
        if pair is None:
            dropped.append((a["key"], "question not in the fetched FAQ (the Ministry changed it?)"))
            continue
        phrase = canonical_for_eval(a["phrase"])
        per_pipeline = [{d for d, ts in index[n].items() if any(phrase in t for t in ts)} for n in PIPELINES]
        docs = sorted(set.intersection(*per_pipeline))
        if not docs:
            dropped.append((a["key"], f"phrase not found in the chunks of both pipelines ({[len(p) for p in per_pipeline]} docs): {a['phrase'][:50]}"))
        elif len(docs) > MAX_DOCS:
            dropped.append((a["key"], f"phrase found in {len(docs)} PDFs: too generic: {a['phrase'][:50]}"))
        else:
            questions.append({"id": f"pdf-{len(questions) + 1}", "type": "faq-in-pdf", "question": pair["question"],
                              "gold_evidence": [[a["phrase"]]], "gold_docs": docs, "reference_answer": pair["answer"],
                              "category": a["category"], "needs_review": True})
    PDF_FAQ_QUESTIONS.parent.mkdir(parents=True, exist_ok=True)
    PDF_FAQ_QUESTIONS.write_text(json.dumps(questions, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"wrote {len(questions)} questions to {PDF_FAQ_QUESTIONS}; dropped {len(dropped)} of {len(align)} aligned")
    for k, why in dropped:
        print(f"  dropped {k}: {why}")
    docs_used = {}
    for q in questions:
        for d in q["gold_docs"]:
            docs_used[d] = docs_used.get(d, 0) + 1
    print("questions per gold PDF:", dict(sorted(docs_used.items())))
    return 0


if __name__ == "__main__":
    sys.exit(main())
