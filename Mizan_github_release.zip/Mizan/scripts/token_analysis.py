"""What do the token savings actually mean? Measurements at four levels, each with its own definition.

  A  tokenizers      is the tokenizer used for 'retrieved tokens' the one the generator uses?
  B  documents       tokens per word of the text as extracted vs after each preprocessing arm (no retrieval involved)
  C  retrieval       tokens of the 4 chunks passed on, per question, paired Standard vs Mizan, with the quality measured alongside
  D  generation      input tokens the generator really received (Ollama usage), output tokens, latency; how input tokens relate to retrieved tokens

    python scripts/token_analysis.py [--colab-dir results/colab_run3] [--answers results/eval-20261007-212624.json]

Writes docs/data_audit/token_analysis.json and .md. Reads only existing result files and the local corpora; the only download is the
two tokenizer files (a few MB). Nothing is generated here: every number is either computed from a file or measured on the local text.
"""
from __future__ import annotations

import argparse
import json
import statistics
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src.stats import paired_bootstrap  # noqa: E402

OUT = ROOT / "docs" / "data_audit"
ARMS = {"Standard": "baseline", "Mizan-full": "mizan+repair_lam_alef", "Mizan-lite": "mizan-lite+repair_lam_alef"}


def col(result: dict, arm: str, key: str, ids=None) -> dict:
    return {r["id"]: r[key] for r in result["pipelines"][arm]["per_question"] if r.get(key) is not None and (ids is None or r["id"] in ids)}


def paired(a: dict, b: dict) -> dict | None:
    r = paired_bootstrap(a, b)
    if r is None:
        return None
    mean, lo, hi, n = r
    base = statistics.fmean(a[i] for i in a if i in b)
    return {"n": n, "mean_base": round(base, 3), "diff": round(mean, 3), "ci": [round(lo, 3), round(hi, 3)],
            "pct_change": round(100 * mean / base, 1) if base else None}


def level_a(texts: list[str]) -> dict:
    try:
        from transformers import AutoTokenizer
        t_emb = AutoTokenizer.from_pretrained("Qwen/Qwen3-Embedding-0.6B")
        t_llm = AutoTokenizer.from_pretrained("Qwen/Qwen3-4B-Instruct-2507")
        t_e5 = AutoTokenizer.from_pretrained("intfloat/multilingual-e5-small")
    except Exception as e:  # noqa: BLE001 - offline: say so instead of guessing
        return {"checked": False, "reason": f"{type(e).__name__}: tokenizer files could not be downloaded"}
    same_vocab = t_emb.get_vocab() == t_llm.get_vocab()
    ids_equal = sum(t_emb.encode(t, add_special_tokens=False) == t_llm.encode(t, add_special_tokens=False) for t in texts)
    e5_ratio = statistics.fmean(len(t_e5.encode(t, add_special_tokens=False)) / max(1, len(t_emb.encode(t, add_special_tokens=False))) for t in texts)
    return {"checked": True, "qwen3_embedding_vs_qwen3_4b_instruct": {"identical_vocabulary": same_vocab, "texts_tokenized_identically": f"{ids_equal}/{len(texts)}"},
            "e5_small_tokens_per_qwen3_token": round(e5_ratio, 3),
            "meaning": "retrieved_tokens (Qwen3-Embedding tokenizer) equals the generator's token count for the same text only if the vocabularies match; "
                       "e5-small uses a different tokenizer, so its token counts are not comparable with the generator's"}, t_emb


def level_b(pages_by_corpus: dict, tok) -> dict:
    from src.preprocessing import get_config, preprocess_text
    out = {}
    for corpus, pages in pages_by_corpus.items():
        text = "\n".join(p.text for p in pages)
        words = len(text.split())
        row = {}
        for label, arm in ARMS.items():
            t = preprocess_text(text, get_config(arm))
            n = len(tok.encode(t, add_special_tokens=False))
            row[label] = {"characters": len(t), "words": len(t.split()), "tokens": n, "tokens_per_word": round(n / max(1, len(t.split())), 3)}
        raw_tokens = len(tok.encode(text, add_special_tokens=False))
        no_tat = len(tok.encode(text.replace("ـ", ""), add_special_tokens=False))
        row["as_extracted"] = {"characters": len(text), "words": words, "tokens": raw_tokens, "tokens_per_word": round(raw_tokens / max(1, words), 3)}
        row["tokens_caused_by_tatweel"] = {"tokens": raw_tokens - no_tat, "share_of_tokens_%": round(100 * (raw_tokens - no_tat) / max(1, raw_tokens), 1)}
        out[corpus] = row
    return out


def preprocessing_time(pages) -> dict:
    from src.preprocessing import get_config, preprocess_pages
    res = {}
    for label, arm in ARMS.items():
        cfg, ts = get_config(arm), []
        for _ in range(3):
            t0 = time.perf_counter()
            preprocess_pages(pages, cfg)
            ts.append(time.perf_counter() - t0)
        res[label] = round(statistics.median(ts), 3)
    return {"seconds_for_the_PDF_corpus_median_of_3": res, "note": "pure Python text processing on one CPU; negligible next to embedding and generation"}


def level_c(colab_dir: Path) -> dict:
    out = {}
    for emb in ("e5-small", "Qwen3-Embedding-0.6B", "Qwen3-Embedding-4B"):
        for corpus in ("pdf", "web"):
            p = colab_dir / f"lite-{emb}-{corpus}.json"
            if not p.exists():
                continue
            r = json.loads(p.read_text(encoding="utf-8"))
            row = {"index_tokens": {k: r["pipelines"][a]["index"]["tokens"] for k, a in ARMS.items()},
                   "chunks": {k: r["pipelines"][a]["index"]["chunks"] for k, a in ARMS.items()}}
            std = col(r, ARMS["Standard"], "retrieved_tokens")
            for label in ("Mizan-full", "Mizan-lite"):
                arm = col(r, ARMS[label], "retrieved_tokens")
                row[f"retrieved_tokens_per_query_{label}_vs_Standard"] = paired(std, arm)
                row[f"questions_with_fewer_tokens_{label}_%"] = round(100 * sum(arm[i] < std[i] for i in std if i in arm) / len(std), 1)
                hit_s, hit_m = col(r, ARMS["Standard"], "hit"), col(r, ARMS[label], "hit")
                row[f"hit@4_{label}_vs_Standard"] = paired(hit_s, hit_m)
            if corpus == "pdf":                      # does the saving repeat across document types?
                qs = {q["id"]: q for q in json.loads((ROOT / "data" / "web" / "questions_pdf.json").read_text(encoding="utf-8"))} \
                    if (ROOT / "data" / "web" / "questions_pdf.json").exists() else {}
                by_doc = {}
                lite = col(r, ARMS["Mizan-lite"], "retrieved_tokens")
                for qid, q in qs.items():
                    if qid in std and qid in lite and q.get("gold_docs"):
                        by_doc.setdefault(q["gold_docs"][0], []).append((std[qid], lite[qid]))
                row["by_gold_document_lite_vs_Standard"] = {d: {"n": len(v), "standard_mean": round(statistics.fmean(s for s, _ in v)), "lite_mean": round(statistics.fmean(m for _, m in v)),
                                                                 "pct_change": round(100 * (statistics.fmean(m for _, m in v) / statistics.fmean(s for s, _ in v) - 1), 1)}
                                                            for d, v in sorted(by_doc.items())}
            out[f"{emb} / {corpus}"] = row
    return out


def level_d(answers: Path) -> dict:
    r = json.loads(answers.read_text(encoding="utf-8"))
    s = r["settings"]
    std, mz = ARMS["Standard"], ARMS["Mizan-full"]
    out = {"file": answers.name, "generator": f"{s['llm_provider']}:{s['llm_model']}", "embedder": s["embedding_model"], "reranker": s.get("reranker") or "none",
           "adapter": s.get("embedding_adapter") or "none", "n_questions": r["pipelines"][std]["aggregate"]["n_questions"]}
    for key, label in (("input_tokens", "LLM input tokens (generator usage)"), ("output_tokens", "LLM output tokens"), ("retrieved_tokens", "retrieved-context tokens (embedding tokenizer)"),
                       ("llm_latency_s", "LLM latency s"), ("retrieval_latency_s", "retrieval latency s"), ("total_latency_s", "end-to-end s"), ("keyword_coverage", "answer keyword coverage"),
                       ("hit", "hit@4")):
        out[label] = paired(col(r, std, key), col(r, mz, key))
    xs, ys = [], []
    for arm in (std, mz):
        for q in r["pipelines"][arm]["per_question"]:
            if q.get("input_tokens") and q.get("retrieved_tokens"):
                xs.append(q["retrieved_tokens"])
                ys.append(q["input_tokens"])
    if len(xs) > 3:
        mx, my = statistics.fmean(xs), statistics.fmean(ys)
        slope = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sum((x - mx) ** 2 for x in xs)
        out["input_tokens_vs_retrieved_tokens"] = {"n": len(xs), "slope": round(slope, 3), "intercept": round(my - slope * mx, 1),
                                                   "pearson_r": round(statistics.correlation(xs, ys), 3),
                                                   "mean_share_of_input_that_is_retrieved_context_%": round(100 * statistics.fmean(x / y for x, y in zip(xs, ys)), 1)}
    lat = [(q["input_tokens"], q["llm_latency_s"]) for arm in (std, mz) for q in r["pipelines"][arm]["per_question"]
           if q.get("input_tokens") and q.get("llm_latency_s") and not q.get("llm_cached")]
    if len(lat) > 5:
        out["input_tokens_vs_llm_latency"] = {"n": len(lat), "pearson_r": round(statistics.correlation([a for a, _ in lat], [b for _, b in lat]), 3),
                                              "note": "uncached answers only; latency also depends on output length and GPU memory contention"}
    return out


def markdown(rep: dict) -> str:
    out = ["# Token analysis (generated by scripts/token_analysis.py)", ""]
    a = rep["A_tokenizers"]
    out += ["## A. Which tokenizer?", "", json.dumps(a, ensure_ascii=False, indent=1), ""]
    out += ["## B. Documents: tokens per word (no retrieval involved)", "", "| corpus | variant | characters | words | tokens | tokens/word |", "|---|---|---|---|---|---|"]
    for corpus, row in rep["B_documents"].items():
        for k in ("as_extracted", "Standard", "Mizan-lite", "Mizan-full"):
            v = row[k]
            out.append(f"| {corpus} | {k} | {v['characters']:,} | {v['words']:,} | {v['tokens']:,} | {v['tokens_per_word']} |")
        out.append(f"| {corpus} | tokens caused by tatweel | | | {row['tokens_caused_by_tatweel']['tokens']:,} | {row['tokens_caused_by_tatweel']['share_of_tokens_%']}% of all tokens |")
    out += ["", f"Preprocessing time: {rep['B_preprocessing_time']}", "", "## C. Retrieval: tokens of the 4 chunks passed on (per question, paired)", "",
            "| embedder / corpus | arm | tokens/query Standard | difference [95% CI] | % | questions with fewer tokens | hit@4 difference [95% CI] |", "|---|---|---|---|---|---|---|"]
    for k, row in rep["C_retrieval"].items():
        for label in ("Mizan-lite", "Mizan-full"):
            t, h = row.get(f"retrieved_tokens_per_query_{label}_vs_Standard"), row.get(f"hit@4_{label}_vs_Standard")
            if t:
                out.append(f"| {k} | {label} | {t['mean_base']} | {t['diff']:+} [{t['ci'][0]:+}, {t['ci'][1]:+}] | {t['pct_change']}% | {row[f'questions_with_fewer_tokens_{label}_%']}% | "
                           + (f"{h['diff']:+} [{h['ci'][0]:+}, {h['ci'][1]:+}] (n={h['n']})" if h else "n/a") + " |")
    out += ["", "Index tokens (whole corpus) and chunks:", "", "| embedder / corpus | Standard | Mizan-lite | Mizan-full | chunks S / lite / full |", "|---|---|---|---|---|"]
    for k, row in rep["C_retrieval"].items():
        i, c = row["index_tokens"], row["chunks"]
        out.append(f"| {k} | {i['Standard']:,} | {i['Mizan-lite']:,} ({100 * (i['Mizan-lite'] / i['Standard'] - 1):+.1f}%) | {i['Mizan-full']:,} ({100 * (i['Mizan-full'] / i['Standard'] - 1):+.1f}%) | {c['Standard']} / {c['Mizan-lite']} / {c['Mizan-full']} |")
    for k, row in rep["C_retrieval"].items():
        if "by_gold_document_lite_vs_Standard" in row and k.startswith("Qwen3-Embedding-0.6B"):
            out += ["", f"By gold document ({k}, lite vs Standard, mean retrieved tokens per query):", "", "| document | n | Standard | lite | % |", "|---|---|---|---|---|"]
            out += [f"| {d} | {v['n']} | {v['standard_mean']} | {v['lite_mean']} | {v['pct_change']}% |" for d, v in row["by_gold_document_lite_vs_Standard"].items()]
    out += ["", "## D. Generation: what the generator really received", "", "```", json.dumps(rep["D_generation"], ensure_ascii=False, indent=1), "```"]
    return "\n".join(out)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--colab-dir", default=str(ROOT / "results" / "colab_run3"))
    ap.add_argument("--answers", default=str(ROOT / "results" / "eval-20261007-212624.json"))
    a = ap.parse_args()
    from src import config
    from src.ingestion import load_pdfs
    from src.web_corpus import load_web_corpus
    web, _ = load_web_corpus(config.WEB_DIR)
    pdf = load_pdfs(config.RAW_DIR)
    sample = [p.text for p in (pdf[::4] + web[::25]) if p.text.strip()]
    ra = level_a(sample)
    if isinstance(ra, tuple):
        ra, tok = ra
    else:
        tok = None
    rep = {"A_tokenizers": ra}
    if tok is not None:
        rep["B_documents"] = level_b({"pdf (8 regulations)": pdf, "web (739 records)": web}, tok)
    else:
        rep["B_documents"] = {}
    rep["B_preprocessing_time"] = preprocessing_time(pdf)
    rep["C_retrieval"] = level_c(Path(a.colab_dir))
    rep["D_generation"] = level_d(Path(a.answers))
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "token_analysis.json").write_text(json.dumps(rep, ensure_ascii=False, indent=1), encoding="utf-8")
    (OUT / "token_analysis.md").write_text(markdown(rep), encoding="utf-8")
    print((OUT / "token_analysis.md").read_text(encoding="utf-8"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
