"""Build the evaluation question file from the Ministry's FAQ: data/web/questions_faq.json.

Each FAQ question becomes an evaluation question. Its gold evidence is the start of the Ministry's own answer, and the
answer page is the only relevant document. The question is never indexed, only the answer, so retrieval cannot match
the question text itself. Written by the Ministry, not by us or an LLM, so it is independent of the preprocessing.

    python scripts/make_faq_questions.py            # write the file
    python scripts/make_faq_questions.py --check    # also check every gold phrase against the chunks both pipelines index

Caveat: FAQ questions and answers share vocabulary, so absolute scores will look better than real-world retrieval.
Use the file to compare pipelines, not to quote an accuracy. The data is local only (see scripts/fetch_web_corpus.py).
"""
import argparse
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src.chunking import chunk_pages  # noqa: E402
from src.config import SETTINGS, WEB_DIR, WEB_QUESTIONS  # noqa: E402
from src.preprocessing import canonical_for_eval, get_config, preprocess_pages  # noqa: E402
from src.web_corpus import load_web_corpus  # noqa: E402

MIN_ANSWER = 40  # characters: "نعم" and similar one-word answers cannot be told apart from other text
PHRASE = 60  # characters of the answer used as gold evidence


def gold_phrase(answer: str) -> str:
    flat = re.sub(r"\s+", " ", answer).strip()
    return flat[:PHRASE].rsplit(" ", 1)[0] if len(flat) > PHRASE else flat


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="verify the gold phrases against both pipelines' chunks")
    args = ap.parse_args()
    pages, pairs = load_web_corpus(WEB_DIR, sources=("faq",))
    questions, seen = [], set()
    for pair in pairs:
        if len(pair["answer"]) < MIN_ANSWER or pair["question"] in seen:
            continue
        seen.add(pair["question"])
        questions.append({"id": f"faq-{len(questions) + 1}", "type": "faq", "question": pair["question"],
                          "gold_evidence": [[gold_phrase(pair["answer"])]], "gold_docs": [pair["doc"]],
                          "reference_answer": pair["answer"], "category": pair["category"]})
    WEB_QUESTIONS.parent.mkdir(parents=True, exist_ok=True)
    WEB_QUESTIONS.write_text(json.dumps(questions, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"wrote {len(questions)} questions to {WEB_QUESTIONS} ({len(pairs) - len(questions)} FAQ pairs left out: "
          f"answer under {MIN_ANSWER} characters or repeated question)")
    if args.check:
        bad = 0
        for name in ("baseline", "mizan+repair_lam_alef"):
            chunks = chunk_pages(preprocess_pages(pages, get_config(name)), SETTINGS.chunk_size, SETTINGS.chunk_overlap)
            by_doc: dict[str, list[str]] = {}
            for c in chunks:
                by_doc.setdefault(c.doc, []).append(canonical_for_eval(c.text))
            missing = [q["id"] for q in questions if not any(canonical_for_eval(q["gold_evidence"][0][0]) in t for t in by_doc.get(q["gold_docs"][0], []))]
            print(f"  {name}: {len(questions) - len(missing)}/{len(questions)} gold phrases found in the indexed chunks" + (f"; missing {missing[:8]}" if missing else ""))
            bad += len(missing)
        return 1 if bad else 0
    return 0


if __name__ == "__main__":
    sys.exit(main())
