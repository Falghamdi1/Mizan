"""Generate a LARGER evaluation set from the held-out documents, with machine-verifiable gold evidence.

    python scripts/gen_eval_questions.py --docs Tour-Guide-Regulations-Ar-V012.pdf,Tourist-Visa-Regulations-Ar-V012.pdf

For each chunk the LLM returns questions + a short VERBATIM evidence phrase + a reference answer + keywords.
A question is kept only if (all checked automatically):
  * the evidence phrase occurs in the chunk (pipeline-independent canonicalizer, same as scoring),
  * every answer keyword occurs in the chunk (the answer is derivable from the passage),
  * the question does not copy a 6-word run from the passage and is not a duplicate,
  * the question names its regulation (so it is answerable unambiguously in principle).
Output: eval/questions_large.json (+ eval/questions_large_review.md for human review).
All generated questions are flagged "needs_review": a human who did NOT design the preprocessing must read them.
Use with:  MIZAN_QUESTIONS=eval/questions_large.json python -m src.evaluation ...
Requires a real LLM (MIZAN_LLM_PROVIDER=ollama ...).
"""
import argparse
import json
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from finetune.make_pairs import topic_of
from src.chunking import chunk_pages
from src.config import RAW_DIR, SETTINGS
from src.ingestion import load_pdfs
from src.preprocessing import canonical_for_eval, get_config, preprocess_pages
from src.rag import call_llm

GEN_CONFIG = "baseline+repair_lam_alef+remove_tatweel+join_broken_lines"  # readable text, original orthography

SYSTEM = (
    "أنت تبني اختبار تقييم لنظام أسئلة وأجوبة عن لوائح رسمية. سأعطيك اسم اللائحة ومقطعًا منها. "
    "اكتب حتى {n} أسئلة عربية واقعية يمكن الإجابة عنها من المقطع وحده. شروط كل سؤال: "
    "(1) يذكر موضوع اللائحة بشكل طبيعي (مثل الإرشاد السياحي أو تأشيرة السياحة) لأن لوائح أخرى تتشابه معها؛ "
    "(2) صياغته تختلف عن نص المقطع وليست نسخًا حرفيًا؛ (3) إجابته موجودة صراحة في المقطع. "
    "لكل سؤال أعد: question، وevidence (عبارة قصيرة من 4 إلى 10 كلمات منسوخة حرفيًا من المقطع تحتوي الإجابة)، "
    "وanswer (إجابة موجزة)، وkeywords (من 1 إلى 3 كلمات أو أرقام لازمة في أي إجابة صحيحة، وتظهر في المقطع). "
    "إذا كان المقطع عنوانًا أو فهرسًا أو بلا أحكام فأعد []. أجب بقائمة JSON فقط."
)


def parse(text: str) -> list[dict]:
    try:
        data = json.loads(text[text.index("["): text.rindex("]") + 1])
    except Exception:
        return []
    return [d for d in data if isinstance(d, dict) and all(k in d for k in ("question", "evidence", "answer", "keywords"))]


def ngrams(t: str, n: int = 6) -> set[str]:
    w = t.split()
    return {" ".join(w[i:i + n]) for i in range(len(w) - n + 1)}


OUT_OF_SCOPE = [  # handwritten, generic: no regulation text could answer these
    "كم تبلغ أسعار تذاكر الطيران من الرياض إلى جدة؟",
    "ما حالة الطقس في أبها هذا الأسبوع؟",
    "ما أفضل مطعم لتناول المأكولات البحرية في جدة؟",
    "كم عدد سكان مدينة العلا؟",
    "ما موعد انطلاق موسم الرياض القادم؟",
    "كم تكلفة الليلة في فندق خمس نجوم بمكة المكرمة؟",
]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--docs", default="Tour-Guide-Regulations-Ar-V012.pdf,Tourist-Visa-Regulations-Ar-V012.pdf")
    ap.add_argument("--per-chunk", type=int, default=3, help="questions requested per chunk")
    ap.add_argument("--keep-per-chunk", type=int, default=2)
    ap.add_argument("--max", type=int, default=70, help="max answerable questions kept")
    ap.add_argument("--out", default="eval/questions_large.json")
    args = ap.parse_args()
    if SETTINGS.llm_provider == "mock":
        raise SystemExit("Set MIZAN_LLM_PROVIDER=ollama (or anthropic/openai): the mock LLM cannot write questions.")

    docs = {d.strip() for d in args.docs.split(",")}
    pages = [p for p in load_pdfs(RAW_DIR) if p.doc in docs]
    chunks = chunk_pages(preprocess_pages(pages, get_config(GEN_CONFIG)), SETTINGS.chunk_size, SETTINGS.chunk_overlap)
    print(f"{len(chunks)} chunks from {sorted(docs)}")

    kept, seen_q, reject = [], set(), {"evidence": 0, "keywords": 0, "copy": 0, "dup": 0, "no_topic": 0, "parse": 0}
    for i, c in enumerate(chunks, 1):
        prompt = f"اللائحة: {topic_of(c.doc)}\nالمقطع:\n{c.text}\n\nأعد القائمة:"
        items = parse(call_llm(prompt, [], system=SYSTEM.format(n=args.per_chunk)).text)
        if not items:
            reject["parse"] += 1
        canon = canonical_for_eval(c.text)
        n_here = 0
        for it in items:
            q, ev, ans = str(it["question"]).strip(), str(it["evidence"]).strip(), str(it["answer"]).strip()
            kws = [str(k).strip() for k in (it["keywords"] if isinstance(it["keywords"], list) else [it["keywords"]]) if str(k).strip()]
            if n_here >= args.keep_per_chunk:
                break
            if canonical_for_eval(ev) not in canon or len(canonical_for_eval(ev).split()) < 3:
                reject["evidence"] += 1
            elif not kws or any(canonical_for_eval(k) not in canon for k in kws):
                reject["keywords"] += 1
            elif ngrams(q) & ngrams(c.text):
                reject["copy"] += 1
            elif canonical_for_eval(q) in seen_q:
                reject["dup"] += 1
            elif not any(w in q for w in ("إرشاد", "الارشاد", "مرشد", "الإرشاد", "تأشيرة", "التأشيرة", "السياحة", "سياح")):
                reject["no_topic"] += 1
            else:
                seen_q.add(canonical_for_eval(q))
                kept.append({"question": q, "evidence": ev, "answer": ans, "keywords": kws, "doc": c.doc, "page": c.page})
                n_here += 1
        if i % 10 == 0:
            print(f"  {i}/{len(chunks)} chunks, {len(kept)} kept")

    random.Random(0).shuffle(kept)
    kept = kept[: args.max]
    kept.sort(key=lambda d: (d["doc"], d["page"]))
    questions = []
    for n, k in enumerate(kept, 1):
        questions.append({
            "id": f"g{n}", "type": "generated", "question": k["question"],
            "gold_docs": [k["doc"]], "gold_evidence": [[k["evidence"]]],
            "answer_keywords": k["keywords"], "reference_answer": k["answer"],
            "source": {"doc": k["doc"], "page": k["page"]}, "needs_review": True,
        })
    for n, q in enumerate(OUT_OF_SCOPE, 1):
        questions.append({"id": f"u{n}", "type": "unanswerable", "question": q, "gold_evidence": [],
                          "answer_keywords": [], "reference_answer": "غير مذكور في الوثائق.", "needs_review": False})
    Path(args.out).write_text(json.dumps(questions, ensure_ascii=False, indent=1), encoding="utf-8")

    review = ["# Review sheet: generated evaluation questions", "",
              "Tick **OK** only if (1) the question is clear and natural, (2) the evidence phrase really contains the answer, "
              "(3) the reference answer is correct. Fix or delete the rest in `questions_large.json`.", "",
              "| id | doc / page | question | reference answer | evidence (verbatim) | OK |", "|---|---|---|---|---|---|"]
    for q in questions:
        if q["type"] == "generated":
            s = q["source"]
            review.append(f"| {q['id']} | {s['doc'][:20]} p.{s['page']} | {q['question']} | {q['reference_answer']} | "
                          f"{q['gold_evidence'][0][0]} | ☐ |")
    Path(args.out).with_name("questions_large_review.md").write_text("\n".join(review), encoding="utf-8")
    by_doc = {d: sum(1 for q in questions if q.get("gold_docs") == [d]) for d in docs}
    print(f"kept {len(kept)} answerable (+{len(OUT_OF_SCOPE)} unanswerable); per doc {by_doc}; rejected {reject}")
    print(f"wrote {args.out} and the review sheet")


if __name__ == "__main__":
    main()
