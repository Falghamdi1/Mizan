"""Build Mizan_Arabic_RAG_Optimization.ipynb from the files in this repository.

The notebook is one file with all of its code visible: section 2 writes each module to disk with a `%%writefile` cell and the
later sections import it, so the notebook runs on a machine that has nothing else (Colab). The experiment itself is the short
cells in sections 3-9. Run again after any change to src/, scripts/ or eval/:

    python scripts/build_notebook.py
"""
from pathlib import Path

import nbformat as nbf

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "Mizan_Arabic_RAG_Optimization.ipynb"

# (path, role). Support code only: the experiment is in the short cells below.
MODULES = [
    ("src/config.py", "shared settings"), ("src/memory.py", "GPU memory profiles"), ("src/ingestion.py", "PDF text extraction"),
    ("src/preprocessing.py", "the Arabic preprocessing steps: the only experimental variable"), ("src/chunking.py", "chunks"),
    ("src/titles.py", "regulation titles"), ("src/embeddings.py", "stage-1 embedder"), ("src/retrieval.py", "vector index and search"),
    ("src/rerank.py", "stage-2 reranker"), ("src/local_llm.py", "local generator and judge"), ("src/rag.py", "the RAG pipeline"),
    ("src/evaluation.py", "metrics and judge"), ("src/stats.py", "paired bootstrap"), ("src/ui_theme.py", "HTML style"),
    ("src/corpus.py", "which documents are indexed (PDF or web corpus)"), ("src/web_corpus.py", "loaders for the JSON/HTML web corpus"),
    ("src/citations.py", "citation check: cited pages vs shown passages"), ("src/safety.py", "instruction-like text and personal-data scans"), ("src/monitoring.py", "query log, rolling metrics, alerts"), ("src/comparison.py", "side-by-side comparison"), ("src/insights_evidence.py", "Mizan Insights: the evidence of a run, checked facts"), ("src/insights.py", "Mizan Insights: the LLM explanation and its checks"), ("src/i18n.py", "interface strings in English and Arabic"), ("src/ui_style.py", "design tokens, Gradio theme and CSS"), ("src/backend.py", "the app state and logic behind the interface"), ("src/ui.py", "the Gradio interface"), ("src/colab.py", "notebook helpers"),
    ("scripts/fetch_corpus.py", "download and verify the PDFs"), ("scripts/compare_prompts.py", "compare the generator prompt versions"), ("scripts/human_grading.py", "blind sheets for two human graders"), ("data/corpus_manifest.json", "the 8 PDFs: URL, size, SHA-256"),
    ("eval/questions.json", "10 reference questions"), ("eval/questions_large.json", "51 generated questions"),
]


def md(text):
    return nbf.v4.new_markdown_cell(text.strip())


def code(text):
    return nbf.v4.new_code_cell(text.strip("\n"))


INTRO = """
# مِيزان · Mizan: Arabic RAG optimizer

**Question.** Does Arabic-specific text preprocessing improve retrieval or efficiency in a RAG system?
Two pipelines get the same PDFs, questions, models and settings; **only the Arabic preprocessing differs**. The notebook measures what changes and says so plainly when nothing does.

**Everything runs locally on this runtime** (open models from the Hugging Face Hub, no API, no key): Qwen3 embedder, Qwen3 reranker, Qwen3-4B generator, and a non-Qwen judge.

**How to run.** *Runtime › Change runtime type › T4 GPU*, then *Run all*. Your own computer only needs a browser. All code is visible: section 2 holds the project's modules (skip it), sections 3-9 are the experiment.
"""


def cells():
    c = [md(INTRO), md("## 1. Setup")]
    c.append(code('''
import os, sys, time
os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")   # before CUDA starts: less memory fragmentation
T0 = time.perf_counter()
import torch
print("GPU:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "none (this run will be retrieval-only; use a T4 GPU runtime)")
'''))
    c.append(code('''
%pip install -q pymupdf chromadb python-dotenv gradio "sentence-transformers>=5" "transformers>=4.51" accelerate bitsandbytes
'''))
    listing = "\n".join(f"- `{p}`: {d}" for p, d in MODULES)
    c += [md("## 2. Project code (you can skip this section)\nEach cell writes one file; later sections import it.\n\n" + listing),
          code('''
BASE = os.getcwd() if os.path.basename(os.getcwd()) == "mizan" else os.path.join(os.getcwd(), "mizan")   # safe to run twice
for d in ("src", "scripts", "data/raw", "eval"):
    os.makedirs(os.path.join(BASE, d), exist_ok=True)
os.chdir(BASE); sys.path.insert(0, BASE); ROOT = BASE
'''),
          code("%%writefile src/__init__.py\n# Mizan prototype package")]
    c += [code(f"%%writefile {p}\n" + ((ROOT / p).read_text(encoding="utf-8") or "# (empty file)\n")) for p, _ in MODULES]   # %%writefile refuses an empty body

    c += [md("## 3. Models\nThe best profile that fits the GPU is chosen (4B embedder in 16-bit, 4-bit, or the 0.6B one). Each model is loaded and tested at its largest input; on out-of-memory the next smaller profile is used. Only one of generator and judge is in memory at a time."),
          code('''
from src import memory
from src.colab import Stopwatch, start_models
from src.config import SETTINGS
SW = Stopwatch(T0)
PROFILE, _ = start_models("auto", SW)
print(PROFILE.note, "|", memory.report())
'''),
          md("## 4. Documents\nEight public Ministry of Tourism regulation PDFs, downloaded and checked against their SHA-256 (`data/corpus_manifest.json`). If the site cannot be reached from this runtime, upload the PDFs to `mizan/data/raw/` and run the cell again."),
          code('''
from src.colab import get_corpus
from src.config import RAW_DIR
from src.ingestion import load_pdfs
with SW.stage("download + read PDFs"):
    get_corpus(ROOT)
    pages = load_pdfs(RAW_DIR)
print(len({p.doc for p in pages}), "documents,", len(pages), "pages")
'''),
          md("## 5. Two pipelines\n**Standard RAG**: trim and collapse whitespace. **Mizan** (the lite preset, `mizan-lite+repair_lam_alef`): only steps that repair PDF-extraction damage: invisible characters, Unicode NFKC, lam-alef repair, kashida removal, look-alike letters and digit forms. It does not fold correct spelling (diacritics, alef / ya forms, punctuation) and does not remove repeated lines or join lines: in the web-corpus evaluation those steps gave no gain, and the full preset cost a little on clean text. Everything else is shared."),
          code('''
from src.preprocessing import FLAGS, get_config
from src.rag import Pipeline
NAMES = ["baseline", "mizan-lite+repair_lam_alef"]   # Standard RAG, Mizan (lite). The full preset is "mizan+repair_lam_alef".
PIPES = {}
for n in NAMES:
    with SW.stage("index " + n):
        PIPES[n] = Pipeline(get_config(n))
        PIPES[n].build(pages)
    print(f"{n}: {PIPES[n].index_stats['chunks']} passages")
print("steps on in Mizan only:", [f for f in FLAGS if getattr(get_config(NAMES[1]), f) and not getattr(get_config(NAMES[0]), f)])
'''),
          md("**What the PDF really contains** (real lines from the Tour-Guide regulation, page 8): the same line as each pipeline receives it."),
          code('''
from src.colab import show_html
from src.preprocessing import preprocess_text
from src.ui_theme import ar, esc
page8 = next(p for p in pages if p.doc.startswith("Tour-Guide") and p.page == 8)
assert "ال تزيد مدة سريان الترخيص" in page8.text and "الالئحـة" in page8.text     # the two lines below are real, not typed from memory
show_html("".join(f'<p class="mz-label">{esc(who)}</p>{ar(txt, "mz-passage")}' for who, txt in [
    ("As extracted (Standard RAG)", "ال تزيد مدة سريان الترخيص  ·  الالئحـة بحسـب فئـة الترخيـص"),
    ("After Mizan", "لا تزيد مدة سريان الترخيص  ·  اللائحة بحسب فئة الترخيص")]))
print("page 8:", len(page8.text), "characters raw,", len(preprocess_text(page8.text, get_config(NAMES[1]))), "after Mizan")
'''),
          md("## 6. Experiment\nTen reference questions with gold evidence (answers, tokens, latency, and an independent judge that grades after all answers exist), then 51 generated questions for retrieval only (no LLM). The 51 were not reviewed by a person."),
          code('''
from pathlib import Path
from src.evaluation import load_questions, run_eval
QUESTIONS_FILE, LARGE_FILE = Path("eval/questions.json"), Path("eval/questions_large.json")
QUESTIONS = load_questions(QUESTIONS_FILE)
GEN = PROFILE.generator
with SW.stage("answer run + judge"):
    ANS = run_eval(NAMES, pipelines=PIPES, questions_path=QUESTIONS_FILE, retrieve_only=not GEN, judge_answers=GEN)
with SW.stage("retrieval-only run"):
    RET = run_eval(NAMES, pipelines=PIPES, questions_path=LARGE_FILE, retrieve_only=True)
'''),
          md("## 7. Results\nAll numbers are measured in this run. The last column is plain arithmetic (Mizan minus Standard RAG), not a verdict."),
          code('''
from src.colab import paired_line, results_rows, show_html
from src.ui_theme import metrics_table
show_html(metrics_table(results_rows(RET, ANS, *NAMES), ["Standard RAG", "Mizan"], "Measured in this run", na_note=False))
for m in ("hit", "mrr", "first_stage_hit", "candidate_recall"):
    print(paired_line(RET, *NAMES, m, m)["text"])
'''),
          code('''
from src.colab import answers_html
show_html("<h3>Answers next to the reference answer</h3><p class='mz-note'>The judge is small and unvalidated: read the answers yourself.</p>"
          + answers_html(ANS, QUESTIONS, *NAMES))
'''),
          code('''
import matplotlib.pyplot as plt
from src.colab import plot_results
plot_results(RET, ANS, *NAMES); plt.show()
'''),
          md("## 7b. Prompt versions\nThree generator prompts (`src/rag.py`, `PROMPTS`): **v1** the original four rules (every result above uses it), **v2** explicit rules (exact numbers, conflicting passages, exact citation format, refuse without guessing), **v3** structured (answer, quoted evidence, source). Retrieval runs once per question and all three prompts get **the same passages**, the same model and temperature 0, so only the system prompt differs. Measured without an LLM judge: keyword coverage, refusals, whether each citation names a page that was really retrieved, tokens, latency. A blind sheet for two people to grade correctness is written to `results/`. Needs the real generator; skipped on the retrieval-only profile."),
          code('''
RUN_PROMPTS = GEN
if RUN_PROMPTS:
    sys.path.insert(0, "scripts")
    import compare_prompts as CP
    from IPython.display import Markdown
    from src.rag import PROMPTS, warm_up_llm
    warm_up_llm()                                        # the judge replaced the generator in memory; reload it
    PROMPT_QUESTIONS = QUESTIONS + load_questions(LARGE_FILE)      # the 10 reference + the 51 generated questions
    with SW.stage("prompt versions"):
        PR = CP.run(PIPES[NAMES[1]], PROMPT_QUESTIONS, list(PROMPTS))
    paths = CP.save(PR, PROMPT_QUESTIONS)
    display(Markdown(CP.markdown(PR)))
    print("blind grading sheet:", paths["sheet"], "\\nkey (do not open before grading):", paths["key"])
'''),
          md("## 7c. Human grading sheets\nThe judge is small and unvalidated, and keyword coverage is a surface check, so correctness needs people. This cell turns the answer run above into **two identical blind sheets** (one per grader): the reference answer and one answer per pipeline in shuffled columns, no pipeline names, plus a key kept apart. Grade alone with `eval/human_grading/RUBRIC.md`, then merge with `python scripts/human_grading.py merge <folder> --grader1 g1.csv --grader2 g2.csv` to get agreement (kappa), the disagreements to settle together, accuracy per pipeline with a paired interval, and how well the judge and the keyword score match the humans. Needs the real generator."),
          code('''
if GEN:
    import json, pathlib, shutil, subprocess
    pathlib.Path("results").mkdir(exist_ok=True)
    pathlib.Path("results/answers_for_grading.json").write_text(json.dumps(ANS, ensure_ascii=False), encoding="utf-8")
    made = subprocess.run([sys.executable, "scripts/human_grading.py", "make", "results/answers_for_grading.json", "--arms", ",".join(NAMES),
                           "--n", "30", "--unanswerable", "4", "--out", "results/grading"], capture_output=True, text=True, encoding="utf-8")
    print(made.stdout or made.stderr)
    shutil.make_archive("grading_sheets", "zip", "results/grading")          # contains KEY.json: keep it away from the graders
    try:
        from google.colab import files
        files.download("grading_sheets.zip")
    except ImportError:
        print("not in Colab: grading_sheets.zip is in the current folder")
'''),
          md("## 8. Demo\nThe screen from the demo video: same question, same documents, two pipelines. Below it is the same interface as an app: click a prepared question or type your own, and use **Add PDF** to add documents (both pipelines are re-indexed)."),
          code('''
from src.rag import warm_up_llm
from src.ui import render_comparison
if GEN:
    warm_up_llm()                    # the judge replaced the generator in memory; reload it
show_html(render_comparison(PIPES, QUESTIONS[2]["question"], QUESTIONS[2]))
'''),
          code('''
from src.colab import launch
from src.ui import build_ui
launch(build_ui(pages, PIPES, QUESTIONS))
'''),
          md("## 8b. Monitoring\nEvery question asked above and in the app is logged to `logs/queries.jsonl` by `src/monitoring.py`: pipeline, a hash of the question (not its text), retrieved file and page ids, tokens, retrieval / LLM / total latency, whether the answer was a refusal, and how many `[file, page N]` citations point at a page that was really retrieved. No answer or document text is stored. Rules over the last 20 entries per pipeline raise an **alert** (generator errors, refusal rate, p95 latency, missing citations, empty retrieval); alerts are written to `logs/alerts.jsonl`, shown above the table, and sent to a webhook or by email if `MIZAN_ALERT_WEBHOOK` / `MIZAN_ALERT_SMTP_*` are set (see `.env.example`). Thresholds are starting values, not tuned."),
          code('''
from src import monitoring
from src.colab import show_html
show_html(monitoring.panel_html() or "<p>No questions logged yet: ask one above.</p>")
'''),
          md("**Alert drill.** To show that the alert fires without waiting for real traffic, this cell feeds a throw-away monitor six *synthetic* refusals (clearly not real traffic, written to a temporary folder, nothing in `logs/` changes)."),
          code('''
import tempfile, pathlib
from types import SimpleNamespace
from src import monitoring
tmp = pathlib.Path(tempfile.mkdtemp())
drill = monitoring.Monitor(monitoring.MonitorConfig(log_path=tmp / "q.jsonl", alerts_path=tmp / "a.jsonl"), notifier=lambda alerts, cfg: [])
refusal = "لا يحتوي السياق المتاح على إجابة هذا السؤال"
for i in range(6):
    drill.record(SimpleNamespace(pipeline="demo-pipeline", question=f"synthetic {i}", passages=[], answer=refusal, retrieval_latency_s=0.1,
                                 llm=SimpleNamespace(input_tokens=0, output_tokens=0, latency_s=0.1, cached=False), retrieved_tokens=0, total_latency_s=0.2))
for a in drill.after_answer():
    print("ALERT:", a.message)
'''),
          md("## 9. Conclusions\nGenerated from the numbers above. “Distinguishable from zero” means only that the bootstrap interval excludes zero."),
          code('''
from IPython.display import Markdown
from src.colab import summary_lines
G = summary_lines(RET, ANS, *NAMES)
block = lambda title, items: f"**{title}**\\n\\n" + "\\n".join(f"- {x}" for x in items or ["none"]) + "\\n\\n"
display(Markdown(block("Mizan higher (interval excludes zero)", G["up"]) + block("No difference distinguishable from zero", G["flat"])
                 + block("Mizan lower (interval excludes zero)", G["down"]) + block("Efficiency, as measured", G["efficiency"])))
'''),
          md("""
**Limitations.** One run, no repeated seeds. Ten answer questions are far too few to test anything; the 51 retrieval questions were generated by an LLM and not reviewed by a person; the ten reference questions cover two of the eight documents. Chunk size is counted in characters after cleaning, so the pipelines get different numbers of chunks. Both pipelines show the generator the text as indexed. Embedder, reranker and generator are all Qwen; the judge is small and unvalidated. 4-bit quantisation is a memory trade-off whose effect on answers was not measured. No BM25 baseline; one corpus.

**Next.** One-step ablations (`scripts/run_ablations.py` in the repository), a token-based chunk size, a human-reviewed question set, a second corpus, BM25.
"""),
          code('''
show_html(metrics_table([[k, v] for k, v in SW.rows()], ["measured"], "Wall-clock time on this runtime", na_note=False))
''')]
    return c


def main() -> None:
    nb = nbf.v4.new_notebook()
    nb.cells = cells()
    nb.metadata = {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
                   "language_info": {"name": "python"}, "accelerator": "GPU", "colab": {"provenance": [], "gpuType": "T4"}}
    nbf.write(nb, OUT)
    code_lines = sum(len(x.source.splitlines()) for x in nb.cells if x.cell_type == "code" and not x.source.startswith("%%writefile"))
    print(f"wrote {OUT.name}: {len(nb.cells)} cells, {OUT.stat().st_size / 1024:.0f} KB; experiment cells: {code_lines} lines of code")


if __name__ == "__main__":
    main()
