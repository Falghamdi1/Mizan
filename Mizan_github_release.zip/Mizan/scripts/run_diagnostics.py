"""Diagnostics of one Colab results folder that the notebooks do not print: what the preprocessing costs and saves, how much of the
candidate pool it keeps, how steady the runs are, and which individual steps help or hurt. No model, no GPU.

    python scripts/run_diagnostics.py --run results/colab_run4 --earlier results/colab_run2 results/colab_run3

Reads the `lite-<embedder>-<corpus>.json` and `eval-<embedder>-<corpus>.json` files (written by the web notebook) and the leave-one-out
and ablation tables (`*.md`). Writes `docs/data_audit/run_diagnostics.md` and `.json`.

  1. Index cost: chunks, characters and embedding tokens per pipeline, as a change against Standard. Fewer tokens = less to embed,
     store and send, regardless of any quality effect. Measured on the actual indexes, not estimated.
  2. Candidate pool and first stage: paired lite-minus-Standard differences (bootstrap, src/stats.py) in "gold evidence is among the
     top-20 candidates" and "first-stage hit@4" on the answerable questions. These show what the reranker has to work with.
  3. Retrieval latency per question (median and p95) for each pipeline. One run each on a shared Colab GPU: indicative, not a speed claim.
  4. Reproducibility: the same file name in an earlier run, compared metric by metric. Identical results from separate Colab sessions
     mean the pipeline is deterministic; a difference is explained (a different corpus fingerprint) or reported.
  5. Step tally: of the one-step ablations and leave-one-out variants, how many are higher, lower or not distinguishable from the
     reference (the table's own bootstrap labels). This is the optimizer's output: which preprocessing steps actually move retrieval.
"""
from __future__ import annotations

import argparse
import json
import re
import statistics
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src.stats import paired_bootstrap  # noqa: E402

ARMS = ["baseline", "mizan-lite+repair_lam_alef", "mizan+repair_lam_alef"]
SHORT = {"baseline": "Standard", "mizan-lite+repair_lam_alef": "Mizan-lite", "mizan+repair_lam_alef": "Mizan full"}


def load(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))


def pct(new: float, old: float) -> str:
    return f"{(new - old) / old * 100:+.1f}%" if old else "n/a"


def percentile(xs: list[float], q: float) -> float:
    xs = sorted(xs)
    return xs[min(len(xs) - 1, int(q * len(xs)))] if xs else float("nan")


def index_cost(files: list[Path]) -> list[dict]:
    rows = []
    for f in files:
        d = load(f)["pipelines"]
        if ARMS[0] not in d:
            continue
        emb, corpus = re.match(r"lite-(.+)-(pdf|web)\.json", f.name).groups()
        base = d[ARMS[0]]["index"]
        for a in ARMS[1:]:
            if a in d:
                i = d[a]["index"]
                rows.append({"embedder": emb, "corpus": corpus, "pipeline": SHORT[a], "chunks": i["chunks"], "chunks_base": base["chunks"],
                             "chars": i["chars"], "chars_base": base["chars"], "tokens": i["tokens"], "tokens_base": base["tokens"]})
    return rows


def pool(files: list[Path]) -> list[dict]:
    rows = []
    for f in files:
        d = load(f)["pipelines"]
        emb, corpus = re.match(r"lite-(.+)-(pdf|web)\.json", f.name).groups()
        for metric in ("candidate_recall", "first_stage_hit", "hit"):
            for a in ARMS[1:]:
                if a not in d or ARMS[0] not in d:
                    continue
                x = {q["id"]: q[metric] for q in d[ARMS[0]]["per_question"] if q.get(metric) is not None}
                y = {q["id"]: q[metric] for q in d[a]["per_question"] if q.get(metric) is not None}
                pb = paired_bootstrap(x, y)
                if pb:
                    rows.append({"embedder": emb, "corpus": corpus, "metric": metric, "pipeline": SHORT[a], "standard": statistics.fmean(x.values()),
                                 "arm": statistics.fmean(y.values()), "diff": pb[0], "low": pb[1], "high": pb[2], "n": pb[3]})
    return rows


def latency(files: list[Path]) -> list[dict]:
    rows = []
    for f in files:
        d = load(f)["pipelines"]
        emb, corpus = re.match(r"lite-(.+)-(pdf|web)\.json", f.name).groups()
        for a in ARMS:
            if a in d:
                xs = [q["retrieval_latency_s"] for q in d[a]["per_question"] if q.get("retrieval_latency_s") is not None]
                if xs:
                    rows.append({"embedder": emb, "corpus": corpus, "pipeline": SHORT[a], "n": len(xs), "median": statistics.median(xs), "p95": percentile(xs, 0.95), "max": max(xs)})
    return rows


def latency_paired(files: list[Path]) -> list[dict]:
    """Mean paired difference in retrieval seconds (pipeline minus Standard), the first question of each pipeline dropped as warm-up."""
    rows = []
    for f in files:
        d = load(f)["pipelines"]
        emb, corpus = re.match(r"lite-(.+)-(pdf|web)\.json", f.name).groups()
        for a in ARMS[1:]:
            if a not in d or ARMS[0] not in d:
                continue
            x = {q["id"]: q["retrieval_latency_s"] for q in d[ARMS[0]]["per_question"][1:] if q.get("retrieval_latency_s") is not None}
            y = {q["id"]: q["retrieval_latency_s"] for q in d[a]["per_question"][1:] if q.get("retrieval_latency_s") is not None}
            pb = paired_bootstrap(x, y)
            if pb:
                rows.append({"embedder": emb, "corpus": corpus, "pipeline": SHORT[a], "standard_mean": statistics.fmean(x.values()), "arm_mean": statistics.fmean(y.values()),
                             "diff": pb[0], "low": pb[1], "high": pb[2], "n": pb[3]})
    return rows


def reproduce(run: Path, earlier: list[Path]) -> list[dict]:
    rows = []
    metrics = ("hit", "mrr", "precision", "first_stage_hit", "candidate_recall", "retrieved_tokens")
    for e in earlier:
        for f in sorted(run.glob("*.json")):
            g = e / f.name
            if not g.exists() or not re.match(r"(lite|eval)-.+\.json", f.name):
                continue
            a, b = load(f), load(g)
            if "pipelines" not in a or "pipelines" not in b:
                continue
            same_corpus = a.get("run", {}).get("corpus_sha256") == b.get("run", {}).get("corpus_sha256")
            for arm in set(a["pipelines"]) & set(b["pipelines"]):
                for m in metrics:
                    x, y = a["pipelines"][arm]["aggregate"].get(m), b["pipelines"][arm]["aggregate"].get(m)
                    if x is None or y is None:
                        continue
                    rows.append({"earlier": e.name, "file": f.name, "arm": SHORT.get(arm, arm), "metric": m, "now": x, "then": y,
                                 "identical": abs(x - y) < 1e-9, "same_corpus": same_corpus, "absdiff": abs(x - y)})
    return rows


def step_tally(run: Path) -> list[dict]:
    out = []
    for f in sorted(run.glob("*.md")):
        text = f.read_text(encoding="utf-8")
        m = re.search(r"vs `([^`]+)`", text)
        if not m:
            continue
        ref = m.group(1)
        counts = {"higher": 0, "lower": 0, "n.d.": 0}
        steps = {"higher": [], "lower": []}
        for line in text.splitlines():
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if len(cells) < 7 or not cells[0].startswith("`") or "reference" in cells[4]:
                continue
            label = "higher" if cells[4].endswith("higher") else "lower" if cells[4].endswith("lower") else "n.d."
            counts[label] += 1
            if label != "n.d.":
                steps[label].append((cells[0].strip("`"), cells[4]))
        out.append({"file": f.name, "reference": ref, "variants": sum(counts.values()), **counts, "steps": steps})
    return out


def render(res: dict, run: Path) -> str:
    L = ["# Run diagnostics", "", f"Computed by `scripts/run_diagnostics.py` from `{run.name}`. No model was run.", ""]
    L += ["## 1. Index cost (change against Standard, measured on the indexes)", "", "| embedder | corpus | pipeline | chunks | characters | embedding tokens |", "|---|---|---|---|---|---|"]
    for r in res["index_cost"]:
        L.append(f"| {r['embedder']} | {r['corpus']} | {r['pipeline']} | {r['chunks']} ({pct(r['chunks'], r['chunks_base'])}) | {r['chars']:,} ({pct(r['chars'], r['chars_base'])}) | {r['tokens']:,} ({pct(r['tokens'], r['tokens_base'])}) |")
    L += ["", "## 2. Candidate pool and first stage (difference to Standard, paired bootstrap 95%)", "", "| embedder | corpus | metric | pipeline | Standard | pipeline | difference | n |", "|---|---|---|---|---|---|---|---|"]
    for r in res["pool"]:
        star = "" if r["low"] <= 0 <= r["high"] else " *"
        L.append(f"| {r['embedder']} | {r['corpus']} | {r['metric']} | {r['pipeline']} | {r['standard']:.3f} | {r['arm']:.3f} | {r['diff']:+.3f} [{r['low']:+.3f}, {r['high']:+.3f}]{star} | {r['n']} |")
    L += ["", "`*` = interval excludes zero. `candidate_recall` = gold evidence is among the 20 candidates the reranker sees (single-stage embedders: the top 4).", ""]
    L += ["## 3. Retrieval latency per question (seconds; one run each on a shared Colab GPU)", "", "| embedder | corpus | pipeline | n | median | p95 | max |", "|---|---|---|---|---|---|---|"]
    for r in res["latency"]:
        L.append(f"| {r['embedder']} | {r['corpus']} | {r['pipeline']} | {r['n']} | {r['median']:.2f} | {r['p95']:.2f} | {r['max']:.2f} |")
    L += ["", "Paired difference in retrieval seconds against Standard (first question of each pipeline dropped as warm-up; paired bootstrap 95%). The Standard pipeline always ran first in the notebook, so run order is a possible confound; the PDF differences also follow the smaller index (fewer tokens for the reranker):", "",
          "| embedder | corpus | pipeline | Standard mean s | pipeline mean s | difference | n |", "|---|---|---|---|---|---|---|"]
    for r in res["latency_paired"]:
        star = "" if r["low"] <= 0 <= r["high"] else " *"
        L.append(f"| {r['embedder']} | {r['corpus']} | {r['pipeline']} | {r['standard_mean']:.3f} | {r['arm_mean']:.3f} | {r['diff']:+.3f} [{r['low']:+.3f}, {r['high']:+.3f}]{star} | {r['n']} |")
    L += ["", "## 4. Reproducibility against earlier runs", ""]
    rep = res["reproduce"]
    if not rep:
        L.append("No earlier run given.")
    else:
        for e in sorted({r["earlier"] for r in rep}):
            rs = [r for r in rep if r["earlier"] == e]
            same = [r for r in rs if r["same_corpus"]]
            ident = [r for r in same if r["identical"]]
            L.append(f"- **{e}**: {len(rs)} metric values compared across matching files; **{len(ident)} of {len(same)} identical** where the corpus fingerprint is the same; "
                     f"{len(rs) - len(same)} values are on a different corpus (not comparable).")
            bad = [r for r in same if not r["identical"]]
            if bad:
                files = sorted({r["file"] for r in bad})
                L.append(f"  - the {len(bad)} differing values are in {', '.join('`' + f + '`' for f in files)}; largest difference in hit/MRR/precision/recall: "
                         f"{max((r['absdiff'] for r in bad if r['metric'] != 'retrieved_tokens'), default=0):.4f} (one question of 250 = 0.004).")
    L += ["", "## 5. Which steps move retrieval (tally of the notebook's own bootstrap labels)", "", "| table | reference | variants | higher | lower | not distinguishable |", "|---|---|---|---|---|---|"]
    for t in res["steps"]:
        L.append(f"| `{t['file']}` | `{t['reference']}` | {t['variants']} | {t['higher']} | {t['lower']} | {t['n.d.']} |")
    for t in res["steps"]:
        for k in ("higher", "lower"):
            for name, cell in t["steps"][k]:
                L.append(f"- `{t['file']}`: `{name}` is **{k}**: {cell}")
    L.append("")
    return "\n".join(L)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--run", required=True)
    ap.add_argument("--earlier", nargs="*", default=[])
    ap.add_argument("--out", default=str(ROOT / "docs" / "data_audit" / "run_diagnostics"))
    args = ap.parse_args()
    run = Path(args.run)
    lite = sorted(run.glob("lite-*.json"))
    res = {"index_cost": index_cost(lite), "pool": pool(lite), "latency": latency(lite), "latency_paired": latency_paired(lite),
           "reproduce": reproduce(run, [Path(e) for e in args.earlier]), "steps": step_tally(run)}
    out = Path(args.out)
    out.with_suffix(".json").write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
    md = render(res, run)
    out.with_suffix(".md").write_text(md, encoding="utf-8")
    print(md)


if __name__ == "__main__":
    main()
