"""Build a single-file HTML form for writing the blind test questions: the documents on one side, the question and its evidence phrase on the other,
with the phrase checked live against the document text.

    python scripts/make_blind_form.py            # writes data/blind_form/blind_question_form.html (git-ignored: it contains the corpus text)

Open the file in a browser, write 15 to 20 questions, download the CSV. The CSV has the columns of eval/blind_test/template.csv and is then
checked by `python scripts/make_blind_test.py --check yourfile.csv`, which stays the authority (it also applies the chunking of every arm).

The form uses the SAME canonicalizer as the evaluation: the character tables, the diacritic pattern and the order of steps are exported from
src/preprocessing.py, not rewritten. It shows no retrieval or model output, so it cannot leak a result. It embeds the text of the PDFs and of the
web corpus: do not publish or share the generated file (the tourism.sa content is the Ministry's).
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

TEMPLATE = ROOT / "tools" / "blind_question_form.template.html"
OUT = ROOT / "data" / "blind_form" / "blind_question_form.html"


def table(t: dict) -> dict:
    """A str.translate table as {codepoint: replacement or None} with string keys (JSON)."""
    return {str(k): (None if v is None else (v if isinstance(v, str) else chr(v))) for k, v in t.items()}


def canon_tables() -> dict:
    from src import preprocessing as P

    return {"invisible": table(P._INVISIBLE), "alef": table(P._ALEF_FORMS), "ya": table(P._YA_FORMS), "persian": table(P._PERSIAN_FORMS),
            "ta": table(P._TA_MARBUTA), "hamza": table(P._HAMZA_SEATS), "digits": table(P._DIGITS),
            "tatweel": P._TATWEEL, "diacritics": P._DIACRITICS.pattern, "marks": P._MARKS}


def collect() -> dict:
    import make_blind_test as M
    from src import config
    from src.corpus import corpus_fingerprint, load_corpus

    pages, fps = [], []
    for kind, d in (("pdf", config.RAW_DIR), ("web", config.WEB_DIR)):
        if not d.exists() or not any(d.iterdir()):
            print(f"note: no {kind} corpus on this machine, the form will not offer it")
            continue
        for p in load_corpus(d, kind):
            pages.append({"k": kind, "d": p.doc, "p": p.page, "t": p.text})
        fps.append(corpus_fingerprint(d, kind)[:12])
    if not pages:
        raise SystemExit("no corpus found: run scripts/fetch_corpus.py (PDFs) and scripts/fetch_web_corpus.py (web)")
    return {"pages": pages, "fingerprint": "-".join(fps), "canon": canon_tables(), "dev_questions": [q["question"] for q in M.dev_questions()],
            "quota": M.QUOTA, "max_docs": M.MAX_DOCS, "min_words": M.MIN_PHRASE_WORDS}


def render(data: dict, template: str) -> str:
    assert "/*DATA*/" in template
    blob = json.dumps(data, ensure_ascii=False).replace("</", "<\\/")      # a "</script>" inside the text must not end the data block
    return template.replace("/*DATA*/", blob, 1)


def main() -> None:
    sys.path.insert(0, str(ROOT / "scripts"))
    data = collect()
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(render(data, TEMPLATE.read_text(encoding="utf-8")), encoding="utf-8")
    print(f"wrote {OUT} ({OUT.stat().st_size / 1e6:.1f} MB, {len(data['pages'])} pages, {len(data['dev_questions'])} development questions to avoid)")
    print("Open it in a browser. Do not share it: it contains the corpus text.")


if __name__ == "__main__":
    main()
