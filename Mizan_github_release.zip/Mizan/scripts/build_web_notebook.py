"""Build Mizan_Web_Evaluation_Colab.ipynb: the web-corpus evaluation (FAQ questions, three embedders, optional PDFs and
ablations) as one Colab notebook, so nothing heavy has to run on a laptop.

Same rules as the main notebook: all code is visible in ordinary cells; section 2 writes the project's modules to disk and
the later sections import them. Run again after any change to src/ or scripts/:

    python scripts/build_web_notebook.py
"""
import sys
from pathlib import Path

import nbformat as nbf

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
from build_notebook import code, md  # noqa: E402  (same cell helpers as the main notebook)

OUT = ROOT / "Mizan_Web_Evaluation_Colab.ipynb"
MODULES = [
    ("src/config.py", "shared settings"), ("src/memory.py", "GPU memory profiles"), ("src/ingestion.py", "PDF text extraction"),
    ("src/preprocessing.py", "the Arabic preprocessing steps: the only experimental variable"), ("src/chunking.py", "chunks"),
    ("src/titles.py", "regulation titles"), ("src/embeddings.py", "stage-1 embedder"), ("src/retrieval.py", "vector index and search"),
    ("src/rerank.py", "stage-2 reranker"), ("src/local_llm.py", "local model cache (needed by memory.py)"),
    ("src/rag.py", "the RAG pipeline"), ("src/web_corpus.py", "loaders for the JSON/HTML web corpus"),
    ("src/citations.py", "citation check: cited pages vs shown passages"), ("src/safety.py", "instruction-like text and personal-data scans"), ("src/corpus.py", "which documents are indexed"), ("src/evaluation.py", "metrics"), ("src/stats.py", "paired bootstrap"),
    ("src/ablation.py", "one-step ablations"), ("src/colab.py", "notebook helpers"),
    ("scripts/fetch_web_corpus.py", "download the web corpus"), ("scripts/make_faq_questions.py", "build the 250 FAQ questions"),
    ("scripts/fetch_corpus.py", "download the 8 PDFs (optional part)"), ("data/corpus_manifest.json", "the 8 PDFs: URL, size, SHA-256"),
    ("scripts/make_pdf_questions.py", "build the questions whose evidence is inside the PDFs"),
    ("eval/pdf_faq_alignment.json", "FAQ question (hash) -> evidence phrase inside the PDFs"),
    ("finetune/__init__.py", "package marker"), ("finetune/remap_pairs.py", "map the training pairs onto another pipeline's text"),
    ("finetune/train_lora.py", "LoRA fine-tuning of the embedder"), ("finetune/pairs_v2.jsonl", "556 training pairs (questions written by Qwen3-4B, from 6 PDFs)"),
    ("scripts/run_adaptation.py", "model adaptation: train, then before/after on held-out documents"),
    ("eval/questions.json", "10 hand-written questions"), ("eval/questions_large.json", "51 generated questions"),
]

INTRO = """
# مِيزان · Mizan: web-corpus evaluation

**Question.** On clean official Arabic text (JSON and HTML from the Ministry of Tourism platform, the Bureau of Experts and GASTAT), does Arabic preprocessing change retrieval?
Two pipelines get the same documents, the same 250 questions and the same models; **only the preprocessing differs**. The 250 questions are the Ministry's own FAQ questions, so they are not written by us or by an LLM. Retrieval only: no generator and no judge.

**How to run.** *Runtime › Change runtime type › T4 GPU*, then *Run all*. Your own computer only needs a browser. Section 4 (the 4B embedder) and section 6 (the ablations) are the slow ones; the lists and switches at the top of each say how to skip them. A free Colab session can disconnect after a few hours: if the ablations are too long, set `RUN_ABLATIONS = False` first and run them in a second session.

**Data terms.** The tourism.sa content is the Ministry's: its terms require written permission to copy it into other systems. Use this notebook for the team's own evaluation, do not share the downloaded text, and delete the runtime when done.
"""

# The frozen blind test set joins the notebook only once it exists (scripts/make_blind_test.py --build), together with its hashes.
for _extra, _why in (("eval/questions_final_test_pdf.json", "blind test set, PDF questions (frozen)"), ("eval/questions_final_test_web.json", "blind test set, web questions (frozen)"),
                     ("eval/blind_test/FROZEN.json", "hashes of the frozen blind set"), ("scripts/make_blind_test.py", "checks that the frozen set is unchanged")):
    if (ROOT / _extra).exists() and all((ROOT / "eval" / f"questions_final_test_{k}.json").exists() for k in ("pdf", "web")):
        MODULES.append((_extra, _why))


def cells():
    c = [md(INTRO), md("## 1. Setup")]
    c.append(code('''
import os, sys, time
os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")   # before CUDA starts: less memory fragmentation
os.environ["MIZAN_CORPUS"] = "web"
T0 = time.perf_counter()
import torch
print("GPU:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "none: choose a T4 GPU runtime, the Qwen models are too slow on a CPU")
'''))
    c.append(code('''
%pip install -q pymupdf chromadb python-dotenv peft "sentence-transformers>=5" "transformers>=4.51" accelerate
'''))
    listing = "\n".join(f"- `{p}`: {d}" for p, d in MODULES)
    c += [md("## 2. Project code (you can skip this section)\nEach cell writes one file; later sections import it.\n\n" + listing),
          code('''
BASE = os.getcwd() if os.path.basename(os.getcwd()) == "mizan" else os.path.join(os.getcwd(), "mizan")   # safe to run twice
for d in ("src", "scripts", "eval", "finetune", "data/raw", "data/web/raw", "results"):
    os.makedirs(os.path.join(BASE, d), exist_ok=True)
os.chdir(BASE); sys.path.insert(0, BASE); ROOT = BASE
'''),
          code("%%writefile src/__init__.py\n# Mizan prototype package")]
    c += [code(f"%%writefile {p}\n" + ((ROOT / p).read_text(encoding="utf-8") or "# (empty file)\n")) for p, _ in MODULES]   # %%writefile refuses an empty body

    c += [md("## 3. The corpus and the questions\nThe fetch script downloads the raw JSON and HTML files and records the SHA-256 of each. The question script turns each FAQ question into an evaluation question whose gold evidence is the start of the Ministry's own answer, then checks that every gold phrase exists in the chunks both pipelines index."),
          code('''
!python scripts/fetch_web_corpus.py
'''),
          md("**Check that everything arrived.** Some sites answer slowly or not at all from Colab's network (in the first Colab run the six Bureau of Experts law pages timed out, and the notebook went on without them: 562 pages instead of 739, so those results are on a smaller corpus). If files are missing and `UPLOAD_IF_MISSING` is on, you are asked to upload them: the `law-*.html` and `gastat-*.html` files from your own copy of `data/web/raw/` (or the one zip `html_for_colab.zip` made from them) are enough."),
          code('''
sys.path.insert(0, "scripts")
import fetch_web_corpus as F
EXPECTED = (["faq.json", "definitions.json", "methodologies.json", "news-0.json"] + [f"law-{s}.html" for s in F.LAWS]
            + [f"gastat-{s}.html" for s in F.GASTAT_PAGES])
UPLOAD_IF_MISSING = True
missing = [f for f in EXPECTED if not os.path.exists(f"data/web/raw/{f}")]
if missing and UPLOAD_IF_MISSING:
    print("Missing:", ", ".join(missing), "\\nChoose the missing file(s) or one zip of them.")
    from google.colab import files
    import zipfile
    for name, data in files.upload().items():
        path = f"data/web/raw/{name}"
        open(path, "wb").write(data)
        if name.endswith(".zip"):
            zipfile.ZipFile(path).extractall("data/web/raw")
    missing = [f for f in EXPECTED if not os.path.exists(f"data/web/raw/{f}")]
print("All expected files are present." if not missing else f"WARNING: still missing {missing}. The corpus is incomplete; results are NOT comparable with a run that has every file.")
'''),
          code('''
!python scripts/make_faq_questions.py --check
'''),
          code('''
from src import config
from src.corpus import load_corpus
PAGES = load_corpus(config.RAW_DIR)
kinds = {}
for p in PAGES:
    kinds.setdefault(p.doc.split("/")[0], []).append(len(p.text))
for k, v in kinds.items():
    print(f"{k:12s} {len(v):4d} pages {sum(v):8,d} characters")
print("total", len(PAGES), "pages,", sum(len(p.text) for p in PAGES), "characters")
''')]

    c += [md("## 4. Experiment: three embedders\nStandard RAG (whitespace cleanup only) against Mizan (`mizan+repair_lam_alef`: all steps, with the lam-alef repair that has nothing to repair in web text). Everything else is shared. `hit` is whether a chunk with the start of the Ministry's answer is in the top 4. The difference column is Mizan minus Standard with a 95% interval from a paired bootstrap over the 250 questions; no correction for the several metrics shown."),
          code('''
from src import memory, retrieval
from src.colab import Stopwatch, paired_line
from src.evaluation import run_eval
SW = Stopwatch(T0)
NAMES = ["baseline", "mizan+repair_lam_alef"]          # Standard RAG, Mizan
EMBEDDERS = {                                           # label -> (embedding model, reranker; "" = single stage)
    "e5-small": ("intfloat/multilingual-e5-small", ""),
    "Qwen3-Embedding-0.6B + reranker": ("Qwen/Qwen3-Embedding-0.6B", "Qwen/Qwen3-Reranker-0.6B"),
    "Qwen3-Embedding-4B + reranker": ("Qwen/Qwen3-Embedding-4B", "Qwen/Qwen3-Reranker-0.6B"),   # about 8 GB download
}
RUN = ["e5-small", "Qwen3-Embedding-0.6B + reranker", "Qwen3-Embedding-4B + reranker"]           # delete a name to skip it
'''),
          code('''
def evaluate(label, corpus="web", questions=None):
    model, reranker = EMBEDDERS[label]
    config.CORPUS = corpus                              # "web", or "all" = web + the 8 PDFs
    config.override(embedding_model=model, embed_quant="none", embedding_adapter="", reranker=reranker, rerank_top_n=20,
                    rerank_4bit=False, chunk_title=False, llm_provider="mock", judge_provider="")
    with SW.stage(f"{label}, corpus {corpus}"):
        res = run_eval(NAMES, questions_path=questions or config.WEB_QUESTIONS, retrieve_only=True)
    for n in NAMES:
        retrieval.drop_index(n)
    memory.release_all()                                # unload the models before the next one
    return res

RESULTS = {(label, "web"): evaluate(label) for label in RUN}
'''),
          code('''
import pandas as pd
def comparison(results):
    rows = []
    for (label, corpus), res in results.items():
        for metric in ("hit", "mrr", "precision", "first_stage_hit", "candidate_recall"):
            line = paired_line(res, *NAMES, metric, metric)
            if line["kind"] == "na":
                continue
            rows.append({"embedder": label, "corpus": corpus, "metric": metric, "Standard": round(line["a"], 3), "Mizan": round(line["b"], 3),
                         "Mizan - Standard": round(line["diff"], 3), "95% CI": f"[{line['lo']:+.3f}, {line['hi']:+.3f}]",
                         "reading": {"up": "Mizan higher", "down": "Mizan lower", "flat": "no difference distinguishable from zero"}[line["kind"]]})
    return pd.DataFrame(rows)
comparison(RESULTS)
''')]

    c += [md("## 5. Optional: add the 8 PDFs as extra, noisy documents\nThe same 250 questions, but the index also holds the 8 Ministry PDFs (extraction defects, lam-alef damage). **Read this section carefully:** the FAQ answers are the only gold, but the regulations the FAQ is based on are in the PDFs, so a PDF chunk that answers the question correctly still counts as a miss. A pipeline that cleans the PDF text makes those chunks match the questions better, so it can *lose* hit rate here for a good reason. The table after the comparison shows how much of the top 4 comes from PDFs, which is the number to read first. Set `INCLUDE_PDFS = False` to skip."),
          code('''
INCLUDE_PDFS = True
if INCLUDE_PDFS:
    from src.colab import get_corpus
    get_corpus(ROOT)                                    # downloads and verifies the 8 PDFs (needs the ministry site to be reachable)
    for label in RUN:
        RESULTS[(label, "all")] = evaluate(label, "all")
    config.CORPUS = "web"
comparison({k: v for k, v in RESULTS.items() if k[1] == "all"}) if INCLUDE_PDFS else None
'''),
          code('''
def pdf_share(res, name):                               # share of the retrieved top-4 chunks that come from a PDF
    docs = [r["doc"] for q in res["pipelines"][name]["per_question"] for r in q["retrieved"]]
    return sum(d.lower().endswith(".pdf") for d in docs) / len(docs)
if INCLUDE_PDFS:
    print("Share of the top 4 that are PDF chunks (the PDFs are 2 of 7 sources but not the gold):")
    for (label, corpus), res in RESULTS.items():
        if corpus == "all":
            print(f"  {label:34s} Standard {pdf_share(res, NAMES[0]):.1%}   Mizan {pdf_share(res, NAMES[1]):.1%}")
'''),
          md("""## 5b. PDF-based questions: where Mizan can matter
Everything above uses clean web text, where there is little for Arabic preprocessing to fix. This section is the test that can show an effect: **the evidence is inside the 8 regulation PDFs**, whose extraction is damaged (lam-alef ligatures, lost letters, stray glyphs). The questions are still the Ministry's own FAQ questions, but only those whose answer is stated in a PDF, with the evidence phrase taken from the PDF text (`eval/pdf_faq_alignment.json`). Only the PDFs are indexed, so the FAQ answers cannot be retrieved instead.

How the set was made, and what it is not: a lexical search proposed PDF passages for each of the 196 FAQ questions in the six categories that map to our PDFs, and the evidence phrase was chosen by reading the answer next to the passage. That is a judgement by one reader (an AI assistant), so **every question is flagged `needs_review`: a second person should check it.** A question is kept only if its phrase is found, after the fixed evaluation canonicalizer, in the chunks of *both* pipelines, so neither pipeline is favoured by the choice of phrase. Questions whose phrase exists only in Mizan's repaired text (the text is too damaged in Standard RAG's version to contain it) were dropped, which understates Mizan's advantage if anything. Set `INCLUDE_PDF_QUESTIONS = False` to skip."""),
          code('''
INCLUDE_PDF_QUESTIONS = True
if INCLUDE_PDF_QUESTIONS:
    import subprocess
    from src.colab import get_corpus
    get_corpus(ROOT)                                    # the 8 PDFs (already there if section 5 ran)
    made = subprocess.run([sys.executable, "scripts/make_pdf_questions.py"], capture_output=True, text=True, encoding="utf-8",
                          env={**os.environ, "PYTHONIOENCODING": "utf-8"})
    print(made.stdout[-1800:] or made.stderr[-1800:])
    for label in RUN:
        RESULTS[(label, "pdf")] = evaluate(label, "pdf", config.PDF_FAQ_QUESTIONS)
    config.CORPUS = "web"
comparison({k: v for k, v in RESULTS.items() if k[1] == "pdf"}) if INCLUDE_PDF_QUESTIONS else None
''')]

    c += [md("## 6. Optional: one-step ablations (the slow part)\nWhich single step moves retrieval? By default 17 pipelines: the references (`baseline`, `mizan`, `mizan+repair_lam_alef`) and `baseline + one step` for each of the 14 steps, each built and evaluated in turn with one embedder. In the first Colab run this took 59 minutes on a T4 (about 3.5 minutes per pipeline). Use `ablation_names()` instead for all 29 (adds `Mizan minus one step`). The intervals are uncorrected: with this many comparisons, read an interval that barely excludes zero as weak evidence. **Noise floor:** in the first run on web text, `baseline+repair_lam_alef` (which changes nothing there) still scored one question differently from `baseline`, so one question is noise. On the PDF questions the repair does change the text, so that step is expected to matter. `ABLATION_ON` chooses the PDF questions (default) or the web questions; with the PDFs only 356 chunks are indexed, so each pipeline takes less time than on the web corpus. Set `RUN_ABLATIONS = False` to skip."),
          code('''
RUN_ABLATIONS = True
ABLATION_EMBEDDER = "Qwen3-Embedding-0.6B + reranker"
ABLATION_ON = "pdf"                                     # "pdf" = the PDF questions (where an effect can show), "web" = the 250 web questions
ABLATION_QUESTIONS = config.PDF_FAQ_QUESTIONS if ABLATION_ON == "pdf" else config.WEB_QUESTIONS
if RUN_ABLATIONS:
    from src.ablation import markdown, run_ablations
    model, reranker = EMBEDDERS[ABLATION_EMBEDDER]
    config.CORPUS = ABLATION_ON
    config.override(embedding_model=model, embed_quant="none", embedding_adapter="", reranker=reranker, rerank_top_n=20,
                    rerank_4bit=False, chunk_title=False, llm_provider="mock", judge_provider="")
    from src.ablation import ablation_names
    NAMES_ABL = [n for n in ablation_names() if not n.startswith("mizan-no-")]      # references + add-one; use ablation_names() for all
    with SW.stage("ablations"):
        ABL = run_ablations(load_corpus(config.RAW_DIR), ABLATION_QUESTIONS, NAMES_ABL)
    memory.release_all()
    table_md = markdown(ABL)
    open(f"results/ablations-{ABLATION_ON}.md", "w", encoding="utf-8").write(table_md)
    from IPython.display import Markdown
    display(Markdown(table_md))
'''),
          md("## 6b. Optional: pick steps on one half of the questions, test on the other\nChoosing steps because they scored well on the same questions you then report on makes the result look better than it is. Here the questions are split at random (fixed seed) into a dev half and a test half. A step is chosen only if it gains at least two questions on the dev half; the chosen steps are combined into one pipeline, and that pipeline is compared with `baseline` on the test half only. With the 77 PDF questions each half has only about 38, so the interval is very wide: treat this as a demonstration of the method, not as a result."),
          code('''
if RUN_ABLATIONS:
    import random, statistics
    from src.stats import paired_bootstrap
    ids = [r["id"] for r in ABL["pipelines"]["baseline"]["per_question"]]
    random.Random(0).shuffle(ids)
    DEV, TEST = set(ids[:len(ids) // 2]), set(ids[len(ids) // 2:])
    def hits(result, name, subset):
        return {r["id"]: r["hit"] for r in result["pipelines"][name]["per_question"] if r["id"] in subset}
    base_dev = statistics.fmean(hits(ABL, "baseline", DEV).values())
    gain = {n.split("+", 1)[1]: statistics.fmean(hits(ABL, n, DEV).values()) - base_dev for n in ABL["pipelines"] if n.startswith("baseline+")}
    CHOSEN = [f for f, g in sorted(gain.items(), key=lambda x: -x[1]) if g >= 2 / len(DEV)]
    print("gain on the dev half:", {f: round(g, 3) for f, g in sorted(gain.items(), key=lambda x: -x[1])})
    print("chosen on the dev half:", CHOSEN or "none")
    if CHOSEN:
        SEL = "baseline+" + "+".join(CHOSEN)
        with SW.stage("selected pipeline"):
            SELECTED = run_eval([SEL], questions_path=ABLATION_QUESTIONS, retrieve_only=True)       # all questions are run; only the test half is scored below
        a, b = hits(ABL, "baseline", TEST), hits(SELECTED, SEL, TEST)
        mean, lo, hi, n = paired_bootstrap(a, b)
        print(f"TEST half ({n} questions): baseline {statistics.fmean(a.values()):.3f}, {SEL} {statistics.fmean(b.values()):.3f}, "
              f"difference {mean:+.3f} [95% CI {lo:+.3f}, {hi:+.3f}]")
        retrieval.drop_index(SEL)
        memory.release_all()
'''),
          ]

    c += [md("""## 6c. Mizan-lite: the same test with a smaller set of steps
Run 2 showed the full Mizan preset helping the small embedder on damaged PDF text, doing nothing measurable for the Qwen3 models there, and costing a little on clean web text with the Qwen3 models. **Mizan-lite** keeps only the steps that repair extraction damage (invisible marks, presentation forms, kashida, look-alike letters, digit forms, plus the lam-alef repair) and switches off the steps that fold correct spelling (diacritics, alef and alef-maqsura forms, punctuation) or delete and reshape text (repeated lines, joined lines). Kashida removal matters most: in these PDFs it removes 12% of all characters.

**This is a pre-specified test, not a tuned result.** The set was fixed before it was run on either question set, so each cell below is one honest comparison. If lite is then changed because of these numbers, the changed version needs a fresh test set. The table reports lite against Standard *and* against the full Mizan, on both question sets, for each embedder. Set `RUN_LITE = False` to skip."""),
          code('''
RUN_LITE = True
LITE_EMBEDDERS = list(RUN)                              # delete a name to skip it
LITE_NAMES = ["baseline", "mizan+repair_lam_alef", "mizan-lite+repair_lam_alef"]
LITE = {}
if RUN_LITE:
    from src.colab import get_corpus
    get_corpus(ROOT)
    for label in LITE_EMBEDDERS:
        model, reranker = EMBEDDERS[label]
        config.override(embedding_model=model, embed_quant="none", embedding_adapter="", reranker=reranker, rerank_top_n=20,
                        rerank_4bit=False, chunk_title=False, llm_provider="mock", judge_provider="")
        for corpus, questions in (("pdf", config.PDF_FAQ_QUESTIONS), ("web", config.WEB_QUESTIONS)):
            config.CORPUS = corpus
            with SW.stage(f"lite: {label}, {corpus}"):
                LITE[(label, corpus)] = run_eval(LITE_NAMES, questions_path=questions, retrieve_only=True)
            for n in LITE_NAMES:
                retrieval.drop_index(n)
            memory.release_all()
    config.CORPUS = "web"
'''),
          code('''
def lite_table(results):
    rows = []
    for (label, corpus), res in results.items():
        for metric in ("hit", "mrr"):
            row = {"embedder": label, "questions": corpus, "metric": metric}
            for tag, a, b in (("lite - Standard", LITE_NAMES[0], LITE_NAMES[2]), ("lite - full Mizan", LITE_NAMES[1], LITE_NAMES[2]),
                              ("full Mizan - Standard", LITE_NAMES[0], LITE_NAMES[1])):
                line = paired_line(res, a, b, metric, metric)
                row[tag] = "n/a" if line["kind"] == "na" else (f"{line['diff']:+.3f} [{line['lo']:+.3f}, {line['hi']:+.3f}]"
                                                              + (" *" if line["kind"] != "flat" else ""))
            row["lite hit/mrr"] = round(res["pipelines"][LITE_NAMES[2]]["aggregate"][metric], 3)
            rows.append(row)
    return pd.DataFrame(rows)
if RUN_LITE:
    print("difference [95% CI]; * = the interval excludes zero. n.d. otherwise.")
    display(lite_table(LITE))
    for (label, corpus), res in LITE.items():
        s = [res["pipelines"][n]["index"] for n in LITE_NAMES]
        print(f"{label:34s} {corpus}: chunks {s[0]['chunks']} / {s[1]['chunks']} / {s[2]['chunks']}   index tokens {s[0]['tokens']} / {s[1]['tokens']} / {s[2]['tokens']}   (Standard / full Mizan / lite)")
'''),
          md("""**Which step does the work for the small embedder?** The full preset gave e5-small +0.234 on the PDF questions. This cheap leave-one-out (e5-small only, PDF questions only, 13 pipelines) removes each full-preset step in turn and compares with the full preset, so the table shows which steps that gain depends on. It is a diagnosis, not a selection: if a step looks unneeded here, that is a hypothesis for a new test set, not a reason to change lite and quote the result. Set `RUN_LOO = False` to skip."""),
          code('''
RUN_LOO = True
if RUN_LOO:
    from IPython.display import Markdown, display
    from src.ablation import ablation_names, markdown, run_ablations
    model, reranker = EMBEDDERS["e5-small"]
    config.CORPUS = "pdf"
    config.override(embedding_model=model, embed_quant="none", embedding_adapter="", reranker=reranker, rerank_top_n=20,
                    rerank_4bit=False, chunk_title=False, llm_provider="mock", judge_provider="")
    NAMES_LOO = ["baseline", "mizan"] + [n for n in ablation_names() if n.startswith("mizan-no-")]
    with SW.stage("leave-one-out, e5-small"):
        LOO = run_ablations(load_corpus(config.RAW_DIR), config.PDF_FAQ_QUESTIONS, NAMES_LOO)
    memory.release_all()
    loo_md = markdown(LOO, ref="mizan")
    open("results/leave-one-out-e5-pdf.md", "w", encoding="utf-8").write(loo_md)
    display(Markdown(loo_md))
    config.CORPUS = "web"
''')]

    c += [md("""## 6d. Model adaptation: LoRA fine-tuning of the embedder, before vs after
This is the required model-adaptation experiment (fine-tuning, not preprocessing, not a prompt change). `Qwen3-Embedding-0.6B` is fine-tuned with LoRA on 554 question-passage pairs (the questions were written by Qwen3-4B from **six** of the eight PDFs, mapped onto Mizan-lite text with regulation titles) for 3 epochs, then compared with the untuned model on questions about the **two held-out PDFs** (Tour-Guide and Tourist-Visa) that the training never saw. Same Mizan-lite text, titles, index, top-4 and questions in both arms; no reranker. The script first prints a **leakage report** and stops if an evaluation question equals a training query. Three question sets are reported separately because they are not equally trustworthy: 45 questions generated by the same model family that wrote the training pairs (a gain there can be partly question-style learning), 9 hand-written, and the few Ministry FAQ questions whose gold passages are all in the held-out PDFs. About 15 minutes on a T4 (training about 100 steps). Set `RUN_ADAPTATION = False` to skip. A neutral or negative result is reported as it is."""),
          code('''
RUN_ADAPTATION = True
if RUN_ADAPTATION:
    import subprocess
    from src.colab import get_corpus
    get_corpus(ROOT)                                    # the 8 PDFs
    if not os.path.exists(config.PDF_FAQ_QUESTIONS):    # the Ministry FAQ questions that point into the PDFs (section 5b builds them too)
        subprocess.run([sys.executable, "scripts/make_pdf_questions.py"], capture_output=True)
    from src import memory
    memory.release_all()                                # the 4B embedder and the reranker of section 4 may still hold GPU memory
    log = open("results/adaptation-log.txt", "w", encoding="utf-8")      # kept in the results zip, so a failure can be diagnosed afterwards
    proc = subprocess.Popen([sys.executable, "scripts/run_adaptation.py", "--train"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, encoding="utf-8", bufsize=1, env={**os.environ, "PYTHONIOENCODING": "utf-8"})
    for line in proc.stdout:
        print(line, end=""); log.write(line)
    rc = proc.wait(); log.close()
    print("exit code", rc)
    if rc:
        print("ADAPTATION DID NOT FINISH. Read the message above; results/adaptation-log.txt has the full output and goes into the results zip. "
              "If it says out of memory: Runtime > Restart session, then run only sections 1, 2, 3 and 6d.")
    memory.release_all()
''')]

    c += [md("""## 6e. The final comparison on the frozen blind test set (run once)
The three of us wrote these questions before looking at any result for them (`eval/blind_test/README.md`), froze them with a hash, and this cell checks the hash before using them. **They are used here once, for the final Standard vs Mizan-full vs Mizan-lite comparison, and never to choose anything.** PDF questions are evaluated on the PDF corpus and web questions on the web corpus, never in one index. If no blind set has been frozen yet (the files are added to this notebook when it is rebuilt after `make_blind_test.py --build`), the cell says so and does nothing."""),
          code('''
RUN_BLIND = True
BLIND = {}
if RUN_BLIND and os.path.exists("eval/blind_test/FROZEN.json"):
    import subprocess
    ver = subprocess.run([sys.executable, "scripts/make_blind_test.py", "--verify"], capture_output=True, text=True, encoding="utf-8")
    print(ver.stdout.strip())
    assert ver.returncode == 0, "the blind set changed after it was frozen: do not use it"
    from src.colab import get_corpus
    get_corpus(ROOT)
    for label in LITE_EMBEDDERS:
        model, reranker = EMBEDDERS[label]
        config.override(embedding_model=model, embed_quant="none", embedding_adapter="", reranker=reranker, rerank_top_n=20,
                        rerank_4bit=False, chunk_title=False, llm_provider="mock", judge_provider="")
        for corpus in ("pdf", "web"):
            config.CORPUS = corpus
            with SW.stage(f"blind: {label}, {corpus}"):
                BLIND[(label, corpus)] = run_eval(LITE_NAMES, questions_path=f"eval/questions_final_test_{corpus}.json", retrieve_only=True)
            for n in LITE_NAMES:
                retrieval.drop_index(n)
            memory.release_all()
    config.CORPUS = "web"
    display(lite_table(BLIND))
else:
    print("No frozen blind set in this notebook yet: nothing to run.")
''')]

    c += [md("## 7. Save the results\nThe zip holds the result files (per-question retrieval, settings, corpus fingerprint, versions) and the comparison tables. It is a few hundred KB."),
          code('''
import json, shutil
comparison(RESULTS).to_csv("results/comparison.csv", index=False)
if BLIND:
    lite_table(BLIND).to_csv("results/blind_test.csv", index=False)
    for (label, corpus), res in BLIND.items():
        open(f"results/blind-{label.split(chr(32))[0].replace(chr(43), chr(95))}-{corpus}.json", "w", encoding="utf-8").write(json.dumps(res, ensure_ascii=False, indent=1))
if LITE:
    lite_table(LITE).to_csv("results/lite.csv", index=False)
    for (label, corpus), res in LITE.items():
        name = label.split(" ")[0].replace("+", "") + "-" + corpus
        open(f"results/lite-{name}.json", "w", encoding="utf-8").write(json.dumps(res, ensure_ascii=False, indent=1))
for (label, corpus), res in RESULTS.items():
    name = label.split(" ")[0].replace("+", "") + "-" + corpus
    open(f"results/eval-{name}.json", "w", encoding="utf-8").write(json.dumps(res, ensure_ascii=False, indent=1))
shutil.make_archive("/content/mizan_web_results" if os.path.isdir("/content") else "mizan_web_results", "zip", "results")
try:
    from google.colab import files
    files.download("/content/mizan_web_results.zip")
except ImportError:
    print("not in Colab: the zip is in the current folder")
'''),
          md("""
**How to read this.** One run, no repeated seeds. Questions are the Ministry's FAQ questions, answers share vocabulary with their questions, so absolute scores overstate real-world retrieval: use the notebook to compare pipelines, not to quote an accuracy. A chunk counts as a hit only if it holds the start of the answer, so a long answer split over several chunks is harder. Chunk size is counted in characters after cleaning, so the pipelines make slightly different numbers of chunks. Intervals are uncorrected for the several metrics and embedders.
"""),
          code('''
print("Wall-clock time on this runtime")
for name, value in SW.rows():
    print(f"  {name}: {value}")
''')]
    return c


def main() -> None:
    nb = nbf.v4.new_notebook()
    nb.cells = cells()
    nb.metadata = {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
                   "language_info": {"name": "python"}, "accelerator": "GPU", "colab": {"provenance": [], "gpuType": "T4"}}
    nbf.write(nb, OUT)
    lines = sum(len(x.source.splitlines()) for x in nb.cells if x.cell_type == "code" and not x.source.startswith("%%writefile"))
    print(f"wrote {OUT.name}: {len(nb.cells)} cells, {OUT.stat().st_size / 1024:.0f} KB; experiment cells: {lines} lines of code")


if __name__ == "__main__":
    main()
