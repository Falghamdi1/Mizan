"""Paired bootstrap comparison of two pipelines (or two runs) from saved result files.

Every "difference [95% CI]" number in the documentation comes from this script, so it can be reproduced:

    # two pipelines inside one result file
    python scripts/compare_runs.py results/eval-X.json --a baseline --b mizan+repair_lam_alef

    # the same pipeline in two different runs (e.g. with and without the reranker)
    python scripts/compare_runs.py results/eval-OLD.json results/eval-NEW.json --a mizan+repair_lam_alef

Questions are resampled with replacement (5000 times, fixed seed); the difference (b - a) is computed per resample.
Only questions present and measured in both are used. The interval treats questions as independent, which is
optimistic when many questions come from the same page or document. Many comparisons were run during the project and
none is corrected for multiple testing: treat isolated intervals that just exclude zero with caution.
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src.stats import paired_bootstrap  # noqa: E402

METRICS = ["hit", "mrr", "precision", "keyword_coverage", "judge_correct", "judge_faithful", "retrieved_tokens", "input_tokens",
           "citation_present", "citation_valid_share", "invalid_citation"]


def per_question(run: dict, pipeline: str, metric: str) -> dict:
    return {r["id"]: r[metric] for r in run["pipelines"][pipeline]["per_question"] if r.get(metric) is not None}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("run_a", help="result JSON")
    ap.add_argument("run_b", nargs="?", help="second result JSON (default: same file)")
    ap.add_argument("--a", required=True, help="pipeline name in the first run")
    ap.add_argument("--b", help="pipeline name in the second run (default: same as --a if two files, else required)")
    ap.add_argument("--metrics", default=",".join(METRICS))
    args = ap.parse_args()
    ra = json.loads(Path(args.run_a).read_text(encoding="utf-8"))
    rb = json.loads(Path(args.run_b).read_text(encoding="utf-8")) if args.run_b else ra
    pb = args.b or (args.a if args.run_b else None)
    if pb is None:
        raise SystemExit("ERROR: give --b (second pipeline) when comparing inside one file")
    print(f"b - a   a = {args.run_a}:{args.a}   b = {args.run_b or args.run_a}:{pb}")
    for m in args.metrics.split(","):
        res = paired_bootstrap(per_question(ra, args.a, m), per_question(rb, pb, m))
        print(f"  {m:<18}" + ("n/a (no common measured questions)" if res is None else
                              f"{res[0]:+.3f}  [{res[1]:+.3f}, {res[2]:+.3f}]  n={res[3]}"))


if __name__ == "__main__":
    main()
