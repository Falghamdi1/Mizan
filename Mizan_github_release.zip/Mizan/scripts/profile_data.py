"""Profile the corpora actually used by the experiments: sizes, Arabic-specific defects, duplicates, chunks, metadata, personal data.

    python scripts/profile_data.py                 # writes docs/data_audit/profile.json and docs/data_audit/profile.md
    python scripts/profile_data.py --no-tokens     # skip the tokenizer (words only; no download)

Everything is measured on the local files (data/raw for the 8 PDFs, data/web/raw for the web corpus) with the same loaders the
experiments use, so the numbers describe exactly what the pipelines index. Tokens use the Qwen3 tokenizer (the embedder's; the Qwen3
chat models share this vocabulary, see scripts/token_analysis.py). Nothing here changes any data.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import statistics
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

OUT = ROOT / "docs" / "data_audit"
TATWEEL = "ـ"
DIAC = re.compile("[ً-ٰٟ]")
PRES = re.compile("[ﭐ-﷿ﹰ-﻿]")
INVISIBLE = re.compile("[​-‏‪-‮⁦-⁩﻿ ]")
ALEF_HAMZA = re.compile("[أإآٱ]")
ARABIC_LETTER = re.compile("[ء-يٱ-ۓ]")
LATIN_LETTER = re.compile("[A-Za-z]")
ARABIC_DIGIT = re.compile("[٠-٩۰-۹]")
ASCII_DIGIT = re.compile("[0-9]")
PERSIAN = re.compile("[یکھ]")
MIXED_WORD = re.compile(r"\w*[ء-ي]\w*[A-Za-zÀ-ÿ]\w*|\w*[A-Za-zÀ-ÿ]\w*[ء-ي]\w*")
ORPHAN_AL = re.compile(r"(?<![ء-ي])ال(?![ء-ي])")           # a stand-alone "ال": a swapped lam-alef leaves these behind
PII = {
    "email": re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+"),
    "saudi_mobile": re.compile(r"(?<!\d)(?:\+?966|00966|0)5\d{8}(?!\d)"),
    "national_id_with_label": re.compile(r"(?:رقم\s+(?:الهوية|الإقامة|الاقامة|السجل\s+المدني)|national\s+id)[^\d]{0,15}[12]\d{9}(?!\d)", re.IGNORECASE),
    "iban_sa": re.compile(r"\bSA\d{2}\s?(?:\d{4}\s?){4}\d{4}\b", re.IGNORECASE),
}


def source_kind(doc: str) -> str:
    if doc.lower().endswith(".pdf"):
        return "pdf"
    return doc.split("/")[0] if "/" in doc else doc


def pct(v: float) -> float:
    return round(100 * v, 2)


def dist(xs: list[int]) -> dict:
    if not xs:
        return {}
    s = sorted(xs)
    q = lambda p: s[min(len(s) - 1, int(p * len(s)))]
    return {"min": s[0], "p10": q(0.1), "median": int(statistics.median(s)), "p90": q(0.9), "max": s[-1], "mean": round(statistics.fmean(s), 1)}


def shingles(text: str, k: int = 5) -> set:
    w = text.split()
    return {" ".join(w[i:i + k]) for i in range(max(1, len(w) - k + 1))} if len(w) >= k else {text}


def near_duplicates(pages, threshold: float = 0.9) -> list[tuple[str, int, str, int, float]]:
    sets = [(p, shingles(p.text)) for p in pages if len(p.text) > 200]
    out = []
    for i in range(len(sets)):
        for j in range(i + 1, len(sets)):
            a, b = sets[i][1], sets[j][1]
            inter = len(a & b)
            if inter and inter / len(a | b) >= threshold:
                out.append((sets[i][0].doc, sets[i][0].page, sets[j][0].doc, sets[j][0].page, round(inter / len(a | b), 3)))
    return out


def profile_pages(pages, count_tokens) -> dict:
    kinds: dict[str, list] = {}
    for p in pages:
        kinds.setdefault(source_kind(p.doc), []).append(p)
    out = {}
    for kind, ps in sorted(kinds.items()):
        text = "\n".join(p.text for p in ps)
        n = max(1, len(text))
        letters = len(ARABIC_LETTER.findall(text)) + len(LATIN_LETTER.findall(text))
        per10k = lambda rx: round(len(rx.findall(text)) / n * 10000, 2)
        lens = [len(p.text) for p in ps]
        dup_exact = len(ps) - len({hashlib.sha1(p.text.encode("utf-8")).hexdigest() for p in ps})
        near = near_duplicates(ps)
        line_counts = Counter(ln.strip() for p in ps for ln in set(p.text.split("\n")) if 8 < len(ln.strip()) < 120)
        boiler = [(ln, c) for ln, c in line_counts.most_common(5) if c >= max(3, len(ps) // 4)]
        words = len(text.split())
        out[kind] = {
            "documents": len({p.doc for p in ps}), "records_pages": len(ps), "characters": len(text), "words": words,
            "tokens_qwen3": count_tokens(text) if count_tokens else None,
            "tokens_per_word": round(count_tokens(text) / words, 3) if count_tokens and words else None,
            "empty_or_tiny_records(<20 chars)": sum(len(p.text.strip()) < 20 for p in ps),
            "arabic_letter_share_%": pct(len(ARABIC_LETTER.findall(text)) / letters) if letters else None,
            "page_length_chars": dist(lens),
            "per_10k_chars": {"tatweel": round(text.count(TATWEEL) / n * 10000, 2), "diacritics": per10k(DIAC), "presentation_forms": per10k(PRES),
                              "invisible_or_nbsp": per10k(INVISIBLE), "alef_with_hamza_or_madda": per10k(ALEF_HAMZA),
                              "alef_maqsura_ى": text.count("ى") / n * 10000, "ta_marbuta_ة": text.count("ة") / n * 10000,
                              "persian_letters": per10k(PERSIAN), "arabic_indic_digits": per10k(ARABIC_DIGIT), "ascii_digits": per10k(ASCII_DIGIT),
                              "arabic_punctuation_،؛؟": (text.count("،") + text.count("؛") + text.count("؟")) / n * 10000,
                              "mixed_arabic_latin_words(suspicious)": per10k(MIXED_WORD), "orphan_ال_tokens(swapped lam-alef proxy)": per10k(ORPHAN_AL)},
            "tatweel_share_of_characters_%": pct(text.count(TATWEEL) / n),
            "exact_duplicate_records": dup_exact, "near_duplicate_pairs(>=0.9 shingle Jaccard)": len(near), "near_duplicate_examples": near[:3],
            "repeated_boilerplate_lines": [{"line": ln[:80], "pages": c} for ln, c in boiler],
            "metadata": {"doc": sum(bool(p.doc) for p in ps), "title": sum(bool(getattr(p, "title", "")) for p in ps),
                         "page": sum(bool(p.page) for p in ps), "of": len(ps)},
        }
        for name, rx in PII.items():
            hits = [(p.doc, p.page) for p in ps if rx.search(p.text)]
            out[kind].setdefault("pii_pattern_hits(pages)", {})[name] = len(hits)
    return out


def profile_chunks(pages, count_tokens) -> dict:
    from src import config
    from src.chunking import chunk_pages
    from src.preprocessing import get_config, preprocess_pages

    res = {}
    for arm in ("baseline", "mizan+repair_lam_alef", "mizan-lite+repair_lam_alef"):
        chunks = chunk_pages(preprocess_pages(pages, get_config(arm)), config.SETTINGS.chunk_size, config.SETTINGS.chunk_overlap)
        lens = [len(c.text) for c in chunks]
        toks = [count_tokens(c.text) for c in chunks] if count_tokens else []
        res[arm] = {"chunks": len(chunks), "chars_per_chunk": dist(lens), "tokens_per_chunk": dist(toks) if toks else None,
                    "total_tokens": sum(toks) if toks else None, "chunks_under_100_chars": sum(n < 100 for n in lens),
                    "metadata_complete_%": pct(sum(bool(c.doc) and bool(c.page) for c in chunks) / max(1, len(chunks)))}
    res["settings"] = {"chunk_size_chars": config.SETTINGS.chunk_size, "overlap_chars": config.SETTINGS.chunk_overlap,
                       "rule": "sentence based, never across a page"}
    return res


def structure_checks(web_pages, pairs) -> dict:
    laws = [p for p in web_pages if p.doc.startswith("law/")]
    art = [p for p in laws if re.match(r"\s*المادة", p.text)]
    faq = [p for p in web_pages if p.doc.startswith("faq/")]
    return {"law_pages": len(laws), "law_pages_starting_with_المادة": len(art),
            "law_pages_not_starting_with_المادة(preamble/other)": len(laws) - len(art),
            "faq_pairs_in_source": len(pairs), "faq_pages_indexed(duplicate answers merged)": len(faq),
            "faq_question_text_indexed": any(pr["question"] in p.text for pr in pairs[:50] for p in faq[:300]),
            "news_items": sum(p.doc.startswith("news/") for p in web_pages)}


def to_markdown(rep: dict) -> str:
    out = ["# Data profile (generated by scripts/profile_data.py)", "",
           f"Tokenizer: {rep['tokenizer']}. Chunking: {rep['chunks_pdf']['settings']}.", ""]
    for corpus in ("web", "pdf"):
        out += [f"## {corpus} corpus", "", "| source | docs | records | characters | words | tokens | tokens/word | Arabic letters % | tatweel % of chars | diacritics /10k | pres. forms /10k | orphan ال /10k | mixed Arabic-Latin words /10k | exact dup | near-dup pairs |",
                "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
        for kind, s in rep[f"pages_{corpus}"].items():
            p = s["per_10k_chars"]
            out.append(f"| {kind} | {s['documents']} | {s['records_pages']} | {s['characters']:,} | {s['words']:,} | {s['tokens_qwen3'] or 'n/a'} | {s['tokens_per_word'] or 'n/a'} | "
                       f"{s['arabic_letter_share_%']} | {s['tatweel_share_of_characters_%']} | {p['diacritics']} | {p['presentation_forms']} | "
                       f"{p['orphan_ال_tokens(swapped lam-alef proxy)']} | {p['mixed_arabic_latin_words(suspicious)']} | {s['exact_duplicate_records']} | {s['near_duplicate_pairs(>=0.9 shingle Jaccard)']} |")
        out.append("")
    for corpus in ("web", "pdf"):
        out += [f"### chunks, {corpus} corpus", "", "| arm | chunks | median chars | p10-p90 chars | median tokens | total tokens |", "|---|---|---|---|---|---|"]
        for arm, c in rep[f"chunks_{corpus}"].items():
            if arm == "settings":
                continue
            tp = c["tokens_per_chunk"] or {}
            out.append(f"| `{arm}` | {c['chunks']} | {c['chars_per_chunk']['median']} | {c['chars_per_chunk']['p10']}-{c['chars_per_chunk']['p90']} | {tp.get('median', 'n/a')} | {c['total_tokens'] or 'n/a'} |")
        out.append("")
    out += ["### structure", "", "```", json.dumps(rep["structure_web"], ensure_ascii=False, indent=1), "```", "",
            "### personal-data pattern hits (pages matching, per source)", "", "```"]
    for corpus in ("web", "pdf"):
        for kind, s in rep[f"pages_{corpus}"].items():
            out.append(f"{kind}: {s['pii_pattern_hits(pages)']}")
    out.append("```")
    return "\n".join(out)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-tokens", action="store_true")
    a = ap.parse_args()
    from src import config
    from src.ingestion import load_pdfs
    from src.web_corpus import load_web_corpus

    count_tokens, tok_name = None, "none (words only)"
    if not a.no_tokens:
        from transformers import AutoTokenizer
        tk = AutoTokenizer.from_pretrained("Qwen/Qwen3-Embedding-0.6B")
        count_tokens = lambda t: len(tk.encode(t, add_special_tokens=False))
        tok_name = "Qwen/Qwen3-Embedding-0.6B (151,669 entries; shared by the Qwen3 chat models)"
    web_pages, pairs = load_web_corpus(config.WEB_DIR)
    pdf_pages = load_pdfs(config.RAW_DIR)
    rep = {"tokenizer": tok_name, "pages_web": profile_pages(web_pages, count_tokens), "pages_pdf": profile_pages(pdf_pages, count_tokens),
           "chunks_web": profile_chunks(web_pages, count_tokens), "chunks_pdf": profile_chunks(pdf_pages, count_tokens),
           "structure_web": structure_checks(web_pages, pairs)}
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "profile.json").write_text(json.dumps(rep, ensure_ascii=False, indent=1), encoding="utf-8")
    (OUT / "profile.md").write_text(to_markdown(rep), encoding="utf-8")
    print((OUT / "profile.md").read_text(encoding="utf-8"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
