"""Extraction profile of PDFs: usage  python pdf_profile.py out.json file1.pdf file2.pdf ...
Measures what a plain PDF -> text -> chunk pipeline would get. Read-only."""
import sys, re, json, collections, statistics, pymupdf
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))   # the repository root
from src.chunking import chunk_pages
from src.ingestion import Page
AR = re.compile(r'[\u0600-\u06FF]'); PF = re.compile(r'[\uFB50-\uFDFF\uFE70-\uFEFF]'); LAT = re.compile(r'[A-Za-z]'); DIG = re.compile(r'[0-9\u0660-\u0669]')
DIAC = re.compile(r'[\u064B-\u0652]'); TAT = '\u0640'
res = []
for path in sys.argv[2:]:
    doc = pymupdf.open(path); name = path.replace("\\", "/").split("/")[-1]
    pages, empty, imgs, tabs, draws, txt_all, plines = [], 0, 0, 0, 0, [], []
    linecount = collections.Counter(); words_per_line = []; imgpages = 0; para_lens = []
    for i, p in enumerate(doc, 1):
        t = p.get_text()
        n_img = len(p.get_images(full=True)); imgs += n_img; imgpages += n_img > 0
        try: nt = len(p.find_tables().tables)
        except Exception: nt = 0
        tabs += nt; draws += len(p.get_drawings())
        if len(t.strip()) < 50: empty += 1
        pages.append(Page(name, name, i, t)); txt_all.append(t)
        ls = [l.strip() for l in t.splitlines() if l.strip()]
        for l in set(ls): linecount[l] += 1
        words_per_line += [len(l.split()) for l in ls]
        for para in re.split(r"\n\s*\n", t):
            if len(para.strip()) > 40: para_lens.append(len(para))
    n = len(doc); text = "\n".join(txt_all); chars = len(text.replace("\n", "").replace(" ", ""))
    ar, pf, la, di = len(AR.findall(text)), len(PF.findall(text)), len(LAT.findall(text)), len(DIG.findall(text))
    hdr = [(l, c) for l, c in linecount.most_common(12) if c >= max(3, 0.3 * n) and len(l) > 3]
    hdr_chars = sum(len(l) * c for l, c in hdr)
    chunks = chunk_pages([Page(p.doc, p.title, p.page, re.sub(r"\s+", " ", p.text).strip()) for p in pages], 600, 100)
    # lam-alef defect signature: "ال" glued where "لا" expected, approximated by known broken words
    broken = len(re.findall(r"الئحة|ثالث|الزم|ال\s+(?:يجوز|يحق|يقل|يزيد|تقل|تزيد)", text))
    r = dict(file=name, pages=n, size_mb=round(__import__("os").path.getsize(path)/2**20,1), chars=chars, chars_per_page=round(chars/n),
             empty_pages=empty, arabic_pct=round(100*ar/max(1,ar+la),1), arabic_share_of_nonspace=round(100*(ar+pf)/max(1,chars),1), latin_pct=round(100*la/max(1,chars),1),
             digit_pct=round(100*di/max(1,chars),1), presentation_forms=pf, tatweel=text.count(TAT), diacritics=len(DIAC.findall(text)),
             images=imgs, pages_with_images=imgpages, tables=tabs, vector_drawings=draws, words_per_line=round(statistics.mean(words_per_line),1) if words_per_line else 0,
             repeated_lines=hdr[:4], repeated_line_share_pct=round(100*hdr_chars/max(1,len(text)),1), chunks=len(chunks), lam_alef_signature=broken)
    res.append(r); print(json.dumps(r, ensure_ascii=False))
json.dump(res, open(sys.argv[1], "w", encoding="utf-8"), ensure_ascii=False)
