import openpyxl, glob, re, sys, json
AR = re.compile(r'[\u0600-\u06FF]')
# usage: python xlsx_profile.py FOLDER  (the folder holding the GASTAT All_provinces_2021_2025_*.xlsx files; default: current folder)
files = sorted(glob.glob(str((sys.argv[1] if len(sys.argv) > 1 else ".") + "/All_provinces_2021_2025_*.xlsx")))
out = {}
for f in files:
    wb = openpyxl.load_workbook(f)
    name = f.split("_")[-1]
    print("=====", name, "sheets:", len(wb.worksheets), "creator:", wb.properties.creator, "created:", wb.properties.created, "modified:", wb.properties.modified)
    tot = dict(cells=0, num=0, txt=0, ar=0, words_sent=0, chars=0, archars=0)
    sheets = {}
    for ws in wb.worksheets:
        cells = num = txt = sent = chars = arc = 0
        longest = ""
        texts = []
        for row in ws.iter_rows(values_only=True):
            for v in row:
                if v is None: continue
                cells += 1
                if isinstance(v, (int, float)): num += 1
                else:
                    s = str(v).strip()
                    if not s: continue
                    txt += 1; chars += len(s); arc += len(AR.findall(s)); texts.append(s)
                    if len(s.split()) >= 12: sent += 1
                    if len(s) > len(longest): longest = s
        sheets[ws.title] = (ws.dimensions, cells, num, txt, sent, len(longest))
        for k, v in zip(["cells","num","txt","ar","words_sent","chars","archars"], [cells,num,txt,0,sent,chars,arc]): tot[k] += v
        print(f"  {ws.title:6s} {ws.dimensions:9s} cells={cells:5d} num={num:5d} text={txt:4d} long-text(>=12w)={sent:3d} longest={len(longest):4d}")
    print("  TOTAL", tot, "numeric share = %.1f%%" % (100*tot['num']/tot['cells']), "Arabic chars share of text = %.1f%%" % (100*tot['archars']/max(1,tot['chars'])))
    out[name] = {k: list(v) for k, v in sheets.items()}
json.dump(out, open(sys.argv[1], "w"))
