"""Pull a sample of Arabic Wikipedia articles about Saudi tourism places and measure it (audit only; writes JSON to argv[1]).
Text is CC BY-SA: keep the article titles and revision links if you ever redistribute anything derived from it."""
import json, re, sys, time, urllib.parse, urllib.request

UA = {"User-Agent": "MizanAudit/1.0 (student capstone data audit)"}
CATS = ["تصنيف:مواقع التراث العالمي في السعودية", "تصنيف:مناطق السعودية", "تصنيف:مهرجانات في السعودية", "تصنيف:فنادق في السعودية",
        "تصنيف:حدائق وطنية في السعودية", "تصنيف:محميات طبيعية في السعودية", "تصنيف:مدن السعودية", "تصنيف:مواقع أثرية في السعودية"]


def api(**p):
    p["format"] = "json"
    url = "https://ar.wikipedia.org/w/api.php?" + urllib.parse.urlencode(p)
    return json.load(urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=60))


titles = []
for c in CATS:
    members = api(action="query", list="categorymembers", cmtitle=c, cmlimit=500, cmtype="page")["query"]["categorymembers"]
    titles += [m["title"] for m in members if m["ns"] == 0 and not m["title"].startswith("قائمة")][:60]
docs = {}
for t in dict.fromkeys(titles):
    page = next(iter(api(action="query", prop="extracts", explaintext=1, exsectionformat="plain", titles=t, redirects=1)["query"]["pages"].values()))
    if page.get("extract"):
        docs[t] = page["extract"]
    time.sleep(0.05)
json.dump(docs, open(sys.argv[1], "w", encoding="utf-8"), ensure_ascii=False)
text = "\n".join(docs.values())
print(len(docs), "articles,", len(text), "characters,", len(re.findall(r"[ً-ْ]", text)), "diacritics")
