"""Retrieval-only evaluation of the pipelines on the web corpus and the Ministry's FAQ questions.

    python scripts/run_web_eval.py --embedder e5                      # multilingual-e5-small, no reranker
    python scripts/run_web_eval.py --embedder qwen06                  # Qwen3-Embedding-0.6B + Qwen3-Reranker-0.6B (the 'compact' profile)
    python scripts/run_web_eval.py --embedder qwen06 --corpus all     # web corpus + the 8 PDFs as extra (noisy) distractors
    python scripts/run_web_eval.py --embedder qwen06 --ablations      # all one-step ablations (about 28 pipelines)

Questions: data/web/questions_faq.json (scripts/make_faq_questions.py). No generator, no judge. Everything except the
Arabic preprocessing is identical for the pipelines. The result file goes to results/ and the paired bootstrap
(10,000 resamples) is printed for each metric.
"""
import argparse
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

EMBEDDERS = {  # name -> (embedding model, reranker; "" = single-stage)
    "e5": ("intfloat/multilingual-e5-small", ""),
    "qwen06": ("Qwen/Qwen3-Embedding-0.6B", "Qwen/Qwen3-Reranker-0.6B"),
}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--embedder", choices=EMBEDDERS, default="e5")
    ap.add_argument("--corpus", choices=("web", "all"), default="web")
    ap.add_argument("--pipelines", default="baseline,mizan+repair_lam_alef")
    ap.add_argument("--ablations", action="store_true", help="run all one-step ablations instead (src/ablation.py), writes results/ablations-web-<embedder>-<corpus>.md")
    args = ap.parse_args()
    os.environ["MIZAN_CORPUS"] = args.corpus  # before src.config is imported
    os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")

    from src import config
    from src.colab import paired_line
    from src.evaluation import run_eval
    model, reranker = EMBEDDERS[args.embedder]
    config.override(embedding_model=model, embed_quant="none", embedding_adapter="", reranker=reranker, rerank_top_n=20,
                    rerank_4bit=False, chunk_title=False, llm_provider="mock", judge_provider="")
    if args.ablations:
        from src.ablation import markdown, run_ablations
        from src.corpus import load_corpus
        res = run_ablations(load_corpus(config.RAW_DIR), config.WEB_QUESTIONS)
        out = config.RESULTS_DIR / f"ablations-web-{args.embedder}-{args.corpus}.md"
        out.write_text(markdown(res), encoding="utf-8")
        print(f"written {out}")
        return 0
    names = [n.strip() for n in args.pipelines.split(",")]
    res = run_eval(names, questions_path=config.WEB_QUESTIONS, retrieve_only=True)
    print(f"\nembedder {model}, reranker {reranker or 'none'}, corpus {args.corpus}, {len(res['pipelines'][names[0]]['per_question'])} questions")
    for n in names:
        print(f"  {n}: {res['pipelines'][n]['index']['chunks']} chunks")
    base = names[0]
    for other in names[1:]:
        print(f"\n{other} minus {base}:")
        for m in ("hit", "mrr", "precision", "first_stage_hit", "candidate_recall"):
            line = paired_line(res, base, other, m, m)
            if line:
                print("  " + line["text"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
