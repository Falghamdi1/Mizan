"""Third-person adjudication of the P3 human grading: build a blind sheet for the existing grading form, plus a private key.

The two graders' sheets are compared cell by cell. A cell goes to the adjudicator when the graders disagree or when either left it
empty (for `supported`, both empty is normal on a refusal and is not sent). Every question with at least one such cell becomes one
row of the adjudication sheet, in the exact format of the grader sheets, so it opens in the existing form `tools/grading_form.html`
and comes back as the form's export (same header). Per row the two answers are shuffled again (new A/B), so the adjudicator cannot
carry over the graders' letters; the true mapping goes to a private key that `scripts/human_grading.py merge --adjudication-key`
uses to map the labels back.

    python scripts/prepare_adjudication.py                    # defaults: results/final_blind, adjudication/
    -> adjudication/p3_adjudication_input.csv   (give to the third grader, with the README)
       adjudication/p3_adjudication_key.csv     (private: never give it to the grader)

Fails (exit 1) if any cell of the input names a pipeline or a condition (see LEAK_TERMS and the arm names in KEY.json).
"""
from __future__ import annotations

import argparse
import csv
import json
import random
import re
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PICK_COL = "better (A, B or tie)"
REFUSAL = "لا يحتوي السياق المتاح على إجابة"
ENDPOINTS = ("correct", "supported", "correct_refusal", "pairwise_pick")
KEY_COLUMNS = ["adjudication_id", "endpoint", "item_id", "true_pipeline_A", "true_pipeline_B", "original_order", "notes"]
# words that would tell the adjudicator which system wrote an answer, or where the files come from
LEAK_TERMS = ["baseline", "standard", "mizan", "lite", "repair_lam_alef", "lam_alef", "pipeline", "preset", "KEY.json", "results/",
              "grading_", "answers_blind", "eval-2026", "ميزان", "القياسي"]


def read_sheet(path: Path) -> list[dict]:
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def label(v: str | None) -> str:
    """'1' / '0' / '' as the form and human_grading.parse_label read them."""
    v = (v or "").strip().lower()
    if v in {"1", "y", "yes", "true", "نعم", "صح"}:
        return "1"
    if v in {"0", "n", "no", "false", "لا", "خطأ"}:
        return "0"
    return ""


def pick(v: str | None) -> str:
    v = (v or "").strip()
    if v.lower() in {"tie", "t", "=", "same", "equal"} or v in {"تعادل", "متساوي"}:
        return "tie"
    return v.upper() if len(v) == 1 and v.upper() in "AB" else ""


def col(header: list[str], prefix: str, letter: str) -> str:
    return next(h for h in header if h.startswith(f"{prefix}_{letter} "))


def cells_to_adjudicate(corpus: str, key: dict, g1: list[dict], g2: list[dict]) -> list[dict]:
    """One dict per cell that needs a third decision, in the ORIGINAL letters of the grader sheets."""
    by2 = {r["id"]: r for r in g2}
    header = list(g1[0])
    out = []
    for r1 in g1:
        qid = r1["id"]
        r2 = by2.get(qid, {})
        info = key["rows"][qid]
        for letter in info["map"]:
            for field in ("correct", "supported"):
                c = col(header, field, letter)
                a, b = label(r1.get(c)), label(r2.get(c))
                if field == "supported" and not a and not b:
                    continue                                   # refusals and unmarked support: nothing to decide
                if a and b and a == b:
                    continue
                kind = f"g1={a},g2={b}" if a and b else ("g1_empty" if not a and b else "g2_empty" if a and not b else "both_empty")
                endpoint = field if field == "supported" else ("correct" if info["answerable"] else "correct_refusal")
                out.append({"corpus": corpus, "item_id": qid, "endpoint": endpoint, "field": field, "letter": letter, "type": kind,
                            "grader_1": a, "grader_2": b})
        if PICK_COL in r1:
            a, b = pick(r1.get(PICK_COL)), pick(r2.get(PICK_COL))
            if not (a and b and a == b):
                kind = f"g1={a},g2={b}" if a and b else ("g1_empty" if not a and b else "g2_empty" if a and not b else "both_empty")
                out.append({"corpus": corpus, "item_id": qid, "endpoint": "pairwise_pick", "field": "pick", "letter": "", "type": kind,
                            "grader_1": a, "grader_2": b})
    return out


def build(sources: dict[str, tuple[Path, Path, Path]], seed: int = 0) -> tuple[list[dict], list[dict], list[dict], dict]:
    """sources: {corpus: (KEY.json, grader_1 csv, grader_2 csv)}. Returns (sheet rows, key rows, cells, arms per corpus)."""
    rng = random.Random(seed)
    cells, texts, keys = [], {}, {}
    for corpus, (key_path, p1, p2) in sources.items():
        key = json.loads(Path(key_path).read_text(encoding="utf-8"))
        keys[corpus] = key
        g1, g2 = read_sheet(Path(p1)), read_sheet(Path(p2))
        cells += cells_to_adjudicate(corpus, key, g1, g2)
        texts.update({(corpus, r["id"]): r for r in g1})
    items = sorted({(c["corpus"], c["item_id"]) for c in cells})
    rng.shuffle(items)                                        # row order says nothing about corpus or question id
    sheet, key_rows = [], []
    for n, (corpus, qid) in enumerate(items, start=1):
        adj_id = f"adj-{n:03d}"
        src = texts[(corpus, qid)]
        swap = rng.random() < 0.5
        old = {"A": "B", "B": "A"} if swap else {"A": "A", "B": "B"}          # new letter -> original letter
        header = list(src)
        row = {"id": adj_id, "question": src["question"], "reference_answer": src["reference_answer"]}
        for new in "AB":
            o = old[new]
            row[f"sources_{new}"] = src.get(f"sources_{o}", "")
            row[f"answer_{new}"] = src.get(f"answer_{o}", "")
            row[f"correct_{new} (0/1)"] = ""
            row[f"supported_{new} (0/1, not for refusals)"] = ""
        if PICK_COL in header:
            row[PICK_COL] = ""
        row["comment"] = ""
        sheet.append(row)
        arm = {new: keys[corpus]["rows"][qid]["map"][old[new]]["arm"] for new in "AB"}
        for c in (c for c in cells if c["corpus"] == corpus and c["item_id"] == qid):
            where = (f"{c['field']}: original column {c['letter']}, sheet column {next(k for k, v in old.items() if v == c['letter'])}" if c["letter"]
                     else "pick: grader values below use the original letters")
            key_rows.append({"adjudication_id": adj_id, "endpoint": c["endpoint"], "item_id": qid, "true_pipeline_A": arm["A"],
                             "true_pipeline_B": arm["B"], "original_order": "BA" if swap else "AB",
                             "notes": f"corpus {corpus}; {where}; {c['type']}"})
    return sheet, key_rows, cells, {c: k["arms"] for c, k in keys.items()}


def leaks(sheet: list[dict], arm_names: list[str]) -> list[str]:
    """Every cell (and header) that names a pipeline, a condition or a result path."""
    terms = sorted(set(LEAK_TERMS) | {a for a in arm_names} | {p for a in arm_names for p in re.split(r"[+_\-]", a) if len(p) > 3})
    # whole words only (Unicode-aware), so the Arabic "الميزانية" (budget) does not count as "ميزان"
    edge = lambda ch: ch.isalnum()                         # a word boundary is only needed where the term starts or ends with a letter
    pats = [(t, re.compile((r"(?<![^\W_])" if edge(t[0]) else "") + re.escape(t) + (r"(?![^\W_])" if edge(t[-1]) else ""), re.I)) for t in terms]
    found = []
    for i, row in enumerate(sheet):
        for k, v in list(row.items()) + [(k, k) for k in row]:
            for t, p in pats:
                if p.search(str(v)):
                    found.append(f"row {row.get('id', i)} column {k!r}: contains {t!r}")
    return sorted(set(found))


def write(sheet: list[dict], key_rows: list[dict], out_dir: Path) -> tuple[Path, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    inp, keyp = out_dir / "p3_adjudication_input.csv", out_dir / "p3_adjudication_key.csv"
    with open(inp, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(sheet[0]))
        w.writeheader()
        w.writerows(sheet)
    with open(keyp, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=KEY_COLUMNS)
        w.writeheader()
        w.writerows(key_rows)
    return inp, keyp


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--results", default=str(ROOT / "results" / "final_blind"))
    ap.add_argument("--out", default=str(ROOT / "adjudication"))
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()
    res = Path(a.results)
    sources = {c: (res / f"grading_{c}" / "KEY.json", res / "graded" / f"g1_{c}.csv", res / "graded" / f"g2_{c}.csv") for c in ("pdf", "web")}
    missing = [str(p) for t in sources.values() for p in t if not p.exists()]
    if missing:
        print("missing input files:", *missing, sep="\n  ")
        return 1
    sheet, key_rows, cells, arms = build(sources, a.seed)
    bad = leaks(sheet, [x for v in arms.values() for x in v])
    print(f"cells to adjudicate: {len(cells)} in {len(sheet)} rows")
    for corpus in sources:
        cc = [c for c in cells if c["corpus"] == corpus]
        print(f"  {corpus}: " + ", ".join(f"{e} {sum(c['endpoint'] == e for c in cc)}" for e in ENDPOINTS))
        for (e, t), n in sorted(Counter((c["endpoint"], c["type"]) for c in cc).items()):
            print(f"      {e:15s} {t:16s} {n}")
    if bad:
        print("\nBLINDING FAILED: the sheet names a pipeline or a condition. Nothing was written.", *bad[:20], sep="\n  ")
        return 1
    inp, keyp = write(sheet, key_rows, Path(a.out))
    print(f"\nblinding check passed (no pipeline name, condition or result path in {len(sheet)} rows)")
    print(f"wrote {inp} (for the third grader) and {keyp} (private)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
