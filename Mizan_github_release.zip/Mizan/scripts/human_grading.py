"""Human grading of generated answers: blind sheets for two graders, then agreement, per-arm accuracy and judge validation.

Why: every automatic answer score in this project is weak (keyword coverage is a surface check; the LLM judges disagreed and one
marked everything correct). A small, blind, double-graded sample is the evidence for answer quality, and it also tells us whether any
automatic score can be trusted.

    python scripts/human_grading.py make  results/eval-XXXX.json --arms baseline,mizan-lite+repair_lam_alef --n 30 --unanswerable 6
    python scripts/human_grading.py make  results/prompts-XXXX.json --arms v1,v2,v3 --n 30      # prompt versions instead of pipelines
    # -> results/grading-<stamp>/grader_1.csv, grader_2.csv (identical rows, blind), KEY.json (do NOT give it to the graders)
    # each grader fills their own CSV alone, following eval/human_grading/RUBRIC.md; then
    python scripts/human_grading.py merge results/grading-<stamp> --grader1 g1.csv --grader2 g2.csv [--adjudicated adj.csv]
    # third-person adjudication prepared by scripts/prepare_adjudication.py (own ids, A/B shuffled again):
    python scripts/human_grading.py merge results/grading-<stamp> --grader1 g1.csv --grader2 g2.csv \
        --adjudicated adjudication/p3_adjudication_output.csv --adjudication-key adjudication/p3_adjudication_key.csv

The sheet shows, per question, the reference answer and one answer per arm in shuffled columns A/B/C (the order differs from row to row, the key
maps it back). Pipeline and prompt names are not on the sheet. The answers themselves can hint at their origin (for example letter-folded
quotations), which is a limit of blinding by shuffling alone and is stated in the report.

`merge` reports: completeness, percent agreement and Cohen's kappa between the two graders, the disagreements (to adjudicate together), final
accuracy per arm, paired differences between arms with a bootstrap interval, and, when the result file has them, how well the LLM judge and the
keyword score agree with the human labels. Questions with an unresolved disagreement are left out and counted.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import random
import statistics
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src.stats import paired_bootstrap  # noqa: E402

GATE_MIN_N, GATE_KAPPA, GATE_FALSE_ACCEPT = 50, 0.6, 0.10                     # when may an automatic score replace a human
LETTERS = "ABCDEFGH"
YES = {"1", "y", "yes", "true", "نعم", "صح"}
NO = {"0", "n", "no", "false", "لا", "خطأ"}
SHEET_COLS = ["id", "question", "reference_answer"]
PICK_COL = "better (A, B or tie)"                                           # only on two-arm sheets
TIES = {"tie", "t", "=", "same", "equal", "تعادل", "متساوي"}


# ---------------------------------------------------------------------------------------------------------------
# Reading the arms out of a result file (pipelines of an evaluation run, or prompt versions)
# ---------------------------------------------------------------------------------------------------------------
def load_arms(result: dict) -> dict[str, dict[str, dict]]:
    """{arm: {question id: row}} with row = {answer, sources, answerable, judge_correct, keyword_coverage}."""
    arms: dict[str, dict[str, dict]] = {}
    if "pipelines" in result:
        for name, p in result["pipelines"].items():
            arms[name] = {r["id"]: {"answer": (r.get("answer") or "").strip(), "answerable": bool(r.get("answerable")),
                                    "sources": [f"{x['doc']}#{x['page']}" for x in r.get("retrieved", [])],
                                    "judge_correct": r.get("judge_correct"), "keyword_coverage": r.get("keyword_coverage"),
                                    "question": r.get("question")} for r in p["per_question"]}
    elif "versions" in result:
        for name, v in result["versions"].items():
            arms[name] = {r["id"]: {"answer": (r.get("answer") or "").strip(), "answerable": bool(r.get("answerable")), "sources": [],
                                    "judge_correct": None, "keyword_coverage": r.get("keyword_coverage"), "question": None}
                          for r in v["rows"]}
    else:
        raise SystemExit("not a result file: expected 'pipelines' (evaluation) or 'versions' (compare_prompts)")
    return arms


def find_questions(result: dict, explicit: str | None) -> dict[str, dict]:
    cand = [Path(explicit)] if explicit else []
    name = (result.get("run") or {}).get("questions_file")
    if name:
        cand += [ROOT / "eval" / name, ROOT / "data" / "web" / name]
    for p in cand:
        if p.exists():
            return {q["id"]: q for q in json.loads(p.read_text(encoding="utf-8"))}
    raise SystemExit("question file not found: pass --questions (it supplies the reference answers)")


# ---------------------------------------------------------------------------------------------------------------
# make
# ---------------------------------------------------------------------------------------------------------------
def make(result_path: Path, arm_names: list[str], n: int, n_unans: int, seed: int, out_dir: Path | None, questions: str | None) -> Path:
    result = json.loads(result_path.read_text(encoding="utf-8"))
    arms = load_arms(result)
    missing = [a for a in arm_names if a not in arms]
    if missing:
        raise SystemExit(f"arms not in the result file: {missing}. Available: {list(arms)}")
    if len(arm_names) < 2:
        raise SystemExit("blind grading compares at least two arms")
    qs = find_questions(result, questions)
    ids = [i for i in arms[arm_names[0]] if all(i in arms[a] and arms[a][i]["answer"] for a in arm_names) and i in qs]
    ans = [i for i in ids if arms[arm_names[0]][i]["answerable"]]
    unans = [i for i in ids if not arms[arm_names[0]][i]["answerable"]]
    rng = random.Random(seed)
    rng.shuffle(ans)
    rng.shuffle(unans)
    chosen = ans[:n] + unans[:n_unans]
    rng.shuffle(chosen)                                           # answerable and unanswerable mixed
    if not chosen:
        raise SystemExit("no question has an answer in every arm (was this a retrieval-only run?)")
    sheet, key = [], {"source_result": result_path.name, "seed": seed, "arms": arm_names, "rows": {}}
    letters = LETTERS[: len(arm_names)]
    for qid in chosen:
        order = arm_names[:]
        rng.shuffle(order)
        row = {"id": qid, "question": qs[qid]["question"], "reference_answer": qs[qid].get("reference_answer", "")}
        info = {"answerable": arms[arm_names[0]][qid]["answerable"], "map": {}}
        for letter, arm in zip(letters, order):
            a = arms[arm][qid]
            row[f"sources_{letter}"] = "; ".join(a["sources"][:4])
            row[f"answer_{letter}"] = a["answer"]
            row[f"correct_{letter} (0/1)"] = ""
            row[f"supported_{letter} (0/1, not for refusals)"] = ""
            info["map"][letter] = {"arm": arm, "judge_correct": a["judge_correct"], "keyword_coverage": a["keyword_coverage"]}
        if len(arm_names) == 2:                                    # "which is better" is a pairwise question: two arms only
            row[PICK_COL] = ""
        row["comment"] = ""
        sheet.append(row)
        key["rows"][qid] = info
    out_dir = out_dir or ROOT / "results" / f"grading-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    out_dir.mkdir(parents=True, exist_ok=True)
    for g in (1, 2):
        with open(out_dir / f"grader_{g}.csv", "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(sheet[0]))
            w.writeheader()
            w.writerows(sheet)
    (out_dir / "KEY.json").write_text(json.dumps(key, ensure_ascii=False, indent=1), encoding="utf-8")
    return out_dir


# ---------------------------------------------------------------------------------------------------------------
# merge
# ---------------------------------------------------------------------------------------------------------------
def parse_label(v: str) -> int | None:
    v = (v or "").strip().lower()
    if v in YES:
        return 1
    if v in NO:
        return 0
    return None


def parse_pick(v: str, letters: str) -> str | None:
    """"A" / "B" / "tie" from what a grader typed; None when empty or not understood."""
    v = (v or "").strip()
    if v.lower() in TIES or v in TIES:
        return "tie"
    return v.upper() if len(v) == 1 and v.upper() in letters else None


def read_picks(path: Path, key: dict) -> tuple[dict, list[str]]:
    """{question id: "A" | "B" | "tie" | None} from the pick column (two-arm sheets only) and a list of problems."""
    picks, problems = {}, []
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    if rows and PICK_COL not in rows[0]:
        return picks, problems
    for r in rows:
        qid = r.get("id")
        if qid not in key["rows"]:
            continue                                                     # read_grades reports unknown ids
        raw = (r.get(PICK_COL) or "").strip()
        v = parse_pick(raw, "".join(key["rows"][qid]["map"]))
        if raw and v is None:
            problems.append(f"{path.name} {qid} {PICK_COL}: {raw!r} is not A, B or tie")
        picks[qid] = v
    return picks, problems


def sign_test(wins_a: int, wins_b: int) -> float | None:
    """Exact two-sided sign test on the questions with a winner (ties are left out). None when there is no winner at all."""
    n = wins_a + wins_b
    if n == 0:
        return None
    k = min(wins_a, wins_b)
    return min(1.0, 2 * sum(math.comb(n, i) for i in range(k + 1)) / 2 ** n)


def multi_kappa(a: list[str], b: list[str]) -> float | None:
    """Cohen's kappa for two raters and any number of categories (A, B, tie)."""
    n = len(a)
    if n == 0:
        return None
    po = sum(x == y for x, y in zip(a, b)) / n
    pe = sum((a.count(c) / n) * (b.count(c) / n) for c in set(a) | set(b))
    return None if pe == 1 else (po - pe) / (1 - pe)


def read_grades(path: Path, key: dict) -> tuple[dict, list[str]]:
    """{(qid, letter): {"correct": 0/1/None, "supported": 0/1/None}} and a list of problems."""
    grades, problems = {}, []
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        qid = r.get("id")
        if qid not in key["rows"]:
            problems.append(f"{path.name}: unknown id {qid!r}")
            continue
        for letter in key["rows"][qid]["map"]:
            c = [v for k, v in r.items() if k.startswith(f"correct_{letter}")]
            s = [v for k, v in r.items() if k.startswith(f"supported_{letter}")]
            cv, sv = parse_label(c[0] if c else ""), parse_label(s[0] if s else "")
            if c and c[0].strip() and cv is None:
                problems.append(f"{path.name} {qid} correct_{letter}: {c[0]!r} is not 0/1")
            if s and s[0].strip() and sv is None:
                problems.append(f"{path.name} {qid} supported_{letter}: {s[0]!r} is not 0/1")
            grades[(qid, letter)] = {"correct": cv, "supported": sv}
    return grades, problems


def read_adjudication(path: Path, adj_key: Path, key: dict) -> tuple[dict, dict, list[str]]:
    """The grading form's export of an adjudication sheet (scripts/prepare_adjudication.py) mapped back to this KEY's question ids and
    original letters through the private adjudication key. Rows that belong to another question file are skipped.
    Returns (grades as read_grades, picks as read_picks, problems)."""
    with open(adj_key, encoding="utf-8-sig", newline="") as f:
        where = {}
        for r in csv.DictReader(f):
            where.setdefault(r["adjudication_id"], (r["item_id"], r["original_order"]))
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    grades, picks, problems = {}, {}, []
    for r in rows:
        aid = r.get("id")
        if aid not in where:
            problems.append(f"{path.name}: id {aid!r} is not in {adj_key.name}")
            continue
        qid, order = where[aid]
        if qid not in key["rows"]:
            continue
        if order not in ("AB", "BA"):
            problems.append(f"{adj_key.name} {aid}: original_order {order!r} is not AB or BA")
            continue
        to_orig = {"A": "A", "B": "B"} if order == "AB" else {"A": "B", "B": "A"}
        for new, orig in to_orig.items():
            c = [v for k, v in r.items() if k.startswith(f"correct_{new}")]
            s_ = [v for k, v in r.items() if k.startswith(f"supported_{new}")]
            cv, sv = parse_label(c[0] if c else ""), parse_label(s_[0] if s_ else "")
            if c and c[0].strip() and cv is None:
                problems.append(f"{path.name} {aid} correct_{new}: {c[0]!r} is not 0/1")
            if s_ and s_[0].strip() and sv is None:
                problems.append(f"{path.name} {aid} supported_{new}: {s_[0]!r} is not 0/1")
            grades[(qid, orig)] = {"correct": cv, "supported": sv}
        if PICK_COL in r:
            raw = (r.get(PICK_COL) or "").strip()
            v = parse_pick(raw, "AB")
            if raw and v is None:
                problems.append(f"{path.name} {aid} {PICK_COL}: {raw!r} is not A, B or tie")
            picks[qid] = to_orig.get(v, v)
    return grades, picks, problems


def kappa(a: list[int], b: list[int]) -> float | None:
    """Cohen's kappa for two binary raters; None when undefined (no variation in both)."""
    n = len(a)
    if n == 0:
        return None
    po = sum(x == y for x, y in zip(a, b)) / n
    pa1, pb1 = sum(a) / n, sum(b) / n
    pe = pa1 * pb1 + (1 - pa1) * (1 - pb1)
    return None if pe == 1 else (po - pe) / (1 - pe)


def merge(out_dir: Path, g1: Path, g2: Path, adjudicated: Path | None = None, adjudication_key: Path | None = None) -> dict:
    key = json.loads((out_dir / "KEY.json").read_text(encoding="utf-8"))
    r1, p1 = read_grades(g1, key)
    r2, p2 = read_grades(g2, key)
    adj_picks = None
    if adjudicated and adjudication_key:
        adj, adj_picks, p3 = read_adjudication(adjudicated, adjudication_key, key)
    else:
        adj, p3 = read_grades(adjudicated, key) if adjudicated else ({}, [])
    problems = p1 + p2 + p3
    final, disagreements, unresolved, incomplete, adjudicated_used = {}, [], 0, 0, 0
    agree_pairs = {"correct": ([], []), "supported": ([], [])}
    for (qid, letter), a in r1.items():
        b = r2.get((qid, letter), {"correct": None, "supported": None})
        for field in ("correct", "supported"):
            x, y = a[field], b[field]
            if field == "supported" and x is None and y is None:
                continue                                           # refusal rows, or the optional column left empty by both
            if x is None or y is None:
                z = adj.get((qid, letter), {}).get(field)              # a cell one grader left empty can be decided by the adjudicator
                if z is None:
                    incomplete += 1
                else:
                    final[(qid, letter, field)] = z
                    adjudicated_used += 1
                continue
            agree_pairs[field][0].append(x)
            agree_pairs[field][1].append(y)
            if x == y:
                final[(qid, letter, field)] = x
            else:
                disagreements.append({"id": qid, "arm": key["rows"][qid]["map"][letter]["arm"], "column": f"{field}_{letter}", "grader_1": x, "grader_2": y})
                z = adj.get((qid, letter), {}).get(field)
                if z is None:
                    unresolved += 1
                else:
                    final[(qid, letter, field)] = z
                    adjudicated_used += 1
    arms = key["arms"]
    pick_report = None
    k1, q1 = read_picks(g1, key)
    k2, q2 = read_picks(g2, key)
    ka, q3 = (adj_picks, []) if adj_picks is not None else (read_picks(adjudicated, key) if adjudicated else ({}, []))
    problems += q1 + q2 + q3
    if k1 or k2:
        wins, ties, undecided, pick_dis = {a: 0 for a in arms}, 0, 0, []
        both = [(qid, k1.get(qid), k2.get(qid)) for qid in key["rows"] if qid in k1 or qid in k2]
        agree_a, agree_b = [], []
        for qid, x, y in both:
            if x is None or y is None:
                z = ka.get(qid)
                if z is None:
                    undecided += 1
                elif z == "tie":
                    ties += 1
                else:
                    wins[key["rows"][qid]["map"][z]["arm"]] += 1
                continue
            agree_a.append(x)
            agree_b.append(y)
            z = x if x == y else ka.get(qid)
            if x != y:
                pick_dis.append({"id": qid, "grader_1": x, "grader_2": y})
            if z is None:
                undecided += 1
            elif z == "tie":
                ties += 1
            else:
                wins[key["rows"][qid]["map"][z]["arm"]] += 1
        a0, a1 = arms[0], arms[1]
        pick_report = {"arms": arms[:2], "wins": wins, "ties": ties, "undecided": undecided, "n_decided": ties + sum(wins.values()),
                       "sign_test_p": sign_test(wins[a0], wins[a1]),
                       "grader_agreement": {"n": len(agree_a), "percent": (sum(x == y for x, y in zip(agree_a, agree_b)) / len(agree_a)) if agree_a else None,
                                            "kappa": multi_kappa(agree_a, agree_b)},
                       "disagreements": pick_dis}
    per_arm = {a: {"correct_ans": {}, "correct_unans": {}, "supported": {}, "judge": [], "kw": []} for a in arms}
    for (qid, letter, field), v in final.items():
        info = key["rows"][qid]
        arm = info["map"][letter]["arm"]
        if field == "correct":
            per_arm[arm]["correct_ans" if info["answerable"] else "correct_unans"][qid] = v
            jc, kw = info["map"][letter]["judge_correct"], info["map"][letter]["keyword_coverage"]
            if jc is not None:
                per_arm[arm]["judge"].append((v, int(jc)))
            if kw is not None and info["answerable"]:
                per_arm[arm]["kw"].append((v, int(kw >= 0.5)))
        else:
            per_arm[arm]["supported"][qid] = v
    mean = lambda d: (statistics.fmean(d.values()) if d else None)
    summary = {a: {"answerable_graded": len(p["correct_ans"]), "accuracy_answerable": mean(p["correct_ans"]),
                   "unanswerable_graded": len(p["correct_unans"]), "correct_on_unanswerable": mean(p["correct_unans"]),
                   "supported_graded": len(p["supported"]), "supported_rate": mean(p["supported"])} for a, p in per_arm.items()}
    paired = {}
    base = arms[0]
    for other in arms[1:]:
        for label, field in (("accuracy_answerable", "correct_ans"), ("supported_rate", "supported")):
            b = paired_bootstrap(per_arm[base][field], per_arm[other][field])
            paired[f"{other} - {base}: {label}"] = None if b is None else {"diff": b[0], "lo": b[1], "hi": b[2], "n": b[3]}
    validation = {}
    for name, pairs in (("llm_judge", [x for p in per_arm.values() for x in p["judge"]]), ("keyword_coverage>=0.5", [x for p in per_arm.values() for x in p["kw"]])):
        if pairs:
            h, m = [x for x, _ in pairs], [y for _, y in pairs]
            wrong = [y for x, y in pairs if x == 0]                       # answers the humans marked wrong: how many did the score accept?
            fa = (sum(wrong) / len(wrong)) if wrong else None
            k = kappa(h, m)
            validation[name] = {"n": len(pairs), "agreement": sum(x == y for x, y in pairs) / len(pairs), "kappa": k,
                                "false_accept_rate": fa, "n_human_wrong": len(wrong),
                                # docs/JUDGE_DIAGNOSIS.md: an automatic score may stand in for human grading only if all three hold
                                "adopt": bool(len(pairs) >= GATE_MIN_N and k is not None and k >= GATE_KAPPA and fa is not None and fa <= GATE_FALSE_ACCEPT)}
    report = {"created": datetime.now().isoformat(timespec="seconds"), "source_result": key["source_result"], "arms": arms,
              "n_questions": len(key["rows"]), "problems": problems, "incomplete_cells": incomplete, "unresolved_disagreements": unresolved, "adjudicated_cells_used": adjudicated_used,
              "agreement": {f: {"n": len(a), "percent": (sum(x == y for x, y in zip(a, b)) / len(a)) if a else None, "kappa": kappa(a, b)}
                            for f, (a, b) in agree_pairs.items()},
              "disagreements": disagreements, "per_arm": summary, "paired": paired, "validation_of_automatic_scores": validation,
              "preference": pick_report}
    (out_dir / "human_grading_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8")
    (out_dir / "human_grading_report.md").write_text(markdown(report), encoding="utf-8")
    return report


def markdown(rep: dict) -> str:
    f = lambda v, d=3: "n/a" if v is None else f"{v:.{d}f}"
    out = [f"# Human grading of answers ({rep['source_result']})", "",
           f"{rep['n_questions']} questions in the sheet; arms: {', '.join(rep['arms'])}. Two graders, blind to the arm. "
           f"Incomplete cells: {rep['incomplete_cells']}. Unresolved disagreements (left out): {rep['unresolved_disagreements']}. "
           f"Cells decided by the adjudicator: {rep.get('adjudicated_cells_used', 0)}.", ""]
    if rep["problems"]:
        out += ["**Problems in the sheets:**", *[f"- {p}" for p in rep["problems"]], ""]
    out += ["## Agreement between the graders", "", "| column | cells | agreement | kappa |", "|---|---|---|---|"]
    for k, v in rep["agreement"].items():
        out.append(f"| {k} | {v['n']} | {f(v['percent'])} | {f(v['kappa'])} |")
    out += ["", "Kappa below about 0.6 means the rubric or the graders need work before the labels are trusted.", "",
            "## Final labels per arm (after adjudication)", "", "| arm | answerable graded | correct | unanswerable graded | correct (refused) | supported graded | cited source supports the answer |",
            "|---|---|---|---|---|---|---|"]
    for a, s in rep["per_arm"].items():
        out.append(f"| `{a}` | {s['answerable_graded']} | {f(s['accuracy_answerable'])} | {s['unanswerable_graded']} | {f(s['correct_on_unanswerable'])} | "
                   f"{s['supported_graded']} | {f(s['supported_rate'])} |")
    out += ["", "## Paired differences (second arm minus first), bootstrap 95%", ""]
    for k, v in rep["paired"].items():
        out.append(f"- {k}: " + ("not measurable" if v is None else
                   f"{v['diff']:+.3f} [{v['lo']:+.3f}, {v['hi']:+.3f}] n={v['n']} " + ("higher" if v["lo"] > 0 else "lower" if v["hi"] < 0 else "no difference distinguishable from zero")))
    pr = rep.get("preference")
    if pr:
        a0, a1 = pr["arms"]
        p = pr["sign_test_p"]
        out += ["", "## Which answer is better? (pick A or B, order hidden)", "",
                f"`{a0}` wins {pr['wins'][a0]}, `{a1}` wins {pr['wins'][a1]}, ties {pr['ties']}, undecided {pr['undecided']} (of {pr['n_decided'] + pr['undecided']} questions). "
                + ("No question has a winner, so no test is possible." if p is None else
                   f"Exact sign test on the questions with a winner (ties left out): p = {p:.3f}"
                   + (" (a difference we can distinguish from chance)." if p < 0.05 else " (not distinguishable from chance).")),
                f"The two graders picked the same in {f(pr['grader_agreement']['percent'])} of {pr['grader_agreement']['n']} questions, kappa {f(pr['grader_agreement']['kappa'])}. "
                "A tie means equal quality (both right or both wrong). This is a second view next to the 0/1 correctness; it does not replace it."]
    if rep["validation_of_automatic_scores"]:
        out += ["", "## Do the automatic scores agree with the human labels?", "", "| score | answers | agreement | kappa | accepted answers the humans marked wrong | may replace a human grader |", "|---|---|---|---|---|---|"]
        for k, v in rep["validation_of_automatic_scores"].items():
            fa = "n/a" if v.get("false_accept_rate") is None else f"{v['false_accept_rate']:.0%} of {v['n_human_wrong']}"
            out.append(f"| {k} | {v['n']} | {f(v['agreement'])} | {f(v['kappa'])} | {fa} | {'yes' if v.get('adopt') else 'no'} |")
        out.append(f"\nAn automatic score may stand in for a human grader only with at least {GATE_MIN_N} graded answers, kappa of at least {GATE_KAPPA} "
                   f"and at most {GATE_FALSE_ACCEPT:.0%} of the human-wrong answers accepted (docs/JUDGE_DIAGNOSIS.md). A score with kappa near 0 does not "
                   "measure correctness here and must not be quoted as accuracy.")
    if rep["disagreements"]:
        out += ["", "## Disagreements to adjudicate together", "", "| question | arm | column | grader 1 | grader 2 |", "|---|---|---|---|---|"]
        out += [f"| {d['id']} | `{d['arm']}` | {d['column']} | {d['grader_1']} | {d['grader_2']} |" for d in rep["disagreements"]]
    out += ["", "Limits: a small sample; two graders from the team that built the system (not independent); blinding by shuffling only (the answers can "
                "hint at their pipeline); partial answers are graded 0 by the rubric; one run of the generator."]
    return "\n".join(out)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    m = sub.add_parser("make")
    m.add_argument("result")
    m.add_argument("--arms", required=True, help="comma list of pipeline names or prompt versions")
    m.add_argument("--n", type=int, default=30, help="answerable questions")
    m.add_argument("--unanswerable", type=int, default=6)
    m.add_argument("--seed", type=int, default=0)
    m.add_argument("--out")
    m.add_argument("--questions", help="question file with the reference answers (default: the one named in the result file)")
    g = sub.add_parser("merge")
    g.add_argument("dir")
    g.add_argument("--grader1", required=True)
    g.add_argument("--grader2", required=True)
    g.add_argument("--adjudicated", help="adjudicated sheet: a copy of the grader sheet, or the grading form's export of an adjudication sheet")
    g.add_argument("--adjudication-key", help="private key of scripts/prepare_adjudication.py; needed when --adjudicated is its sheet")
    a = ap.parse_args()
    if a.cmd == "make":
        d = make(Path(a.result), [x.strip() for x in a.arms.split(",") if x.strip()], a.n, a.unanswerable, a.seed,
                 Path(a.out) if a.out else None, a.questions)
        print(f"wrote {d}/grader_1.csv, grader_2.csv (give one to each grader) and KEY.json (keep it away from them)")
        return 0
    d = Path(a.dir)
    rep = merge(d, Path(a.grader1), Path(a.grader2), Path(a.adjudicated) if a.adjudicated else None,
                Path(a.adjudication_key) if a.adjudication_key else None)
    print((d / "human_grading_report.md").read_text(encoding="utf-8"))
    return 1 if rep["problems"] else 0


if __name__ == "__main__":
    sys.exit(main())
