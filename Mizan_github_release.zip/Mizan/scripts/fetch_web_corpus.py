"""Download the raw web corpus (JSON and HTML) into data/web/raw/ and write data/web/manifest.json.

    python scripts/fetch_web_corpus.py            # download everything (skips files already present)
    python scripts/fetch_web_corpus.py --refresh  # download again and overwrite
    python scripts/fetch_web_corpus.py --verify   # only compare existing files with the manifest

Sources (see docs/DATA_AUDIT.md and docs/DATA_SOURCES_SHEET.md):
  tourism.sa CMS (JSON): FAQ, news, tourism definitions and methodologies. The terms of use on tourism.sa require the
      Ministry's written permission to copy content into other systems: keep this data local, do not publish it.
  Bureau of Experts (HTML): six tourism-related laws. Terms: personal use; no open licence.
  GASTAT (HTML): three methodology-and-quality reports. Open reuse with attribution (stats.gov.sa/ar/use-policy).
The CMS endpoints are the public calls the tourism.sa front end makes. They are undocumented and may change.
"""
import argparse
import hashlib
import json
import sys
import time
import urllib.parse
import urllib.request
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RAW = ROOT / "data" / "web" / "raw"
CMS = "https://cms.tourism.sa/api"
BOE = "https://laws.boe.gov.sa/BoeLaws/Laws/LawDetails/{}/1"
GASTAT = "https://www.stats.gov.sa/ar/w/"

LAWS = {  # file slug -> Bureau of Experts id
    "tourism-law": "7d777c66-d28b-43de-9305-af23013b1738",
    "mt-organization": "898062b9-805f-4bab-974c-ac4500ed4262",
    "travel-association": "c4a35dbe-fa16-4cd3-b539-a9a700f27af5",
    "accommodation-association": "9b96a85d-7a9e-4adb-9379-a9a700f27a9c",
    "hajj-umrah-work-visa": "9bfa5aa2-77cb-4e3d-a3e7-b20a00c3dccb",
    "antiquities": "a7d4493b-7c03-4c2d-b3c6-a9a700f275cd",
}
GASTAT_PAGES = {
    "methodology-tourism-establishments": "methodology-and-quality-report-of-tourism-establishments-statistics",
    "methodology-umrah": "methodology-and-quality-report-for-umrah-statistics",
    "methodology-hajj": "methodology-and-quality-report-for-hajj-statistics",
}
NEWS_PAGE = 100  # the CMS caps a page at 100 items


def get(url: str, timeout: int = 25) -> bytes:
    url = urllib.parse.quote(url, safe=":/?&=$,")  # the CMS filters contain [ ] and $, which must be percent-encoded
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (compatible; MizanPrototype)"})
    for attempt in range(2):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.read()
        except Exception:
            if attempt == 1:
                raise
            time.sleep(2)


def targets() -> list[tuple[str, str]]:
    """(file name, url) for everything except the news pages, which depend on the total count."""
    q = urllib.parse.quote
    t = [("faq.json", f"{CMS}/faq-categories?locale=ar&filters[showOnFaqPage][$eq]=true&sort=order:asc&populate[faqs]=true&pagination[pageSize]=100"),
         ("definitions.json", f"{CMS}/tourism-definitions-page?locale=ar&populate[cards]=true"),
         ("methodologies.json", f"{CMS}/tourism-methodologies-page?locale=ar&populate[cards][populate][card]=true&populate[cards][populate][table][populate][cards]=true")]
    t += [(f"law-{slug}.html", BOE.format(i)) for slug, i in LAWS.items()]
    t += [(f"gastat-{slug}.html", GASTAT + q(page, safe="-")) for slug, page in GASTAT_PAGES.items()]
    return t


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--refresh", action="store_true")
    ap.add_argument("--verify", action="store_true")
    args = ap.parse_args()
    RAW.mkdir(parents=True, exist_ok=True)
    manifest_path = RAW.parent / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {"files": {}}
    failed = 0

    def fetch(name: str, url: str) -> None:
        nonlocal failed
        path = RAW / name
        if path.exists() and not args.refresh:
            return
        if args.verify:
            return
        try:
            data = get(url)
            tmp = path.with_suffix(path.suffix + ".part")
            tmp.write_bytes(data)
            tmp.replace(path)
            manifest["files"][name] = {"url": url, "retrieved": date.today().isoformat(), "bytes": len(data),
                                       "sha256": hashlib.sha256(data).hexdigest()}
            print(f"downloaded {name} ({len(data) / 1e3:.0f} KB)")
            time.sleep(0.5)  # be polite to the servers
        except Exception as e:
            failed += 1
            print(f"FAILED     {name}: {type(e).__name__}: {e}")

    for name, url in targets():
        fetch(name, url)
    start = 0  # news: pages of 100 until a short page
    while not args.verify:
        name = f"news-{start}.json"
        url = f"{CMS}/news?locale=ar&sort[0]=date:desc&sort[1]=id:desc&pagination[start]={start}&pagination[limit]={NEWS_PAGE}"
        fetch(name, url)
        path = RAW / name
        if not path.exists() or len(json.loads(path.read_text(encoding="utf-8")).get("data", [])) < NEWS_PAGE:
            break
        start += NEWS_PAGE
    manifest["note"] = "Raw files for the web corpus. Not for redistribution; see the header of scripts/fetch_web_corpus.py."
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
    different = 0
    for name, meta in manifest["files"].items():
        path = RAW / name
        if not path.exists():
            print(f"MISSING    {name}")
            different += 1
        elif hashlib.sha256(path.read_bytes()).hexdigest() != meta["sha256"]:
            print(f"DIFFERENT  {name} (changed since it was recorded)")
            different += 1
    print(f"\n{len(list(RAW.glob('*')))} files in {RAW}; {failed} download(s) failed; {different} differ from the manifest")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
