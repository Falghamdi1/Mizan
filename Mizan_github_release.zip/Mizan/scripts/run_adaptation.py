"""Model adaptation, end to end and reproducible: LoRA fine-tuning of Qwen3-Embedding-0.6B and a before/after on held-out documents.

What is adapted: the EMBEDDING model (contrastive LoRA, in-batch negatives), because retrieval, not generation, is where the logged failures
are (near-duplicate clauses in different regulations). This is fine-tuning of a model; it is not preprocessing, a prompt change or reranking.

    python scripts/run_adaptation.py --train            # map the pairs onto Mizan-lite text, train (about 100 steps), evaluate untuned vs tuned
    python scripts/run_adaptation.py --adapter finetune/out/q06_lite     # evaluate an existing adapter only
    python scripts/run_adaptation.py --check-only       # the leakage report, no models
    python scripts/run_adaptation.py --adapter finetune/out/q06_lite --blind   # ALSO the one-shot test on the frozen blind PDF questions (docs/ANALYSIS_PLAN.md, P5)

Leakage controls (all enforced in code, and reported):
  * training pairs come from 6 of the 8 PDFs; Tour-Guide and Tourist-Visa are held out. Only questions whose gold documents are ALL held out are
    used for the before/after (`leakage_report` stops the run otherwise);
  * no evaluation question equals a training query (canonical form);
  * the three question sets are reported separately: the 45 LLM-generated ones (same model family as the pairs: the weakest evidence), the 9
    hand-written ones, and the Ministry-written FAQ questions whose answer lies in a held-out PDF (independent of us and of any LLM);
  * the blind test set (eval/questions_final_test_*.json) is read ONLY with --blind, after `make_blind_test.py --verify` passes, and a
    second --blind run is refused while results/adaptation-blind-*.json exists (the set is used once; docs/ANALYSIS_PLAN.md).
Same everything else in both arms: Mizan-lite text, regulation titles prepended, top-4, no reranker, the same index and questions.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

PAIRS = ROOT / "finetune" / "pairs_v2.jsonl"
LITE_PAIRS = ROOT / "finetune" / "pairs_v2_lite_titled.jsonl"
ADAPTER = ROOT / "finetune" / "out" / "q06_lite"
PIPE = "mizan-lite+repair_lam_alef"
SETS = {"generated (45, same LLM family as the pairs)": ROOT / "eval" / "questions_large.json",
        "hand-written (9)": ROOT / "eval" / "questions.json",
        "Ministry FAQ in held-out PDFs": ROOT / "data" / "web" / "questions_pdf.json"}


def canon(text: str) -> str:
    from src.preprocessing import canonical_for_eval
    return canonical_for_eval(text)


def training_docs(pairs_path: Path) -> set[str]:
    return {json.loads(line)["doc"] for line in pairs_path.read_text(encoding="utf-8").splitlines() if line.strip()}


def load_sets() -> dict[str, list[dict]]:
    out = {}
    for name, path in SETS.items():
        if path.exists():
            out[name] = [q for q in json.loads(path.read_text(encoding="utf-8")) if q.get("gold_evidence")]
    return out


def leakage_report(pairs_path: Path, sets: dict[str, list[dict]]) -> dict:
    """Which evaluation questions are safe to use. Raises nothing: callers decide; `usable` holds only questions whose gold documents are all held out."""
    train_docs = training_docs(pairs_path)
    train_queries = {canon(json.loads(l).get("query_raw") or json.loads(l)["query"]) for l in pairs_path.read_text(encoding="utf-8").splitlines() if l.strip()}
    rep = {"training_documents": sorted(train_docs), "sets": {}, "usable": {}}
    for name, qs in sets.items():
        usable = [q for q in qs if q.get("gold_docs") and not (set(q["gold_docs"]) & train_docs)]
        overlap_q = [q["id"] for q in usable if canon(q["question"]) in train_queries]
        rep["sets"][name] = {"answerable_questions": len(qs), "all_gold_docs_held_out": len(usable), "excluded_because_gold_doc_was_in_training": len(qs) - len(usable),
                             "equal_to_a_training_query": overlap_q}
        rep["usable"][name] = [q for q in usable if q["id"] not in overlap_q]
    rep["problems"] = [f"{n}: {s['equal_to_a_training_query']}" for n, s in rep["sets"].items() if s["equal_to_a_training_query"]]
    return rep


BLIND_PDF = ROOT / "eval" / "questions_final_test_pdf.json"


def blind_sets(pairs_path: Path) -> dict[str, list[dict]]:
    """The frozen blind PDF questions (answerable only), split by whether the gold document was in the training pairs. Empty if none is frozen.
    Refuses (raises) when the freeze check fails or a question equals a training query."""
    if not BLIND_PDF.exists() or not (ROOT / "eval" / "blind_test" / "FROZEN.json").exists():
        return {}
    ver = subprocess.run([sys.executable, str(ROOT / "scripts" / "make_blind_test.py"), "--verify"], capture_output=True, text=True, encoding="utf-8", cwd=ROOT)
    if ver.returncode != 0:
        raise RuntimeError("the blind set changed after it was frozen; do not use it:\n" + ver.stdout + ver.stderr)
    qs = [q for q in json.loads(BLIND_PDF.read_text(encoding="utf-8")) if q.get("gold_evidence")]
    train_docs = training_docs(pairs_path)
    train_queries = {canon(json.loads(l).get("query_raw") or json.loads(l)["query"]) for l in pairs_path.read_text(encoding="utf-8").splitlines() if l.strip()}
    same = [q["id"] for q in qs if canon(q["question"]) in train_queries]
    if same:
        raise RuntimeError(f"blind questions equal to training queries: {same}")
    held = [q for q in qs if q.get("gold_docs") and not (set(q["gold_docs"]) & train_docs)]
    seen = [q for q in qs if q not in held]
    out = {"blind PDF, all documents (P5)": qs}
    if held:
        out["blind PDF, documents held out of training (generalisation)"] = held
    if seen:
        out["blind PDF, documents in the training pairs (known corpus)"] = seen
    return out


def train(pairs: Path, out: Path) -> None:
    if not LITE_PAIRS.exists():
        subprocess.run([sys.executable, "-m", "finetune.remap_pairs", "--pairs", str(pairs), "--from-pipeline", "mizan+repair_lam_alef",
                        "--to-pipeline", PIPE, "--titled", "--out", str(LITE_PAIRS)], check=True, cwd=ROOT)
    subprocess.run([sys.executable, "-m", "finetune.train_lora", "--pairs", str(LITE_PAIRS), "--out", str(out), "--epochs", "3", "--batch", "16",
                    "--max-len", "512", "--grad-ckpt"], check=True, cwd=ROOT)


def evaluate(adapter: str, questions: list[dict]) -> dict:
    """Retrieval-only run of Mizan-lite with titles, with (adapter) or without ("") the LoRA adapter."""
    import tempfile

    from src import config, embeddings, memory, retrieval
    from src.corpus import load_corpus
    from src.evaluation import run_eval
    from src.preprocessing import get_config
    from src.rag import Pipeline

    config.override(embedding_model="Qwen/Qwen3-Embedding-0.6B", embedding_adapter=adapter, embed_quant="none", reranker="", chunk_title=True,
                    llm_provider="mock", judge_provider="")
    config.CORPUS = "pdf"
    embeddings.release()
    p = Pipeline(get_config(PIPE))
    p.build(load_corpus(config.RAW_DIR, kind="pdf"))
    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False, encoding="utf-8") as f:
        json.dump(questions, f, ensure_ascii=False)
    res = run_eval([PIPE], pipelines={PIPE: p}, questions_path=Path(f.name), retrieve_only=True, save=False)
    retrieval.drop_index(PIPE)
    memory.release_all()
    return res


def compare(before: dict, after: dict, sets: dict[str, list[dict]]) -> dict:
    from src.stats import paired_bootstrap
    col = lambda r, key, ids: {x["id"]: x[key] for x in r["pipelines"][PIPE]["per_question"] if x["id"] in ids and x.get(key) is not None}
    out = {}
    for name, qs in list(sets.items()) + [("all held-out questions pooled", [q for v in sets.values() for q in v])]:
        ids = {q["id"] for q in qs}
        row = {"n": len(ids)}
        for key in ("hit", "mrr"):
            a, b = col(before, key, ids), col(after, key, ids)
            if not a:
                continue
            bs = paired_bootstrap(a, b)
            row[key] = {"before": round(sum(a.values()) / len(a), 3), "after": round(sum(b.values()) / len(b), 3),
                        "diff": None if bs is None else round(bs[0], 3), "ci": None if bs is None else [round(bs[1], 3), round(bs[2], 3)]}
        out[name] = row
    return out


def markdown(rep: dict, title: str = "Model adaptation: LoRA fine-tuning of Qwen3-Embedding-0.6B, before vs after", guide: bool = True) -> str:
    out = ["# " + title, "",
           f"Run {rep['timestamp']}. Both arms: `{PIPE}` text, titles on, top-4, no reranker, same index and questions. "
           f"Adapter: `{rep['adapter']}`. Training: {rep.get('training', 'see finetune/out/*/mizan_train.json')}.", "",
           "## Leakage report", "", "```", json.dumps({k: v for k, v in rep["leakage"].items() if k != "usable"}, ensure_ascii=False, indent=1), "```", "",
           "## Result (hit@4 and MRR; after minus before, paired bootstrap 95%)", "", "| question set | n | hit@4 before | after | difference [95% CI] | MRR before | after | difference [95% CI] |", "|---|---|---|---|---|---|---|---|"]
    for name, r in rep["results"].items():
        h, m = r.get("hit"), r.get("mrr")
        if not h:
            continue
        out.append(f"| {name} | {r['n']} | {h['before']} | {h['after']} | {h['diff']:+} [{h['ci'][0]:+}, {h['ci'][1]:+}] | {m['before']} | {m['after']} | {m['diff']:+} [{m['ci'][0]:+}, {m['ci'][1]:+}] |")
    if not guide:
        return "\n".join(out + ["", "Blind set, used once. Rule (docs/ANALYSIS_PLAN.md, P5): the adapter counts as shown to help only if the lower bound of the all-documents row is above 0; "
                               "the held-out-documents row measures generalisation to unseen documents, the other row use on the known corpus. Whatever came out is reported."])
    out += ["", "Reading guide: the generated questions share a model family and style with the training pairs, so a gain there can partly be question-style learning. "
                "The hand-written and Ministry FAQ rows are the style-independent checks but small. A difference whose interval includes zero is not distinguishable "
                "from zero; this file reports whatever came out, including a neutral or negative result."]
    return "\n".join(out)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--train", action="store_true")
    ap.add_argument("--adapter", default=str(ADAPTER))
    ap.add_argument("--check-only", action="store_true")
    ap.add_argument("--blind", action="store_true", help="also run the one-shot test on the frozen blind PDF questions")
    ap.add_argument("--force-blind", action="store_true", help="allow a second blind run (must be reported as a repeat)")
    a = ap.parse_args()
    if a.blind and not a.force_blind and list((ROOT / "results").glob("adaptation-blind-*.json")):
        print("STOP: a blind adaptation result already exists in results/. The blind set is used once (docs/ANALYSIS_PLAN.md). Use --force-blind only to repeat a failed run, and report both.")
        return 1
    sets = load_sets()
    leak = leakage_report(PAIRS, sets)
    print(json.dumps({k: v for k, v in leak.items() if k != "usable"}, ensure_ascii=False, indent=1))
    if leak["problems"]:
        print("STOP: evaluation questions equal training queries:", leak["problems"])
        return 1
    usable = {k: v for k, v in leak["usable"].items() if v}
    if a.check_only:
        return 0
    if not usable:
        print("no held-out questions available")
        return 1
    adapter = Path(a.adapter)
    if a.train:
        try:
            train(PAIRS, adapter)
        except subprocess.CalledProcessError as e:
            print(f"TRAINING FAILED (exit code {e.returncode}). Common cause on a T4: GPU memory still held by an earlier model. Restart the runtime and run only this section; "
                  "see the traceback above.")
            return 2
    if not (adapter / "adapter_config.json").exists():
        print(f"no adapter at {adapter}: run with --train")
        return 1
    qs = [q for v in usable.values() for q in v]
    print(f"evaluating {len(qs)} held-out questions: base model, then base + adapter")
    before, after = evaluate("", qs), evaluate(str(adapter), qs)
    train_meta = json.loads((adapter / "mizan_train.json").read_text(encoding="utf-8")) if (adapter / "mizan_train.json").exists() else {}
    rep = {"timestamp": datetime.now().isoformat(timespec="seconds"), "adapter": str(adapter), "leakage": leak,
           "training": {k: train_meta.get(k) for k in ("base", "epochs", "batch", "lr", "r", "alpha", "max_len", "steps", "n_pairs", "seed")},
           "results": compare(before, after, usable)}
    out = ROOT / "results" / f"adaptation-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    out.parent.mkdir(exist_ok=True)
    out.with_suffix(".json").write_text(json.dumps({**rep, "before": before, "after": after}, ensure_ascii=False, indent=1), encoding="utf-8")
    out.with_suffix(".md").write_text(markdown(rep), encoding="utf-8")
    print(markdown(rep))
    if a.blind:
        try:
            bsets = blind_sets(PAIRS)
        except RuntimeError as e:
            print("BLIND RUN REFUSED:", e)
            return 3
        if not bsets:
            print("No frozen blind PDF set found (eval/questions_final_test_pdf.json and eval/blind_test/FROZEN.json): nothing to run.")
            return 0
        bqs = bsets["blind PDF, all documents (P5)"]
        print(f"blind set: {len(bqs)} answerable PDF questions; base model, then base + adapter (used once)")
        bbefore, bafter = evaluate("", bqs), evaluate(str(adapter), bqs)
        brep = {"timestamp": datetime.now().isoformat(timespec="seconds"), "adapter": str(adapter), "leakage": {"blind_questions_equal_to_training_queries": []},
                "training": rep["training"], "results": compare(bbefore, bafter, bsets)}
        bout = ROOT / "results" / f"adaptation-blind-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        bout.with_suffix(".json").write_text(json.dumps({**brep, "before": bbefore, "after": bafter}, ensure_ascii=False, indent=1), encoding="utf-8")
        bmd = markdown(brep, title="Adaptation on the frozen blind set (P5, used once)", guide=False)
        bout.with_suffix(".md").write_text(bmd, encoding="utf-8")
        print(bmd)
    return 0


if __name__ == "__main__":
    sys.exit(main())
