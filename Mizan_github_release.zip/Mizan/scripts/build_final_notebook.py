"""Build Mizan_Final_Colab.ipynb: the ONE final run on the frozen blind set (docs/ANALYSIS_PLAN.md), separate from the long
development notebooks so a failure in one step does not cost a three-hour session.

It produces, in one session on a T4 (about 1.5 hours):
  P5  the LoRA adapter against the base model, on the held-out documents (development questions) and on the frozen blind PDF questions;
  P1  Mizan-lite against Standard (and the full preset as a reference) on the blind PDF and web questions, retrieval only, three stacks;
  P2  the same on the web questions (inside the same table);
  P3/P4  real answers from the final stack for the blind questions, the refusal rate on the unanswerable ones, and two blind grading sheets
      per corpus for the two human graders (the KEY stays with the evaluator).
Every step is a separate cell with its own switch and a clear message when it cannot run; results are zipped at the end whatever happened.

    python scripts/build_final_notebook.py        # run again after any change to src/ or scripts/
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import build_notebook as B  # noqa: E402
import build_web_notebook as W  # noqa: E402

code, md = B.code, B.md
OUT = ROOT / "Mizan_Final_Colab.ipynb"

# union of what the two other notebooks write, in a stable order; the frozen blind files are uploaded by the notebook itself
_seen, MODULES = set(), []
for path, why in list(W.MODULES) + list(B.MODULES):
    if path not in _seen and not path.startswith("eval/questions_final_test") and path != "eval/blind_test/FROZEN.json":
        _seen.add(path)
        MODULES.append((path, why))
for extra, why in (("scripts/make_blind_test.py", "checks that the frozen blind set is unchanged"), ):
    if extra not in _seen:
        MODULES.append((extra, why))

INTRO = """
# مِيزان · Mizan: the final run on the frozen blind test set

**Read `docs/ANALYSIS_PLAN.md` first.** It fixes, before any blind question existed, what is measured and how each result is read. This notebook runs once, after the blind questions are frozen (`python scripts/make_blind_test.py --build`) and after the prompt has been chosen on development data.

**Do not change any setting after seeing a blind result.** If a step crashes, run it again unchanged and report both runs.

**How to run.** *Runtime › Change runtime type › T4 GPU*, then *Run all*. When asked, upload the three frozen files (`eval/questions_final_test_pdf.json`, `eval/questions_final_test_web.json`, `eval/blind_test/FROZEN.json`) and, if the law and GASTAT pages cannot be fetched, `html_for_colab.zip`. About 1.5 hours.
"""


def cells():
    c = [md(INTRO), md("## 1. Setup")]
    c.append(code('''
import os, sys, time
os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")
T0 = time.perf_counter()
import torch
print("GPU:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "none: choose a T4 GPU runtime")
'''))
    c.append(code('''
%pip install -q pymupdf chromadb python-dotenv gradio peft "sentence-transformers>=5" "transformers>=4.51" accelerate bitsandbytes
%pip uninstall -q -y torchao   # the Colab image ships torchao 0.10, which peft rejects when it is installed (final run, 2026-10-12)
'''))
    listing = "\n".join(f"- `{p}`: {d}" for p, d in MODULES)
    c += [md("## 2. Project code (you can skip this section)\nEach cell writes one file; later sections import it.\n\n" + listing),
          code('''
BASE = os.getcwd() if os.path.basename(os.getcwd()) == "mizan" else os.path.join(os.getcwd(), "mizan")   # safe to run twice
for d in ("src", "scripts", "eval", "eval/blind_test", "finetune", "data/raw", "data/web/raw", "results"):
    os.makedirs(os.path.join(BASE, d), exist_ok=True)
os.chdir(BASE); sys.path.insert(0, BASE); ROOT = BASE
'''),
          code("%%writefile src/__init__.py\n# Mizan prototype package")]
    c += [code(f"%%writefile {p}\n" + ((ROOT / p).read_text(encoding="utf-8") or "# (empty file)\n")) for p, _ in MODULES]

    c += [md("## 3. Settings fixed in advance\nThese are the values of `docs/ANALYSIS_PLAN.md` section 3. The prompt is the version chosen on development data and written in `docs/EXPERIMENT_LOG.md` **before** this run; it is not chosen here."),
          code('''
PROMPT = "v1"        # the prompt version fixed by the analysis plan, section 5 (v1 unless the log says v4 was chosen on the development sheet)
RUN_ADAPTATION, RUN_RETRIEVAL, RUN_ANSWERS = True, True, True    # each step is independent; set False only to skip, never to retry with other settings
from src import config
config.override(prompt_version=PROMPT)
print("prompt version:", config.SETTINGS.prompt_version)
'''),
          md("## 4. The frozen blind set\nUpload the three frozen files if they are not here yet. The cell then runs `make_blind_test.py --verify`: it stops if anything changed after the freeze."),
          code('''
import json, subprocess
NEED = ["eval/questions_final_test_pdf.json", "eval/questions_final_test_web.json", "eval/blind_test/FROZEN.json"]
if not all(os.path.exists(f) for f in NEED):
    print("Choose the three frozen files:", NEED)
    try:
        from google.colab import files
        import re
        for name, data in files.upload().items():
            name = re.sub(r" \\(\\d+\\)(?=\\.json$)", "", name)   # Colab renames a repeated upload to "name (1).json"
            dest = "eval/blind_test/FROZEN.json" if name == "FROZEN.json" else f"eval/{name}"
            open(dest, "wb").write(data)
    except ImportError:
        print("not in Colab: place the files by hand")
BLIND_OK = all(os.path.exists(f) for f in NEED)
if BLIND_OK:
    ver = subprocess.run([sys.executable, "scripts/make_blind_test.py", "--verify"], capture_output=True, text=True, encoding="utf-8")
    print(ver.stdout.strip() or ver.stderr.strip())
    BLIND_OK = ver.returncode == 0
    assert BLIND_OK, "the blind set changed after it was frozen: do not use it"
    for k in ("pdf", "web"):
        qs = json.load(open(f"eval/questions_final_test_{k}.json", encoding="utf-8"))
        print(k, len(qs), "questions,", sum(1 for q in qs if q.get("gold_evidence")), "answerable")
else:
    print("NO FROZEN BLIND SET: the blind steps below will say so and do nothing. Only the development part of the adaptation can run.")
'''),
          md("## 5. Data\nThe web corpus (for the blind web questions) and the 8 PDFs. The law and GASTAT pages sometimes time out from Colab: upload `html_for_colab.zip` when asked. **The fingerprint printed here must be `b3871676ff02…`** for the complete web corpus."),
          code('''
!python scripts/fetch_web_corpus.py
sys.path.insert(0, "scripts")
import fetch_web_corpus as F
EXPECTED = (["faq.json", "definitions.json", "methodologies.json", "news-0.json"] + [f"law-{s}.html" for s in F.LAWS] + [f"gastat-{s}.html" for s in F.GASTAT_PAGES])
missing = [f for f in EXPECTED if not os.path.exists(f"data/web/raw/{f}")]
if missing:
    print("Missing:", ", ".join(missing), "\\nChoose the missing file(s) or html_for_colab.zip.")
    from google.colab import files
    import zipfile
    for name, data in files.upload().items():
        path = f"data/web/raw/{name}"
        open(path, "wb").write(data)
        if name.endswith(".zip"):
            zipfile.ZipFile(path).extractall("data/web/raw")
    missing = [f for f in EXPECTED if not os.path.exists(f"data/web/raw/{f}")]
print("All expected files are present." if not missing else f"WARNING: still missing {missing}: the corpus is incomplete and results are NOT comparable.")
from src.colab import get_corpus
from src.corpus import corpus_fingerprint, load_corpus
get_corpus(ROOT)
print("web fingerprint:", corpus_fingerprint(config.RAW_DIR, "web")[:12], "| pdf fingerprint:", corpus_fingerprint(config.RAW_DIR, "pdf")[:12])
!python scripts/make_faq_questions.py --check
!python scripts/make_pdf_questions.py
'''),
          md("## 6. P5: model adaptation (LoRA on the embedder)\nTrains the adapter on the six training PDFs, then compares base against adapted on (a) the development questions about the two held-out PDFs and (b) **the frozen blind PDF questions, once**. The full console output is saved to `results/final-adaptation.log`; if training fails the message says why. About 25 minutes."),
          code('''
from src import memory
if RUN_ADAPTATION:
    memory.release_all()
    args = [sys.executable, "scripts/run_adaptation.py", "--train"] + (["--blind"] if BLIND_OK else [])
    log = open("results/final-adaptation.log", "w", encoding="utf-8")
    proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", bufsize=1,
                            env={**os.environ, "PYTHONIOENCODING": "utf-8"})
    for line in proc.stdout:
        print(line, end=""); log.write(line)
    code_ = proc.wait(); log.close()
    print("exit code", code_)
    memory.release_all()
'''),
          md("## 7. P1 and P2: retrieval on the blind questions\nStandard, Mizan-lite and (reference) the full preset, retrieval only, on the blind PDF questions (PDF corpus) and the blind web questions (web corpus), never in one index. The final stack is the first row; the other two are secondary. Differences are paired bootstrap 95% intervals; `*` = the interval excludes zero."),
          code('''
import pandas as pd
from src import retrieval
from src.colab import paired_line
from src.evaluation import run_eval
ARMS = ["baseline", "mizan-lite+repair_lam_alef", "mizan+repair_lam_alef"]
STACKS = {"final stack: Qwen3-0.6B + reranker": ("Qwen/Qwen3-Embedding-0.6B", "Qwen/Qwen3-Reranker-0.6B"),
          "secondary: e5-small": ("intfloat/multilingual-e5-small", ""),
          "secondary: Qwen3-4B + reranker": ("Qwen/Qwen3-Embedding-4B", "Qwen/Qwen3-Reranker-0.6B")}
BLIND_RET = {}
if RUN_RETRIEVAL and BLIND_OK:
    for label, (model, reranker) in STACKS.items():
        config.override(embedding_model=model, embed_quant="none", embedding_adapter="", reranker=reranker, rerank_top_n=20, rerank_4bit=False,
                        chunk_title=False, llm_provider="mock", judge_provider="")
        for corpus in ("pdf", "web"):
            config.CORPUS = corpus
            BLIND_RET[(label, corpus)] = run_eval(ARMS, questions_path=f"eval/questions_final_test_{corpus}.json", retrieve_only=True)
            for n in ARMS:
                retrieval.drop_index(n)
            memory.release_all()
    rows = []
    for (label, corpus), res in BLIND_RET.items():
        for metric in ("hit", "mrr", "candidate_recall"):
            row = {"stack": label, "questions": corpus, "metric": metric, "Standard": round(res["pipelines"][ARMS[0]]["aggregate"][metric] or 0, 3)}
            for tag, a, b in (("lite - Standard", ARMS[0], ARMS[1]), ("full - Standard", ARMS[0], ARMS[2])):
                line = paired_line(res, a, b, metric, metric)
                row[tag] = "n/a" if line["kind"] == "na" else f"{line['diff']:+.3f} [{line['lo']:+.3f}, {line['hi']:+.3f}]" + (" *" if line["kind"] != "flat" else "")
            rows.append(row)
    TABLE = pd.DataFrame(rows)
    display(TABLE)
    TABLE.to_csv("results/final-retrieval.csv", index=False)
    print("index tokens per pipeline (the same text on every stack with the same tokenizer):")
    for (label, corpus), res in BLIND_RET.items():
        print(f"  {label[:34]:34s} {corpus}: " + " / ".join(f"{res['pipelines'][n]['index']['tokens']:,}" for n in ARMS))
else:
    print("skipped (switch off or no frozen blind set)")
'''),
          md("## 8. P3 and P4: real answers and the grading sheets\nThe final stack (0.6B embedder, reranker, Qwen3-4B generator in 4-bit), the fixed prompt, Standard against Mizan-lite, on the blind questions. This cell does **not** judge correctness: no LLM judge is used. It measures refusals on the unanswerable questions, citations, tokens and latency, and writes **two identical blind grading sheets per corpus** (`results/grading_pdf`, `results/grading_web`). Give a grader only `grader_1.csv` or `grader_2.csv`, never `KEY.json`."),
          code('''
import shutil
from src.colab import Stopwatch, start_models
from src.preprocessing import get_config
from src.rag import Pipeline
NAMES = ["baseline", "mizan-lite+repair_lam_alef"]
BLIND_ANS = {}
if RUN_ANSWERS and BLIND_OK:
    memory.release_all()
    SW = Stopwatch(T0)
    PROFILE, _ = start_models("compact", SW, judge=False)
    config.override(prompt_version=PROMPT)
    print(PROFILE.note, "| prompt", config.SETTINGS.prompt_version)
    for corpus in ("pdf", "web"):
        config.CORPUS = corpus
        pages = load_corpus(config.RAW_DIR, corpus)
        pipes = {}
        for n in NAMES:
            pipes[n] = Pipeline(get_config(n)); pipes[n].build(pages)
        with SW.stage(f"blind answers: {corpus}"):
            res = run_eval(NAMES, pipelines=pipes, questions_path=f"eval/questions_final_test_{corpus}.json", retrieve_only=False, judge_answers=False)
        BLIND_ANS[corpus] = res
        path = f"results/answers_blind_{corpus}.json"
        json.dump(res, open(path, "w", encoding="utf-8"), ensure_ascii=False)
        made = subprocess.run([sys.executable, "scripts/human_grading.py", "make", path, "--arms", ",".join(NAMES), "--n", "500", "--unanswerable", "500",
                               "--questions", f"eval/questions_final_test_{corpus}.json", "--out", f"results/grading_{corpus}"], capture_output=True, text=True, encoding="utf-8")
        print(made.stdout or made.stderr)
        for n in NAMES:
            retrieval.drop_index(n)
    rows = []
    for corpus, res in BLIND_ANS.items():
        for n in NAMES:
            a = res["pipelines"][n]["aggregate"]
            rows.append({"questions": corpus, "pipeline": n, "refused an answerable question": a.get("false_abstain_rate"), "correct refusal of an unanswerable question": a.get("correct_abstain_rate"),
                         "citation present": a.get("citation_present"), "citation valid share": a.get("citation_valid_share"), "input tokens": a.get("input_tokens"),
                         "median total latency s": a.get("total_latency_s")})
    display(pd.DataFrame(rows))
else:
    print("skipped (switch off or no frozen blind set)")
'''),
          md("## 9. Save everything\nOne zip with every result file, the log and the grading sheets (`KEY.json` inside: keep it away from the graders). It downloads even if a step above failed."),
          code('''
import glob, shutil
shutil.make_archive("mizan_final_results", "zip", "results")
print(sorted(os.path.basename(f) for f in glob.glob("results/*"))[:60])
try:
    from google.colab import files
    files.download("mizan_final_results.zip")
except ImportError:
    print("not in Colab: mizan_final_results.zip is in the current folder")
''')]
    return c


def main():
    import nbformat as nbf

    nb = nbf.v4.new_notebook()
    nb.cells = cells()
    nb.metadata["kernelspec"] = {"display_name": "Python 3", "language": "python", "name": "python3"}
    nb.metadata["accelerator"] = "GPU"
    nbf.write(nb, OUT)
    print("wrote", OUT, f"({len(nb.cells)} cells)")


if __name__ == "__main__":
    main()
