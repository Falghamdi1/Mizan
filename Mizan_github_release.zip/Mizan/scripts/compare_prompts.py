"""Compare the generator prompt versions (src/rag.py PROMPTS) on the SAME retrieved passages.

Why it is fair: retrieval is run once per question and every version gets exactly those passages, the same user prompt, the
same model and temperature 0. Only the system prompt differs. Answers are cached per (model, prompt), so a re-run is free.

What it measures (all without an LLM judge, which was shown to be unreliable in this project):
  keyword coverage        share of the question's `answer_keywords` found in the answer (surface check, answerable questions)
  false refusals          answerable questions the model refused
  correct refusals        unanswerable questions the model refused
  citation validity       among answers that cite, the share of citations naming a retrieved (file, page)   [monitoring.citation_report]
  answers with a valid citation   among non-refusals
  input / output tokens, LLM latency (median), answers that may have been cut off at the token limit
Differences to v1 come with a paired bootstrap interval. It also writes a blind grading sheet: 20 random answerable questions,
the answers of all versions in shuffled columns A/B/C with the key in a separate file, so two people can grade correctness without
knowing the version. Keyword coverage is a weak proxy; the human grades are the check on it.
(The more complete tool is scripts/human_grading.py: two graders, a rubric, agreement, adjudication and judge validation; it accepts this
script's result file with --arms v1,v2,v3.)

    python scripts/compare_prompts.py --pipeline mizan-lite+repair_lam_alef --questions eval/questions.json --versions v1,v2,v3
Needs a real generator (MIZAN_LLM_PROVIDER=ollama or hf): the mock provider ignores the prompt and is refused.
In a notebook, call run(pipeline, questions, versions) with an already built pipeline.
"""
from __future__ import annotations

import argparse
import csv
import json
import random
import statistics
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src import monitoring  # noqa: E402
from src.config import RESULTS_DIR, SETTINGS  # noqa: E402
from src.evaluation import load_questions, score  # noqa: E402
from src.rag import PROMPTS, LLMResult, RAGResult, build_user_prompt, call_llm  # noqa: E402
from src.stats import paired_bootstrap  # noqa: E402


def run(pipeline, questions: list[dict], versions: list[str]) -> dict:
    """Generate with every version on the same retrieval. Returns {"versions": {v: {"rows": [...], "aggregate": {...}}}, ...}."""
    if SETTINGS.llm_provider == "mock":
        raise RuntimeError("The mock generator ignores the prompt. Set MIZAN_LLM_PROVIDER=ollama or hf (a real model).")
    for v in versions:
        if v not in PROMPTS:
            raise ValueError(f"unknown prompt version {v!r}; available: {', '.join(PROMPTS)}")
    rows: dict[str, list[dict]] = {v: [] for v in versions}
    for i, q in enumerate(questions, start=1):
        pq, passages, t_ret, cands = pipeline.retrieve(q["question"])
        user = build_user_prompt(q["question"], passages)
        for v in versions:
            llm: LLMResult = call_llm(user, passages, system=PROMPTS[v])
            r = RAGResult(pipeline.name, q["question"], pq, passages, llm.text, t_ret, llm, sum(p.tokens for p in passages),
                          meta={"candidates": cands, "prompt": v})
            s = score(q, r)
            cite = monitoring.citation_report(llm.text, passages)
            rows[v].append({"id": q["id"], "answerable": s["answerable"], "answer": llm.text, "keyword_coverage": s["keyword_coverage"],
                            "refused": int(monitoring.is_refusal(llm.text)), "n_cited": cite["n_cited"], "n_valid": cite["n_valid"], "cites_gold": s["cites_gold"],
                            "input_tokens": llm.input_tokens, "output_tokens": llm.output_tokens, "llm_s": llm.latency_s,
                            "truncated": int((llm.output_tokens or 0) >= SETTINGS.llm_max_tokens), "cached": llm.cached})
        if i % 10 == 0 or i == len(questions):
            print(f"  {i}/{len(questions)} questions", flush=True)
    return {"timestamp": datetime.now().isoformat(timespec="seconds"), "pipeline": pipeline.name,
            "settings": SETTINGS.as_dict(), "n_questions": len(questions),
            "versions": {v: {"rows": rows[v], "aggregate": aggregate(rows[v])} for v in versions}}


def _mean(xs):
    xs = [x for x in xs if x is not None]
    return statistics.fmean(xs) if xs else None


def aggregate(rows: list[dict]) -> dict:
    ans = [r for r in rows if r["answerable"]]
    unans = [r for r in rows if not r["answerable"]]
    nonref = [r for r in rows if not r["refused"]]
    cited = sum(r["n_cited"] for r in rows)
    lat = [r["llm_s"] for r in rows if r["llm_s"] is not None and not r["cached"]]
    return {
        "n": len(rows), "n_answerable": len(ans), "n_unanswerable": len(unans),
        "keyword_coverage": _mean([r["keyword_coverage"] for r in ans]),
        "false_refusal_rate": _mean([r["refused"] for r in ans]), "correct_refusal_rate": _mean([r["refused"] for r in unans]),
        "citation_validity": (sum(r["n_valid"] for r in rows) / cited) if cited else None,
        "answers_with_valid_citation": _mean([int(r["n_valid"] > 0) for r in nonref]),
        "cites_gold": _mean([r.get("cites_gold") for r in ans]),
        "mean_input_tokens": _mean([r["input_tokens"] for r in rows]), "mean_output_tokens": _mean([r["output_tokens"] for r in rows]),
        "median_llm_s": statistics.median(lat) if lat else None, "truncated": sum(r["truncated"] for r in rows),
        "from_cache": sum(bool(r["cached"]) for r in rows)}


def paired(result: dict, base: str, other: str, metric: str, answerable_only: bool = True):
    """other - base, paired over questions, or None when not measurable."""
    def col(v):
        return {r["id"]: r[metric] for r in result["versions"][v]["rows"]
                if r[metric] is not None and (r["answerable"] or not answerable_only)}
    return paired_bootstrap(col(base), col(other))


def markdown(result: dict, base: str = "v1") -> str:
    vs = list(result["versions"])
    f = lambda x, d=3: "n/a" if x is None else f"{x:.{d}f}"
    a = {v: result["versions"][v]["aggregate"] for v in vs}
    out = [f"Prompt versions on the same retrieval ({result['pipeline']}, {result['n_questions']} questions, "
           f"{a[vs[0]]['n_answerable']} answerable). Differences are version minus `{base}`, paired bootstrap 95% (n.d. = interval includes zero).", "",
           "| metric | " + " | ".join(vs) + " |", "|---|" + "---|" * len(vs)]
    for key, label in (("keyword_coverage", "keyword coverage (answerable)"), ("false_refusal_rate", "refused an answerable question"),
                       ("correct_refusal_rate", "refused an unanswerable question"), ("citation_validity", "citations naming a retrieved page"),
                       ("answers_with_valid_citation", "non-refusals with a valid citation"),
                       ("cites_gold", "answerable non-refusals citing the gold passage"), ("mean_input_tokens", "input tokens / query"),
                       ("mean_output_tokens", "output tokens / query"), ("median_llm_s", "LLM latency, median s (uncached)"),
                       ("truncated", "possibly cut off"), ("from_cache", "answers from cache")):
        out.append(f"| {label} | " + " | ".join(f(a[v][key], 1 if "tokens" in key or key.endswith("_s") else 3) if key not in ("truncated", "from_cache") else str(a[v][key]) for v in vs) + " |")
    out += ["", f"Paired differences to `{base}`:", "", "| version | keyword coverage | refused an answerable question |", "|---|---|---|"]
    for v in vs:
        if v == base:
            continue
        cells = []
        for metric in ("keyword_coverage", "refused"):
            b = paired(result, base, v, metric)
            if b is None:
                cells.append("n/a")
                continue
            mean, lo, hi, n = b
            cells.append(f"{mean:+.3f} [{lo:+.3f}, {hi:+.3f}] {'higher' if lo > 0 else 'lower' if hi < 0 else 'n.d.'} (n={n})")
        out.append(f"| `{v}` | {cells[0]} | {cells[1]} |")
    out += ["", "Keyword coverage is a surface check; judge scores are not used. Correctness needs the human grading sheet. "
                "One run, temperature 0; with this few questions only large differences will show."]
    return "\n".join(out)


def grading_sheet(result: dict, questions: list[dict], n: int = 20, seed: int = 0) -> tuple[list[dict], dict]:
    """Blind sheet: n random answerable questions; answers of all versions in shuffled columns A, B, C...; key kept apart."""
    rng = random.Random(seed)
    vs = list(result["versions"])
    by_id = {q["id"]: q for q in questions}
    ids = [r["id"] for r in result["versions"][vs[0]]["rows"] if r["answerable"]]
    rng.shuffle(ids)
    sheet, key = [], {}
    letters = "ABCDEFGH"[: len(vs)]
    for qid in ids[:n]:
        order = vs[:]
        rng.shuffle(order)
        ans = {v: next(r["answer"] for r in result["versions"][v]["rows"] if r["id"] == qid) for v in vs}
        row = {"id": qid, "question": by_id[qid]["question"], "reference_answer": by_id[qid].get("reference_answer", "")}
        for letter, v in zip(letters, order):
            row[f"answer_{letter}"] = ans[v]
            row[f"correct_{letter} (0/1)"] = ""
        sheet.append(row)
        key[qid] = dict(zip(letters, order))
    return sheet, key


def save(result: dict, questions: list[dict], out_dir: Path = RESULTS_DIR) -> dict[str, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    paths = {"json": out_dir / f"prompts-{stamp}.json", "md": out_dir / f"prompts-{stamp}.md",
             "sheet": out_dir / f"prompts-{stamp}-grading-sheet.csv", "key": out_dir / f"prompts-{stamp}-grading-KEY.json"}
    paths["json"].write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding="utf-8")
    paths["md"].write_text(markdown(result), encoding="utf-8")
    sheet, key = grading_sheet(result, questions)
    if sheet:
        with open(paths["sheet"], "w", encoding="utf-8-sig", newline="") as fh:   # utf-8-sig: Excel opens Arabic correctly
            w = csv.DictWriter(fh, fieldnames=list(sheet[0]))
            w.writeheader()
            w.writerows(sheet)
    paths["key"].write_text(json.dumps(key, indent=1), encoding="utf-8")
    return paths


def main() -> None:
    from src.config import resolve_questions_path
    from src.corpus import load_corpus
    from src.rag import Pipeline
    from src.config import resolve_data_dir
    from src.preprocessing import get_config

    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--pipeline", default="mizan-lite+repair_lam_alef")
    ap.add_argument("--questions", default=None)
    ap.add_argument("--versions", default=",".join(PROMPTS))
    ap.add_argument("--limit", type=int, default=0, help="only the first N questions (smoke test)")
    args = ap.parse_args()
    qs = load_questions(Path(args.questions) if args.questions else resolve_questions_path()[0])
    if args.limit:
        qs = qs[: args.limit]
    p = Pipeline(get_config(args.pipeline))
    p.build(load_corpus(resolve_data_dir()[0]))
    res = run(p, qs, [v.strip() for v in args.versions.split(",") if v.strip()])
    paths = save(res, qs)
    print(markdown(res))
    print("\nwritten:", ", ".join(str(x) for x in paths.values()))


if __name__ == "__main__":
    main()
