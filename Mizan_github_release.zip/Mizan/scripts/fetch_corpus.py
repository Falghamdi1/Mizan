"""Download the 8 public Ministry of Tourism PDFs listed in data/corpus_manifest.json into data/raw/ and verify
their sha256, so another engineer gets the exact corpus every reported number was measured on.

    python scripts/fetch_corpus.py            # downloads only missing files, then verifies all
    python scripts/fetch_corpus.py --verify   # verify only, download nothing

The documents are public. If a hash differs, the ministry has published a new version: results are then NOT
comparable with the ones in the README (the script says so instead of silently continuing).
"""
import argparse
import hashlib
import json
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--verify", action="store_true", help="check existing files only; download nothing")
    args = ap.parse_args()
    manifest = json.loads((ROOT / "data" / "corpus_manifest.json").read_text(encoding="utf-8"))
    raw = ROOT / "data" / "raw"
    raw.mkdir(parents=True, exist_ok=True)
    bad = 0
    for item in manifest["files"]:
        path = raw / item["file"]
        if not path.exists() and not args.verify:
            print(f"downloading {item['file']} ({item['bytes'] / 1e6:.1f} MB) from {item['url']}")
            try:  # a browser-like User-Agent (some CDNs refuse urllib's); write to a temp name so a failed download leaves no half file
                req = urllib.request.Request(item["url"], headers={"User-Agent": "Mozilla/5.0 (compatible; MizanPrototype)"})
                with urllib.request.urlopen(req, timeout=90) as resp:
                    tmp = path.with_suffix(".part")
                    tmp.write_bytes(resp.read())
                    tmp.replace(path)
            except Exception as e:
                print(f"FAILED    {item['file']}: {type(e).__name__}: {e}")
                continue
        if not path.exists():
            print(f"MISSING   {item['file']}")
            bad += 1
            continue
        ok = hashlib.sha256(path.read_bytes()).hexdigest() == item["sha256"]
        print(f"{'ok       ' if ok else 'DIFFERENT'} {item['file']}")
        bad += not ok
    if bad:
        print(f"\n{bad} file(s) missing or different from the corpus used for the reported results.")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
