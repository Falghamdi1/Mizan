"""Run the one-step ablations (see src/ablation.py) with the current .env / environment settings.

    python scripts/run_ablations.py                                 # eval/questions_combined.json
    python scripts/run_ablations.py --questions eval/questions.json

Retrieval only, no LLM needed. Writes results/ablations.md next to the full results/eval-*.json.
"""
import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.ablation import markdown, run_ablations  # noqa: E402
from src.config import RESULTS_DIR, ROOT, resolve_data_dir  # noqa: E402
from src.ingestion import load_pdfs  # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--questions", default="eval/questions_combined.json")
    args = ap.parse_args()
    t = time.perf_counter()
    res = run_ablations(load_pdfs(resolve_data_dir()[0]), ROOT / args.questions)
    md = markdown(res)
    RESULTS_DIR.mkdir(exist_ok=True)
    (RESULTS_DIR / "ablations.md").write_text(md, encoding="utf-8")
    print(f"\n{md}\n\n{time.perf_counter() - t:.0f} s")


if __name__ == "__main__":
    main()
