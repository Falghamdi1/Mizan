"""Why did the LLM judge not work? Measure it on the answers already stored in results/eval-*.json. No model is run.

    python scripts/judge_diagnosis.py            # writes docs/JUDGE_DIAGNOSIS.md and docs/data_audit/judge_diagnosis.json

For each judge model it reports how often the judge says "correct" and, on the same answers, what a deterministic check says:
keyword coverage (do the reference key facts appear in the answer) and whether the gold passage was retrieved at all.
A judge that says "correct" on answers with no key fact and no gold passage is not discriminating. Keyword coverage is itself
a proxy (a correct paraphrase can score 0), so this shows leniency, not exact error rates; the exact rates need human labels
(scripts/judge_calibrate.py).
"""
from __future__ import annotations

import glob
import json
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def load_rows(pattern: str = "results/eval-*.json") -> dict[str, list[dict]]:
    by: dict[str, list[dict]] = defaultdict(list)
    for f in sorted(glob.glob(str(ROOT / pattern))):
        try:
            d = json.loads(Path(f).read_text(encoding="utf-8"))
        except Exception:
            continue
        pl = d.get("pipelines") if isinstance(d, dict) else None
        if not isinstance(pl, dict):
            continue
        j = (d.get("judge") or {}).get("model") or "qwen3-4b-instruct (the generator itself)"
        for pn, p in pl.items():
            for r in (p.get("per_question") if isinstance(p, dict) else None) or []:
                if r.get("judge_correct") is None or r.get("abstained"):    # refusals are graded by rule, not by the judge
                    continue
                by[j].append({"file": Path(f).name, "pipeline": pn, **r})
    return by


def summarize(rows: list[dict]) -> dict:
    n = len(rows)
    ok = sum(r["judge_correct"] for r in rows)
    with_kc = [r for r in rows if r.get("keyword_coverage") is not None]
    low = [r for r in with_kc if r["keyword_coverage"] < 0.5]
    high = [r for r in with_kc if r["keyword_coverage"] >= 0.5]
    nosupport = [r for r in low if not r.get("hit")]                          # no key fact AND the gold passage was not even retrieved
    return {"n": n, "judged_correct": ok, "yes_rate": ok / n if n else None,
            "low_coverage_n": len(low), "low_coverage_judged_correct": sum(r["judge_correct"] for r in low),
            "high_coverage_n": len(high), "high_coverage_judged_correct": sum(r["judge_correct"] for r in high),
            "no_support_n": len(nosupport), "no_support_judged_correct": sum(r["judge_correct"] for r in nosupport),
            "faithful_yes_rate": (sum(r["judge_faithful"] for r in rows if r.get("judge_faithful") is not None) / n) if n else None}


def main() -> int:
    by = load_rows()
    if not by:
        print("no judged answers found in results/eval-*.json")
        return 1
    out = {j: summarize(rs) for j, rs in by.items()}
    (ROOT / "docs" / "data_audit").mkdir(parents=True, exist_ok=True)
    (ROOT / "docs" / "data_audit" / "judge_diagnosis.json").write_text(json.dumps(out, indent=1, ensure_ascii=False), encoding="utf-8")
    L = ["# Judge diagnosis (measured on stored answers, no model run)", "",
         "Source: every `results/eval-*.json` with judge verdicts; refusals excluded (they are graded by rule). Answers repeat across files "
         "(the same question in several runs), so counts are verdicts, not distinct questions.", "",
         "| judge | verdicts | said correct | key facts present (coverage >= 0.5): said correct | few key facts (< 0.5): said correct | few key facts AND gold passage not retrieved: said correct |",
         "|---|---|---|---|---|---|"]
    for j, s in out.items():
        L.append(f"| {j} | {s['n']} | {s['yes_rate']:.0%} | {s['high_coverage_judged_correct']}/{s['high_coverage_n']} | "
                 f"{s['low_coverage_judged_correct']}/{s['low_coverage_n']} | {s['no_support_judged_correct']}/{s['no_support_n']} |")
    L += ["", "Reading: a judge that is useful says \"correct\" mostly when the key facts are there and rarely when they are not. "
          "The table shows it says \"correct\" in both cases. Keyword coverage is a proxy, so some of the low-coverage answers may be right "
          "paraphrases; the by-hand reading of the disagreements is in `docs/JUDGE_DIAGNOSIS.md`.", ""]
    (ROOT / "docs" / "data_audit" / "judge_diagnosis.md").write_text("\n".join(L), encoding="utf-8")
    print("\n".join(L))
    return 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    sys.exit(main())
