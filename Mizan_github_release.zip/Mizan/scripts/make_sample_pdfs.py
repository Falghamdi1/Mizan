"""Generate a tiny SYNTHETIC Arabic corpus in data/sample/ so the pipeline can be smoke-tested
before real PDFs are available. The documents are invented, are NOT official, and every page says so.

They deliberately contain ordinary orthographic variation seen in real Arabic documents (diacritics in
some headings, tatweel, mixed alef forms, Arabic-Indic vs ASCII digits, repeated page headers/footers).
That makes this corpus suitable for checking that the machinery works. It is NOT evidence about real
documents: results on it must never be presented as findings.

Run:  python scripts/make_sample_pdfs.py
"""
import sys
from pathlib import Path

import pymupdf as fitz

sys.stdout.reconfigure(encoding="utf-8")
OUT = Path(__file__).resolve().parent.parent / "data" / "sample"
FONT_DIR = Path("C:/Windows/Fonts")
CSS = """
@font-face { font-family: arfont; src: url(arial.ttf); }
@font-face { font-family: arfont; font-weight: bold; src: url(arialbd.ttf); }
body { font-family: arfont; direction: rtl; text-align: right; font-size: 13pt; line-height: 1.7; }
h1 { font-size: 17pt; } p { margin: 0 0 9pt 0; }
.small { font-size: 9pt; color: #555; text-align: center; }
"""
DISCLAIMER = "وثيقة تجريبية اصطناعية — غير رسمية — لاختبار النظام فقط"

DOCS = {
    "دليل_ترخيص_الإيواء_السياحي.pdf": ("دليل ترخيص مرافق الإيواء السياحي (نموذج تجريبي)", [
        ["<h1>دليلُ تَرخيصِ مرافقِ الإيواءِ السياحيّ</h1>",
         "<p>يُقصد بمرفق الإيواء السياحي كل منشأة تقدم خدمة المبيت للسائحين، وتشمل الفنادق والشقق الفندقية والنُّزُل والمخيمات السياحية.</p>",
         "<p>يهدف هذا الدليل إلى بيان إجراءات الحصول على ترخيص مرفق الإيواء السياحي وشروطه ومدته وكيفية تجديده.</p>",
         "<p>تُطبَّق أحكام هذا الدليل على جميع المنشآت التي تستقبل الزوار داخل المملكة.</p>"],
        ["<h1>الاشـتراطات الأسـاسية للترخـيص</h1>",
         "<p>يشترط للحصول على الترخيص ما يلي: سجل تجاري ساري المفعول، وشهادة سلامة صادرة من الدفاع المدني، وعقد ملكية أو إيجار لا تقل مدته عن خمس سنوات، ومخطط معماري معتمد.</p>",
         "<p>مدة صلاحية الترخيص ثلاث سنوات من تاريخ الإصدار، وهي قابلة للتجديد.</p>",
         "<p>يجب أن يتوافر في المرفق مدخل مخصص للأشخاص ذوي الإعاقة.</p>"],
        ["<h1>الرسوم والتجديد</h1>",
         "<p>رسوم إصدار ترخيص مرفق الإيواء ٢٠٠٠ ريال، ورسوم التجديد ١٠٠٠ ريال.</p>",
         "<p>يُقدَّم طلب التجديد قبل انتهاء الترخيص بتسعين يومًا على الأقل عبر المنصة الإلكترونية.</p>",
         "<p>يجوز للجهة المختصة إلغاء الترخيص عند تكرار المخالفات الجسيمة ثلاث مرات خلال سنة واحدة.</p>"],
    ]),
    "دليل_ترخيص_المرشد_السياحي.pdf": ("دليل ترخيص المرشد السياحي (نموذج تجريبي)", [
        ["<h1>تعريف المرشد السياحي وشروط الترخيص</h1>",
         "<p>المرشد السياحي هو الشخص المرخص له بمرافقة السائحين وتقديم المعلومات عن المواقع السياحية والتراثية.</p>",
         "<p>يشترط في طالب الترخيص ألا يقل عمره عن 21 سنة، وأن يحمل شهادة الثانوية العامة على الأقل، وأن يجتاز دورة التأهيل المعتمدة ومدتها 40 ساعة تدريبية.</p>"],
        ["<h1>مدة الرخصة ورسومها</h1>",
         "<p>مدة صلاحية رخصة المرشد السياحي سنتان من تاريخ الإصدار.</p>",
         "<p>رسوم إصدار الرخصة 500 ريال.</p>",
         "<p>يلتزم المرشد بوضع بطاقة التعريف الرسمية في مكان ظاهر أثناء الجولة.</p>"],
        ["<h1>التزامات المرشد</h1>",
         "<p>يُحظر على المرشد السياحي اصطحاب أكثر من ثلاثين سائحًا في المجموعة الواحدة داخل المواقع الأثرية.</p>",
         "<p>يجب على المرشد إبلاغ الجهة المختصة عن أي حادث يقع أثناء الجولة خلال أربع وعشرين ساعة.</p>"],
    ]),
    "الأسئلة_الشائعة_للزائرين.pdf": ("الأسئلة الشائعة للزائرين (نموذج تجريبي)", [
        ["<h1>التأشيرة السياحية</h1>",
         "<p>هل يمكن للزائر الحصول على تأشيرة سياحية إلكترونية؟ نعم، تُصدر التأشيرة السياحية الإلكترونية عبر المنصة الرسمية خلال دقائق لمواطني الدول المؤهلة.</p>",
         "<p>كم مدة الإقامة بالتأشيرة السياحية؟ تتيح التأشيرة السياحية الإلكترونية الإقامة ثلاثة أشهر (٩٠ يومًا) في كل زيارة.</p>"],
        ["<h1>التأمين والصحة</h1>",
         "<p>هل يجب أن يكون لدى الزائر تأمين صحي؟ نعم، يُشترط وجود تأمين صحي يغطي حالات الطوارئ طوال مدة الإقامة.</p>",
         "<p>هل يمكن اصطحاب الأطفال؟ نعم، ويُرحَّب بالعائلات في جميع المرافق السياحية.</p>"],
    ]),
    "لائحة_زيارة_المواقع_التراثية.pdf": ("لائحة زيارة المواقع التراثية (نموذج تجريبي)", [
        ["<h1>شروط الدخول</h1>",
         "<p>لا تجوز زيارة المواقع التراثية دون تذكرة دخول مسبقة.</p>",
         "<p>رسوم الدخول ٢٥ ريالًا للبالغ، ومجانًا لمن هم دون ١٢ سنة.</p>"],
        ["<h1>السلوك داخل الموقع</h1>",
         "<p>يُحظر لمس النقوش الصخرية أو الكتابة عليها.</p>",
         "<p>يُحظر استخدام الطائرات المسيّرة في المواقع التراثية إلا بتصريح مسبق من الجهة المختصة.</p>"],
        ["<h1>التصوير التجاري</h1>",
         "<p>يخضع التصوير التجاري داخل المواقع التراثية لتصريح خاص، ورسوم التصوير التجاري ١٥٠٠ ريال عن اليوم الواحد.</p>",
         "<p>لا تتطلب الصور الشخصية للزوار أي تصريح.</p>"],
    ]),
}


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    archive = fitz.Archive(str(FONT_DIR))
    for fname, (title, pages) in DOCS.items():
        doc = fitz.open()
        for i, blocks in enumerate(pages, start=1):
            page = doc.new_page(width=595, height=842)
            page.insert_htmlbox(fitz.Rect(40, 20, 555, 50), f'<div class="small">{DISCLAIMER}</div>', css=CSS, archive=archive)
            page.insert_htmlbox(fitz.Rect(40, 70, 555, 780), "".join(blocks), css=CSS, archive=archive)
            page.insert_htmlbox(fitz.Rect(40, 800, 555, 830), f'<div class="small">{DISCLAIMER} — صفحة {i}</div>', css=CSS, archive=archive)
        doc.set_metadata({"title": title})
        doc.subset_fonts()                                  # embed only the glyphs used: about 90 KB per file instead of 8 to 13 MB
        doc.save(OUT / fname, garbage=4, deflate=True)
        print("wrote", OUT / fname)


if __name__ == "__main__":
    main()
