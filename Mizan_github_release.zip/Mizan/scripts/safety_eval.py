"""Measure the model-free safeguards in src/safety.py on a larger, labelled set. No model, no GPU.

    python scripts/safety_eval.py                  # attacks, benign text, personal data, and every chunk of the local corpora
    python scripts/safety_eval.py --no-corpus      # skip the corpus scan
    python scripts/safety_eval.py --out results/safety-eval-before

Data (eval/safety/, one JSON object per line, hashes recorded in every output):
  attacks.jsonl  128 texts. `in_scope` = a literal Arabic or English attack, or a cosmetic disguise of one: what the scan claims to
                 catch. Out of scope = paraphrase, other languages, encoded or homoglyph text, splitting, goal hijacking, data
                 exfiltration: known limits of a pattern scan, listed here so the numbers cannot be read as a general defence.
  benign.jsonl   60 ordinary regulation-style sentences that contain trigger words in a legitimate use ("tour guides must not ignore
                 the safety rules"). Their true label is "not an attack"; a flag is a false positive.
  pii.jsonl      56 texts: positives with a category, negatives that only look like personal data, and out-of-scope positives
                 (bare ID numbers, cards, passports) that the scan does not claim to find.

Protocol: every file has a `dev` and a `heldout` half. Only `dev` may guide changes to src/safety.py. `heldout` was written first and run
once on the unchanged scan ("before"); any later run on `heldout` is reported next to that and is no longer untouched. Both halves were
written by the same author who knows the patterns, so the held-out half is a check, not an independent red team.

Intervals are Wilson 95% intervals for a proportion. A catch rate on an in-scope set says how often the scan catches attacks of THAT
kind; it says nothing about what a model does with text that passes (untested; see docs/RESPONSIBLE_AI.md).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src import config, safety  # noqa: E402

DATA = ROOT / "eval" / "safety"
_INVISIBLE = re.compile("[\u00ad\u200b-\u200f\u202a-\u202e\u2060-\u2069\ufeff\u00a0]")


def wilson(k: int, n: int, z: float = 1.96) -> tuple[float, float]:
    if n == 0:
        return (0.0, 0.0)
    p = k / n
    d = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / d
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return max(0.0, centre - half), min(1.0, centre + half)


def rate(k: int, n: int) -> str:
    lo, hi = wilson(k, n)
    return f"{k}/{n} = {k / n:.3f} [{lo:.3f}, {hi:.3f}]" if n else "0/0"


def show(text: str, limit: int = 70) -> str:
    """Printable form: invisible characters become \\uXXXX so a disguised text can be read."""
    t = _INVISIBLE.sub(lambda m: "\\u%04x" % ord(m.group()), text).replace("\n", "\\n")
    return (t[:limit] + "…") if len(t) > limit else t


def load(name: str) -> list[dict]:
    return [json.loads(line) for line in (DATA / f"{name}.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def eval_attacks(rows: list[dict]) -> dict:
    out = {"cells": {}, "categories": {}, "missed_in_scope": [], "caught_out_of_scope": []}
    for r in rows:
        hits = safety.scan_injection(r["text"])
        key = (r["set"], "in_scope" if r["in_scope"] else "out_of_scope")
        c = out["cells"].setdefault(key, [0, 0])
        c[1] += 1
        c[0] += bool(hits)
        cat = out["categories"].setdefault((r["set"], r["in_scope"], r["category"]), [0, 0])
        cat[1] += 1
        cat[0] += bool(hits)
        if r["in_scope"] and not hits:
            out["missed_in_scope"].append(r)
        if not r["in_scope"] and hits:
            out["caught_out_of_scope"].append((r, hits))
    return out


def eval_benign(rows: list[dict]) -> dict:
    out = {"cells": {}, "flagged": []}
    for r in rows:
        hits = safety.scan_injection(r["text"])
        c = out["cells"].setdefault(r["set"], [0, 0])
        c[1] += 1
        c[0] += bool(hits)
        if hits:
            out["flagged"].append((r, hits))
    return out


def eval_pii(rows: list[dict]) -> dict:
    out = {"recall": defaultdict(lambda: [0, 0]), "recall_by_set": defaultdict(lambda: [0, 0]), "missed": [], "false_pos": [],
           "neg": defaultdict(lambda: [0, 0]), "gaps_found": [], "gaps_missed": [], "tp": 0}
    for r in rows:
        found = safety.scan_pii(r["text"])
        if r["label"] == "pos" and r["in_scope"]:
            ok = r["category"] in found
            out["recall"][r["category"]][1] += 1
            out["recall"][r["category"]][0] += ok
            out["recall_by_set"][r["set"]][1] += 1
            out["recall_by_set"][r["set"]][0] += ok
            out["tp"] += ok
            if not ok:
                out["missed"].append(r)
        elif r["label"] == "neg":
            out["neg"][r["set"]][1] += 1
            out["neg"][r["set"]][0] += bool(found)
            if found:
                out["false_pos"].append((r, found))
        else:                                   # out-of-scope positive: the scan does not claim these
            (out["gaps_found"] if found else out["gaps_missed"]).append(r)
    return out


def scan_corpora() -> dict:
    from src.chunking import chunk_pages
    from src.corpus import corpus_fingerprint, load_corpus
    from src.preprocessing import get_config, preprocess_pages

    res = {}
    for kind, d in (("pdf", config.RAW_DIR), ("web", config.WEB_DIR)):
        if not d.exists() or not any(d.iterdir()):
            res[kind] = None
            continue
        pages = load_corpus(d, kind)
        per = {}
        for name in ("baseline", "mizan-lite+repair_lam_alef"):
            chunks = chunk_pages(preprocess_pages(pages, get_config(name)), config.SETTINGS.chunk_size, config.SETTINGS.chunk_overlap)
            flagged = [(c.doc, c.page, safety.scan_injection(c.text)) for c in chunks if safety.scan_injection(c.text)]
            pii = sum(1 for c in chunks if safety.scan_pii(c.text))
            per[name] = {"chunks": len(chunks), "flagged": flagged, "chunks_with_pii_pattern": pii}
        res[kind] = {"fingerprint": corpus_fingerprint(d, kind), "pipelines": per}
    return res


def render(att, ben, pii, corp, hashes) -> str:
    L = ["# Safety evaluation (model-free safeguards)", "",
         f"Generated {datetime.now():%Y-%m-%d %H:%M} by `scripts/safety_eval.py`. Wilson 95% intervals. Data and code versions:", ""]
    L += [f"- `{k}` sha256 `{v[:16]}…`" for k, v in hashes.items()] + [""]
    L += ["## 1. Injection scan on attacks", "", "| set | in scope (the scan's claim) | out of scope (known limits) |", "|---|---|---|"]
    for s in ("dev", "heldout"):
        a, b = att["cells"].get((s, "in_scope"), [0, 0]), att["cells"].get((s, "out_of_scope"), [0, 0])
        L.append(f"| {s} | **{rate(*a)}** | {rate(*b)} |")
    L += ["", "Catch rate by category (in scope):", "", "| category | dev | held-out |", "|---|---|---|"]
    cats = sorted({k[2] for k in att["categories"] if k[1]})
    for c in cats:
        d = att["categories"].get(("dev", True, c), [0, 0]); h = att["categories"].get(("heldout", True, c), [0, 0])
        L.append(f"| {c} | {d[0]}/{d[1]} | {h[0]}/{h[1]} |")
    L += ["", "Out-of-scope categories (expected to be missed unless noted):", "", "| category | dev | held-out |", "|---|---|---|"]
    ocats = sorted({k[2] for k in att["categories"] if not k[1]})
    for c in ocats:
        d = att["categories"].get(("dev", False, c), [0, 0]); h = att["categories"].get(("heldout", False, c), [0, 0])
        L.append(f"| {c} | {d[0]}/{d[1]} | {h[0]}/{h[1]} |")
    L += ["", f"In-scope attacks that were MISSED ({len(att['missed_in_scope'])}):", ""]
    L += [f"- `{r['id']}` ({r['set']}, {r['category']}): `{show(r['text'])}`" for r in att["missed_in_scope"]] or ["- none"]
    if att["caught_out_of_scope"]:
        L += ["", "Out-of-scope attacks that were caught anyway: " + ", ".join(f"`{r['id']}`" for r, _ in att["caught_out_of_scope"])]
    L += ["", "## 2. False positives on benign regulation-style text", "", "| set | flagged | rate |", "|---|---|---|"]
    for s in ("dev", "heldout"):
        k, n = ben["cells"].get(s, [0, 0])
        L.append(f"| {s} | {k}/{n} | {rate(k, n)} |")
    L += ["", f"Flagged benign sentences ({len(ben['flagged'])}):", ""]
    L += [f"- `{r['id']}` ({r['set']}): `{show(r['text'], 90)}` -> {', '.join(h)}" for r, h in ben["flagged"]] or ["- none"]
    L += ["", "## 3. False positives on the real corpora (every chunk)", ""]
    if corp is None:
        L.append("Skipped (`--no-corpus`).")
    else:
        L += ["| corpus | pipeline text | chunks | flagged | rate |", "|---|---|---|---|---|"]
        for kind, v in corp.items():
            if v is None:
                L.append(f"| {kind} | not on this machine | | | |")
                continue
            for name, p in v["pipelines"].items():
                L.append(f"| {kind} (`{v['fingerprint'][:12]}…`) | `{name}` | {p['chunks']} | {len(p['flagged'])} | {rate(len(p['flagged']), p['chunks'])} |")
        fl = [(k, name, f) for k, v in corp.items() if v for name, p in v["pipelines"].items() for f in p["flagged"]]
        if fl:
            L += ["", "Flagged chunks: " + "; ".join(f"{k}/{n}: {d} p.{pg} {h}" for k, n, (d, pg, h) in fl[:12])]
    L += ["", "## 4. Personal-data scan", "", "| category (in scope) | detected | recall |", "|---|---|---|"]
    for c, (k, n) in sorted(pii["recall"].items()):
        L.append(f"| {c} | {k}/{n} | {rate(k, n)} |")
    for s in ("dev", "heldout"):
        k, n = pii["recall_by_set"].get(s, [0, 0])
        L.append(f"| all, {s} | {k}/{n} | {rate(k, n)} |")
    nk = sum(v[0] for v in pii["neg"].values()); nn = sum(v[1] for v in pii["neg"].values())
    tp = pii["tp"]
    prec = f"{tp}/{tp + nk} = {tp / (tp + nk):.3f}" if tp + nk else "n/a"
    L += ["", f"Negatives (look-alikes) flagged: {rate(nk, nn)}; precision over in-scope detections: {prec}.", "",
          f"Missed in-scope positives ({len(pii['missed'])}):", ""]
    L += [f"- `{r['id']}` ({r['set']}, {r['category']}): `{show(r['text'])}`" for r in pii["missed"]] or ["- none"]
    L += ["", f"False alarms ({len(pii['false_pos'])}):", ""]
    L += [f"- `{r['id']}` ({r['set']}): `{show(r['text'])}` -> {f}" for r, f in pii["false_pos"]] or ["- none"]
    L += ["", f"Out-of-scope identifiers (bare ID numbers, cards, passports): found {len(pii['gaps_found'])} of {len(pii['gaps_found']) + len(pii['gaps_missed'])}. "
          "The scan does not claim these."]
    L += [""]
    return "\n".join(L)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--out", default=None)
    ap.add_argument("--no-corpus", action="store_true")
    args = ap.parse_args()
    att, ben, pii = eval_attacks(load("attacks")), eval_benign(load("benign")), eval_pii(load("pii"))
    corp = None if args.no_corpus else scan_corpora()
    hashes = {f"eval/safety/{n}.jsonl": sha(DATA / f"{n}.jsonl") for n in ("attacks", "benign", "pii")}
    hashes["src/safety.py"] = sha(ROOT / "src" / "safety.py")
    md = render(att, ben, pii, corp, hashes)
    stem = Path(args.out) if args.out else config.RESULTS_DIR / f"safety-eval-{datetime.now():%Y%m%d-%H%M%S}"
    stem.parent.mkdir(parents=True, exist_ok=True)
    stem.with_suffix(".md").write_text(md, encoding="utf-8")
    summary = {"hashes": hashes,
               "attacks": {f"{s}/{k}": v for (s, k), v in att["cells"].items()},
               "missed_in_scope": [r["id"] for r in att["missed_in_scope"]],
               "benign_flagged": [r["id"] for r, _ in ben["flagged"]],
               "benign": {s: v for s, v in ben["cells"].items()},
               "pii_recall": {c: v for c, v in pii["recall"].items()}, "pii_recall_by_set": dict(pii["recall_by_set"]),
               "pii_missed": [r["id"] for r in pii["missed"]], "pii_false_alarms": [r["id"] for r, _ in pii["false_pos"]],
               "corpus": None if corp is None else {k: (None if v is None else {"fingerprint": v["fingerprint"], **{n: {"chunks": p["chunks"], "flagged": len(p["flagged"])} for n, p in v["pipelines"].items()}}) for k, v in corp.items()}}
    stem.with_suffix(".json").write_text(json.dumps(summary, ensure_ascii=False, indent=1), encoding="utf-8")
    print(md)
    print(f"\nwrote {stem.with_suffix('.md')} and {stem.with_suffix('.json')}")


if __name__ == "__main__":
    main()
