"""Verify that every gold phrase in the active questions file really occurs in the active corpus
(restricted to gold_docs when given) and print the pages where it occurs. Run after editing questions.

    python scripts/check_gold.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.config import resolve_data_dir, resolve_questions_path
from src.evaluation import load_questions
from src.ingestion import load_pdfs
from src.preprocessing import canonical_for_eval


def check() -> list[str]:
    data_dir, _ = resolve_data_dir()
    pages = load_pdfs(data_dir)
    canon = [(p, canonical_for_eval(p.text)) for p in pages]
    problems = []
    for q in load_questions(resolve_questions_path()[0]):
        docs = q.get("gold_docs")
        for group in q.get("gold_evidence", []):
            hits = [(p.doc, p.page) for p, c in canon if (not docs or p.doc in docs)
                    and any(canonical_for_eval(ph) in c for ph in group)]
            print(f"{q['id']:<4} {group[0][:40]:<42} -> {hits[:6]}")
            if not hits:
                problems.append(f"{q['id']}: no match for {group}")
    return problems


if __name__ == "__main__":
    bad = check()
    print("\nPROBLEMS:\n" + "\n".join(bad) if bad else "\nall gold phrases found")
