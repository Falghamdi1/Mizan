"""Blind test set: collect, check, freeze and verify the questions the three of us write BEFORE seeing any system output.

Why: the brief says "keep a test set that is never used for training or for choosing settings". Every other question set in this
project has been used to choose something (see FINAL_AUDIT.md, section 5). This set is written by hand, checked only against
the DOCUMENT TEXT (never against retrieval results), frozen with a hash, and used once for the final comparison.

Workflow (details and rules: eval/blind_test/README.md)
    python scripts/make_blind_test.py --init NAME            # eval/blind_test/NAME.csv from the template
    python scripts/make_blind_test.py --dump-corpus web      # readable text of the web corpus, to write questions from
    python scripts/make_blind_test.py --check eval/blind_test/NAME.csv   # fix typos in phrases; progress against the quotas
    python scripts/make_blind_test.py --build                # merge every contributor file, check, freeze, write the question files
    python scripts/make_blind_test.py --verify               # before the final run: the frozen files are unchanged
    python scripts/make_blind_test.py --build --skip-quota   # freeze although author quotas are unmet (a logged deviation; row checks still apply)

The check never runs an embedder, a reranker or an LLM, so it cannot tell you which pipeline will find a question. It only tells you
whether your evidence phrase really occurs in the text of the document you named, in every arm that will be evaluated
(baseline, mizan, mizan-lite: a phrase that exists only in one arm's cleaned text would favour that arm).

Outputs: eval/questions_final_test_pdf.json (evaluate with MIZAN_CORPUS=pdf), eval/questions_final_test_web.json (MIZAN_CORPUS=web),
eval/blind_test/FROZEN.json (hashes, counts, corpus fingerprints). A frozen set is not overwritten without --force.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

BLIND_DIR = ROOT / "eval" / "blind_test"
OUT = {"pdf": ROOT / "eval" / "questions_final_test_pdf.json", "web": ROOT / "eval" / "questions_final_test_web.json"}
FROZEN = BLIND_DIR / "FROZEN.json"
COLUMNS = ["author", "corpus", "question", "answerable", "source_doc", "source_page", "evidence_phrase", "alt_phrase",
           "answer_keywords", "reference_answer", "type", "notes"]
TYPES = ["direct", "number", "duration", "fee", "condition", "list", "procedure", "paraphrase", "unanswerable"]
NUMERIC_TYPES = {"number", "duration", "fee"}
ARMS = ("baseline", "mizan+repair_lam_alef", "mizan-lite+repair_lam_alef")
MAX_DOCS = 4                         # a phrase found in more documents than this is too generic to be gold
MIN_PHRASE_WORDS = 3
QUOTA = {"per_author_min": 15, "per_author_max": 25, "pdf_answerable": 5, "web_answerable": 5, "unanswerable": 2, "numeric": 3, "total_min": 45}
SKIP_FILES = {"template.csv", "examples.csv"}


# ---------------------------------------------------------------------------------------------------------------
# Reading and parsing
# ---------------------------------------------------------------------------------------------------------------
def read_csv(path: Path) -> list[dict]:
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    return [{k: (v or "").strip() for k, v in r.items() if k} for r in rows if any((v or "").strip() for v in r.values())]


def parse_keywords(text: str) -> list:
    """'3|ثلاث;سنوات' -> [["3", "ثلاث"], "سنوات"]: ';' separates required keywords, '|' separates acceptable alternatives."""
    out = []
    for part in [p.strip() for p in text.split(";") if p.strip()]:
        alts = [a.strip() for a in part.split("|") if a.strip()]
        out.append(alts if len(alts) > 1 else alts[0])
    return out


def canon(text: str) -> str:
    from src.preprocessing import canonical_for_eval
    return canonical_for_eval(text)


def arabic_share(text: str) -> float:
    letters = [c for c in text if c.isalpha()]
    return (sum("؀" <= c <= "ۿ" for c in letters) / len(letters)) if letters else 0.0


def dev_questions() -> list[dict]:
    """Every development question set that exists on this machine: a blind question must not repeat any of them."""
    out = []
    for p in [ROOT / "eval" / "questions.json", ROOT / "eval" / "questions_large.json",
              ROOT / "data" / "web" / "questions_faq.json", ROOT / "data" / "web" / "questions_pdf.json"]:
        if p.exists():
            out += [{"id": q["id"], "question": q["question"], "set": p.name,
                     "phrases": [canon(ph) for g in q.get("gold_evidence") or [] for ph in g]} for q in json.loads(p.read_text(encoding="utf-8"))]
    return out


# ---------------------------------------------------------------------------------------------------------------
# The document text each arm will index (no embeddings, no retrieval)
# ---------------------------------------------------------------------------------------------------------------
class Index:
    """chunks[corpus][arm] = list of (doc, page, canonical chunk text); docs[corpus] = set of document ids."""

    def __init__(self, corpora=("pdf", "web")):
        from src import config
        from src.chunking import chunk_pages
        from src.corpus import load_corpus
        from src.preprocessing import get_config, preprocess_pages

        self.chunks, self.docs = {}, {}
        for corpus in corpora:
            d = config.RAW_DIR if corpus == "pdf" else config.WEB_DIR
            if corpus == "pdf" and not any(config.RAW_DIR.glob("*.pdf")):
                continue
            if corpus == "web" and not any(config.WEB_DIR.glob("*")):
                continue
            pages = load_corpus(d, kind=corpus)
            self.docs[corpus] = sorted({p.doc for p in pages})
            self.chunks[corpus] = {
                arm: [(c.doc, c.page, canon(c.text)) for c in chunk_pages(preprocess_pages(pages, get_config(arm)),
                                                                          config.SETTINGS.chunk_size, config.SETTINGS.chunk_overlap)]
                for arm in ARMS}

    def resolve_doc(self, corpus: str, name: str) -> tuple[str | None, str]:
        """Exact id, else a unique case-insensitive substring. Returns (doc or None, message)."""
        docs = self.docs.get(corpus, [])
        if name in docs:
            return name, ""
        hits = [d for d in docs if name.lower() in d.lower()]
        if len(hits) == 1:
            return hits[0], ""
        return None, (f"source_doc {name!r} matches {len(hits)} documents ({', '.join(hits[:4])})" if hits
                      else f"source_doc {name!r} is not a document of the {corpus} corpus (use --dump-corpus {corpus} to list them)")

    def phrase_report(self, corpus: str, doc: str, phrase: str, page: int | None) -> dict:
        ph = canon(phrase)
        per_arm, pages_found, any_doc = {}, set(), set()
        for arm, chunks in self.chunks[corpus].items():
            in_doc = [(d, p) for d, p, t in chunks if ph in t and d == doc]
            per_arm[arm] = bool(in_doc)
            if arm == ARMS[0]:
                pages_found = {p for _, p in in_doc}
            any_doc |= {d for d, p, t in chunks if ph in t}
        text_of_doc = " ".join(t for d, _, t in self.chunks[corpus][ARMS[0]] if d == doc)
        return {"per_arm": per_arm, "pages": sorted(pages_found), "docs_with_phrase": sorted(any_doc), "in_doc_text": ph in text_of_doc,
                "page_ok": (page in pages_found) if page else None}


# ---------------------------------------------------------------------------------------------------------------
# Row checks
# ---------------------------------------------------------------------------------------------------------------
def check_rows(rows: list[dict], index: Index, source: str) -> tuple[list[dict], list[str], list[str]]:
    """Returns (valid question dicts, errors, warnings). A row with any error is not returned."""
    dev_all = dev_questions()
    dev = [(canon(q["question"]), q) for q in dev_all]
    dev_words = [(set(c.split()), q) for c, q in dev]
    questions, errors, warnings, seen = [], [], [], {}
    for i, r in enumerate(rows, start=2):                         # line 1 is the header
        tag = f"{source} line {i}"
        errs, warns = [], []
        missing = [c for c in COLUMNS if c not in r]
        if missing:
            errors.append(f"{tag}: missing column(s) {missing}")
            continue
        corpus, answerable = r["corpus"].lower(), r["answerable"].lower()
        q = r["question"]
        if corpus not in ("pdf", "web"):
            errs.append("corpus must be pdf or web")
        elif corpus not in index.docs:
            errs.append(f"the {corpus} corpus is not on this machine (run the fetch script)")
        if answerable not in ("yes", "no"):
            errs.append("answerable must be yes or no")
        if r["type"] and r["type"] not in TYPES:
            errs.append(f"type must be one of {', '.join(TYPES)}")
        if len(q) < 10 or arabic_share(q) < 0.6:
            errs.append("the question must be a full Arabic sentence")
        cq = canon(q)
        if cq in seen:
            errs.append(f"same question as {seen[cq]}")
        seen[cq] = tag
        for c, dq in dev:
            if cq == c:
                errs.append(f"identical to the development question {dq['id']} ({dq['set']}): write your own")
                break
        else:
            words = set(cq.split())
            for w, dq in dev_words:
                if words and w and len(words & w) / len(words | w) >= 0.8:
                    warns.append(f"very similar to the development question {dq['id']} ({dq['set']})")
                    break
        gold, docs = [], []
        if answerable == "yes" and corpus in index.docs:
            phrase, alt = r["evidence_phrase"], r["alt_phrase"]
            if len(canon(phrase).split()) < MIN_PHRASE_WORDS:
                errs.append(f"evidence_phrase needs at least {MIN_PHRASE_WORDS} words")
            doc, why = index.resolve_doc(corpus, r["source_doc"]) if r["source_doc"] else (None, "source_doc is required for an answerable question")
            if why:
                errs.append(why)
            if doc and len(canon(phrase).split()) >= MIN_PHRASE_WORDS:
                page = int(r["source_page"]) if r["source_page"].isdigit() else None
                rep = index.phrase_report(corpus, doc, phrase, page)
                bad_arms = [a for a, ok in rep["per_arm"].items() if not ok]
                if bad_arms:
                    if rep["in_doc_text"] or any(rep["per_arm"].values()):
                        errs.append("the phrase is in the document but not inside one chunk of every arm "
                                    f"(missing in: {', '.join(bad_arms)}). Damaged extraction or a chunk boundary: choose another phrase "
                                    "of 3 to 8 words from the middle of the same sentence, avoiding words with lam-alef and kashida")
                    else:
                        errs.append(f"the phrase was not found in {doc}: check the spelling against the document text")
                elif len(rep["docs_with_phrase"]) > MAX_DOCS:
                    errs.append(f"the phrase occurs in {len(rep['docs_with_phrase'])} documents: too generic to identify the answer")
                else:
                    if r["source_page"] and rep["page_ok"] is False:
                        warns.append(f"the phrase is on page(s) {rep['pages']}, not on page {r['source_page']}")
                    shared = [dq for dq in dev_all if canon(phrase) in dq["phrases"]]
                    if shared:
                        warns.append(f"the evidence phrase is also the gold phrase of the development question {shared[0]['id']}: "
                                     "the same passage is not an independent test")
                    pw = set(canon(phrase).split())
                    if pw and len(pw & set(cq.split())) / len(pw) >= 0.8:
                        warns.append("the evidence phrase mostly repeats the question: the retriever gets the answer for free")
                    gold = [[phrase] + ([alt] if alt and canon(alt) in " ".join(t for d, _, t in index.chunks[corpus][ARMS[0]] if d == doc) else [])]
                    if alt and len(gold[0]) == 1:
                        warns.append("alt_phrase was not found in the document and is ignored")
                    docs = [doc]
            if not r["reference_answer"]:
                errs.append("reference_answer is required for an answerable question")
        elif answerable == "no":
            if r["evidence_phrase"] or r["source_doc"]:
                errs.append("an unanswerable question has no source_doc or evidence_phrase")
            if r["type"] and r["type"] != "unanswerable":
                errs.append("type must be unanswerable (or empty) when answerable is no")
        try:
            kws = parse_keywords(r["answer_keywords"])
        except Exception:  # noqa: BLE001
            kws = []
            errs.append("answer_keywords could not be read")
        if answerable == "yes" and not kws:
            warns.append("no answer_keywords: keyword coverage cannot be scored for this question")
        for e in errs:
            errors.append(f"{tag}: {e}")
        for w in warns:
            warnings.append(f"{tag}: {w}")
        if errs:
            continue
        questions.append({"corpus": corpus, "author": r["author"], "type": r["type"] or ("unanswerable" if answerable == "no" else "direct"),
                          "question": q, "gold_evidence": gold, "gold_docs": docs, "answer_keywords": kws,
                          "reference_answer": r["reference_answer"] or "غير مذكور في الوثائق.", "needs_review": False})
    return questions, errors, warnings


def progress(questions: list[dict]) -> dict:
    by_author: dict[str, list[dict]] = {}
    for q in questions:
        by_author.setdefault(q["author"], []).append(q)
    out = {}
    for a, qs in by_author.items():
        out[a] = {"valid": len(qs), "pdf_answerable": sum(q["corpus"] == "pdf" and bool(q["gold_evidence"]) for q in qs),
                  "web_answerable": sum(q["corpus"] == "web" and bool(q["gold_evidence"]) for q in qs),
                  "unanswerable": sum(not q["gold_evidence"] for q in qs), "numeric": sum(q["type"] in NUMERIC_TYPES for q in qs)}
    return out


def quota_problems(questions: list[dict]) -> list[str]:
    probs = []
    for a, p in progress(questions).items():
        if p["valid"] < QUOTA["per_author_min"]:
            probs.append(f"{a}: {p['valid']} valid questions, need at least {QUOTA['per_author_min']}")
        if p["valid"] > QUOTA["per_author_max"]:
            probs.append(f"{a}: {p['valid']} questions, more than {QUOTA['per_author_max']}: the set would be dominated by one author")
        for key, label in (("pdf_answerable", "answerable PDF"), ("web_answerable", "answerable web"), ("unanswerable", "unanswerable"), ("numeric", "number/duration/fee")):
            if p[key] < QUOTA[key]:
                probs.append(f"{a}: {p[key]} {label} question(s), need at least {QUOTA[key]}")
    if len(progress(questions)) < 3:
        probs.append(f"questions from {len(progress(questions))} author(s); the plan is three")
    if len(questions) < QUOTA["total_min"]:
        probs.append(f"{len(questions)} questions in total, need at least {QUOTA['total_min']}")
    return probs


# ---------------------------------------------------------------------------------------------------------------
# Freeze / verify
# ---------------------------------------------------------------------------------------------------------------
def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def freeze(questions: list[dict], force: bool = False, quota_skipped: list[str] | None = None) -> dict:
    if FROZEN.exists() and not force:
        raise SystemExit(f"{FROZEN} exists: the blind set is already frozen. Re-building would spend it. Use --force only if you will "
                         "write a new set (and say so in docs/EXPERIMENT_LOG.md).")
    from src import config
    from src.corpus import corpus_fingerprint
    questions = sorted(questions, key=lambda q: (q["corpus"], q["author"], q["question"]))
    files = {}
    for corpus, path in OUT.items():
        qs = [dict(q, id=f"blind-{corpus}-{n:03d}") for n, q in enumerate([q for q in questions if q["corpus"] == corpus], start=1)]
        path.write_text(json.dumps([{k: v for k, v in q.items() if k != "corpus"} for q in qs], ensure_ascii=False, indent=1), encoding="utf-8")
        files[path.name] = {"sha256": sha(path), "questions": len(qs), "answerable": sum(bool(q["gold_evidence"]) for q in qs)}
    meta = {"created": datetime.now().isoformat(timespec="seconds"), "files": files, "progress": progress(questions),
            "arms_checked": list(ARMS), "corpus_fingerprints": {
                "pdf": corpus_fingerprint(config.RAW_DIR, kind="pdf"), "web": corpus_fingerprint(config.WEB_DIR, kind="web")},
            "contributor_files": {p.name: sha(p) for p in sorted(BLIND_DIR.glob("*.csv")) if p.name not in SKIP_FILES},
            "rule": "Used once, for the final comparison. Never used to choose a prompt, preset, candidate count or adapter."}
    if quota_skipped:
        meta["quota_skipped"] = quota_skipped      # deviation from docs/ANALYSIS_PLAN.md section 2, explained in docs/EXPERIMENT_LOG.md
    FROZEN.write_text(json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
    return meta


def verify() -> list[str]:
    if not FROZEN.exists():
        return ["not frozen yet: run --build"]
    meta = json.loads(FROZEN.read_text(encoding="utf-8"))
    probs = []
    for name, info in meta["files"].items():
        p = ROOT / "eval" / name
        if not p.exists():
            probs.append(f"{name} is missing")
        elif sha(p) != info["sha256"]:
            probs.append(f"{name} has changed since it was frozen")
    return probs


# ---------------------------------------------------------------------------------------------------------------
# Helpers for the authors
# ---------------------------------------------------------------------------------------------------------------
def dump_corpus(kind: str) -> Path:
    from src import config
    from src.corpus import load_corpus
    pages = load_corpus(config.RAW_DIR if kind == "pdf" else config.WEB_DIR, kind=kind)
    path = ROOT / "data" / ("processed" if kind == "pdf" else "web") / f"corpus_readable_{kind}.txt"
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write("# Readable text of the corpus. Each block starts with: DOC | page. Copy evidence phrases from here (web) or from the\n"
                "# PDF itself (pdf: the extracted text below is damaged: letters swapped, kashida; read the PDF page and type the phrase).\n\n")
        for p in pages:
            f.write(f"===== {p.doc} | page {p.page} =====\n{p.text}\n\n")
    return path


def init_file(name: str) -> Path:
    path = BLIND_DIR / f"{re.sub(r'[^A-Za-z0-9_-]+', '_', name)}.csv"
    if path.exists():
        raise SystemExit(f"{path} already exists")
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        csv.writer(f).writerow(COLUMNS)
    return path


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--init", metavar="NAME")
    g.add_argument("--dump-corpus", choices=["pdf", "web"])
    g.add_argument("--check", nargs="+", metavar="CSV")
    g.add_argument("--build", action="store_true")
    g.add_argument("--verify", action="store_true")
    ap.add_argument("--force", action="store_true", help="re-freeze an already frozen set (spends it)")
    ap.add_argument("--skip-quota", action="store_true", help="with --build: freeze although author quotas are unmet (every row check still "
                    "applies; the unmet quotas are written into FROZEN.json and must be logged as a deviation)")
    a = ap.parse_args()
    if a.init:
        print("created", init_file(a.init))
        return 0
    if a.dump_corpus:
        print("wrote", dump_corpus(a.dump_corpus))
        return 0
    if a.verify:
        probs = verify()
        print("\n".join(probs) if probs else "frozen blind set is unchanged")
        return 1 if probs else 0
    files = [Path(p) for p in a.check] if a.check else [p for p in sorted(BLIND_DIR.glob("*.csv")) if p.name not in SKIP_FILES]
    if not files:
        print("no contributor files in eval/blind_test/ (use --init NAME)")
        return 1
    index = Index()
    all_q, all_err = [], []
    for f in files:
        qs, errs, warns = check_rows(read_csv(f), index, f.name)
        all_q += qs
        all_err += errs
        print(f"\n{f.name}: {len(qs)} valid of {len(read_csv(f))} rows")
        for w in warns:
            print("  warning:", w)
        for e in errs:
            print("  ERROR:", e)
    print("\nprogress per author (valid questions):")
    for author, p in progress(all_q).items():
        print(f"  {author}: {p}")
    print("quota:", QUOTA)
    probs = quota_problems(all_q)
    if a.build:
        blocking = all_err + ([] if a.skip_quota else probs)
        if blocking:
            print("\nNOT BUILT:", *blocking, sep="\n  ")
            return 1
        if probs:
            print("\nQUOTAS NOT MET (--skip-quota; recorded in FROZEN.json, log the deviation):", *probs, sep="\n  ")
        meta = freeze(all_q, force=a.force, quota_skipped=probs if a.skip_quota else None)
        print("\nFROZEN:", json.dumps(meta["files"], ensure_ascii=False))
        print("Do not edit the files. Run --verify before the final evaluation.")
        return 0
    if probs:
        print("\nstill to do:", *probs, sep="\n  ")
    return 1 if all_err else 0


if __name__ == "__main__":
    sys.exit(main())
