"""Apply the prompt decision rule of docs/ANALYSIS_PLAN.md section 5 mechanically, on DEVELOPMENT data (never the blind set).

    python scripts/decide_prompt.py --prompts results/prompts-20261010-160638.json \\
        --grading results/grading_prompts/human_grading_report.json --accept-cost

Inputs: the result file of `scripts/compare_prompts.py` (citations, refusals, tokens, latency per version) and the report written by
`scripts/human_grading.py merge` on the blind prompt sheet (two human graders, versions as arms). Rule, fixed before the blind run:

  switch the default from the baseline version to the candidate if and only if
    (a) citations naming a retrieved page, candidate, are at least 0.90;
    (b) human-graded correctness, candidate minus baseline, has a point estimate of at least -0.05;
    (c) the candidate refuses at most 2 more answerable questions than the baseline;
    (d) the cost (more input tokens, more latency) is accepted: pass --accept-cost to say so explicitly.
  Otherwise the baseline stays and its shortfall is stated as a limit. The decision is written to docs/PROMPT_DECISION.md; commit it
  before the blind run.

The interval printed for (a) is a Wilson interval over pooled citations; citations inside one answer are not independent, so it is optimistic.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

THRESH_CITATION, MARGIN_ACCURACY, MAX_EXTRA_REFUSALS = 0.90, -0.05, 2


def wilson(k: int, n: int, z: float = 1.96) -> tuple[float, float]:
    if n == 0:
        return (0.0, 0.0)
    p = k / n
    d = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / d
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return max(0.0, centre - half), min(1.0, centre + half)


def decide(prompts: dict, grading: dict, baseline: str, candidate: str, accept_cost: bool) -> dict:
    vs = prompts["versions"]
    for v in (baseline, candidate):
        if v not in vs:
            raise SystemExit(f"version {v!r} is not in the prompts result (has {list(vs)})")
    rows = {v: vs[v]["rows"] for v in (baseline, candidate)}
    agg = {v: vs[v]["aggregate"] for v in (baseline, candidate)}
    cited = {v: (sum(r["n_valid"] for r in rows[v]), sum(r["n_cited"] for r in rows[v])) for v in rows}
    refused = {v: sum(1 for r in rows[v] if r["answerable"] and r["refused"]) for v in rows}
    key = f"{candidate} - {baseline}: accuracy_answerable"
    paired = (grading.get("paired") or {}).get(key)
    out = {"baseline": baseline, "candidate": candidate, "criteria": {}}
    k, n = cited[candidate]
    lo, hi = wilson(k, n)
    out["criteria"]["a"] = {"text": f"citations naming a retrieved page, {candidate}, at least {THRESH_CITATION:.2f}", "value": (k / n) if n else None, "n_citations": n,
                            "wilson": [round(lo, 3), round(hi, 3)], "baseline_value": (cited[baseline][0] / cited[baseline][1]) if cited[baseline][1] else None,
                            "met": bool(n and k / n >= THRESH_CITATION)}
    out["criteria"]["b"] = {"text": f"human-graded correctness {candidate} minus {baseline}, point estimate at least {MARGIN_ACCURACY}",
                            "value": None if paired is None else paired["diff"], "interval": None if paired is None else [round(paired["lo"], 3), round(paired["hi"], 3)],
                            "n": None if paired is None else paired["n"], "met": bool(paired is not None and paired["diff"] >= MARGIN_ACCURACY)}
    out["criteria"]["c"] = {"text": f"{candidate} refuses at most {MAX_EXTRA_REFUSALS} more answerable questions than {baseline}", "baseline_refusals": refused[baseline],
                            "candidate_refusals": refused[candidate], "value": refused[candidate] - refused[baseline], "met": refused[candidate] - refused[baseline] <= MAX_EXTRA_REFUSALS}
    ti, tb = agg[candidate].get("mean_input_tokens"), agg[baseline].get("mean_input_tokens")
    li, lb = agg[candidate].get("median_llm_s"), agg[baseline].get("median_llm_s")
    out["criteria"]["d"] = {"text": "the cost is accepted (explicit --accept-cost)", "input_tokens": [tb, ti], "median_llm_s": [lb, li],
                            "input_token_change": None if not (ti and tb) else round(ti / tb - 1, 3), "met": bool(accept_cost)}
    missing = [c for c, v in out["criteria"].items() if c == "b" and v["value"] is None]
    out["complete"] = not missing
    out["switch"] = out["complete"] and all(v["met"] for v in out["criteria"].values())
    out["decision"] = candidate if out["switch"] else baseline
    out["incomplete_reason"] = "no human grading result for the paired accuracy: grade the prompt sheet first" if missing else None
    return out


def markdown(d: dict, prompts_name: str, grading_name: str) -> str:
    b, c = d["baseline"], d["candidate"]
    L = [f"# Prompt decision ({datetime.now():%Y-%m-%d})", "",
         f"Rule: `docs/ANALYSIS_PLAN.md` section 5, applied by `scripts/decide_prompt.py` to `{prompts_name}` (development questions) and `{grading_name}` (two human graders). "
         "Written before the blind run.", "", f"## Decision: **{d['decision']}** is the default prompt", ""]
    if d["incomplete_reason"]:
        L += [f"**Not final:** {d['incomplete_reason']}. The baseline stays until then.", ""]
    L += ["| criterion | result | met |", "|---|---|---|"]
    a, bb, cc, dd = (d["criteria"][x] for x in "abcd")
    L.append(f"| (a) {a['text']} | {a['value']:.3f} over {a['n_citations']} citations, Wilson {a['wilson']} (baseline {a['baseline_value']:.3f}) | {'yes' if a['met'] else 'no'} |"
             if a["value"] is not None else "| (a) citations | not measurable | no |")
    L.append(f"| (b) {bb['text']} | " + ("not graded yet" if bb["value"] is None else f"{bb['value']:+.3f} {bb['interval']} n={bb['n']}") + f" | {'yes' if bb['met'] else 'no'} |")
    L.append(f"| (c) {cc['text']} | {b}: {cc['baseline_refusals']}, {c}: {cc['candidate_refusals']} | {'yes' if cc['met'] else 'no'} |")
    L.append(f"| (d) {dd['text']} | input tokens {dd['input_tokens'][0]} to {dd['input_tokens'][1]} ({dd['input_token_change']:+.1%}), median LLM seconds {dd['median_llm_s'][0]} to {dd['median_llm_s'][1]} | {'yes' if dd['met'] else 'no'} |"
             if dd["input_token_change"] is not None else f"| (d) {dd['text']} | not measurable | {'yes' if dd['met'] else 'no'} |")
    L += ["", "If the baseline stays, its citation shortfall is a stated limit of the system. Commit this file before running `Mizan_Final_Colab.ipynb`, and set `PROMPT` in that notebook to the decision.", ""]
    return "\n".join(L)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--prompts", required=True)
    ap.add_argument("--grading", required=True)
    ap.add_argument("--baseline", default="v1")
    ap.add_argument("--candidate", default="v4")
    ap.add_argument("--accept-cost", action="store_true")
    ap.add_argument("--out", default=str(ROOT / "docs" / "PROMPT_DECISION.md"))
    a = ap.parse_args()
    prompts = json.loads(Path(a.prompts).read_text(encoding="utf-8"))
    grading = json.loads(Path(a.grading).read_text(encoding="utf-8"))
    d = decide(prompts, grading, a.baseline, a.candidate, a.accept_cost)
    md = markdown(d, Path(a.prompts).name, Path(a.grading).name)
    Path(a.out).write_text(md, encoding="utf-8")
    print(md)
    return 0


if __name__ == "__main__":
    sys.exit(main())
