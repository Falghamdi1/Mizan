"""Generate the one-page individual report template (Word) for the capstone.

    python scripts/make_report_template.py        # -> docs/individual_report/INDIVIDUAL_REPORT_TEMPLATE.docx

The brief asks each student for a one-page report: what you personally did, which requirements you covered, and what you would improve.
The grey italic lines are instructions: delete them. With your text the report must still fit one page (about 350 to 450 words).
"""
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

OUT = Path(__file__).resolve().parent.parent / "docs" / "individual_report" / "INDIVIDUAL_REPORT_TEMPLATE.docx"
GREY = RGBColor(0x6B, 0x6B, 0x6B)
TEAL = RGBColor(0x0F, 0x76, 0x6E)


def set_font(run, size=10, bold=False, italic=False, color=None, arabic=False):
    run.font.name = "Calibri"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Calibri")
    run.font.size = Pt(size)
    run.bold, run.italic = bold, italic
    if color is not None:
        run.font.color.rgb = color
    if arabic:
        rpr = run._element.get_or_add_rPr()
        rpr.append(OxmlElement("w:rtl"))
        rf = rpr.rFonts
        rf.set(qn("w:cs"), "Arial")


def para(doc_or_cell, text="", size=10, bold=False, italic=False, color=None, space_after=2, align=None):
    p = doc_or_cell.add_paragraph()
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.line_spacing = 1.0
    if align:
        p.alignment = align
    if text:
        set_font(p.add_run(text), size, bold, italic, color)
    return p


def heading(doc, en, ar):
    p = para(doc, space_after=1)
    p.paragraph_format.space_before = Pt(5)
    set_font(p.add_run(en + "  "), 10.5, bold=True, color=TEAL)
    set_font(p.add_run(ar), 10.5, bold=True, color=TEAL, arabic=True)


def shade(cell, hex_fill):
    tcpr = cell._element.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_fill)
    tcpr.append(shd)


def build() -> Document:
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
    sec.left_margin = sec.right_margin = Cm(1.7)
    sec.top_margin, sec.bottom_margin = Cm(1.3), Cm(1.2)
    doc.styles["Normal"].font.name = "Calibri"
    doc.styles["Normal"].font.size = Pt(10)

    p = para(doc, space_after=0)
    set_font(p.add_run("Individual report  "), 14, bold=True, color=TEAL)
    set_font(p.add_run("التقرير الفردي"), 14, bold=True, color=TEAL, arabic=True)
    para(doc, "Mizan (مِيزان): Arabic RAG optimization  ·  Tuwaiq Academy, Generative AI Application Engineering  ·  Capstone, final submission 14 October 2026",
         8.5, color=GREY, space_after=3)

    t = doc.add_table(rows=2, cols=4)
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    cells = [("Name", "[full name]"), ("Role in the team", "[RAG / NLP and evaluation / UI and demo]"),
             ("Teammates", "[the two other names]"), ("Date", "[date]")]
    for i, (k, v) in enumerate(cells):
        c = t.cell(i // 2, (i % 2) * 2)
        c.width = Cm(3.0)
        shade(c, "E6F2F1")
        c.paragraphs[0].paragraph_format.space_after = Pt(0)
        set_font(c.paragraphs[0].add_run(k), 9, bold=True)
        d = t.cell(i // 2, (i % 2) * 2 + 1)
        d.width = Cm(5.8)
        d.paragraphs[0].paragraph_format.space_after = Pt(0)
        set_font(d.paragraphs[0].add_run(v), 9, color=GREY)

    heading(doc, "1. What I personally did", "ما أنجزته شخصيًا")
    para(doc, "4 to 6 bullets. Each one names something you can show: a file, a function, a result, a decision. Say 'I' only for what you did; say 'with X' for shared work. "
              "Example shape: 'Built src/monitoring.py (alert rules, webhook delivery) and its 15 tests; verified a real HTTP alert.'", 8.5, italic=True, color=GREY)
    for _ in range(4):
        para(doc, "•  ", 10, space_after=3)

    heading(doc, "2. Requirements I covered", "المتطلبات التي غطيتها")
    para(doc, "Use the names in the brief (12 core + 3 advanced). List only the ones you contributed to, and point to the evidence. 'Evidence' = a file and section, a table, a screenshot, a number with its source.",
         8.5, italic=True, color=GREY)
    tb = doc.add_table(rows=5, cols=3)
    tb.style = "Table Grid"
    widths = (Cm(4.0), Cm(7.2), Cm(6.4))
    for i, h in enumerate(("Requirement (from the brief)", "My contribution", "Evidence")):
        c = tb.rows[0].cells[i]
        c.width = widths[i]
        shade(c, "E6F2F1")
        c.paragraphs[0].paragraph_format.space_after = Pt(0)
        set_font(c.paragraphs[0].add_run(h), 9, bold=True)
    for r in range(1, 5):
        for i in range(3):
            tb.rows[r].cells[i].width = widths[i]
            tb.rows[r].cells[i].paragraphs[0].paragraph_format.space_after = Pt(6)
            set_font(tb.rows[r].cells[i].paragraphs[0].add_run(" "), 9)

    heading(doc, "3. What did not work, and the limits of my part", "ما لم ينجح وحدود عملي")
    para(doc, "2 to 3 sentences, honest: a result that was neutral or negative, a bug you found late, something you could not verify. The brief asks for honest reporting.", 8.5, italic=True, color=GREY)
    para(doc, "", space_after=14)

    heading(doc, "4. What I would improve", "ما الذي سأحسّنه")
    para(doc, "2 to 3 concrete improvements, with the reason (for example: the next experiment, the evidence that is missing, the feature that was cut).", 8.5, italic=True, color=GREY)
    para(doc, "", space_after=14)

    heading(doc, "5. What I learned", "ما تعلّمته")
    para(doc, "Optional, one or two sentences: one technical lesson and one about working with evidence.", 8.5, italic=True, color=GREY)
    para(doc, "", space_after=8)

    p = para(doc, space_after=0)
    p.paragraph_format.space_before = Pt(4)
    set_font(p.add_run("AI assistants used for my part: "), 9, bold=True)
    set_font(p.add_run("[tool and what it did; the brief requires the README to say so]. "), 9, color=GREY)
    p = para(doc, space_after=0)
    set_font(p.add_run("Declaration: "), 9, bold=True)
    set_font(p.add_run("I wrote this report myself, it describes my own work, and I can explain the whole project, not only my part.   Signature: ____________"), 9)
    return doc


if __name__ == "__main__":
    OUT.parent.mkdir(parents=True, exist_ok=True)
    build().save(OUT)
    print("wrote", OUT)
