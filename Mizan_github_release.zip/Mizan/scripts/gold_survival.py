"""Gold-phrase survival: how much of the evidence is still readable in the text each pipeline indexes? No model, no GPU.

    python scripts/gold_survival.py                      # all question sets that have their corpus on disk
    python scripts/gold_survival.py --pipelines baseline mizan-lite+repair_lam_alef mizan+repair_lam_alef

For every answerable question the script rebuilds exactly the chunks a pipeline would index (preprocess, then chunk; the same
functions `Pipeline.build` uses, minus the embedding) and asks, per evidence group of the question, whether any chunk of an allowed
document contains one of the gold phrases. Two matchers are reported:

  strict     the gold phrase, written in correct Arabic, appears VERBATIM in a chunk after collapsing whitespace only. This is a
             fidelity measure of the index text: kashida, reversed lam-alef ligatures and presentation forms break it. It rewards
             a pipeline that repairs damage BY CONSTRUCTION, so it is a diagnostic of extraction damage, not a retrieval result.
  canonical  the evaluation matcher (`preprocessing.canonical_for_eval`, fixed and pipeline-independent). This is the upper bound
             on what retrieval can ever find: if a pipeline's cleaning destroyed evidence, this number is lower than the baseline's.
             It is also the matcher behind hit@k, so it is the fair one.

Reported per question set and pipeline: share of questions with at least one evidence group present (any), share of evidence groups
present (coverage), and the paired difference to the first pipeline with a 95% bootstrap interval (src/stats.py).

Read `strict` with care. It measures agreement with the surface form of the gold phrase, and where that phrase came from decides what the
number means. On the PDF question sets the phrases are in correct Arabic and do not follow the damaged extraction (the canonical matcher finds
every one of them in the PDFs, while the verbatim match fails on the raw text), so a low baseline value means the extracted text is damaged. On the web FAQ set the phrases were copied from the raw web text, so the raw (baseline) text
matches them by construction and a pipeline that normalises letters or digits scores LOWER (lite 0.920, full 0.092 in the first run) while
retrieval is unaffected (canonical 1.000 for all). Quote `strict` only for the PDF sets, and always next to `canonical`.

What this does not show: that the right chunk is retrieved (see hit@k), or that the answer is correct. Evidence that spans two chunks
counts as missing for both pipelines alike.
"""
from __future__ import annotations

import argparse
import json
import re
import statistics
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src import config  # noqa: E402
from src.chunking import chunk_pages  # noqa: E402
from src.corpus import corpus_fingerprint, load_corpus  # noqa: E402
from src.preprocessing import canonical_for_eval, get_config, preprocess_pages  # noqa: E402
from src.stats import paired_bootstrap  # noqa: E402

_WS = re.compile(r"\s+")
DEFAULT_PIPELINES = ["baseline", "mizan-lite+repair_lam_alef", "mizan+repair_lam_alef"]

# (label, questions file, corpus kind). A set is skipped, with a note, when its files are not on this machine.
QUESTION_SETS = [
    ("77 Ministry FAQ questions answered inside the PDFs", config.PDF_FAQ_QUESTIONS, "pdf"),
    ("10 hand-written questions", config.EVAL_DIR / "questions.json", "pdf"),
    ("51 LLM-generated questions", config.EVAL_DIR / "questions_large.json", "pdf"),
    ("250 web FAQ questions", config.WEB_QUESTIONS, "web"),
]


def collapse(text: str) -> str:
    return _WS.sub(" ", text or "").strip()


def build_chunks(pages: list, pipeline: str) -> list:
    """The chunks `Pipeline.build` would index for this pipeline (no embedding step)."""
    processed = preprocess_pages(pages, get_config(pipeline))
    return chunk_pages(processed, config.SETTINGS.chunk_size, config.SETTINGS.chunk_overlap)


def survival(questions: list[dict], chunks: list) -> dict[str, dict[str, float]]:
    """{question id: {"strict_any", "strict_cov", "canon_any", "canon_cov"}} for the answerable questions."""
    strict_texts = [(c.doc, collapse(c.text)) for c in chunks]
    canon_texts = [(c.doc, canonical_for_eval(c.text)) for c in chunks]
    out: dict[str, dict[str, float]] = {}
    for q in questions:
        groups = q.get("gold_evidence") or []
        if not groups:
            continue
        docs = q.get("gold_docs")
        allowed_s = [t for d, t in strict_texts if not docs or d in docs]
        allowed_c = [t for d, t in canon_texts if not docs or d in docs]
        s_found = [any(collapse(ph) and collapse(ph) in t for t in allowed_s for ph in g) for g in groups]
        c_found = [any(canonical_for_eval(ph) and canonical_for_eval(ph) in t for t in allowed_c for ph in g) for g in groups]
        out[q["id"]] = {"strict_any": float(any(s_found)), "strict_cov": sum(s_found) / len(groups),
                        "canon_any": float(any(c_found)), "canon_cov": sum(c_found) / len(groups)}
    return out


def summarize(per_pipeline: dict[str, dict[str, dict[str, float]]]) -> dict:
    names = list(per_pipeline)
    base = names[0]
    rows = {}
    for n in names:
        res = per_pipeline[n]
        row = {"n": len(res), "chunks": None}
        for m in ("strict_any", "strict_cov", "canon_any", "canon_cov"):
            row[m] = statistics.fmean(v[m] for v in res.values()) if res else None
            if n != base and res:
                pb = paired_bootstrap({k: v[m] for k, v in per_pipeline[base].items()}, {k: v[m] for k, v in res.items()})
                row[m + "_diff"] = {"mean": pb[0], "low": pb[1], "high": pb[2], "n": pb[3]} if pb else None
        rows[n] = row
    return rows


def fmt_diff(d) -> str:
    if not d:
        return "reference"
    sig = "" if d["low"] <= 0 <= d["high"] else " *"
    return f"{d['mean']:+.3f} [{d['low']:+.3f}, {d['high']:+.3f}]{sig}"


def render(results: list[dict], pipelines: list[str], skipped: list[str]) -> str:
    lines = ["# Gold-phrase survival", "",
             f"Generated {datetime.now():%Y-%m-%d %H:%M} by `scripts/gold_survival.py`. Differences are to `{pipelines[0]}`, paired bootstrap 95% over questions; `*` = interval excludes zero.",
             "`strict` = verbatim in correct Arabic (a diagnostic of extraction damage that favours a repairing pipeline by construction); `canonical` = the evaluation matcher (the fair upper bound on what retrieval can find).", ""]
    for r in results:
        lines += [f"## {r['label']}", "", f"{r['n_questions']} answerable questions; corpus fingerprint `{r['fingerprint'][:12]}…`; chunks per pipeline: "
                  + ", ".join(f"`{k}` {v}" for k, v in r["chunks"].items()) + ".", "",
                  "| pipeline | strict: any evidence present | strict: coverage | canonical: any | canonical: coverage |", "|---|---|---|---|---|"]
        for n in pipelines:
            row = r["rows"][n]
            lines.append(f"| `{n}` | {row['strict_any']:.3f} {fmt_diff(row.get('strict_any_diff')) if n != pipelines[0] else ''} | {row['strict_cov']:.3f} | "
                         f"{row['canon_any']:.3f} {fmt_diff(row.get('canon_any_diff')) if n != pipelines[0] else ''} | {row['canon_cov']:.3f} |")
        lines.append("")
    if skipped:
        lines += ["Skipped (files not on this machine): " + "; ".join(skipped), ""]
    return "\n".join(lines)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--pipelines", nargs="+", default=DEFAULT_PIPELINES)
    ap.add_argument("--out", default=None, help="output stem (default: results/gold-survival-<timestamp>)")
    args = ap.parse_args()
    corpora: dict[str, list] = {}
    results, skipped = [], []
    for label, qpath, kind in QUESTION_SETS:
        data_dir = config.RAW_DIR if kind == "pdf" else config.WEB_DIR
        if not Path(qpath).exists() or not data_dir.exists() or not any(data_dir.iterdir()):
            skipped.append(label)
            continue
        if kind not in corpora:
            corpora[kind] = load_corpus(data_dir, kind)
        pages = corpora[kind]
        questions = json.loads(Path(qpath).read_text(encoding="utf-8"))
        per, chunks_n = {}, {}
        for n in args.pipelines:
            chunks = build_chunks(pages, n)
            chunks_n[n] = len(chunks)
            per[n] = survival(questions, chunks)
        rows = summarize(per)
        results.append({"label": label, "kind": kind, "questions_file": str(Path(qpath).relative_to(ROOT)), "n_questions": rows[args.pipelines[0]]["n"],
                        "fingerprint": corpus_fingerprint(data_dir, kind), "chunks": chunks_n, "rows": rows})
        print(f"done: {label}")
    stem = Path(args.out) if args.out else config.RESULTS_DIR / f"gold-survival-{datetime.now():%Y%m%d-%H%M%S}"
    stem.parent.mkdir(parents=True, exist_ok=True)
    stem.with_suffix(".json").write_text(json.dumps({"pipelines": args.pipelines, "settings": {"chunk_size": config.SETTINGS.chunk_size, "chunk_overlap": config.SETTINGS.chunk_overlap},
                                                     "results": results, "skipped": skipped}, ensure_ascii=False, indent=1), encoding="utf-8")
    md = render(results, args.pipelines, skipped)
    stem.with_suffix(".md").write_text(md, encoding="utf-8")
    print(md)
    print(f"\nwrote {stem.with_suffix('.md')} and {stem.with_suffix('.json')}")


if __name__ == "__main__":
    main()
