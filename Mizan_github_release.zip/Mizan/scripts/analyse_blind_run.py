"""Per-question analysis of the final blind run (docs/BLIND_RESULTS_ANALYSIS.md). Reads the raw files in results/final_blind/ and the
frozen questions; never writes into them. Usage: python scripts/analyse_blind_run.py OUTPUT_DIR   (writes OUTPUT_DIR/analysis.json)"""
import csv
import json
import re
import sys
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.stdout.reconfigure(encoding="utf-8")
FB = ROOT / "results" / "final_blind"
OUT = Path(sys.argv[1])
A, B = "baseline", "mizan-lite+repair_lam_alef"
RUNS = {"pdf": {"retr": "eval-20261012-162146.json", "ans": "answers_blind_pdf.json", "ans_eval": "eval-20261012-165337.json",
                "e5": "eval-20261012-162443.json", "q4b": "eval-20261012-162724.json"},
        "web": {"retr": "eval-20261012-162404.json", "ans": "answers_blind_web.json", "ans_eval": "eval-20261012-172359.json",
                "e5": "eval-20261012-162511.json", "q4b": "eval-20261012-163023.json"}}
res = {}


def load(name):
    return json.load(open(FB / name, encoding="utf-8"))


def pq(run, arm):
    return {q["id"]: q for q in run["pipelines"][arm]["per_question"]}


def retrieved(q):
    r = q.get("retrieved")
    return r if isinstance(r, list) else []


# human labels
def labels(corpus):
    key = json.load(open(FB / f"grading_{corpus}" / "KEY.json", encoding="utf-8"))["rows"]
    g = {}
    for n in (1, 2):
        rows = list(csv.DictReader(open(FB / "graded" / f"g{n}_{corpus}.csv", encoding="utf-8-sig")))
        for r in rows:
            for letter in "AB":
                arm = key[r["id"]]["map"][letter]["arm"]
                for col, field in (("correct", f"correct_{letter} (0/1)"), ("supported", f"supported_{letter} (0/1, not for refusals)")):
                    v = (r.get(field) or "").strip()
                    g.setdefault((r["id"], arm, col), {})[n] = int(v) if v in ("0", "1") else None
    return key, g


PRES = re.compile("[\uFB50-\uFDFF\uFE70-\uFEFF]")
TATWEEL = "\u0640"
from src.preprocessing import canonical_for_eval, get_config, preprocess_pages  # noqa: E402
from src.corpus import load_corpus  # noqa: E402
from src import config  # noqa: E402

page_text = {}
for corpus in ("pdf", "web"):
    pages = load_corpus(config.RAW_DIR if corpus == "pdf" else config.WEB_DIR, kind=corpus)
    for arm in (A, B):
        for p in preprocess_pages(pages, get_config(arm)):
            page_text[(corpus, arm, p.doc, p.page)] = p.text

for corpus, f in RUNS.items():
    qs = {q["id"]: q for q in json.load(open(ROOT / "eval" / f"questions_final_test_{corpus}.json", encoding="utf-8"))}
    retr, ans, ans_eval = load(f["retr"]), load(f["ans"]), load(f["ans_eval"])
    R = {arm: pq(retr, arm) for arm in (A, B)}
    S = {arm: pq(ans, arm) for arm in (A, B)}
    E = {arm: pq(ans_eval, arm) for arm in (A, B)}
    key, H = labels(corpus)
    answerable = [i for i, q in qs.items() if q["gold_evidence"]]
    # conflicts between the retrieval run and the answer run (same stack, same questions)
    conflicts = {arm: [i for i in answerable if R[arm][i]["hit"] != S[arm][i]["hit"]] for arm in (A, B)}
    same_file = all(json.dumps(S[arm][i], sort_keys=True) == json.dumps(E[arm][i], sort_keys=True) for arm in (A, B) for i in qs)
    means_titles_off = {arm: {m: round(sum(R[arm][i][m] for i in answerable) / len(answerable), 3) for m in ("hit", "mrr", "candidate_recall", "first_stage_hit")} for arm in (A, B)}
    cat_off = defaultdict(list)
    for i in sorted(answerable):
        cat_off[{(1, 1): "both", (1, 0): "standard_only", (0, 1): "mizan_only", (0, 0): "neither"}[(R[A][i]["hit"], R[B][i]["hit"])]].append(i)
    R = S                       # examples, anatomy and categories below use the answer run (titles on), whose answers were graded
    cat = defaultdict(list)
    for i in sorted(answerable):
        a, b = R[A][i]["hit"], R[B][i]["hit"]
        cat[{(1, 1): "both", (1, 0): "standard_only", (0, 1): "mizan_only", (0, 0): "neither"}[(a, b)]].append(i)

    def human(i, arm, col="correct"):
        d = H.get((i, arm, col), {})
        v1, v2 = d.get(1), d.get(2)
        return {"g1": v1, "g2": v2, "agreed": v1 if (v1 is not None and v1 == v2) else None}

    hcat = defaultdict(list)
    for i in sorted(answerable):
        a, b = human(i, A)["agreed"], human(i, B)["agreed"]
        if a is None or b is None:
            hcat["not_agreed"].append(i)
            continue
        hcat[{(1, 1): "both", (1, 0): "standard_only", (0, 1): "mizan_only", (0, 0): "neither"}[(a, b)]].append(i)

    def diag(i):
        q = qs[i]
        phrase = q["gold_evidence"][0][0] if q["gold_evidence"] else ""
        doc = (q.get("gold_docs") or [None])[0]
        out = {}
        for arm in (A, B):
            pages = [k for k in page_text if k[0] == corpus and k[1] == arm and k[2] == doc]
            on = [k[3] for k in pages if canonical_for_eval(phrase) in canonical_for_eval(page_text[k])]
            strict = [k[3] for k in pages if unicodedata.normalize("NFC", phrase) in unicodedata.normalize("NFC", page_text[k])]
            gp = on[0] if on else None
            t = page_text.get((corpus, arm, doc, gp), "")
            out[arm] = {"gold_pages_canonical": on, "gold_pages_verbatim": strict, "presentation_forms_on_gold_page": len(PRES.findall(t)),
                        "tatweel_on_gold_page": t.count(TATWEEL), "gold_page_chars": len(t)}
        return out

    def example(i):
        q = qs[i]
        ex = {"id": i, "type": q["type"], "question": q["question"], "gold_phrase": q["gold_evidence"][0] if q["gold_evidence"] else [],
              "gold_doc": q.get("gold_docs"), "reference": q["reference_answer"], "text_diagnostics": diag(i) if q["gold_evidence"] else None}
        for arm in (A, B):
            r = R[arm][i]
            ex[arm] = {"hit": r["hit"], "rank": r["first_relevant_rank"], "first_stage_hit": r["first_stage_hit"], "candidate_recall": r["candidate_recall"],
                       "retrieved": [(x["doc"], x["page"], x["score"]) for x in retrieved(r)],
                       "answer": (S[arm][i].get("answer") or "")[:260], "abstained": S[arm][i].get("abstained"), "cites_gold": S[arm][i].get("cites_gold"),
                       "human_correct": human(i, arm), "human_supported": human(i, arm, "supported")}
        return ex

    # failure anatomy for retrieval misses (final stack)
    anatomy = {}
    for arm in (A, B):
        miss = [i for i in answerable if R[arm][i]["hit"] == 0]
        c = Counter()
        for i in miss:
            r = R[arm][i]
            gold_doc = (qs[i].get("gold_docs") or [None])[0]
            docs = [x["doc"] for x in retrieved(r)]
            c["gold_not_in_top20_candidates" if not r["candidate_recall"] else "in_top20_but_reranked_out"] += 1
            c["gold_document_in_top4_wrong_passage" if gold_doc in docs else "gold_document_absent_from_top4"] += 1
        anatomy[arm] = {"misses": len(miss), **c}

    # answer-side facts
    trunc = {arm: sum(bool(S[arm][i].get("possibly_truncated")) for i in qs) for arm in (A, B)}
    outmax = {arm: Counter(S[arm][i].get("output_tokens") for i in qs).most_common(2) for arm in (A, B)}
    unans = [i for i in qs if not qs[i]["gold_evidence"]]
    refusal = {arm: {"abstained": sum(bool(S[arm][i]["abstained"]) for i in unans), "n": len(unans),
                     "human_agreed_correct": sum(human(i, arm)["agreed"] == 1 for i in unans),
                     "human_agreed_n": sum(human(i, arm)["agreed"] is not None for i in unans)} for arm in (A, B)}
    false_refusal = {arm: [i for i in answerable if S[arm][i]["abstained"]] for arm in (A, B)}
    # disagreement direction
    dis = Counter()
    for (i, arm, col), d in H.items():
        if d.get(1) is not None and d.get(2) is not None and d[1] != d[2]:
            dis[(col, "g1=1,g2=0" if d[1] == 1 else "g1=0,g2=1")] += 1
            dis[(col, arm)] += 1
    # retrieval hit vs human correctness (agreed labels, answerable)
    cross = Counter()
    for arm in (A, B):
        for i in answerable:
            h = human(i, arm)["agreed"]
            if h is not None:
                cross[(arm, f"hit={R[arm][i]['hit']}", f"correct={h}")] += 1

    means = {arm: {m: round(sum(R[arm][i][m] for i in answerable) / len(answerable), 3) for m in ("hit", "mrr", "candidate_recall", "first_stage_hit")} for arm in (A, B)}
    sec = {}
    for name in ("e5", "q4b"):
        run = load(f[name])
        sec[name] = {arm: round(sum(q["hit"] for q in run["pipelines"][arm]["per_question"] if q["id"] in answerable) / len(answerable), 3) for arm in (A, B)}
        sec[name]["discordant"] = {"standard_only": sum(1 for q in answerable if pq(run, A)[q]["hit"] > pq(run, B)[q]["hit"]),
                                   "mizan_only": sum(1 for q in answerable if pq(run, B)[q]["hit"] > pq(run, A)[q]["hit"])}
    examples = {k: [example(i) for i in v] for k, v in cat.items() if k in ("standard_only", "mizan_only")}
    for k in ("both", "neither"):
        examples[k] = [example(i) for i in cat[k][:2]]           # rule: first two by question id
    hex_ = {k: [example(i) for i in v] for k, v in hcat.items() if k in ("standard_only", "mizan_only")}
    res[corpus] = {"means_titles_off": means_titles_off, "categories_titles_off": dict(cat_off), "n": len(qs), "answerable": len(answerable), "means": means, "secondary": sec, "conflicts_retrieval_vs_answer_run": conflicts,
                   "answer_run_equals_answer_eval": same_file, "retrieval_categories": {k: v for k, v in cat.items()},
                   "human_categories": {k: v for k, v in hcat.items()}, "anatomy": anatomy, "truncated": trunc, "output_tokens_mode": outmax,
                   "refusal": refusal, "false_refusal_answerable": false_refusal, "disagreement_direction": {f"{a}|{b}": v for (a, b), v in dis.items()},
                   "hit_vs_human": {"|".join(k): v for k, v in cross.items()}, "examples": examples, "human_discordant_examples": hex_}
    print(corpus, "answerable", len(answerable), {k: len(v) for k, v in cat.items()}, "human", {k: len(v) for k, v in hcat.items()})
    print("  conflicts", {k: len(v) for k, v in conflicts.items()}, "same answer file:", same_file, "| means", means)
    print("  anatomy", anatomy)
    print("  truncated", trunc, outmax, "| refusal", refusal, "| false refusals", {k: len(v) for k, v in false_refusal.items()})
    print("  disagreement", dict(dis))
    print("  hit vs human", dict(cross))
    print("  secondary", sec)
json.dump(res, open(OUT / "analysis.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
