# Demo script: 60 seconds (and a 2 to 3 minute video version)

> The full shot-by-shot video script, with narration in English and Arabic, is in [docs/DEMO_VIDEO_SCRIPT.md](docs/DEMO_VIDEO_SCRIPT.md).

**Message the demo must carry:** *Same documents. Same questions. Same model. Different preprocessing.*

## Before you film or present (not optional)

The prepared questions in the UI (`PREPARED` in `src/ui.py`: `r3`, `r1`, `r5`, `r10`) and the notes in `SPEAKING_NOTES.md` were recorded with the **full** preset. The demo now runs **Mizan-lite**. **Nothing below says which side wins on which question, because that has not been re-checked.** Do this once on the demo machine with real models:

1. Run the four prepared questions plus two you pick, in the UI, and note for each: retrieved page(s), whether the answer is right (compare with `reference_answer` in `eval/questions.json`), tokens.
2. Choose the three to show by this rule, fixed in advance: **(a)** one where Mizan retrieves the right page and Standard does not; **(b)** one where both are right; **(c)** one not in the documents (`r10`). If no (a) exists under lite, say so and show the token difference instead. Do not hide a question where Mizan is worse; show it if it is cheap to explain.
3. Write the three chosen question ids and what actually happened on the line below the script. Replace the bracketed placeholders only with what you saw.

## The 60-second flow (what to say, what to show)

| Time | Show | Say |
|---|---|---|
| 0:00 to 0:10 | UI header: the two pipelines named, "same documents, same models" panel | "Same documents, same questions, same models. The only difference is how the Arabic text is cleaned before it is indexed." |
| 0:10 to 0:20 | The page-8 example (as extracted vs after Mizan; also in the notebook section 5) | "This is a real line from a Ministry regulation. Extraction turns *لا تزيد* into *ال تزيد* and pads letters with kashida. Mizan repairs exactly this kind of damage and nothing else." |
| 0:20 to 0:40 | Click question [(a) id: ____ ]; both columns; point at the retrieved page numbers and the cited source | "Same question to both. [Standard retrieved page __ / Mizan retrieved page __]. Each answer cites its file and page." *(Read the actual outcome; do not improvise.)* |
| 0:40 to 0:50 | The metrics rows under the cards: chunks, retrieved tokens, latency | "Mizan sends [__]% fewer tokens to the model here. Latency is [what the card shows]: one run, so I won't claim it is faster." |
| 0:50 to 0:55 | Question [(c) r10], not in the documents | "When the documents do not contain the answer, both say so instead of guessing." |
| 0:55 to 1:00 | Monitoring panel / alert banner (once P1-3 and P3-3 exist) | "Every query is logged, and an alert fires if refusals or latency go over a threshold." |

*If monitoring is not built by Tuesday, delete the last row and do not mention it.*

**Optional 30 seconds: Mizan Insights** (added 2026-10-11, [docs/MIZAN_INSIGHTS.md](docs/MIZAN_INSIGHTS.md); needs a real generator, not `mock`). Under the comparison, read the finding aloud together with its scope line ("one question only"), then open "Evidence behind these insights" to show that every statement rests on numbered, measured facts. Say: "The explanation is written by the model from these facts, and code rejects it if a number or a conclusion is not in the evidence. On one question it can say who retrieved the page, never who is better in general." For your own PDF: add it, ask about it, paste the words that answer the question into the optional box, and show that both pipelines are scored on whether they retrieved that page. In the 2026-10-11 check a local 4B model on a CPU needed about two minutes for one analysis (a GPU should be much faster, but that was not measured): rehearse the timing, and do not film it live on a CPU.

## What to say when asked about the results (30 seconds)

"On damaged PDFs, the repair-only preset, which we call Mizan-lite, raises first-stage retrieval, and most for a small embedder: hit at 4 went from 0.31 to 0.55 on 77 Ministry questions. With a strong embedder and a reranker the final top four does not change, and on clean web text there is no gain. So the contribution is cleaning extraction damage, mainly kashida, and a smaller index. It is not a general Arabic improvement." (All figures from `EXPERIMENT_RESULTS.md`; update if the blind-set run changes them.)

## The 2 to 3 minute video (fallback and for the slides)

1. Problem (15 s): a damaged Arabic PDF line, raw vs repaired.
2. The experiment (20 s): two pipelines, one variable; the `Pipeline` diagram from `MIZAN_PIPELINE.md`.
3. Live comparison (60 s): the 60-second flow above, at slower pace, with the retrieved passages open.
4. Evidence (40 s): the one results table (hit@4 by embedder and corpus) and the token reduction.
5. Adaptation (20 s): the before/after fine-tuning table on held-out documents, stating the question count.
6. Limits (15 s): single reader alignment, small sets, no gain for strong models, licence pending.

## Do not show or say

- Any metric that is not on screen from a real run or in `EXPERIMENT_RESULTS.md`.
- "Mizan improves Arabic RAG" or "statistically significant" without naming the comparison and its interval.
- A judge score as accuracy.
- Latency or token savings as proof of lower cost.
- The raw tourism.sa text on a public slide or repository.

## Fallbacks

Colab down or GPU not available: play the recorded video, then show `results/final/` tables. Ollama down: the UI prints a one-line fix; use `MIZAN_LLM_PROVIDER=mock` only to show the retrieval columns and say so on screen (the UI shows a "Mock LLM" banner).

## What the real app showed on 2026-10-10 (offline embedder and mock generator; the retrieval was the hash embedder's, the text is the real PDF text)

On the prepared fee question ("Fee, 3-year licence") both pipelines put the tour-guide fee table (page 16) first. The text each one passes on differs in exactly the way the project is about: Standard keeps `ثالث سنوات` (the swapped lam-alef ligature as extracted) and `اإلرشاد`, Mizan-lite shows `ثلاث سنوات` and `الإرشاد`. The cards also showed the citation row ("1 of 1 cited pages were among the passages shown"), the notices, and the monitoring panel. This is a good first thing to point at in the demo because it needs no interpretation. **Re-check it with the real embedder and generator before presenting**: with them the ranking, the answer text and the token figures will differ.
