# Mizan on Google Colab

> **Public repository (2026-10-13):** use [`Mizan_Demo_Colab.ipynb`](Mizan_Demo_Colab.ipynb). It clones the repository and runs the app with every feature, without copying code or data into the notebook. The notebooks described below embed the team's question files, so they are not in the public repository; team members rebuild them with `scripts/build_notebook.py`, `build_web_notebook.py` and `build_final_notebook.py` after unzipping `mizan_private_eval.zip`.


**All model inference in this prototype runs locally in the Colab runtime. No external LLM inference API and no API key is required.** Model weights are downloaded once from the Hugging Face Hub (public, no login); after that every model runs on the runtime's own GPU.

## What Mizan is

مِيزان (Mizan) is an Arabic RAG optimizer prototype. It runs two pipelines on the same documents and questions, with the same models and retrieval settings. The **only** difference is the Arabic text preprocessing applied before chunking and embedding. It then reports what changed, without assuming it improved.

**Research question.** Can Arabic-specific text preprocessing improve the retrieval quality or the efficiency of a RAG system compared with a standard pipeline?

Mizan here is text normalisation, not a tokenizer, and nothing is trained in the notebook.

## How to run

The notebook is one file: [`Mizan_Arabic_RAG_Optimization.ipynb`](Mizan_Arabic_RAG_Optimization.ipynb). **All of its code is visible in ordinary cells** (section 3 writes each module to disk and the later sections import it). Nothing is embedded, zipped or downloaded as code. The notebook is generated from this repository by `scripts/build_notebook.py`, so the two cannot drift apart.

1. Open the notebook in Colab (*File › Upload notebook*, or from Google Drive). The machine you browse from only needs a browser: it needs no GPU and no project files.
2. *Runtime › Change runtime type › T4 GPU*.
3. *Runtime › Run all*. If Colab asks to restart the runtime after the install cell, restart and run all again.
4. Section 8 shows the demo question side by side, then starts the interface (Gradio): prepared-question buttons, a question box, **Ask Mizan**, and **Add PDF**. In Colab Gradio opens through a public `gradio.live` link while the cell runs (only the page is tunnelled; the models stay in the runtime; anyone with the link can open it). The static comparison above it needs no link at all.

## Memory plan (how out-of-memory is avoided)

Four models are involved, and they are not all in memory at once. Section 3 chooses a profile from the GPU's memory, loads the models, and runs each one at its worst-case input size before the experiment starts.

| Profile | Chosen when the GPU has | Embedder (stage 1) | Reranker (stage 2) | Generator | Needs about |
|---|---|---|---|---|---|
| `full` | ≥ 13 GiB (T4 has 15) | Qwen3-Embedding-**4B**, 16-bit (7.5 GiB) | Qwen3-Reranker-0.6B (1.1 GiB) | Qwen3-4B-Instruct, 4-bit (2.4 GiB) | 13 GiB |
| `full-4bit` | ≥ 8.6 GiB | Qwen3-Embedding-4B, 4-bit (2.7 GiB) | same | same | 8.6 GiB |
| `compact` | ≥ 6.6 GiB | Qwen3-Embedding-0.6B | same | same | 6.6 GiB |
| `cpu` | no GPU | multilingual-e5-small (118M) on the CPU | none | none (retrieval only) | n/a |

The rules the code follows:
- The generator and the judge are never loaded together. The judge (a different model family) is used only after every answer exists; the generator is unloaded first, then reloaded for the interactive demo.
- If a profile still runs out of memory during the start-up test, the notebook steps down to the next profile automatically (`PROFILE = "auto"`; set it by hand to force one).
- The embedder and the reranker halve their batch size and retry on a CUDA out-of-memory error.
- The reranker computes only the last-position scores (it never builds the full vocabulary-sized output tensor).
- `PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True` is set before CUDA starts, to reduce fragmentation.
- Precision uses float16 on GPUs without native bfloat16 (T4).
- Retrieval refuses to return silently empty results: an empty result raises an error instead of being scored as "evidence not found".

## Models

| Role | Model | Download | Precision in the notebook |
|---|---|---|---|
| Embedder (stage 1) | `Qwen/Qwen3-Embedding-4B` (or the 0.6B on smaller GPUs) | 8.0 GB (0.6B: 1.2 GB) | 16-bit or 4-bit NF4 |
| Reranker (stage 2) | `Qwen/Qwen3-Reranker-0.6B` | 1.2 GB | 16-bit |
| Generator | `Qwen/Qwen3-4B-Instruct-2507` | 8.1 GB | 4-bit NF4 |
| Judge | `ibm-granite/granite-3.3-2b-instruct` (Apache-2.0, no login, Arabic is in its language list) | about 5 GB | 4-bit NF4 |

The first run therefore downloads roughly 22 GB (with the 4B embedder). Retrieval takes the top 20 passages from the embedder, the reranker re-scores them, and the best 4 go to the generator. Greedy decoding, at most 300 new tokens, the same prompt for both pipelines. The notebook prints the measured parameter count, precision and download size of each model.

## Data

Eight public Arabic regulation PDFs from the Saudi Ministry of Tourism (159 pages, about 67 MB). `data/corpus_manifest.json` (shown in section 2) lists each URL with its size and SHA-256; `scripts/fetch_corpus.py` downloads and verifies them. If the ministry site cannot be reached from the Colab network, the notebook says so and offers two fallbacks: upload the PDFs into `mizan/data/raw/` (Files panel) or keep them in a Drive folder named `Mizan_PDFs`. The **Add PDF** button in the interface (section 8) adds more documents later: both pipelines are re-indexed, duplicates (same SHA-256) are skipped, and unreadable or scanned files are rejected with a message without touching the existing corpus.

## What the notebook measures

- **Answer run:** 10 reference questions (9 answerable, 1 unanswerable) about two regulations. Retrieval hit@k, MRR, precision@k, hit@k before and after reranking, candidate recall, keyword coverage, refusals, retrieved and LLM tokens, retrieval / generation / end-to-end latency, and an independent LLM judge for correctness and faithfulness. The judge is small and **unvalidated**; each answer is shown next to the reference answer so a person can check it.
- **Retrieval-only run:** 51 further questions with no LLM, for a larger retrieval sample with a paired-bootstrap interval. These questions were generated by an LLM and were **not reviewed by a person**.
- **Conclusions** (section 9) are generated from the measured numbers. A difference is called "higher" or "lower" only if the bootstrap interval excludes zero, and small samples are flagged.
- **One-step ablations** are not in the notebook (they re-embed the corpus 28 times); run `python scripts/run_ablations.py` in the repository.

## Timing

The last cell prints measured wall-clock time per stage (model download, load and memory check, PDF download and parsing, indexing for each pipeline, answer run, retrieval-only run) plus the whole notebook so far; the per-query latencies are in the results table. Nothing is promised in advance: download speed, the runtime type and the profile decide it. For reference, a full run on the author's laptop (RTX 3070, 8 GB, `compact` profile, models already cached) took 11.3 minutes; about 4 of those minutes came from a start-up test prompt that was far too long and has since been shortened, and the run was not repeated afterwards.

## What was verified, and what was not

| | Status |
|---|---|
| Whole notebook, clean folder, `compact` profile, local RTX 3070 8 GB | **Ran end to end with no errors** (683 s), including the judge swap and the interactive-demo cell |
| 4B embedder in 4-bit: load, embed, release | **Tested on its own**: 2.7 GiB, memory returned on release |
| Generator and judge swapping in memory | **Tested**: only one resident at a time |
| Add-PDF logic and Gradio interface | **Tested** (logic in automated tests; the app was driven in a browser with a mock generator: dark theme, prepared questions, both cards) (51 automated tests) |
| `full-4bit` profile inside the notebook | **Not completed**: the one attempt crashed with a Windows paging-file error because two heavy tests ran at once on a 16 GB laptop |
| `cpu` (retrieval-only) profile, whole notebook with no GPU | **Ran end to end with no errors in 107 s** (multilingual-e5-small embedder; the 0.6B Qwen embedder was impractical on a CPU: indexing ran past 50 minutes) |
| `full` profile (4B embedder in 16-bit, what a T4 selects) | **Not tested**: it does not fit on an 8 GB GPU |
| Real Colab runtime, the Gradio `gradio.live` link from Colab, download from the ministry site on Colab's network, real download time | **Not tested** |

Run the notebook once on a T4 before relying on it in front of people.

## Web-corpus evaluation notebook (run this one in Colab, not on a laptop)

[`Mizan_Web_Evaluation_Colab.ipynb`](Mizan_Web_Evaluation_Colab.ipynb), generated by `scripts/build_web_notebook.py`. Same rules as the main notebook (all code visible, section 2 writes the modules). It downloads the JSON/HTML web corpus (739 pages, about 590,000 characters), builds the 250 FAQ evaluation questions, and compares Standard RAG with Mizan on retrieval with three embedders (e5-small, Qwen3-Embedding-0.6B + reranker, Qwen3-Embedding-4B + reranker), optionally with the 8 PDFs added as noisy distractors, and optionally with the one-step ablations. It ends by zipping the result files for download. Choose a T4 GPU runtime and *Run all*; the switches are `RUN`, `INCLUDE_PDFS`, `INCLUDE_PDF_QUESTIONS`, `RUN_ABLATIONS`, `RUN_LITE` (section 6c: baseline vs full Mizan vs Mizan-lite on the PDF and web questions, three embedders) and `RUN_LOO` (leave-one-out of the full preset's steps for e5-small on the PDF questions). Section 6c ran on the offline hash embedder only (wiring check); no real-model result exists yet.

Verified: all code cells parse; the whole notebook ran end to end on a laptop with the offline hash embedder (no models), including the download, question check, evaluation, comparison table, ablations and zip, in 103 s; the web-plus-PDF path was run separately. **Not verified: any run on Colab, the real models inside this notebook (the same models ran through `scripts/run_web_eval.py` locally for e5-small and the 0.6B pair), the 4B embedder on a T4, whether the Ministry sites answer from Colab's network, and the real time of the ablations (about 3 minutes per pipeline on an RTX 3070 with the 0.6B pair).** **First Colab run:** it worked end to end in 124.6 minutes on a T4, but the six Bureau of Experts law pages timed out from Colab's network and the run continued without them. The notebook now checks that every file arrived and, if not, asks you to upload `data/web/html_for_colab.zip` (made from your own `data/web/raw/` copies of the law and GASTAT pages). The tourism.sa content is the Ministry's; its terms require written permission to copy it into other systems, so do not share the downloaded text.

## Known limitations

- One run, no repeated seeds; the ten answer questions are far too few to test anything; the 51-question set is unreviewed; the ten reference questions cover two of the eight documents.
- Chunk size is counted in characters after cleaning, so the pipelines produce different numbers of chunks: preprocessing and chunking are partly entangled.
- Both pipelines show the LLM the text as indexed, i.e. after their own preprocessing.
- Embedder, reranker and generator are one model family (Qwen); only the judge is different, and it is small and unvalidated.
- 4-bit quantisation (generator, judge, and the embedder on small GPUs) is a memory trade-off whose effect on answers was not measured.
- No BM25 or hybrid baseline; one corpus from one publisher.

## Files

`Mizan_Arabic_RAG_Optimization.ipynb` (generated by `scripts/build_notebook.py`), `src/` (pipeline, `memory.py`, `local_llm.py`, `ui.py`, `colab.py`), `eval/` (questions), `data/corpus_manifest.json`, `requirements-colab.txt`, `TEAM_ROLES.md`, `docs/EXPERIMENT_LOG.md`.
