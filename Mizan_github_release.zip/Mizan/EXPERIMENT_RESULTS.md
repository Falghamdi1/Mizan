# Mizan: measured results (as of 2026-10-12)

Every number here is copied or computed from a file. Source tags: **[R2]** Colab run 2 (`mizan_web_results (1).zip`, complete web corpus, fingerprint `b3871676ff02`); **[R3]** Colab run 3 (`mizan_web_results (2).zip`, web corpus **incomplete**: 1,297 chunks, laws missing, fingerprint `2080d1ad5501`; PDF corpus identical to R2); **[R4]** Colab run 4 (`mizan_web_results rerun.zip`, 2026-10-10, complete web corpus, fingerprint `b3871676ff02`, PDF corpus identical to R2/R3; files in `results/colab_run4/`); **[M1]** the main notebook executed top to bottom on a Colab T4 on 2026-10-10 (48 of 48 code cells, no error, 54.2 minutes; saved as `results/final/Mizan_Arabic_RAG_Optimization_executed_20261010.ipynb`); **[LOG]** an earlier local run recorded in `docs/EXPERIMENT_LOG.md` with its file in `results/`.

**Naming.** *Standard* = `baseline` (whitespace cleanup only). *Mizan-full* = `mizan+repair_lam_alef` (all preset steps plus lam-alef repair). *Mizan-lite* = `mizan-lite+repair_lam_alef` (invisible marks, NFKC, kashida removal, look-alike letters, digit forms, lam-alef repair; no spelling folding, no repeated-line removal, no line joining). The demo and main notebook now use Mizan-lite.

**How to read the intervals.** Differences are *Mizan minus Standard*, with a 95% interval from a paired bootstrap over questions (`src/stats.py`). "n.d." = the interval includes zero (no difference we can distinguish from zero; it does not prove the two are equal). Several metrics, embedders and comparisons are shown; none is corrected for multiple testing, so an interval that barely excludes zero is weak evidence. One question moves hit@4 by 0.013 (n=77) or 0.004 (n=250). The GPU noise floor was about one question.

## 0. Final result: the frozen blind test [BLIND, 2026-10-12]

**Run.** `Mizan_Final_Colab.ipynb`, once, on a Colab A100 (the plan names no GPU; earlier runs used a T4), 52 of 52 cells executed. `make_blind_test.py --verify` passed ("frozen blind set is unchanged"); corpus fingerprints match the freeze (web `b3871676ff02`, PDF `c1b846432f4f`); prompt v1. Questions: the frozen set of 266 (`docs/EXPERIMENT_LOG.md`, 2026-10-12): 93 PDF (69 answerable), 173 web (140 answerable). Files: `results/final_blind/` (local, git-ignored), from `mizan_final_results.zip`.

**Primary endpoints (docs/ANALYSIS_PLAN.md section 4), final stack Qwen3-Embedding-0.6B + Qwen3-Reranker-0.6B, top 4:**

| # | endpoint | n | Standard | Mizan-lite − Standard [95% CI] | reading by the pre-registered rule |
|---|---|---|---|---|---|
| P1 | hit@4, PDF | 69 | 0.681 | **+0.116 [+0.029, +0.217]** | lower bound above 0: **gain shown**; the +0.10 goal is met (point estimate) |
| P2 | hit@4, web | 140 | 0.729 | +0.007 [+0.000, +0.021] | interval touches 0: **not distinguishable from zero**; no loss (the −0.02 limit is not crossed) |
| P3 | answer correctness, two human graders plus a third for every disagreement or empty cell (answerable questions, adjudicated) | PDF 69 paired, web 140 paired | PDF 0.754, web 0.779 | PDF **+0.014 [−0.101, +0.130]**; web **+0.029 [−0.007, +0.071]** | both not distinguishable from zero. **Web:** lower bound above −0.10, so **no loss of answer quality** may be stated. **PDF:** the lower bound is −0.1014, just below −0.10, so by the plan's rule the claim is only "**not distinguishable, small sample**"; no "no loss" claim for PDF. Agreement before adjudication on `correct`: kappa 0.649 (PDF), 0.794 (web); 38 (PDF) and 41 (web) cells decided by the third grader |
| P4 | correct refusal of unanswerable questions (Wilson 95%) | 24 PDF + 33 web | PDF 21/24 = 0.875 [0.690, 0.957]; web 30/33 = 0.909 [0.764, 0.969] | Mizan-lite: PDF 24/24 = 1.000 [0.862, 1.000]; web 30/33 = 0.909 [0.764, 0.969]; all 54/57 = 0.947 [0.856, 0.982] | Mizan-lite meets the 90% target on the point estimate (lower bound 0.856); Standard 51/57 = 0.895 [0.789, 0.951] |
| P5 | hit@4, LoRA adapter − base embedder (Mizan-lite text, titles on, no reranker) | 69 | base 0.841 | adapter **+0.014 [−0.072, +0.101]**; documents held out of training (16): +0.062 [−0.125, +0.250]; documents in training (53): +0.000 [−0.113, +0.113] | lower bound below 0: **adaptation not shown to help**; by the plan the demo runs the base model. Run 2026-10-13 (third attempt, T4); on the development held-out questions the same adapter gave +0.183 [+0.067, +0.300] (n=60), mostly on generated questions in the training style |

**Secondary (no decision rule).** Other stacks, hit@4 lite − Standard: e5-small PDF **+0.261 [+0.145, +0.377]**, web +0.007 [+0.000, +0.021]; Qwen3-Embedding-4B + reranker PDF **+0.101 [+0.014, +0.188]**, web +0.007 [−0.014, +0.029]. MRR on the final stack: PDF +0.080 [−0.006, +0.165], web +0.002 [−0.009, +0.013]. Gold among the 20 candidates (final stack): PDF **+0.116 [+0.029, +0.203]**, web −0.007 [−0.021, +0.000]. Full preset − Standard, final stack: PDF hit +0.116 [+0.014, +0.217], web +0.029 [−0.007, +0.071]; on the 4B stack the full preset loses candidate recall on web (−0.036 [−0.071, −0.007]).

**Cost and answers (final stack, generator Qwen3-4B-Instruct-2507 4-bit, prompt v1), Standard → Mizan-lite:** PDF index tokens 72,706 → 49,619 (−31.8%); generator input tokens per PDF question 1,333 → 1,122 (−15.9%); median answer latency PDF 5.75 → 5.09 s (−11.5%), web 4.36 → 4.44 s; citation present PDF 0.956 → 1.000; share of citations naming a shown page PDF 0.864 → 0.908, web 0.996 → 0.996; refusal of an answerable question PDF 0.058 → 0.058, web 0.179 → 0.164. These answer figures are automatic. Human-graded (two graders, all 266 questions, every disagreement or empty cell decided by a third grader): correct answers PDF 0.754 → 0.768, web 0.779 → 0.807; correct refusals PDF 20/24 → 23/24, web 30/33 → 30/33; cited source supports the answer PDF 0.765 → 0.831 (paired +0.032 [−0.079, +0.143]), web 0.924 → 0.933 (kappa for `supported` before adjudication: 0.608 PDF, 0.507 web, the web value below the 0.6 bar). Pairwise pick (secondary, no decision rule): PDF Mizan-lite 26 wins, Standard 10, ties 56 (sign test p = 0.011); web 12 against 6, 154 ties (p = 0.24). The pick does not change P3: by the plan it is descriptive only. Reports: `results/final_blind/grading_{pdf,web}/human_grading_report.md`.

**What it settles.** On text extracted from the Ministry PDFs, Mizan-lite retrieves the gold evidence more often than Standard on the final stack (P1), and the same holds on the stronger 4B stack, which resolves the "mixed" strong-stack result of section 6 of the analysis plan in the direction of a gain, on the blind set. On clean web text there is no difference in either direction (P2). The PDF index is a third smaller. Graded answer quality shows no loss on web text; on PDF text the difference is not distinguishable from zero but the sample cannot rule out a loss of slightly more than 0.10 (P3). The fine-tuned embedder adds nothing measurable on the blind set (P5), although it gained on development questions written in the style of its training pairs: that gap is the reason for a blind test. **Limits:** the set's deviations (`docs/EXPERIMENT_LOG.md`), questions treated as independent, one run, graders from the team (third grader also from the team).

## 1. Experiment set-up (what is held constant)

Same documents, same questions, same chunker (600 characters, overlap 100, never crossing a page), top-k 4, same embedder, same reranker (Qwen3-Reranker-0.6B over the top 20, for the Qwen rows), same hardware (Colab T4), same retrieval code. **Only the text preprocessing differs.** Chunk size is counted in characters *after* cleaning, so the arms get different numbers of chunks (PDF: 358 / 320 / 323); this is a known confound for token counts and for what a chunk contains. Retrieval only: no generator in these runs. Matching of gold evidence uses a fixed canonicalizer that does not depend on either pipeline.

Embedders: `multilingual-e5-small` (single stage); `Qwen3-Embedding-0.6B` + reranker; `Qwen3-Embedding-4B` + reranker. Question sets: **250** Ministry FAQ questions on the web corpus (gold = start of the Ministry's answer); **77** Ministry FAQ questions whose answer is stated in the 8 PDFs, evaluated on the PDF corpus only (gold = a phrase from the PDF text; aligned by one reader, `needs_review`).

## 2. Headline: hit@4, Standard vs Mizan (first measured with the full preset) [R2]

| embedder | questions (n) | Standard | Mizan-full | difference [95% CI] | reading |
|---|---|---|---|---|---|
| e5-small | PDF (77) | 0.312 | 0.545 | **+0.234** [+0.130, +0.351] | Mizan higher |
| Qwen3-0.6B + rerank | PDF (77) | 0.623 | 0.636 | +0.013 [−0.091, +0.117] | n.d. |
| Qwen3-4B + rerank | PDF (77) | 0.701 | 0.675 | −0.026 [−0.117, +0.065] | n.d. |
| e5-small | web (250) | 0.508 | 0.500 | −0.008 [−0.036, +0.020] | n.d. |
| Qwen3-0.6B + rerank | web (250) | 0.616 | 0.568 | **−0.048** [−0.080, −0.016] | Mizan lower |
| Qwen3-4B + rerank | web (250) | 0.636 | 0.596 | **−0.040** [−0.072, −0.008] | Mizan lower |

MRR, same rows: e5 PDF +0.218 [+0.127, +0.314]; 0.6B PDF +0.071 [−0.015, +0.165]; 4B PDF +0.029 [−0.035, +0.098]; web −0.009 [−0.029, +0.010], −0.026 [−0.051, −0.002], −0.013 [−0.038, +0.012].

**What it establishes:** on damaged PDF text the full preset helps a weak, single-stage embedder a lot. **What it does not:** any gain for Qwen3 + reranker at the final top 4, or any gain on clean text; with the Qwen3 models the full preset costs 4 to 5 points on web text.

## 3. Mizan-lite against Standard and against Mizan-full [PDF rows R3 = R4, web rows R4]

hit@4 (lite in the last column; differences with 95% intervals). PDF rows are on the complete, unchanged PDF corpus and are comparable with section 2 (run 4 reproduced them exactly). **Web rows are from run 4 on the complete web corpus** (fingerprint `b3871676ff02`, 1,569 chunks), comparable with section 2; they replace the run-3 web rows, whose corpus lacked the six law pages.

| embedder | questions | Standard | Mizan-lite | lite − Standard | lite − Mizan-full |
|---|---|---|---|---|---|
| e5-small | PDF (77) | 0.312 | 0.545 | **+0.234** [+0.130, +0.351] | +0.000 [−0.052, +0.052] |
| Qwen3-0.6B + rerank | PDF | 0.623 | 0.623 | +0.000 [−0.104, +0.104] | −0.013 [−0.091, +0.065] |
| Qwen3-4B + rerank | PDF | 0.701 | 0.662 | −0.039 [−0.130, +0.065] | −0.013 [−0.091, +0.065] |
| e5-small | web (250) | 0.504 | 0.516 | +0.012 [+0.000, +0.028] | +0.016 [−0.012, +0.044] |
| Qwen3-0.6B + rerank | web | 0.616 | 0.620 | +0.004 [−0.008, +0.020] | **+0.052** [+0.024, +0.084] |
| Qwen3-4B + rerank | web | 0.636 | 0.644 | +0.008 [−0.008, +0.024] | **+0.048** [+0.020, +0.080] |

MRR lite − Standard: e5 PDF **+0.168** [+0.085, +0.254], 0.6B PDF +0.056 [−0.028, +0.146], 4B PDF +0.021 [−0.049, +0.093]; web +0.005 [+0.000, +0.012], +0.005 [−0.001, +0.012], +0.006 [−0.003, +0.018]. (Lite − full MRR for e5 PDF: −0.050 [−0.102, −0.001], borderline.)

**Reading of the complete-corpus web rows [R4]:** on clean web text Mizan-lite is not distinguishable from Standard with any of the three stacks (every interval includes or touches zero), and it beats the full preset by about 5 points hit@4 with the two Qwen3 stacks. The full preset against Standard on the same web questions is −0.048 [−0.080, −0.016] (0.6B) and −0.040 [−0.072, −0.008] (4B), as in section 2.

**Before the reranker** (first-stage hit, and whether the gold chunk is among the 20 candidates), lite − Standard, PDF questions (computed from the R3 files):

| embedder | first-stage hit@4 | gold in top-20 candidates |
|---|---|---|
| e5-small | +0.234 [+0.130, +0.351] | +0.234 [+0.130, +0.351] (same: single stage) |
| Qwen3-0.6B | **+0.182** [+0.065, +0.299] | +0.104 [+0.000, +0.208] |
| Qwen3-4B | +0.052 [−0.013, +0.130] | +0.039 [−0.013, +0.104] |

**Reading:** lite matches the full preset where the full preset helps (e5, PDF), is not worse than Standard on web text (lower bounds are at +0.000, so "not distinguishable from Standard"), and beats the full preset on web text with the Qwen3 models (the interval only just excludes zero). The reranker hides most of the PDF gain at the final top 4: the first-stage gain of the 0.6B (+0.182) disappears after reranking (+0.000). The honest sentence is: *Mizan-lite lifts first-stage retrieval on damaged PDFs; a strong reranker makes the lift unnecessary at top 4.*

## 4. Which step does it? (leave-one-out of the full preset, e5-small, PDF questions) [R3]

Reference `mizan` = 0.545 hit@4; `baseline` = 0.312. Removing **`remove_tatweel`** gives 0.351 (**−0.195** [−0.299, −0.091]); chunks rise from 320 to 351 and retrieved tokens from 595 to 840. Every other single removal is n.d.: `normalize_punctuation` +0.026 [+0.000, +0.065], `remove_diacritics` +0.013, `remove_repeated_lines` +0.013, `normalize_alef_maqsura` −0.013, the rest +0.000 or n.d. This leave-one-out used `mizan` *without* the lam-alef repair, which still scored 0.545: for e5-small hit@4, kashida removal is the whole effect.

One-step add-one ablation on the PDF questions, Qwen3-0.6B + reranker, n=77 [R2, `ablations-pdf.md`]: no single step improves hit@4 over `baseline` (0.623). Significantly lower: `normalize_hamza_seats` −0.117 [−0.195, −0.052] and `remove_repeated_lines` −0.052 [−0.104, −0.013] (neither is in lite). `baseline+remove_tatweel` −0.026 [−0.117, +0.078], `baseline+repair_lam_alef` −0.013 [−0.065, +0.026] (both n.d.).

## 5. Token efficiency: what was measured, what it means (verified 2026-10-10)

Computed by `scripts/token_analysis.py` from the Colab result files (`results/colab_run3/`), the earlier real-generator answer run (`results/eval-20261007-212624.json`) and the local corpora. Full output: `docs/data_audit/token_analysis.md` and `.json`. Nothing below is estimated.

**Definitions (four different quantities, which must not be mixed).**

| quantity | what it counts | tokenizer |
|---|---|---|
| index tokens | the whole corpus as chunked by that pipeline: what the embedder must encode | embedding model's tokenizer |
| retrieved tokens | the 4 chunks passed on for one question (sum of chunk lengths) | embedding model's tokenizer |
| LLM input tokens | the real prompt the generator received: system prompt + 4 passages with their headers + question (Ollama's own usage count) | the generator's tokenizer |
| LLM output tokens | what the generator wrote | the generator's tokenizer |

**Same tokenizer?** Qwen3-Embedding-0.6B and Qwen3-4B-Instruct have an identical vocabulary and tokenized 70 of 70 sampled texts identically, so for the Qwen3 embedders *retrieved tokens are exactly the number of tokens the generator sees for those passages*. e5-small uses a different tokenizer (about 0.81 e5 tokens per Qwen3 token on this text), so e5 token counts are in e5 units and are not generator tokens. Both pipelines are always measured with the same tokenizer and the same boundaries.

**A. Documents (no retrieval involved).** On the 8 PDFs the extracted text costs **3.60 tokens per word**; the web corpus costs **2.27**. Kashida alone accounts for **21,109 of the PDFs' 71,046 tokens (29.7%)**. After the Standard cleaning the PDFs still cost 3.57 tokens per word; after Mizan-lite 2.50 (−30%); after the full Mizan 2.37. On the web corpus the arms differ by 0.5% (2.270, 2.259, 2.255). Preprocessing time for the whole PDF corpus: 0.007 s (Standard), 0.021 s (lite), 0.042 s (full): negligible.

**B. Retrieval (per question, paired Standard vs Mizan-lite, PDF questions, n=77).**

| embedder | retrieved tokens/query, Standard | difference [95% CI] | change | questions with fewer tokens | index tokens, Standard → lite | hit@4 difference [95% CI] |
|---|---|---|---|---|---|---|
| e5-small (e5 tokens) | 844.5 | −257.6 [−286.3, −229.5] | −30.5% | 96.1% | 64,464 → 37,698 (−41.5%) | +0.234 [+0.130, +0.351] |
| Qwen3-0.6B + reranker | 1,021.1 | −232.3 [−258.7, −205.0] | −22.8% | 94.8% | 72,706 → 49,619 (−31.8%) | +0.000 [−0.104, +0.104] |
| Qwen3-4B + reranker | 1,020.4 | −236.3 [−266.2, −206.2] | −23.2% | 94.8% | 72,706 → 49,619 (−31.8%) | −0.039 [−0.130, +0.065] |

The reduction **repeats**: it holds for 95% to 96% of the 77 questions and for each of the 8 documents (mean retrieved tokens per query, lite vs Standard, Qwen3-0.6B: −14.6% for the visa regulation, −15.8% tour guide, −19.0% travel services, −20.2% to −22.9% for the management regulation and its directory and consultation, −28.3% hospitality facilities, −29.0% travel-services directory). It is **absent on clean text**: on the 250 web questions retrieved tokens change by −0.4% to +0.6% with intervals that include zero, and the index by less than 1%. The full preset is slightly larger on the web (e5: +12.5 tokens/query, [+3.7, +21.2]).

**C. Generation (51 questions, Qwen3-0.6B embedder, no reranker, no adapter, real Qwen3-4B generator through Ollama, full Mizan preset; the run predates lite).**

| quantity | Standard | difference (Mizan − Standard) [95% CI] | change |
|---|---|---|---|
| LLM input tokens / query | 1,183 | −228 [−275, −179] | **−19.3%** |
| retrieved-context tokens / query | 925 | −228 [−274, −179] | −24.7% |
| LLM output tokens / query | 76.8 | −1.3 [−14.8, +10.6] | −1.7% (n.d.) |
| LLM latency, mean s | 6.32 | −0.33 [−0.96, +0.21] | −5.3% (n.d.) |
| end-to-end latency, mean s | 6.39 | −0.34 [−0.96, +0.21] | −5.2% (n.d.) |
| retrieval latency, mean s | 0.078 | −0.000 [−0.007, +0.006] | n.d. |
| answer keyword coverage (n=45) | 0.578 | +0.011 [−0.133, +0.156] | n.d. |
| hit@4 (n=45) | 0.533 | +0.089 [−0.089, +0.267] | n.d. |

How the prompt is made: across both arms (n=102 answers), **LLM input tokens = 1.007 × retrieved tokens + 252** (Pearson r = 0.999). The retrieved context is 75% of the prompt and passes through one for one; 252 tokens are fixed overhead (system prompt, question, passage headers). So a retrieved-token saving appears in the generator's input almost unchanged, and is diluted only by the fixed overhead (−24.7% of the context is −19.3% of the whole prompt).

**What the saving is, and is not.**
- *Source:* one step, kashida removal. Kashida pads PDF text (12.3% of its characters) and is split into many tokens; chunks are sized in characters, so a Mizan chunk of 600 characters holds more real text than a Standard chunk of 600 characters and fewer tokens. The saving is therefore "same content, fewer tokens", not "less content": the median PDF chunk falls from 235 to 178 tokens at about the same character count. The side effect is that the arms form different numbers of chunks (358, 323, 320), a confound stated with every token figure.
- *Real at the level that matters:* it changes the number of tokens the generator receives (measured by the generator's own usage count), not only a separate text count.
- *Not shown to be a latency or cost saving:* LLM latency fell 5.3% but the interval includes zero, and across 100 uncached answers input tokens correlate only weakly with LLM latency (r = 0.244); the answer is about 77 tokens, so generation, not prefill, dominates here, and the runs shared an 8 GB GPU with other processes. Fewer input tokens would lower the cost of a metered API linearly; this system uses local models, so no cost saving is claimed.
- *Quality alongside:* no loss measured. hit@4 is higher for e5-small (+0.234, significant), unchanged for the Qwen3 models with a reranker (+0.000, −0.039; n.d.), and answer keyword coverage unchanged. This is an efficiency gain at no measured quality cost on damaged PDFs, not an efficiency-for-quality trade.
- *Limits:* only on text with extraction damage (nothing on clean web text); the generation-level numbers are from the full preset and from one run of 51 LLM-generated questions (45 answerable); lite's retrieval-level saving is slightly smaller than the full preset's (−22.8% vs −27.3% for Qwen3-0.6B) because it keeps the diacritics and letter forms.
- *Earlier statements to correct:* the Submission 1 slide says cleaning "cut the tokens sent to the model by 17%": consistent with −14% (10-question run) to −19% (51-question run) of LLM input tokens, so quote the 51-question figure with its interval. The same slide says "16% less text to embed after cleaning": the measured figures are **12.5% fewer characters** (138,895 to 121,507, full preset) and **32% to 42% fewer tokens to embed**; replace the 16% by the measured figures.

## 5c. Gold-phrase survival: how much evidence is still readable in the indexed text [LOCAL, 2026-10-10]

`scripts/gold_survival.py`, no model, local corpora (PDF fingerprint `c1b846432f4f`, web `b3871676ff02`; files `docs/data_audit/gold_survival.*`). For each answerable question: does any chunk of an allowed document contain a gold phrase? **strict** = verbatim, in correct Arabic, whitespace collapsed only; **canonical** = the evaluation matcher (the fair upper bound on what retrieval can find). Paired bootstrap 95% intervals against `baseline`; `*` = interval excludes zero.

| question set | pipeline | strict: any evidence present | canonical: any |
|---|---|---|---|
| 77 Ministry FAQ in the PDFs | Standard | 0.117 | 1.000 |
| | Mizan-lite | **0.571** (+0.455 [+0.338, +0.571] *) | 1.000 |
| | Mizan full | 0.221 (+0.104 [+0.000, +0.221]) | 1.000 |
| 45 answerable generated questions | Standard | 0.178 | 0.956 |
| | Mizan-lite | **0.933** (+0.756 [+0.622, +0.867] *) | 1.000 (+0.044 [+0.000, +0.111]) |
| | Mizan full | 0.311 (+0.133 [+0.000, +0.267]) | 1.000 |
| 9 answerable hand-written | Standard / lite / full | 0.111 / 0.667 (+0.556 [+0.222, +0.889] *) / 0.333 | 1.000 for all |
| 250 web FAQ | Standard / lite / full | 1.000 / 0.920 (−0.080 [−0.116, −0.048] *) / 0.092 | 1.000 for all |

**Reading.** (1) On the damaged PDFs the Standard index contains the correct Arabic spelling of the evidence for only 12% to 18% of questions; Mizan-lite brings that to 57% (FAQ) and 93% (generated). This is the extraction damage the preprocessing repairs, shown without any model. (2) **Canonical survival is 1.000 for every pipeline** on the PDF sets and the web set: neither the lite nor the full preset destroys evidence, so the retrieval differences in sections 2, 3 and 6b are not caused by lost text. (3) The 77-question gap between 0.571 and 1.000 shows the damage Mizan-lite does not repair (what remains is not only kashida and lam-alef). (4) **Strict is not a quality measure.** On the web set the gold phrases were copied from the raw text, so raw text matches by construction and the normalising pipelines score lower while retrieval is unchanged. Quote strict only for the PDF sets and always next to canonical. It favours a repairing pipeline by construction; it does not show better answers.

## 5d. Diagnostics of run 4: index cost, candidate pool, latency, reproducibility, which steps matter [R4, vs R2 and R3]

`scripts/run_diagnostics.py` (no model; full tables in `docs/data_audit/run_diagnostics.md`).

**Index cost, measured on the indexes (Mizan-lite against Standard).** Damaged PDFs: chunks **−9.8%** (358 to 323), characters **−12.0%**, embedding tokens **−41.5%** (e5-small) and **−31.8%** (Qwen3). Clean web text: chunks ±0%, characters −0.1%, tokens −0.5%: the saving exists only where the text is damaged. The full preset saves slightly more on PDFs (−36.0% Qwen3 tokens) and costs retrieval quality on web text (section 3). In the main notebook, building the two indexes took 47.7 s (Standard) and 37.1 s (lite), one run, 8 PDFs.

**Candidate pool (what the reranker sees), lite − Standard, PDF questions (n=77):** first-stage hit@4 with the 0.6B embedder **+0.182 [+0.065, +0.299]**, gold in the top-20 candidates +0.104 [+0.000, +0.208]; with the 4B embedder +0.052 [−0.013, +0.130] and +0.039 [−0.013, +0.104] (not distinguishable). The first-stage gain with the 0.6B embedder is absorbed by the reranker: final hit@4 is +0.000 [−0.104, +0.104]. On web text all pool differences are within ±0.012.

**Retrieval latency per question (paired, first question dropped as warm-up; one run on a shared Colab GPU).** PDFs: **−0.129 s [−0.138, −0.119] with the 0.6B stack (0.927 to 0.798 s, −14%)** and −0.125 s [−0.135, −0.115] with the 4B stack. Web text, where the index is the same size: −0.004 s and −0.005 s (under 1%). The web arms act as a control for run order (Standard always ran first): the PDF saving is about 30 times larger than anything the order could explain, and it follows the 23% to 31% fewer retrieved tokens the reranker has to read. Median and p95: 0.93 and 0.96 s (Standard) against 0.79 and 0.87 s (lite), 0.6B, PDFs. Indicative, not a benchmark: one run, shared GPU. The generator latency was not different in the main-notebook run (section 6b).

**Reproducibility.** Run 4 against run 3 on the PDF corpus: **54 of 54 metric values identical** (three embedders, three pipelines). Run 4 against run 2 on the complete web corpus (same fingerprint): 91 of 108 values identical; the 17 that differ differ by at most 0.008 (two questions of 250), in five files. So the pipeline is deterministic on the PDFs and shows a small amount of run-to-run noise on the web set; differences below about 0.01 hit@4 on 250 questions are within noise.

**Which steps move retrieval (the optimizer's own output).** Of the 16 one-step additions to Standard on the 0.6B + reranker stack (77 PDF questions), **none improves hit@4**, two lower it (`remove_repeated_lines` −0.052 [−0.104, −0.013], `normalize_hamza_seats` −0.117 [−0.195, −0.052]) and 14 are not distinguishable. Leave-one-out of the full preset with the weak e5-small embedder: removing only `remove_tatweel` matters (hit@4 0.545 to 0.351, −0.195 [−0.299, −0.091]); the other 11 steps do not. That is the reason for Mizan-lite: keep the repair (kashida, lam-alef, invisible marks, NFKC, look-alike letters, digit forms), drop the steps that do nothing or harm. Intervals treat questions as independent; many come from the same page.

## 5b. Failure cases, individually (PDF questions, n=77, Qwen3-0.6B + reranker)

Of the 29 questions that miss at the final top 4 with either arm: **21 are missed by both Standard and lite, 8 are fixed by lite, 8 are broken by lite** (net zero, which is the +0.000). Splitting each miss by where the gold passage was lost:

| arm | missed | gold chunk not in the first-stage top-20 (embedding / extraction / chunking) | in the top-20 but not in the final top-4 (reranker or near-duplicate clause) |
|---|---|---|---|
| Standard | 29 | 19 | 10 |
| Mizan-lite | 29 | 11 | 18 |

Preprocessing really helps the first stage (19 to 11 first-stage misses) and the reranker then loses more near-duplicate clauses (10 to 18): the bottleneck moves from "text damage" to "which of several nearly identical regulations' clauses is right". The 21 questions missed by both are dominated by the largest categories (travel services 8, hospitality facility 5, consultation 4); read individually they are mostly **ambiguous as questions**: the Ministry FAQ writes them inside a category page, so "متى يتم إصدار الترخيص؟" ("when is the licence issued?") or "ماهي متطلبات تجديد الترخيص؟" never names the regulation, and several regulations contain a matching clause. This is a limit of FAQ-derived questions, not of the preprocessing, and it is why the blind set requires questions that name their subject. With e5-small, every miss is a first-stage miss (no reranker): 53 for Standard and 35 for lite.

## 6. Answer-level results (earlier setup, PDF corpus, Mizan-full text) [LOG]

These are the only answer-generation measurements, all with Qwen3-4B (4-bit, Ollama, temperature 0). They predate the web corpus, the 77 PDF questions and Mizan-lite. Treat as a different experiment.

- **10 reference questions (9 answerable) [LOG, `eval-20261008-005634.json` for retrieval tokens; the answer-stage figures are from `docs/BRIEFING.md` and were not re-derived here]:** retrieved tokens 999 → 827 (−17%); LLM input tokens 1,262 → 1,089 (−14%); output 77 → 70; hit@4 1.000 vs 1.000. Ten questions cannot test anything; one question is 0.11.
- **45 generated answerable questions (+6 unanswerable), Qwen3-0.6B embedder + titles, matched fine-tuned arms [LOG]:** hit@4 0.644 (raw text, baseline-trained adapter) vs 0.867 (cleaned text, Mizan-trained adapter), +0.222 [+0.089, +0.356]; refusals of answerable questions 0.27 vs 0.09; LLM input tokens 1,018 vs 857. The judge (Qwen, then Gemma) was shown to be unreliable (Gemma judged all 41 and 33 non-refused answers correct, kappa 0.00; Qwen disagreed on 8 and was right on the clear cases). **No judge score in this project is validated.** Do not quote "judge correct" as accuracy.
- **Faithfulness and citation quality:** the prompt asks the model to cite `[file, page N]`. The citation check (`src/citations.py`) now scores this without a judge. A retroactive pass over every earlier real-model answer file in `results/` (31 pipeline-runs; repeated runs of the same configuration are included, so **this is not a comparison between arms**) found: 644 non-refusal answers, all 644 contained at least one citation; 922 citations, 816 (88.5%) naming a (file, page) among the passages shown; 53 answers (8.2%) contained at least one citation to a page that was not shown. Per-run invalid-citation answers ranged from 0 to 8 of 33 to 43 non-refusal answers on the 51-question runs. `cites_gold` (does a valid citation point at the passage holding the evidence) could not be computed retroactively because the stored results do not keep passage text; it will be reported from the next answer run. Faithfulness (does the cited text support the sentence) is still only judged by the unvalidated judges.
- **Unanswerable questions:** 6 + 1 in the earlier sets; refusal worked in all recorded arms (correct-abstain 1.0), but n is tiny.

## 6b. First end-to-end run of the main notebook on the current code [M1]

Setup: Colab T4, memory profile "full" (Qwen3-Embedding-4B in 16-bit, Qwen3-Reranker-0.6B, Qwen3-4B generator in 4-bit), judge `granite-3.3-2b-instruct`, 8 PDFs, `baseline` (358 passages) against `mizan-lite+repair_lam_alef` (323 passages), temperature 0, one run. All numbers below are copied from the executed notebook; the notebook computes intervals only where stated.

**Retrieval, 51 LLM-generated questions (45 answerable; intervals on the 45):**

| measure | Standard | Mizan-lite | difference |
|---|---|---|---|
| hit@4 after reranking | 0.733 | 0.844 | **+0.111** [+0.022, +0.200] |
| gold passage among the top-20 candidates | 0.911 | 1.000 | **+0.089** [+0.022, +0.178] |
| first-stage hit@4 | 0.756 | 0.778 | +0.022 [−0.044, +0.089] n.d. |
| MRR | 0.578 | 0.646 | +0.069 [−0.030, +0.167] n.d. |
| precision@4 | 0.200 | 0.222 | +0.022 [−0.011, +0.056] n.d. |

**How this sits with sections 2 and 3:** the same kind of stack (4B embedder + reranker) gave −0.039 [−0.130, +0.065] on the 77 Ministry FAQ questions whose answers lie in the PDFs. The two question sets disagree in sign; the 45 here were written by an LLM of the same model family as the system, the 77 come from the Ministry's FAQ. We do not choose between them: the claim for strong stacks is "mixed", not "none".

**Efficiency, as measured here (lite, not the full preset):** retrieved tokens per query 974 → 899 (−7.7%); LLM input tokens 1,235 → 1,161 (−6.0%); output tokens 60 → 60; median latency retrieval 1.03 → 0.91 s, generation 5.68 → 5.37 s, end to end 6.69 → 6.29 s (no intervals computed; latency differences of this size were within noise in earlier runs). The earlier −19% input-token cut (section 6) was with the full preset in a different setup and must not be quoted for lite.

**Answer run, 10 hand-written questions (9 answerable, so every interval is too wide to mean much):** hit@4 1.000 vs 1.000; keyword coverage 0.889 vs 0.611 (−0.278 [−0.667, +0.056], n.d.); refused an answerable question 0.000 vs 0.111 (one question: r2, minimum age, evidence retrieved, the Mizan arm answered with the refusal sentence); one wrong Mizan answer (r1, "two years" where the reference and the Standard answer say three); one Mizan answer (r4) cited a regulation title instead of the file name. Judge "correct" 0.8 vs 0.8. **The small judge is unreliable**: it called the wrong r1 Mizan answer "correct, faithful" and the right r3 Mizan answer (1,000 riyals) "incorrect". So at the answer level the point estimates favour Standard on these ten questions and nothing is demonstrated either way; human grading is the only evidence that will count.

**Prompt versions (section 7b): same retrieved passages, lite arm, 61 questions (54 answerable, 7 unanswerable), one run:**

| metric | v1 | v2 | v3 | v4 |
|---|---|---|---|---|
| keyword coverage (answerable) | 0.753 | 0.747 | 0.769 | 0.762 |
| refused an answerable question | 0.019 | 0.019 | 0.056 | 0.019 |
| refused an unanswerable question | 1.000 | 1.000 | 1.000 | 1.000 |
| citations naming a retrieved page | 0.767 | 0.903 | 1.000 | 0.967 |
| non-refusals with a valid citation | 0.887 | 0.906 | 0.941 | 0.943 |
| answerable non-refusals citing the gold passage | 0.698 | 0.736 | 0.706 | 0.774 |
| input tokens / query | 1,076.6 | 1,226.6 | 1,175.6 | 1,296.6 |
| output tokens / query | 80.1 | 83.3 | 114.3 | 84.2 |
| median LLM latency, s (uncached) | 6.0 | 6.4 | 8.9 | 6.8 |
| possibly cut off | 3 | 2 | 2 | 2 |

Paired differences to v1 in keyword coverage: v2 −0.006 [−0.049, +0.046], v3 +0.015 [−0.059, +0.093], v4 +0.009 [−0.028, +0.056], all n.d.; refusals of answerable questions: v3 +0.037 [+0.000, +0.093], others +0.000.
**Reading:** answer coverage does not move; what moves is citation grounding. v1 cites a page that was not retrieved in about one citation in four (23%); v4 in about one in thirty (3%) and cites the gold passage most often (0.774 against 0.698), at about 20% more input tokens and 0.8 s more latency than v1. v3 is the most grounded but writes 43% more output, is 3 s slower and refuses more answerable questions. The citation differences have no intervals and correctness was not graded by people, so **v4 is the candidate, not yet the decision**: switch the default only after the blind sheet (`prompts-20261010-160638-grading-sheet.csv`, with its KEY) has been graded; otherwise keep v1 and state this limit.

**Other checks in the same run:** the human-grading sheets for the 10 answer questions were written (`results/colab_run4/grading_sheets/`; blank, nothing graded yet); the monitoring alert drill fired its two alerts ("no retrieved passage", "refused 100% of the last 6 questions, threshold 50%"; an in-notebook drill with a stub pipeline, so a real webhook or e-mail is still untested); wall-clock: 54.2 minutes in total, of which 37 minutes for the four prompt versions.

## 7. Fine-tuning (model adaptation), before and after [LOG]

LoRA on `Qwen3-Embedding-0.6B`, 556 LLM-generated pairs from six PDFs, evaluated on questions pointing only to two held-out PDFs. Titles on, retrieval only, 45 generated answerable questions:

| text / retrieval | hit@4 | MRR |
|---|---|---|
| untuned, raw text | 0.667 | 0.522 |
| untuned, cleaned (Mizan-full) text | 0.600 | 0.543 |
| tuned on raw text, applied to raw text | 0.644 | 0.548 |
| tuned, applied to cleaned text | **0.867** | 0.687 to 0.713 |

Tuned vs untuned embedder on cleaned text: hit@4 **+0.267 [+0.133, +0.422]**. With the reranker added the tuned-vs-untuned gap shrinks (the tuned embedder + cleaned text alone scores 0.867, reranked 0.822; n.d.). **Limits:** the pairs and test questions share one LLM family and style; 9 hand-written questions are the style-independent check (hit@4 0.667 → 0.889, 8/9 vs 6/9); one run; the PDF text used was the *full* preset's, not lite.

**Status of the adaptation experiment (2026-10-10).** `scripts/run_adaptation.py` makes it reproducible (map the 554 of 556 pairs onto Mizan-lite text, train 3 epochs with LoRA r=16, evaluate untuned vs tuned on held-out documents; notebook `Mizan_Web_Evaluation_Colab.ipynb` section 6d). Its leakage report, run on the real files: training uses 6 PDFs; the 45 generated and 9 hand-written questions all point only at the two held-out PDFs; **71 of the 77 Ministry FAQ questions touch a training document and are excluded**, leaving only 6 Ministry questions as independent evidence, so the style-independent held-out evidence is **15 questions** (9 hand-written + 6 Ministry FAQ). The experiment itself has **not been re-run on Mizan-lite text**: it needs a Colab GPU (about 15 minutes). The numbers in the table above are for the full-preset text.

## 8. What is not measured (do not claim)

- Answer correctness on the current corpora and any human-graded answer sample (section 6b has only keyword coverage, citation measures and an unreliable small judge, on 10 and 61 questions); the fine-tuning re-run on Mizan-lite text (run 4 produced no adaptation file).
- Anything about the 4B generator vs another generator, the effect of 4-bit quantization on quality or speed, LLM-stage latency under lite.
- Any untouched test set (see `FINAL_AUDIT.md` section 5).
- Whether results transfer to other corpora, to BM25/hybrid retrieval, or to long Arabic prose.
- Repeated seeds. Run-to-run noise on identical inputs was about one question; run 2 vs run 3 web numbers differ because the corpus differed, not because of noise.

## 9. Reproducibility

| Item | Value |
|---|---|
| Code | this folder (not under version control yet: `git init` and tag before submission) |
| Tests | `python -m pytest`: 112 passed (verified 2026-10-09, after adding the monitoring, prompt, citation, responsible-use, blind-set and grading tests) |
| Web corpus | `python scripts/fetch_web_corpus.py` into `data/web/raw/`; frozen local copy fingerprint `b3871676ff02…` = R2; `data/web/html_for_colab.zip` supplies the law and GASTAT pages when Colab cannot fetch them |
| PDF corpus | `python scripts/fetch_corpus.py`; fingerprint `c1b846432f4f…`; URLs and SHA-256 in `data/corpus_manifest.json` |
| Questions | `data/web/questions_faq.json` (250), `data/web/questions_pdf.json` (77, from `eval/pdf_faq_alignment.json`), `eval/questions.json` (10), `eval/questions_large.json` (51) |
| Settings per run | stored in every `results/eval-*.json` under `settings`, with corpus and question hashes and library versions |
| Libraries | `requirements-tested.txt` (local), `requirements-colab.txt` (Colab: Python 3.13.15, torch 2.11.0+cu130, transformers 5.18.0, sentence-transformers 5.7.0, chromadb 1.5.9) |
| Colab runs | web notebook run 4 times (R1 laws missing, R2 complete, R3 laws missing, R4 complete); the main notebook was executed once end to end on 2026-10-10 (M1, section 6b) |
| Known loss | the earlier per-question PDF ablation JSON files were deleted by mistake and are logged; `scripts/run_ablations.py` regenerates them |
