"""Gradio UI:  python app.py   ->  http://127.0.0.1:7860

The UI itself lives in src/ui.py (shared with the Colab notebook). This file only loads the documents,
builds the pipelines once and launches.
"""
from src.comparison import load_pipelines
from src.config import DEMO_PIPELINES, resolve_questions_path
from src.evaluation import load_questions
from src.ui import build_ui, launch_kwargs

if __name__ == "__main__":
    print("Loading documents and building both indexes ...")
    PAGES, PIPES, SYNTHETIC = load_pipelines(DEMO_PIPELINES)
    build_ui(PAGES, PIPES, load_questions(resolve_questions_path()[0], missing_ok=True), SYNTHETIC).launch(
        server_name="127.0.0.1", **launch_kwargs())
