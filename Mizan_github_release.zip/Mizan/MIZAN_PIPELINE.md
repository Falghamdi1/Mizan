# Mizan pipeline: current implementation and intended final system

> **The current architecture, configuration and open decisions are in `docs/FINAL_ARCHITECTURE.md`.** This file keeps the stage-by-stage status table; its diagram below predates the safety filter and the citation check, and its "52 tests" line is old (now 170).

Status key: **Complete** (works, tested or measured), **Partial** (works but evidence or a piece is missing), **Missing**, **Not needed** (deliberately out of the MVP). "Verified" means checked in the 2026-10-09 audit (52 tests pass; UI renders offline); anything involving real models is from earlier runs recorded in `docs/EXPERIMENT_LOG.md`.

The one idea the whole system is built around: **two pipelines that differ only in text preprocessing**, so any difference in retrieval or answers can be attributed to it.

```mermaid
flowchart LR
  subgraph Sources
    W[Web: FAQ, news, laws, GASTAT JSON/HTML]
    P[8 Ministry PDFs]
  end
  W --> L[web_corpus loaders]
  P --> I[PDF ingestion + lam-alef repair]
  L --> PG[Pages: doc, title, page, text]
  I --> PG
  PG --> PA[Standard: whitespace only] --> CA[Chunking 600/100] --> EA[Embeddings] --> VA[(Chroma: standard)]
  PG --> PB[Mizan-lite steps] --> CB[Chunking 600/100] --> EB[Embeddings] --> VB[(Chroma: mizan)]
  Q[Arabic question] --> QA[same preprocessing as its index] --> VA
  Q --> QB[same preprocessing as its index] --> VB
  VA --> RR[Reranker top-20 to top-4, Qwen models]
  VB --> RR
  RR --> PR[Prompt + passages with file/page headers] --> LLM[Same local LLM, temperature 0]
  LLM --> OUT[Answer with citations + measured tokens/latency]
  OUT --> UI[Side-by-side UI]
  OUT -.planned.-> MON[Query log + alert]
  EV[Evaluation: hit@k, MRR, tokens, paired intervals] -.reads.-> VA
  EV -.reads.-> VB
```

## Stage by stage

| # | Stage | Status | Where | Notes |
|---|---|---|---|---|
| 1 | Data ingestion and source tracking | **Complete** | `scripts/fetch_web_corpus.py`, `scripts/fetch_corpus.py`, `data/web/manifest.json`, `data/corpus_manifest.json`, `src/corpus.py` (`load_corpus`, `corpus_fingerprint`) | URL, date, bytes and SHA-256 per file; a corpus fingerprint stored in every result file. Selection by `MIZAN_CORPUS=pdf\|web\|all`. Colab cannot always reach the law and GASTAT sites: upload `data/web/html_for_colab.zip`. |
| 2a | HTML/JSON parsing | **Complete** (tested) | `src/web_corpus.py`: `parse_faq`, `parse_news`, `parse_definitions`, `parse_methodologies`, `parse_law`, `parse_gastat`, `load_web_corpus` | FAQ questions are never indexed (only answers), duplicates indexed once; one page per law article; cookie banners dropped. |
| 2b | PDF extraction | **Complete** | `src/ingestion.py`: `load_pdfs`, `repair_chars`, `load_pdf` | PyMuPDF; skips unreadable PDFs with a warning; repairs the reversed lam-alef ligature from glyph geometry (1,464 places). No OCR, tables flatten, displaced digits are not repaired (documented limits). |
| 3 | Arabic normalization / preprocessing | **Complete** | `src/preprocessing.py`: `PreprocessConfig`, `BASELINE`, `MIZAN`, `MIZAN_LITE`, `get_config`, `preprocess_text`, `strip_repeated_lines` | 15 named boolean flags in a fixed order, idempotent and deterministic (tested). Demo default: `mizan-lite+repair_lam_alef`. Scoring uses a separate fixed canonicalizer (`canonical_for_eval`). |
| 4 | Chunking and metadata | **Partial** | `src/chunking.py`: `chunk_pages`; `src/titles.py` | Sentence-based, 600 characters, overlap 100, never across a page; keeps doc, page, title. **Known confound:** size is in characters after cleaning, so the arms get different chunk counts. Titles come from a filename table (prototype shortcut), not read from the documents. Not article-aware. A token-budget chunker is *Not needed* for the MVP; state the confound. |
| 5 | Embedding generation | **Complete** | `src/embeddings.py`: `get_embedder` | e5-small, Qwen3-Embedding-0.6B or 4B, optional LoRA adapter, optional 4-bit; offline hash fallback for smoke tests only. |
| 6 | Vector database | **Complete** | `src/retrieval.py`: `build_index`, `search`, `drop_index` | Chroma, cosine, in memory by default (rebuilt each run). One collection per pipeline. `MIZAN_CHROMA_PERSIST=1` keeps it on disk. |
| 7 | Query processing | **Complete** | `src/rag.py` (`Pipeline.ask`) | The query goes through the same preprocessing function as its pipeline's documents; the LLM sees the user's original question. No query rewriting (*Not needed*: nothing measured points at query wording). |
| 8 | Retrieval and reranking | **Complete** | `src/retrieval.py`, `src/rerank.py`: `get_reranker` | Top-20 then Qwen3-Reranker-0.6B keeps 4. Justified by the log (lifts weak first stages; no gain on the strongest). The 4B reranker is untested (*Not needed*). No BM25 or hybrid (*Not needed*; named as a limitation). |
| 9 | Prompt construction | **Built; comparison not yet run on a real model** | `src/rag.py`: `PROMPTS` (v1, v2, v3), `system_prompt()`, `build_user_prompt`; `scripts/compare_prompts.py`; notebook section 7b; `tests/test_prompts.py` | Passages carry `[file, page N]` headers. v1 = the original text (byte-identical, tested); v2 = explicit rules; v3 = structured answer / evidence / source. Selected by `MIZAN_PROMPT` (default v1; recorded in every result file's settings and in the monitoring log). The script compares versions on the same retrieved passages and writes a blind human-grading sheet. **Which version is best is not known yet.** |
| 10 | LLM generation with citations | **Complete** (real-model run of the current code unverified) | `src/rag.py`: `call_llm`, `_generate`, `Pipeline.ask`, `LLMResult`; `src/local_llm.py`; `src/safety.py`; `src/citations.py` | Qwen3-4B-Instruct, 4-bit, temperature 0; providers `hf`, `ollama`, `mock` (plus `anthropic`/`openai` code never run). Passages with instruction-like text are withheld before the prompt is built (the standard refusal, no model call, if none is left). Citations requested in the prompt; `src/citations.py` checks each against the passages the model was *shown*. 31 earlier real-model answer runs: all 644 non-refusal answers cited something, 88.5% of citations named a shown page. |
| 11 | Evaluation and metrics | **Partial** | `src/evaluation.py`: `run_eval`, `load_questions`; `src/stats.py`; `src/ablation.py`; `scripts/*` | Retrieval metrics are strong (hit@k, MRR, precision, first-stage hit, candidate recall, tokens, paired bootstrap). Human grading: `scripts/human_grading.py` builds two blind sheets, reports kappa, adjudication, per-arm accuracy with a paired interval, and tests the judge and keyword score against the human labels; **no human grades exist yet**. Citation metrics are now scored per answer (`citation_present`, `citation_valid_share`, `invalid_citation`, `cites_gold`, `cites_gold_given_hit`; no LLM). **Missing on the current corpora:** answer-level runs with a real generator, a human-graded sample, an untouched test set (P2-1, P2-4). |
| 12 | Baseline vs Mizan comparison | **Complete** | `src/comparison.py`: `compare`, `load_pipelines`; notebooks | Identical in all but preprocessing (see README section 2). Both presets selectable by name. |
| 13 | Interactive UI and demo | **Complete** (verified in a browser with the offline embedder and mock generator; real-model run unverified) | `app.py`, `src/ui.py` (`build_ui` and the render functions), `src/backend.py` (`MizanBackend`, `ingest_pdfs`), `src/i18n.py`, `src/ui_style.py`; `demo.py`; notebook sections 8 and 8b (interface rewritten 2026-10-14: English/Arabic, dark/light) | Side-by-side cards with answer, evidence, sources, a citation row, a withheld-passages row, measured values (n/a when not measurable), responsible-use notices, upload note and warnings, monitoring panel with alerts. Wireframe and specs: `docs/NEEDS_ANALYSIS.md`. |
| 14 | Model adaptation, before/after | **Partial** (real fine-tune with logged before/after; clean re-run pending) | `finetune/` (`make_pairs`, `remap_pairs`, `train_lora`), `scripts/run_adaptation.py`, notebook `Mizan_Web_Evaluation_Colab.ipynb` section 6d | LoRA on Qwen3-Embedding-0.6B (554 of 556 pairs map onto Mizan-lite text; 6 training PDFs, 2 held-out PDFs). `run_adaptation.py` prints a leakage report and refuses to run if an evaluation question equals a training query; it found that only 15 style-independent held-out questions exist (9 hand-written + 6 Ministry FAQ). Logged result (full-preset text, generated questions): hit@4 0.600 to 0.867. **Re-run on Colab to regenerate it from a clean state.** |
| 15a | Error handling | **Complete** | `LLMError` with a one-line fix; PDF skip warnings; empty-retrieval guard; upload rejections with reasons; the UI shows a message, never a stack trace | |
| 15b | Monitoring and alerts | **Complete** (real-service delivery unverified) | `src/monitoring.py` (`Monitor`, `record`, `record_event`, `check_alerts`, `deliver`, `panel_html`), hook in `src/comparison.py`, panel in `src/ui.py`, notebook section 8b, `tests/test_monitoring.py` (15 tests) | One JSON line per answer, failure or event in `logs/queries.jsonl` (hashes, ids, tokens, latency; no text). Rules: errors, refusal rate, p95 latency, missing citations, empty retrieval, ingestion errors, security (withheld passages). Alerts to `logs/alerts.jsonl`, the screen and an optional webhook or e-mail. **Executed:** a test delivers a real HTTP POST to a local server; an unreachable webhook is recorded, not raised. **Not verified:** a real Slack/Discord URL, real SMTP. Evaluation runs are not logged. |
| 15c | Responsible AI (chosen advanced requirement) | **Complete** (model-level effects unverified) | `docs/RESPONSIBLE_AI.md` (13 risks, safeguards, 10 executed tests with outcomes, what is not implemented); `src/safety.py`; notices and rows in `src/comparison.py` and `src/ui.py`; prompt v4; monitoring `security` and `ingestion` rules | Injection scan (17 of 17 attacks, 0 of 3,819 real chunks flagged), withheld passages, no-model refusal, upload warnings (counts only), insufficient-evidence status per pipeline. **Not tested:** prompt v4 and text that passes the scan on a real model; no PII redaction; no auto-delete of uploads. |
| 15d | Reproducibility | **Complete** for the code path, **unverified** with real models | git repository with a first commit and a zip of the git-ignored outputs; fingerprints, settings and library versions in every result file; pinned requirements; 170 tests; both Colab notebooks executed top to bottom in a clean folder offline (47 and 54 code cells, 0 errors) | A guard test checks that each notebook writes every module it needs (it caught four real Colab crashes). One earlier result set was deleted by mistake and is logged. |
| 15e | Quantization | **Partial** | `src/local_llm.py` (`MIZAN_HF_QUANT=4bit`, NF4); `src/embeddings.py` | Used, not evaluated. Optional comparison (P2-5). |
| 15f | Deployment | **Missing** | none | *Not needed* for the core level. The Colab Gradio link is the fallback. |
| 15g | Mizan Insights (an LLM explains the evidence of one run, checked against the measured facts) | **Built and tested offline; checked with a real 4B model on a CPU only** (not on a GPU, not with the real embedder, not on Colab) | `src/insights_evidence.py`, `src/insights.py`, `src/backend.py` (`MizanBackend`), `src/ui.py` (`render_insights`), `tests/test_insights_evidence.py`, `tests/test_insights.py`, `tests/test_insights_session.py`, `docs/MIZAN_INSIGHTS.md` | Facts and the conclusions the evidence allows are computed by code; the model writes the explanation; replies that contradict the facts are rejected; no analysis is written without a configured generator; nothing is stored. |

## Intended final system (what to show on 14 October)

Same as the current system plus four additions, each small:

1. **Monitoring** (built, see stage 15b): every answer shown through `compare` writes one JSON line (time, pipeline, question hash, retrieved doc/page ids, top score, tokens, retrieval/LLM latency, refused?, citations valid?). A monitor computes rolling refusal rate, p95 latency, empty-retrieval count and citation-validity rate, and raises **one automatic alert** (console banner in the UI, plus a webhook or email if configured in `.env`).
2. **Prompt versions**: `PROMPTS = {"v1": current, "v2": ..., "v3": ...}`; the comparison table and the reason for the final choice go into the slides.
3. **Citation check**: parse `[file, page N]` from the answer and test it against the retrieved passages; report the rate.
4. **Fine-tuning evidence in the notebook**: train or load the LoRA adapter on lite text and print the before/after table on held-out documents with human-written questions.

Not added: BM25/hybrid, query rewriting, a new chunker, the 4B reranker, a recipe-recommender for uploads, a hosted deployment.

## Data flow of one request (for the technical-design sequence diagram)

User → UI (`render_comparison`) → for each pipeline: `Pipeline.ask(question)` → preprocess query → `retrieval.search` (top 20) → `rerank` (top 4) → `build_user_prompt` → `call_llm` (cache check, generate) → `RAGResult` (answer, sources, tokens, latencies) → monitoring log → UI renders both columns with passages, citations and measured values. Inputs: Arabic text question. Outputs: Arabic answer with `[file, page N]` markers, the retrieved passages, and numbers measured in that call.
