# Final checklist: how to run everything, in order, and what is still unverified

Written 2026-10-10. Deadlines: **Sun 11 Oct** Submission 2; **Wed 14 Oct** final (presentation, demo, source code, README, one-page individual report each). Steps marked **[Colab]** need a T4 GPU runtime; **[local]** run on a laptop; **[people]** need teammates. Task owners are in `TEAM_HANDOFF.md`.

## A. Reproduce the repository state (local, 5 minutes)

```bash
git clone <repo> && cd Mizan                       # or unzip
pip install -r requirements.txt                    # pinned versions that produced the results: requirements-tested.txt (local) / requirements-colab.txt
cp .env.example .env                               # no key is needed for the local models
python scripts/fetch_corpus.py                     # the 8 public PDFs into data/raw/ (URLs and SHA-256 in data/corpus_manifest.json)
python scripts/fetch_web_corpus.py                 # the JSON/HTML web corpus into data/web/raw/ (keep local: licence)
python scripts/make_faq_questions.py --check       # 250 FAQ questions; every gold phrase checked
python scripts/make_pdf_questions.py               # 77 FAQ-in-PDF questions
python -m pytest tests                             # expect: 407 passed
python scripts/profile_data.py                     # data profile -> docs/data_audit/profile.*
python scripts/token_analysis.py                   # token analysis -> docs/data_audit/token_analysis.*  (downloads two tokenizer files, a few MB)
```

If the law and GASTAT pages time out (they did on 2 of 3 Colab runs and on a laptop), use the frozen copy: `data/web/html_for_colab.zip`. **Check the corpus fingerprint** printed in the result files: the complete web corpus is `b3871676ff02…`; a run with another fingerprint is not comparable.

## B. Colab sessions, in this order (one Colab account at a time)

1. **[Colab] `Mizan_Web_Evaluation_Colab.ipynb`**, Runtime → T4, Run all. Upload `html_for_colab.zip` when asked. About 2 to 3 hours with the 4B embedder. It produces, in `results/` and `mizan_web_results.zip`: section 4 (three embedders, web), 5b (77 PDF questions), 6 (ablations), **6c** (baseline vs full Mizan vs Mizan-lite, plus a leave-one-out), **6d** (LoRA adaptation, before/after, with leakage report, about 15 minutes), **6e** (the frozen blind set, once it exists). Switches at the top of each section skip the slow parts (`RUN`, `RUN_ABLATIONS`, `RUN_LITE`, `RUN_ADAPTATION`, `RUN_BLIND`).
2. **[Colab] `Mizan_Arabic_RAG_Optimization.ipynb`**, Run all. About 1 to 2 hours. It builds both pipelines, the answer run with the real Qwen3-4B generator and the judge, **7b** (prompt versions v1 to v4 on the same passages, blind grading sheet), **7c** (human grading sheets, zip), **8** (the demo UI), **8b** (monitoring panel and an alert drill), conclusions generated from the measured numbers. Save the executed notebook to `results/final/`.
3. **[people]** Grade the sheets (two people, `eval/human_grading/RUBRIC.md`), then `python scripts/human_grading.py merge <folder> --grader1 g1.csv --grader2 g2.csv`.
4. Rebuild the notebooks **after** the blind set is frozen: `python scripts/build_web_notebook.py` (it includes the frozen files and hashes when they exist), then rerun section 6e once.

Offline smoke tests of both notebooks (hash embedder, mock generator, no downloads) already pass: 47 and 54 code cells, 0 errors. **Do not run a notebook locally without disabling downloads**: the main notebook downloads 8 GB of models on any machine (one local run did; the files were deleted).

## C. Launch the application

- **Laptop (8 GB GPU, Ollama):** `ollama pull qwen3:4b-instruct-2507-q4_K_M`, then `python app.py` → http://127.0.0.1:7860 (index build about 40 s at start). Demo configuration is the checked-in `.env`; `MIZAN_PIPELINES=baseline,mizan-lite+repair_lam_alef`; leave `MIZAN_EMBEDDING_ADAPTER` empty unless an adapter trained on lite text exists.
- **Colab:** section 8 of the main notebook launches the same interface (public link only for the session).
- **Without models (UI work, rehearsing the layout):** `MIZAN_EMBEDDER=hash MIZAN_LLM_PROVIDER=mock python app.py` (labelled with a "Mock LLM" banner).

## D. Final demo sequence (60 seconds; details and the question-selection rule in `DEMO_SCRIPT.md`)

1. Header: "Same documents. Same questions. Same model. Different preprocessing."
2. The fee question: Standard retrieves the table with the damaged ligature (`ثالث سنوات`), Mizan with `ثلاث سنوات` (seen in the real app on 2026-10-10 with the offline embedder; re-check with the real models).
3. Evidence check, sources, tokens (only what is measured), the citation row.
4. A question outside the documents: refusal tag, "nothing cited".
5. Monitoring panel; show the alert if five out-of-scope questions were asked.
6. One sentence of honest scope: weak embedders on damaged PDFs gain; strong embedder plus reranker and clean text do not.

## E. Submission requirements (from the brief) and where each is

| Requirement | Where |
|---|---|
| Source code with clear folders: data preparation, models, RAG, application, evaluation | `scripts/`, `src/web_corpus.py` (data); `finetune/`, `src/embeddings.py` (models); `src/rag.py`, `retrieval.py` (RAG); `app.py`, `src/ui.py` (application); `src/evaluation.py`, `eval/` (evaluation) |
| README as a tutorial: what it does, install and run, architecture, how to reproduce | `README.md` |
| Pinned library versions; no keys or passwords | `requirements-tested.txt`, `requirements-colab.txt`; `.env.example` has empty key fields; `.env` is git-ignored |
| Data sources and licences named; no personal data without permission | README table; `docs/DATA_AUDIT.md` Q7; tourism.sa permission written permission requested and approved (team record; the approval e-mail is kept by the team) |
| A test set never used for training or for choosing settings | `eval/blind_test/` (kit built; **questions still to be written**) |
| Honest reporting including what did not work | `docs/EXPERIMENT_LOG.md`, `EXPERIMENT_RESULTS.md` sections 8 and 5b |
| AI assistant disclosure | README section "AI assistants used" |
| Final presentation (Template 3) with numbers against a baseline, adaptation effect, monitoring, responsible AI, demo, lessons | slides from `EXPERIMENT_RESULTS.md`, `docs/RESPONSIBLE_AI.md` |
| Individual one-page report from each student | template and guide in `docs/individual_report/` (`INDIVIDUAL_REPORT_TEMPLATE.docx`, `GUIDE.md`); **each person writes theirs** |

Targets to state in Submission 2 (**targets, not results**): hit@4 for Mizan-lite at least +0.10 over Standard on the PDF questions with a weak embedder (measured on the development set: +0.234); no loss worse than −0.02 on clean web text (measured: within noise); at least 25% fewer index tokens on damaged PDFs (measured: 32% to 42%); refusal on at least 90% of unanswerable test questions (6 of 6 in the early set: tiny); valid citations at least 90% (measured retroactively: 88.5% of citations, 8.2% of answers cite a page not shown); fine-tuned embedder at least +0.10 hit@4 on human-written held-out questions (measured +0.267 on generated questions); alert fires within one query of a threshold being crossed (tested).

## F. Day by day

- **Sat 10:** Person 2 collects the blind questions by noon; Person 3 builds the Submission 2 deck and sends the permission email; Person 1 runs the main notebook on Colab (item B2) and starts the webhook test.
- **Sun 11:** Submission 2. Afterwards Person 1 runs 6d (adaptation); everyone else writes individual reports.
- **Mon 12:** `make_blind_test.py --build`, rebuild the web notebook, run 6e once; human grading; update `EXPERIMENT_RESULTS.md` from files; demo rehearsal with real models; Responsible AI pre-demo tests.
- **Tue 13:** freeze (tag, zip), no code changes except UI bugs; record the fallback video; rehearse twice with a timer; proofread every number against `EXPERIMENT_RESULTS.md`.
- **Wed 14:** start the Colab runtime early; submit code, README, reports, slides; present.

## G. Still unverified (do not claim)

**Verified on 2026-10-10 (Colab T4, `EXPERIMENT_RESULTS.md` sections 3 and 6b):** the main notebook runs end to end with the real embedder, reranker and generator (48 of 48 cells, 54 minutes); the web notebook reran on the complete corpus (run 4); the prompt versions were compared on 61 questions.

**Mizan Insights, verified on 2026-10-11/12 (local, no Colab):** 147 offline tests on the evidence layer, the checks, the session and the screen (all 395 tests pass); 19 hand-run invocations with a local `qwen3:4b-instruct` model on the real 159-page corpus (offline hash embedder, no reranker), among them an uploaded Arabic PDF and the Gradio app over HTTP; 10 validated panels, 8 failed states, 1 crash of the test script, on code that changed during the series. Details and what the checks cannot catch: `docs/MIZAN_INSIGHTS.md` sections 12 and 13.

**Still unverified:** the LoRA adaptation on Mizan-lite text (no 6d output yet); whether prompt v4, or any prompt, resists injected instructions on a real model, and what a real model does with text that passes the injection scan; real e-mail and webhook delivery; the blind-set results (the questions are not written); human-graded answer quality (sheets exist for 10 answer questions and for the 61-question prompt comparison; nothing is graded); the tourism.sa permission; the cost of quantization to answer quality.

**Mizan Insights, still unverified:** a run with the Colab stack or with any model other than the local 4B; Arabic panel text with a real model; the panel at phone width and with a screen reader; whether people find the generated explanations right and useful (nobody has graded them); the failure rate of the final code with a real model (two runs after the last change, both validated); the regenerated notebooks on Colab.


## H. The final evidence, in order (added 2026-10-10 after run 4; rules in `docs/ANALYSIS_PLAN.md`)

The analysis plan was committed before any blind question existed. Its decision rules cannot be changed after the blind set is frozen.

| step | who | how | produces |
|---|---|---|---|
| 1 | each of the three | `python scripts/make_blind_form.py`, write 15 to 20 questions, download the CSV; a teammate reads 5 rows; `python scripts/make_blind_test.py --check yourfile.csv` | `eval/blind_test/<name>.csv` |
| 2 | Person 2 | `python scripts/make_blind_test.py --build` then `--verify`; commit the frozen files | frozen blind set and `FROZEN.json` |
| 3 | two graders, alone | open `tools/grading_form.html`, grade the prompt sheet `prompts-20261010-160638-grading-sheet.csv`, export; Person 2 runs `python scripts/human_grading.py merge ...` | `human_grading_report.json` |
| 4 | Person 1 | `python scripts/decide_prompt.py --prompts results/prompts-20261010-160638.json --grading <report>.json --accept-cost`; commit `docs/PROMPT_DECISION.md` | the prompt for the final run |
| 5 | Person 1 | upload `Mizan_Final_Colab.ipynb` to Colab (T4), set `PROMPT`, Run all, upload the three frozen files when asked | P1 to P5 and the blind answer sheets, `mizan_final_results.zip` |
| 6 | two graders, alone | grade `results/grading_pdf` and `results/grading_web` (`grader_1.csv`, `grader_2.csv`; never `KEY.json`) with the form | P3 |
| 7 | Person 2 | update `EXPERIMENT_RESULTS.md` and the slides from the files; log deviations | final numbers |

Status of the five weaknesses named on 2026-10-10:

| weakness | what is fixed | what is still open |
|---|---|---|
| adaptation re-run missing | one-shot blind test added to `scripts/run_adaptation.py` (`--blind`), log and clear failure message, memory release, a dedicated final notebook; leakage and freeze checks | the run itself (Colab) and the blind questions |
| no untouched test set | analysis plan pre-registered; blind kit, form and checks ready | the 45 to 60 questions must be written and frozen by people |
| no human grading | grading form, blind sheets, merge with kappa | two people must grade (10-question sheet, prompt sheet, blind answers) |
| mixed strong-stack effect | decided by the human-written blind set only; generated questions exploratory; no pooling | the blind run |
| prompt default v1 misses 90% | decision rule fixed in advance and applied by `scripts/decide_prompt.py` | grading the prompt sheet |
