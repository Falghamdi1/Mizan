# Design choices: services and tools examined, chosen, rejected (core requirements 2 and 4)

Each row says what was **measured** (with its source), what was **decided by constraint or reasoning** without a test, and what was **not examined**. Constraint from the brief and the team: local open models, no API key, free Colab T4 or a laptop with an 8 GB GPU, nothing trained from scratch.

## 1. Models and services compared

| Component | Options | What we did | Measured evidence | Chosen | Rejected or not examined, and why |
|---|---|---|---|---|---|
| Embedding model | multilingual-e5-small; Qwen3-Embedding-0.6B; Qwen3-Embedding-4B | all three run on the same corpora and questions (Colab runs 2 and 3) | hit@4 on 250 web questions: 0.508 / 0.616 / 0.636; on 77 PDF questions: 0.312 / 0.623 / 0.701 (Standard text, with reranker for the Qwen rows). Download: 0.1 / 1.2 / about 8 GB; the 4B needs a 16 GB GPU or 4-bit loading | **Qwen3-Embedding-0.6B** for the demo and fine-tuning (fits an 8 GB GPU and the Colab T4); the 4B only as a comparison row; e5-small as the weak-model row where preprocessing matters most | Hosted embedding APIs (OpenAI, Cohere): excluded by the no-API rule, not tested. bge-m3: considered in the plan, not run (time) |
| Reranker | none; Qwen3-Reranker-0.6B (top-20 → top-4) | on/off comparison on the same questions | with the reranker, weak first stages gain +0.09 to +0.18 hit@4 (paired intervals above zero); no gain on the strongest first stage; candidate count N=10, 20, 30 indistinguishable (log) | **0.6B reranker, N=20** in the evaluation notebook; it adds 0.6 to 0.9 s of retrieval latency | 4B reranker: not run (memory, time) |
| Generator | Qwen3-4B-Instruct-2507, 4-bit (about 2.4 GiB) | used in every answer run | answers and refusal behaviour recorded in the log; 4-bit vs 16-bit quality **not measured** | **Qwen3-4B-Instruct-2507** (Ollama locally, in-process `transformers` on Colab) | Hosted LLMs (GPT, Claude, Gemini): excluded by constraint, the Anthropic/OpenAI providers exist in `src/rag.py` but were never run. Larger local models: do not fit the T4 with the embedder, reranker and judge loaded. No other 4B-class generator was compared |
| Judge for answer quality | Qwen3-4B (same as generator); Gemma 3 4B; Granite 3.3 2B | Qwen and Gemma compared on identical answers by hand | Gemma judged every non-refusal answer correct (41 of 41 and 33 of 33), kappa 0.00; Qwen disagreed on 8 cases and was right on the clear ones; Granite was used in the main notebook but never validated | **No LLM judge is trusted.** Correctness is graded by two people (`scripts/human_grading.py`), which also tests the judges | Any score from the three judges is reported as unvalidated |
| Generation backend | Ollama; Hugging Face in-process; hosted | Ollama on the laptop, in-process `hf` on Colab (no daemon there) | Colab run of the web notebook: 124.6 min on a T4 | both local backends behind one `call_llm` | hosted: excluded |
| Vector database | Chroma; FAISS; pgvector/Qdrant/Weaviate | Chroma used throughout | 358 to 1,569 chunks per index: any store is fast enough (retrieval 13 ms for e5-small) | **Chroma**, in memory, cosine, one collection per pipeline (no server to run; optional persistence) | FAISS, pgvector, Qdrant: not tested; a server or extra build step buys nothing at this corpus size |
| PDF reader | PyMuPDF; pdfminer/pypdf; Docling; Marker | PyMuPDF only | its `rawdict` glyph geometry made the lam-alef repair possible (1,464 ligatures); extraction damage still present (tables flatten, displaced digits) | **PyMuPDF** | Docling and Marker (PDF to Markdown with tables): named in the mentor questions, **not tested**; listed as the first next step |
| Preprocessing | the 15 flags of `src/preprocessing.py` | ablations: add-one, leave-one-out, full vs lite | kashida removal is the one step that matters (leave-one-out, e5-small: −0.195 [−0.299, −0.091] without it) | **Mizan-lite** | spelling folds and line operations: no benefit and some harm (see `docs/DATA_AUDIT.md` Q4) |

## 2. Tools (frameworks and libraries) and why

| Need | Tool | Why this one | Alternative not used |
|---|---|---|---|
| Embeddings, reranking | `sentence-transformers`, `transformers` | the same module is used for inference and for LoRA training, so train and test embeddings match (tokenizer, left padding, last-token pooling, query instruction) | LangChain / LlamaIndex embedding wrappers: they hide the exact steps; this project's claim depends on changing one step |
| Fine-tuning | `peft` (LoRA), plain PyTorch loop | a few small adapter files (about 40 MB), runs on the free T4 (about 100 steps) | full fine-tuning (does not fit), QLoRA (only needed above about 3B parameters; the 0.6B model does not need it), alignment/DPO (the measured problem is retrieval, not answer preference) |
| Vector search | `chromadb` | see above | FAISS |
| Orchestration | explicit Python (`src/rag.py`) | the experiment needs each stage visible and identical for both pipelines; about 300 lines | LangChain, LlamaIndex: more code to audit, hidden defaults that would change both arms differently |
| Interface | Gradio | runs inside Colab and on a laptop with the same code (`src/ui.py`), shows the side-by-side comparison with little code | Streamlit, a web framework: more work, no benefit for the demo |
| Statistics | own paired bootstrap (`src/stats.py`, 12 lines, tested against hand-worked cases) | transparent, seeded, no dependency | SciPy bootstrap |
| Tests | `pytest (170 tests) | | |
| Monitoring | `src/monitoring.py` (log file, rules, webhook/e-mail) | no external service, no credentials, privacy by default | Prometheus/Grafana, hosted monitoring: unnecessary for a prototype, adds services |

## 3. Not examined (said plainly)

Docling/Marker/pdfminer; bge-m3; a second 4B generator; 4-bit versus 16-bit answer quality; FAISS and server-based vector stores; hosted APIs (excluded by the brief's local-model constraint); BM25 or hybrid retrieval (the preprocessing effect is expected to be largest there; listed as the first retrieval extension).
