# Individual report: guide

The brief asks each student for **one page**: what you personally did, which requirements you covered, and what you would improve. Assessment is individual, so the report is also your answer sheet for the Q&A: whatever you write, you must be able to explain and show.

**Template:** `INDIVIDUAL_REPORT_TEMPLATE.docx` (A4, one page when filled; regenerate with `python scripts/make_report_template.py`). Delete the grey instructions. About 350 to 450 words. English or Arabic; the headings are bilingual.

## Rules

1. **Claim only what you did.** Use "I" for your own work and "with X" for shared work. Teammates will read each other's reports; the trainers will compare them with the repository.
2. **Every claim names evidence**: a file, a function, a section of a document, a table, a screenshot. If you cannot point at it, leave it out.
3. **Honest limits.** The brief rewards honest reporting; a neutral or negative result you handled well is better than a hidden one.
4. **Numbers come from files**, exactly as in `EXPERIMENT_RESULTS.md`; never from memory.
5. **AI assistants:** say which you used for your part and for what (the brief requires the README to disclose it; the repository's README does so for the shared code).
6. **Do not copy a teammate's sentences.** The three reports should be recognisably different.

## What you may truthfully claim, by area (pick only your own)

This is a menu of work that exists in the repository, with its evidence. It is not a list of who did what: decide that among yourselves, and tick only what you did or checked yourself.

| Area | Work items | Evidence |
|---|---|---|
| **RAG and system** | ingestion and chunking; embeddings and the Chroma index; retrieval and reranking; the safety filter; generator integration and prompt versions; citation check; monitoring and alerts; LoRA adaptation run; Colab runs of the notebooks; version control and freeze | `src/rag.py`, `src/retrieval.py`, `src/safety.py`, `src/monitoring.py`, `src/citations.py`, `finetune/`, `scripts/run_adaptation.py`; `tests/test_safety.py`, `test_monitoring.py`, `test_retrieval_recovery.py`; `results/final/` |
| **Arabic NLP and evaluation** | preprocessing steps and ablations; Mizan-lite; data profile; token analysis; question sets and the blind set; metrics and their hand-worked tests; human grading; failure analysis; results documents | `src/preprocessing.py`, `scripts/profile_data.py`, `scripts/token_analysis.py`, `scripts/make_blind_test.py`, `scripts/human_grading.py`, `tests/test_metrics_manual.py`; `docs/DATA_AUDIT.md` Q1 to Q9; `EXPERIMENT_RESULTS.md` sections 3 to 5b |
| **UI, demo and product** | the Gradio interface and its notices; wireframes and specifications; Submission 2 and 3 decks; demo script and video; Responsible AI document and pre-demo tests; README as a tutorial; the Ministry permission request | `src/ui.py`, `src/comparison.py`, `docs/NEEDS_ANALYSIS.md`, `docs/RESPONSIBLE_AI.md`, `docs/DESIGN_CHOICES.md`, `DEMO_SCRIPT.md`, `docs/PERMISSION_REQUEST.md`, `README.md` |
| **Shared** | the blind questions (each person writes their own); grading answers; reviewing the PDF alignment of a teammate's work | `eval/blind_test/<name>.csv`; the grading sheets; `eval/pdf_faq_alignment.json` |

## The 15 requirements of the brief and where their evidence is

| # | Requirement | Evidence in the repository |
|---|---|---|
| 1 | Needs analysis | `docs/NEEDS_ANALYSIS.md` |
| 2 | Comparison of existing services | `docs/DESIGN_CHOICES.md` section 1 |
| 3 | Prompt engineering | `src/rag.py` `PROMPTS`; `scripts/compare_prompts.py`; notebook section 7b |
| 4 | Tool selection | `docs/DESIGN_CHOICES.md` section 2 |
| 5 | Domain data analysis | `docs/DATA_AUDIT.md` |
| 6 | Data preprocessing | `src/preprocessing.py`; `EXPERIMENT_RESULTS.md` sections 3 to 5 |
| 7 | Embeddings and vector database | `src/embeddings.py`, `src/retrieval.py` |
| 8 | Retrieval-augmented generation | `src/rag.py`, `src/citations.py` |
| 9 | Monitoring | `src/monitoring.py`; `tests/test_monitoring.py` |
| 10 | Evaluation | `src/evaluation.py`; `EXPERIMENT_RESULTS.md`; blind set; human grading |
| 11 | Interactive application | `app.py`, `src/ui.py` |
| 12 | Model adaptation | `finetune/`, `scripts/run_adaptation.py`; notebook section 6d |
| A1 | Quantization | `src/local_llm.py` (4-bit loading; its cost not measured) |
| A2 | Deployment | not done |
| A3 | Responsible AI | `docs/RESPONSIBLE_AI.md`; `src/safety.py` |

Current status of each (met, partial) is in `FINAL_AUDIT.md`; do not describe a partial requirement as complete.

## A skeleton to fill (shape only; the content must be yours)

1. *I built / ran / wrote / reviewed [specific thing] ([file or result]).* (4 to 6 of these)
2. Table: *Requirement | what I did for it | evidence* (3 to 5 rows).
3. *What did not work:* one result or problem, what I did about it, what remains unverified in my part.
4. *I would improve:* the next experiment or missing evidence, and why it matters.
5. *I learned:* one technical and one methodological lesson.
6. AI assistants line and the declaration.

## Be ready to explain (any of these may be asked, about any part)

Why kashida matters (12.3% of the PDFs' characters, about 30% of their tokens) and what Mizan-lite keeps and drops; what a paired interval is and why "not distinguishable from zero" is not "equal"; why the headline gain is for a weak embedder and why a reranker hides it; what was fine-tuned, on what, and which documents were held out; what the blind set is and why it is used once; what the monitor alerts on and what the injection filter does and does not do; why the token saving is real for the generator's input but not shown to lower latency; what the project does **not** show (answer quality by humans, strong embedders, clean text, other corpora).
