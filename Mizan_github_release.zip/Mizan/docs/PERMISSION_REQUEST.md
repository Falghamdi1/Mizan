# Permission request to the Ministry of Tourism

**Status (2026-10-13): sent and approved** (team record; the approval e-mail is kept by the team). The draft below is kept for reference.

**Status: drafted 2026-10-10, not sent.** Send it from your own account, then record the date in the README sources table and keep the reply (or the lack of one) in the repository folder `docs/`.

**Where to send.** The earlier data audit recorded the Ministry's data desk address `DataDesk@mt.gov.sa` (it appears in an FAQ answer on tourism.sa) and the contact form at `tourism.sa/ar/ucc/new-case`. I could not re-check either today: open the form or the FAQ page once and confirm before sending. Use the long email below by e-mail and the short version in section 4 if the form has a character limit.

**Fill in before sending:** your full names, a reply address and phone, the course supervisor's name if they agree to be named (the mentor م. ريم: only name her if she knows and approves), and the date.

**What this request covers, and what it does not.** It covers the tourism.sa content and the 8 regulation PDFs only. GASTAT states open reuse with attribution (cite it in the README). The Bureau of Experts laws are a separate site with terms that have not been checked: read its terms page, or send a similar short note, if you want to quote them.

---

## 1. Email in Arabic (primary)

**الموضوع:** طلب إذن استخدام محتوى منشور لوزارة السياحة في مشروع تدريبي أكاديمي غير تجاري

السادة وزارة السياحة، مكتب البيانات (Data Desk)

السلام عليكم ورحمة الله وبركاته،

نحن ثلاثة متدربين في برنامج «هندسة تطبيقات الذكاء الاصطناعي التوليدي» في أكاديمية طويق: [الاسم الأول]، [الاسم الثاني]، [الاسم الثالث]. نعمل على مشروع التخرج «مِيزان (Mizan)»، وهو تجربة بحثية تقيس: هل تحسّن خطوات المعالجة المسبقة للنص العربي (مثل إزالة التطويل وإصلاح الحروف المتضررة عند استخراج النص من ملفات PDF) جودة البحث عن المعلومات في أنظمة الإجابة عن الأسئلة المعتمدة على الاسترجاع (RAG)؟ اخترنا محتوى الوزارة لأنه عربي رسمي وموثوق ويمثّل حالة واقعية.

**المحتوى الذي نطلب الإذن باستخدامه:**
1. من موقع tourism.sa: الأسئلة الشائعة (256 سؤالًا وجوابًا)، والأخبار (152 خبرًا)، وصفحة تعريفات السياحة، وصفحة منهجيات السياحة.
2. ثماني وثائق منشورة بصيغة PDF في بوابة لوائح الوزارة: لائحة مرافق الضيافة السياحية، ولائحة إدارة مرافق الضيافة السياحية ودليل خدماتها، ولائحة الإرشاد السياحي، ولائحة تأشيرة الباقات السياحية، ولائحة خدمات السفر والسياحة ودليل خدماتها، ولائحة الاستشارات السياحية.

**كيف حصلنا على المحتوى وكيف نستخدمه:**
- حمّلنا النصوص مرة واحدة، آليًا، من الصفحات والواجهات العامة للموقع دون تسجيل دخول، ونحتفظ بنسخة محلية فقط (على أجهزتنا وفي جلسة Google Colab المؤقتة).
- نعالج النصوص بنماذج مفتوحة المصدر تعمل محليًا، ولا نرسل النص إلى أي خدمة خارجية.
- نقسّم النص ونفهرسه، ونستخدم أسئلة الوزارة الشائعة كأسئلة لتقييم دقة الاسترجاع، ونقارن بين طريقتين للمعالجة المسبقة.
- لا نستخدم بيانات شخصية. استخدامنا تعليمي غير تجاري.
- لا ننشر النصوص الكاملة ولا نعيد توزيعها ولا نضعها في مستودع عام. ما سيظهر في العرض النهائي والتقرير هو الأرقام والنتائج ومقتطفات قصيرة جدًا مع ذكر المصدر.

**ما نطلبه من فضلكم:**
1. إذنًا كتابيًا بنسخ هذا المحتوى وتخزينه ومعالجته لغرض هذا المشروع التدريبي غير التجاري.
2. إذنًا باقتباس مقتطفات قصيرة منه مع الإسناد إلى الوزارة في العرض النهائي والتقرير وعرض تجريبي مباشر.
3. إفادتنا بصيغة الإسناد التي تفضّلونها.
4. إن كانت هناك قيود على إعادة استخدام أي جزء، أو قناة رسمية أنسب للحصول على هذه البيانات (واجهة برمجية أو ملفات)، فنرحّب بتوجيهكم.

**التزاماتنا:** نحذف النسخ المحلية فور طلبكم أو خلال 30 يومًا من انتهاء المشروع، ونوضح في المشروع مصدر كل بيان وأنه من إنتاج الوزارة، ويسعدنا أن نشارككم نتائج التجربة إن رغبتم.

موعد التسليم النهائي لمشروعنا هو 14 أكتوبر 2026، ولذلك نقدّر لكم الرد قبل ذلك إن أمكن. وإلى حين وصول إذنكم لن ننشر أي نص من المحتوى.

شاكرين لكم وقتكم وتعاونكم،

[الاسم الكامل]
[البريد الإلكتروني] | [رقم الجوال]
أكاديمية طويق، برنامج هندسة تطبيقات الذكاء الاصطناعي التوليدي

---

## 2. Email in English (same content; send together with the Arabic or on request)

**Subject:** Request for permission to use published Ministry of Tourism content in a non-commercial training project

Dear Ministry of Tourism Data Desk,

We are three trainees on the Generative AI Application Engineering bootcamp at Tuwaiq Academy: [first name], [second name], [third name]. Our capstone project, *Mizan*, is a research experiment that tests whether Arabic text preprocessing (for example removing kashida and repairing characters damaged when text is extracted from PDFs) improves retrieval quality in retrieval-augmented generation (RAG) systems. We chose Ministry content because it is official, reliable Arabic text that represents a realistic case.

**Content we ask permission to use**
1. From tourism.sa: the FAQ (256 question-and-answer pairs), the news items (152), the tourism definitions page and the tourism methodology page.
2. Eight documents published as PDF on the Ministry's regulations portal: the regulations for tourism accommodation facilities, management of tourism accommodation facilities (with its service directory), tour guiding, tourist package visas, travel and tourism services (with its service directory), and tourism consultation.

**How we obtained and use it**
- We downloaded the text once, automatically, from the site's public pages and public data endpoints without logging in, and keep a local copy only (our own machines and a temporary Google Colab session).
- We process it with open-source models that run locally; the text is not sent to any external service.
- We split and index the text, use the Ministry's own FAQ questions as evaluation questions, and compare two preprocessing methods.
- We use no personal data. The use is educational and non-commercial.
- We do not publish or redistribute the full texts or put them in a public repository. The final presentation and report show numbers, results and very short excerpts with their source.

**What we ask**
1. Written permission to copy, store and process this content for this non-commercial training project.
2. Permission to quote short excerpts with attribution to the Ministry in the final presentation, the report and a live demonstration.
3. The attribution wording you prefer.
4. If any part has reuse restrictions, or if there is an official channel better suited to obtaining this data (an API or files), we would welcome your guidance.

**Our commitments:** we will delete the local copies on your request or within 30 days after the project ends, we credit the Ministry as the source of every item, and we would be glad to share the results with you.

Our final submission is on 14 October 2026, so we would appreciate a reply before then if possible. Until we have your permission we will not publish any of the text.

Thank you for your time and help.

[Full name]
[Email] | [Phone]
Tuwaiq Academy, Generative AI Application Engineering bootcamp

---

## 3. Before you send (checklist)

- [ ] Placeholders filled; all three names agreed; the address or form confirmed on tourism.sa.
- [ ] Do not attach any downloaded text. Attach nothing, or only this letter as a PDF.
- [ ] Keep the paragraph "how we obtained it": it states honestly that the download was automatic from public endpoints. Do not rephrase it to hide that; the Ministry may ask.
- [ ] After sending: write the date in the README sources table (the status line currently reads "written permission not yet obtained (request to be sent)").
- [ ] **If there is no reply by 14 October** (likely): keep the data local and git-ignored as it is now, present only numbers and very short excerpts with attribution, and say on the slide "permission requested on [date], no reply yet". Do not say or imply permission was granted.
- [ ] If they say no or restrict use: delete `data/web/` and any copies in Colab, keep the results that contain no text, and state the restriction in the README.

## 4. Short version for the website form (Arabic, about 110 words)

نحن ثلاثة متدربين في أكاديمية طويق نعمل على مشروع تخرج بعنوان «مِيزان» يختبر أثر المعالجة المسبقة للنص العربي على جودة البحث في أنظمة RAG. نطلب إذنًا كتابيًا باستخدام محتوى منشور لوزارة السياحة لأغراض تعليمية غير تجارية: الأسئلة الشائعة والأخبار وصفحتي التعريفات والمنهجيات على tourism.sa، وثماني لوائح منشورة بصيغة PDF. نحتفظ بنسخة محلية فقط، ونعالجها بنماذج محلية دون إرسالها لجهات خارجية، ولن ننشر النصوص الكاملة، وسنكتفي بمقتطفات قصيرة مع الإسناد للوزارة في العرض والتقرير. نحذف النسخ عند طلبكم أو بعد انتهاء المشروع. موعد التسليم 14 أكتوبر 2026. نرجو إفادتنا بالإذن وصيغة الإسناد المفضلة. بيانات التواصل: [الاسم، البريد، الجوال].
