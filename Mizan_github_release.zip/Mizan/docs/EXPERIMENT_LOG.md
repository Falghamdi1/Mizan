# Experiment log

Chronological record of every measurement made on the prototype, moved out of the README so the README stays readable.
All numbers are from a **single run** each (retrieval is deterministic; generated answers are cached per prompt), on one
corpus (8 Ministry of Tourism regulations, sha256 in `data/corpus_manifest.json`) and small question sets (10 hand-drafted,
51 LLM-generated and unreviewed). Differences are observations, not conclusions. Intervals are paired bootstrap over questions
(`python scripts/compare_runs.py`), treat questions as independent, and are not corrected for the many comparisons made.
Result files are in `results/eval-*.json` (git-ignored; regenerate with `python -m src.evaluation`). Caveats that apply to
everything below are listed in the README, section "Validity threats".

Reading order: real-corpus results first (they supersede earlier ones), the synthetic-sample illustration last.

## First observations on the real corpus
Real e5 embedder, **mock LLM** (so retrieval/token numbers only), 10 questions (9 answerable), top-4 of ~330 chunks, one run, so **one question = 0.11 hit@k**. Command: `python -m src.evaluation --pipelines baseline,baseline+remove_tatweel,baseline+unicode_nfkc,baseline+remove_diacritics,mizan,mizan-no-remove_tatweel,mizan-no-remove_diacritics`.

| | baseline | +tatweel only | +NFKC only | +diacritics only | mizan | mizan − tatweel | mizan − diacritics |
|---|---|---|---|---|---|---|---|
| hit@4 | 0.444 | 0.667 | 0.444 | 0.444 | 0.556 | 0.333 | 0.556 |
| MRR | 0.259 | 0.556 | 0.259 | 0.231 | 0.500 | 0.204 | 0.500 |
| retrieved tokens / query | 765 | 626 | 765 | 775 | 628 | 730 | 624 |
| index tokens (whole corpus) | 64,464 | 40,101 | 64,464 | 64,181 | 38,996 | 62,753 | 39,369 |

Observations (measured): (a) a single step, **tatweel removal**, accounts for the token reduction (64k→40k index tokens, −38 %; characters only −12 %) and reproduces or exceeds the whole Mizan difference in hit@4/MRR; NFKC and diacritic removal change essentially nothing on this corpus (no presentation forms, almost no diacritics). (b) Header/footer removal did **not** help here (`baseline+remove_repeated_lines` hit@4 0.333; `mizan-no-remove_repeated_lines` 0.667), opposite to the synthetic corpus, so effects are corpus-dependent. (c) Absolute hit@4 is low (0.44–0.67) for every variant: most misses are probably cross-document confusion between near-identical regulations and the lam-alef/RTL extraction damage, which none of the current steps address.

Interpretation (hypothesis, untested): the useful "Arabic-aware" operation here is cleaning extraction artefacts (kashida inflates the subword count and fragments words), which is closer to PDF-extraction hygiene than to orthographic normalization; the lam-alef repair was then added as the flag below. Not evidence that Arabic preprocessing generally improves RAG: tiny question set, drafted by the same assistant that built the pipeline, a single embedder, mock LLM, one run.

**Lam-alef repair (`repair_lam_alef`), same setup:** 1,464 ligatures repaired across the 8 PDFs (all zero-width alefs accounted for; no standalone `ال` left; legitimate words such as `ثالث` "third" untouched).

| | baseline | +repair | +tatweel | +tatweel +repair | mizan | mizan +repair |
|---|---|---|---|---|---|---|
| hit@4 | 0.444 | 0.444 | 0.667 | 0.667 | 0.556 | 0.556 |
| MRR | 0.259 | 0.389 | 0.556 | 0.611 | 0.500 | 0.500 |
| precision@4 | 0.111 | 0.111 | 0.194 | 0.222 | 0.139 | 0.194 |
| retrieved tokens / query | 765 | 728 | 626 | 584 | 628 | 558 |
| index tokens | 64,464 | 62,719 | 40,101 | 37,706 | 38,996 | 37,234 |

Observation (measured): the repair is directionally positive but small. It lowers token counts by 3–6 % and raises MRR and/or precision in each of the three with/without pairs without lowering either; hit@4 is unchanged in every pair. With 9 answerable questions one question moves hit@4 by 0.11, so none of this is distinguishable from noise yet. It is the *less* important of the two extraction fixes on this corpus (tatweel removal matters far more). Its value should show up better on the lexical/hybrid retrieval variant, which depends on exact spellings, and on a larger question set.

**Same experiment with Qwen3-Embedding-0.6B** (local, GPU, same 9 answerable questions, mock LLM, one run; `MIZAN_EMBEDDING_MODEL=Qwen/Qwen3-Embedding-0.6B`):

| | baseline | +tatweel | +repair | mizan | mizan +repair |
|---|---|---|---|---|---|
| hit@4 | 0.444 | 0.667 | 0.556 | 0.667 | 0.667 |
| MRR | 0.315 | 0.444 | 0.389 | 0.389 | 0.472 |
| precision@4 | 0.111 | 0.167 | 0.139 | 0.194 | 0.167 |
| retrieved tokens / query (Qwen tokenizer) | 1,035 | 884 | 1,007 | 840 | 826 |
| index tokens | 72,706 | 51,542 | 71,135 | 47,856 | 46,567 |

Observations (measured): the direction matches e5-small. Tatweel removal is the step that moves hit@4 (0.444→0.667) and cuts index tokens ~29 %. Unlike with e5, the lam-alef repair also lifts hit@4 on the baseline (0.444→0.556), consistent with Qwen's byte-level BPE having no built-in folding, but the sample is 9 questions so one question = 0.11. Qwen3-0.6B did not beat e5-small in absolute hit@4 (both best at 0.667). Qwen needs ~13 % more tokens for the same Arabic text (72.7k vs 64.5k baseline index).

**Full pipeline with real local answers** (Qwen3-Embedding-0.6B + Qwen3-4B-Instruct-2507 via Ollama, temperature 0, 10 questions / 9 answerable, one run; judge = the same 4B model, unvalidated):

| | baseline | +tatweel | mizan | mizan +repair |
|---|---|---|---|---|
| hit@4 | 0.444 | 0.667 | 0.667 | 0.667 |
| answer keyword coverage | 0.444 | 0.556 | 0.500 | 0.556 |
| judge: correct (unvalidated) | 0.50 | 0.60 | 0.70 | 0.70 |
| false-abstain rate (answerable questions the model refused) | 0.44 | 0.44 | 0.33 | 0.22 |
| correct-abstain rate (unanswerable) | 1.0 | 1.0 | 1.0 | 1.0 |
| LLM input tokens / query | 1,298 | 1,147 | 1,102 | 1,088 |
| LLM latency, median (s) | 3.2 | 3.1 | 3.3 | 3.3 |

Observations (measured): answer quality follows retrieval: in the answers I inspected (r2, r3, r5, r10), a missing passage produced an abstention rather than an invented fact; I have not read all 40 answers, so check them before claiming this in general. The Arabic-aware variants cut LLM input tokens by ~15 % and false abstentions from 4 to 2 of 9, but with 9 questions this is 2 questions, not evidence. Latency is indistinguishable (median); one 33 s call in the baseline was a cold model reload, which is why latency is now reported as a median.
Two questions (r1 license duration, r5 renewal deadline) fail in **every** variant: the retriever returns near-identical clauses from the hospitality/consultation regulations instead of the tour-guide one. Cross-document near-duplicates, not orthography, are the current ceiling. This is the case that fine-tuning with cross-document hard negatives should be tested on.

**First LoRA fine-tune of Qwen3-Embedding-0.6B** (`finetune/out/q06_v2_mask`): 556 LLM-generated question-passage pairs (`pairs_v2.jsonl`, questions name their regulation) from the 6 training documents, 3 epochs, batch 16, LoRA r=16, near-duplicate masking (cos>0.9). Evaluated on the same 10 questions, which point only to the 2 **held-out** documents (Tour-Guide, Tourist-Visa); the other 6 documents are the retrieval distractors and were seen in training. Real answers from Qwen3-4B, one run.

| | base, baseline text | base, mizan+repair | fine-tuned, baseline text* | fine-tuned, mizan+repair |
|---|---|---|---|---|
| hit@4 | 0.444 | 0.667 | 0.778 | 0.778 |
| MRR | 0.315 | 0.472 | 0.648 | 0.574 |
| precision@4 | 0.111 | 0.167 | 0.194 | 0.222 |
| answer keyword coverage | 0.444 | 0.556 | 0.667 | 0.611 |
| judge correct (unvalidated) | 0.50 | 0.70 | 0.70 | 0.70 |
| false-abstain rate | 0.44 | 0.22 | 0.33 | 0.22 |
| retrieved tokens / query | 1,035 | 826 | 893 | 648 |

\* The adapter was trained on Mizan-preprocessed text and applied to baseline-preprocessed text, so this column is not a proper fine-tuned-baseline control (that needs pairs/training built from baseline text).

Observations (measured): fine-tuning raised hit@4 from 0.667 to 0.778 for the Mizan text, which is **one more question answered (r6)** out of 9; per-question ranks moved both ways (r3 and r9 improved, r2, r4, r7 got worse). The two questions that motivated the fine-tune, r1 and r5 (near-duplicate clauses in other regulations), still fail. Retrieved tokens fell 21 % partly because the tuned model ranks shorter chunks higher, which is a side effect, not a verified efficiency gain. Near-duplicate masking removed only 0.1 % of in-batch negatives (random batches rarely contain two near-duplicates), so it had almost no effect in this run; it needs hard-negative batching to matter. Training loss went 2.16 → ~0.1, which on 556 pairs may indicate memorisation of the training documents. None of the differences is distinguishable from noise at n=9.

**Larger evaluation set: 51 questions (45 answerable) generated by Qwen3-4B from the two held-out documents** (`eval/questions_large.json`; evidence phrases and answer keywords machine-verified against the source text, questions **not yet human-reviewed**). Qwen3-Embedding-0.6B, real Qwen3-4B answers, one run. Differences are paired bootstrap over the 45 answerable questions (95 % CI).

| | base, baseline text | base, mizan+repair | fine-tuned, baseline text (*) | fine-tuned, mizan+repair |
|---|---|---|---|---|
| hit@4 | 0.533 | 0.622 | 0.644 | **0.822** |
| MRR | 0.350 | 0.424 | 0.580 | **0.652** |
| precision@4 | 0.150 | 0.167 | 0.172 | 0.222 |
| judge correct (unvalidated) | 0.80 | 0.82 | 0.84 | 0.84 |
| judge faithful (unvalidated) | 0.88 | 0.90 | 0.94 | 0.94 |
| false-abstain rate | 0.22 | 0.16 | 0.20 | 0.18 |
| LLM input tokens / query | 1,183 | 955 | 922 | 777 |

| Comparison (second minus first) | hit@4 | MRR |
|---|---|---|
| mizan+repair vs baseline text, base embedder | +0.089 [-0.089, +0.267] | +0.074 [-0.044, +0.191] |
| fine-tuned vs base embedder, mizan+repair text | **+0.200 [+0.067, +0.333]** | **+0.228 [+0.115, +0.343]** |
| fine-tuned vs base embedder, baseline text (*) | +0.111 [-0.022, +0.244] | +0.230 [+0.117, +0.346] |

(*) adapter trained on Mizan-preprocessed text, applied to baseline text: not a proper control.

Observations (measured): with 45 questions the preprocessing effect (mizan+repair vs baseline) is **not distinguishable from zero** on hit@4/MRR, while the fine-tuning effect is positive with an interval excluding zero. By document, hit@4 for fine-tuned mizan+repair is 0.77 (Tour-Guide, n=30) and 0.93 (Visa, n=15) against 0.60 / 0.67 for the base model.
Caveats that matter more than the p-values: (1) the evaluation questions were written by the same LLM, with a similar prompt style, as the fine-tuning pairs, so part of the gain may be the embedder learning that question style; the 10 hand-written questions (+1 question) are the style-independent check and are too few. (2) The questions are unreviewed and some are weak or generic. (3) Qwen3 generated the questions and is also the embedding family and generator. (4) Fewer retrieved tokens for the tuned model partly reflects a preference for shorter chunks. (5) Questions within one document are not independent, so the intervals are probably too narrow. Treat this as a promising signal that needs a human-written test set, not as a result.

**Chunk-title test (`MIZAN_CHUNK_TITLE=1`)**: every chunk is embedded as "<Arabic regulation title> + chunk text" in both pipelines (title mapping in `src/titles.py`; default off). Base Qwen3-Embedding-0.6B, retrieval only, one run. Hypothesis: near-duplicate clauses in different regulations look identical to the embedder because the chunk text never names its regulation.

| | 9 hand-written, no title | with title | 45 generated, no title | with title |
|---|---|---|---|---|
| baseline text: hit@4 | 0.444 | 0.667 | 0.533 | 0.667 |
| baseline text: MRR | 0.315 | 0.500 | 0.350 | 0.522 |
| mizan+repair: hit@4 | 0.667 | 0.667 | 0.622 | 0.600 |
| mizan+repair: MRR | 0.472 | 0.583 | 0.424 | 0.543 |

Paired bootstrap on the 45 generated questions, title minus no-title: baseline hit@4 +0.133 [+0.022, +0.244], baseline MRR +0.172 [+0.087, +0.263], mizan+repair hit@4 -0.022 [-0.133, +0.089], mizan+repair MRR +0.119 [+0.030, +0.219]. Index size grows 6-9 % (extra tokens).

Observations (measured): titles consistently improve **ranking** (MRR) and, for the baseline text, hit@4. With titles the Mizan advantage over baseline disappears (hit@4 0.600 vs 0.667; MRR 0.543 vs 0.522): part of the earlier "preprocessing benefit" may have been compensating for missing document context. r1 now retrieves only Tour-Guide pages (the document confusion is gone) but still misses the gold chunk, page 8, whose extracted text is damaged (displaced numerals/parentheses, several unrelated clauses in one chunk); r5 still returns hospitality/travel chunks. Remaining failures therefore look like layout/extraction and chunking problems, not embedding-capacity or document-identity problems. The title mapping is filename-based, a prototype shortcut.

**Adapter retrained on titled chunks** (`finetune/out/q06_v2_titled`; pairs from `pairs_v2.jsonl` with the regulation title prepended exactly as at inference via `finetune/add_titles.py`; same settings, 105 steps), evaluated with `MIZAN_CHUNK_TITLE=1`, retrieval only, one run:

| mizan+repair text | base | base + title | tuned (untitled) | tuned + title |
|---|---|---|---|---|
| 9 hand-written: hit@4 | 0.667 | 0.667 | 0.778 | **0.889** |
| 9 hand-written: MRR | 0.472 | 0.583 | 0.574 | **0.759** |
| 45 generated: hit@4 | 0.622 | 0.600 | 0.822 | **0.867** |
| 45 generated: MRR | 0.424 | 0.543 | 0.652 | **0.713** |

Paired bootstrap, 45 generated questions (second minus first): tuned+title vs base+title hit@4 **+0.267 [+0.133, +0.422]**, MRR **+0.170 [+0.043, +0.298]**; tuned+title vs tuned-untitled hit@4 +0.044 [-0.044, +0.133], MRR +0.061 [-0.030, +0.150] (not distinguishable); tuned+title vs the original untitled base hit@4 +0.244 [+0.111, +0.378], MRR +0.289 [+0.172, +0.409].

Observations (measured): fine-tuning is the main driver; titles on top of fine-tuning add little that we can distinguish from noise. This is the best configuration so far (Qwen3-Embedding-0.6B + titles + LoRA, hit@4 0.87 on 45 generated and 0.89 = 8/9 on the hand-written questions, against 0.53 / 0.44 for the original baseline). r5 is now retrieved (rank 3) for the first time; r1 still is not. In the tuned+title arm, Mizan text beats baseline text (hit@4 +0.178 [+0.044, +0.311]), but this is **not** evidence for the preprocessing: the adapter was trained on Mizan-preprocessed text, so it is mismatched on baseline text. A fair comparison needs a second adapter trained on baseline-preprocessed text. The caveats about same-generator training pairs and evaluation questions still apply (the hand-written 9 questions point the same way, but one question = 0.11).

**Fair 2x2 with a baseline-text adapter** (`finetune/out/q06_v2_titled_base`: the same 556 questions mapped onto baseline-preprocessed chunks with `finetune/remap_pairs.py`, 526 pairs matched, 30 dropped; max length 512). Titles on, Qwen3-Embedding-0.6B, real Qwen3-4B answers for the matched arms, one run, 45 generated questions.

| hit@4 / MRR (adapter fine-tuned on ... applied to ...) | baseline text | mizan+repair text |
|---|---|---|
| no fine-tune | 0.667 / 0.522 | 0.600 / 0.543 |
| fine-tuned on baseline text | 0.644 / 0.548 | 0.867 / 0.687 |
| fine-tuned on mizan text | 0.689 / 0.596 | 0.867 / 0.713 |

Matched arms (baseline text + baseline adapter vs mizan+repair text + mizan adapter), 45 generated questions: hit@4 0.644 vs **0.867** (difference **+0.222 [+0.089, +0.356]**), MRR 0.548 vs 0.713 (+0.165 [+0.048, +0.281]), false-abstain rate 0.27 vs 0.09, judge-correct 0.77 vs 0.84 (+0.078 [-0.039, +0.196], not distinguishable), LLM input tokens 1,018 vs 857. On the 9 hand-written questions: hit@4 0.778 vs 0.889.

Observations (measured): the **text pipeline, not the adapter's training text, determines the result**: the baseline-trained adapter also reaches 0.867 on mizan+repair text. Fine-tuning helps only on cleaned text (+0.267 hit@4) and does nothing on raw text (-0.022 / +0.022). Without fine-tuning the cleaning does not help hit@4 (0.600 vs 0.667). So: preprocessing and fine-tuning interact; neither alone produced the gain.

**Which steps? (baseline-trained adapter, retrieval only, titles on)**

| text pipeline | 45 generated hit@4 | MRR | index tokens | 9 hand-written hit@4 | MRR |
|---|---|---|---|---|---|
| raw baseline text | 0.644 | 0.548 | 77,134 | 0.778 | 0.519 |
| + tatweel removal only | **0.844** | 0.676 | 55,548 | 0.889 | **0.806** |
| + lam-alef repair only | 0.756 | 0.600 | 75,551 | 0.889 | 0.537 |
| + tatweel + repair | **0.844** | **0.702** | 53,737 | 0.889 | 0.694 |
| mizan (all steps, no repair) | 0.800 | 0.613 | 51,897 | 0.778 | 0.593 |
| mizan without tatweel removal | 0.711 | 0.565 | 73,101 | 0.778 | 0.491 |
| mizan + repair (all steps) | **0.867** | 0.687 | 50,608 | 0.778 | 0.593 |

Paired bootstrap vs raw text (45 generated): tatweel removal alone hit@4 +0.200 [+0.089, +0.333]; repair alone +0.111 [+0.022, +0.200]; tatweel+repair +0.200 [+0.067, +0.333]; mizan+repair +0.222 [+0.111, +0.356].
Observations (measured): **kashida (tatweel) removal is the dominant step, lam-alef repair is a smaller positive, and the letter-level folding steps (alef/ya/digits/punctuation) add nothing consistent**: tatweel + repair alone matches the full Mizan pipeline. This is extraction hygiene, not orthographic normalization. Caveats: one run, adapter trained on generated pairs, unreviewed generated questions, 9 hand-written questions are one-question steps.

**Independent judge check (Gemma 3 4B vs the Qwen judge).** Because Qwen3-4B generated the answers and also judged them, the matched-arm answers were re-scored with `gemma3:4b` (`MIZAN_JUDGE_PROVIDER=ollama`, `MIZAN_JUDGE_MODEL=gemma3:4b`) on identical answers and retrieval. Refusals are now graded by rule (refusing an answerable question is incorrect; refusing an unanswerable one is correct) because a 4B judge marked a wrong refusal "correct".

| judge_correct (45 generated + 6 unanswerable) | raw text + base-trained adapter | cleaned text + mizan-trained adapter |
|---|---|---|
| Qwen judge | 0.765 | 0.843 |
| Gemma judge | 0.765 | 0.922 |

On substantive (non-refusal) answers Gemma judged **every one correct and faithful** (41/41 in the cleaned arm, 33/33 in the raw arm); Qwen flagged 4 and 2. Cohen's kappa is 0.00 because Gemma never marks anything wrong. Reading the 8 disagreements by hand: Qwen was right on the clear cases (g9 and g19 answers do not answer the question; g6 says "Minister" for "Ministry"; g2 gives the date instead of the decision number), and several others (g12, g18, g23) come from ill-posed generated questions. **Conclusions:** (1) Gemma 3 4B is too lenient to be used as the only judge here; its higher "correct" gap between arms (+0.157 [+0.039, +0.275]) is essentially the refusal-rule difference (4 vs 12 refusals on answerable questions), which the false-abstain rate already measures. (2) We found no evidence that Qwen inflated its own answers (it was the stricter judge), but this is 8 cases. (3) The larger noise source is the unreviewed generated questions with weak references. A human-graded sample is still required: `results/judge_review_A.md` and `results/judge_review_B.md` list the disagreements plus random agreements with an empty human column.

**Two-stage retrieval: Qwen3-Embedding-0.6B top-20, then Qwen3-Reranker-0.6B, keep top-4** (`MIZAN_RERANKER=Qwen/Qwen3-Reranker-0.6B`, `MIZAN_RERANK_TOP_N=20`; `src/rerank.py`). Titles on, retrieval only, one run; each arm compared with the same arm without the reranker.

| hit@4 / MRR (45 generated) | no rerank | with rerank | gold in top-20 |
|---|---|---|---|
| base embedder, raw text | 0.667 / 0.522 | 0.756 / 0.578 | 0.822 |
| base embedder, cleaned text | 0.600 / 0.543 | 0.756 / 0.624 | 0.933 |
| tuned (matched), raw text | 0.644 / 0.548 | 0.822 / 0.648 | 0.933 |
| tuned (matched), cleaned text | **0.867** / 0.713 | 0.822 / 0.659 | 0.956 |
| 9 hand-written, every arm | 0.667 - 0.889 | **1.000** (9/9) | 1.000 |

Paired bootstrap, rerank minus no-rerank, hit@4 on 45 generated: base raw +0.089 [+0.022, +0.178]; base cleaned +0.156 [+0.044, +0.289]; tuned raw +0.178 [+0.022, +0.333]; tuned cleaned -0.044 [-0.133, +0.044] (not distinguishable from zero). MRR changes are all within noise. With the reranker, cleaned vs raw text in the matched arms: hit@4 +0.000 [-0.089, +0.089].
Median retrieval latency rose from 0.05-0.08 s to 0.6-0.9 s per question (reranking 20 passages on the GPU), small next to the 3-5 s LLM call.

Observations (measured): the reranker lifts every weak first stage to about 0.76-0.82 hit@4 and finds the two questions that no first stage found before (r1, r5: now ranked 1-4 in every arm); it adds nothing on top of the best first stage (fine-tuned embedder + cleaned text, 0.867 alone). With the reranker, the cleaning and fine-tuning effects shrink: the gap between cleaned and raw text disappears. The reranker is now the limit: the gold passage is in the top-20 for 82-96 % of questions but ends up in the top-4 for 76-82 %. Caveats: same model family as the embedder, only N=20 tested, the 9 hand-written questions saturate (n is tiny), the 0.6B reranker only (the 4B is the planned next step).

**Candidate count N for the reranker** (first stage returns top-N, reranker keeps 4; 54 answerable questions = 9 hand-written + 45 generated, retrieval only, one run; table cells are hit@4 / MRR, then gold-in-candidates, then median retrieval latency):

| arm | stage 1 only (hit@4) | N=10 | N=20 | N=30 |
|---|---|---|---|---|
| tuned + cleaned text | **0.870** | 0.852 / 0.681, r0.94, 0.36 s | 0.852 / 0.667, r0.96, 0.65 s | 0.815 / 0.654, r1.00, 0.92 s |
| tuned + raw text | 0.667 | 0.796 / 0.690, r0.85, 0.43 s | 0.852 / 0.660, r0.94, 0.78 s | 0.815 / 0.608, r0.94, 1.40 s |
| untuned + cleaned text | 0.611 | 0.759 / 0.617, r0.81, 0.43 s | 0.796 / 0.637, r0.94, 0.62 s | 0.778 / 0.631, r0.94, 2.52 s |

Paired bootstrap on hit@4: no pair of N values is distinguishable (all intervals include zero; largest effect N=10 to N=20 for tuned raw, +0.056 [-0.019, +0.148]; N=20 to N=30 is slightly negative for all three arms, about -0.02 to -0.04).
Observations (measured): the number of candidates barely matters between 10 and 20, and 30 is no better and slower (more distractors reach the reranker even though recall of the gold passage rises to 1.00 for the best arm). The reranker helps weaker first stages (+0.13 to +0.19 hit@4) and does not help, and may slightly hurt, the strongest one (tuned + cleaned: 0.870 alone vs 0.815-0.852 reranked). With reranking, raw and cleaned text reach the same hit@4 for the tuned embedder (0.852 vs 0.852 at N=20). Latencies are single-run medians and noisy (the N=30 untuned figure is unusually high). N=10 is a sensible default for speed; the 4B reranker has not been tested.

**Real Qwen3-4B answers with the reranker** (Qwen3-Reranker-0.6B, N=20, titles on, 45 generated answerable + 6 unanswerable questions; judge = `gemma3:4b` with refusals graded by rule, which is lenient: it called 43/43, 42/42 and 39/40 of the non-refused answers correct, so its "correct" differences mostly restate the refusal rate; keyword coverage and refusal rates are the more informative columns). One run; two chain runs crashed with CUDA out-of-memory (Ollama and the embedder competing for 8 GB) and were rerun or replaced by an equivalent verified run.

| arm | hit@4 | keyword cov. | judge correct | refused an answerable q | LLM input tokens |
|---|---|---|---|---|---|
| tuned + cleaned, no rerank | 0.867 | 0.667 | 0.922 | 0.089 | 858 |
| tuned + cleaned, rerank | 0.822 | 0.722 | 0.961 | 0.044 | 968 |
| tuned + raw, no rerank | 0.644 | 0.537 | 0.765 | 0.267 | 1,018 |
| tuned + raw, rerank | 0.822 | 0.693 | 0.941 | 0.067 | 1,187 |
| untuned + cleaned, rerank (no fine-tune) | 0.756 | 0.626 | 0.882 | 0.111 | 1,020 |

Paired bootstrap, with rerank minus without, matched arms: **tuned + raw**: hit@4 +0.178 [+0.022, +0.333], keyword coverage +0.156 [+0.022, +0.289], judge correct +0.176 [+0.059, +0.294], refusals on answerable questions -0.200 [-0.333, -0.067]. **tuned + cleaned**: hit@4 -0.044 [-0.133, +0.044], keyword +0.056 [-0.022, +0.144], judge +0.039 [-0.039, +0.118], refusals -0.044 [-0.133, +0.044] (none distinguishable from zero). On the 9 hand-written questions every reranked arm retrieves 9/9 and refuses none.
Observations (measured): the reranker repairs the weaker arm, so tuned + raw text with a reranker answers about as well as tuned + cleaned text without one (0.822 vs 0.867 hit@4; 7 % vs 9 % refusals) and gains nothing on the strongest arm. Even an untuned embedder with the reranker is in the same range (0.756 hit@4, 11 % refusals) without any fine-tuning, though not compared with a paired test. The reranker picks longer passages, raising LLM input tokens by 13-17 %, and cleaned text still costs about 28 % fewer LLM input tokens than raw text (968 vs 1,187 with reranking). The LLM latency figures (3.6-6.7 s median) are contaminated by GPU memory contention and should not be compared.

## One-step ablations in the notebook configuration (retrieval only)

Configuration: the Colab notebook's: base Qwen3-Embedding-0.6B (no adapter), chunk titles on, 600/100 characters, top-4, no LLM. Questions: `eval/questions_combined.json` (10 reference + 51 generated, 54 answerable; the generated ones are unreviewed). One run (about 4.5 min locally). Script: `python scripts/run_ablations.py`; full per-question data was in `results/ablations-*.json`, **which was deleted by mistake on 2026-10-09** (a cleanup wildcard also matched it); the table below and `results/ablations.md` survive, the per-question data does not, so the intervals cannot be recomputed from files. Re-run `python scripts/run_ablations.py` (about 4.5 min locally, or in Colab) to regenerate it. Each variant is compared with `baseline` by a paired bootstrap over questions. One question is worth 0.0185 of hit@k.

Retrieval-only ablations, 54 answerable questions, paired bootstrap vs `baseline` (n.d. = interval includes zero).

| variant | chunks | retrieved tokens | hit@k | Δhit [95% CI] | MRR | ΔMRR [95% CI] |
|---|---|---|---|---|---|---|
| `baseline` | 358 | 954 | 0.667 | reference | 0.519 | reference |
| `mizan` | 320 | 811 | 0.667 | +0.000 [-0.111, +0.111] n.d. | 0.559 | +0.040 [-0.052, +0.134] n.d. |
| `mizan+repair_lam_alef` | 320 | 804 | 0.611 | -0.056 [-0.167, +0.056] n.d. | 0.549 | +0.031 [-0.073, +0.131] n.d. |
| `baseline+remove_invisible_chars` | 358 | 958 | 0.648 | -0.019 [-0.056, +0.000] n.d. | 0.515 | -0.003 [-0.014, +0.005] n.d. |
| `baseline+unicode_nfkc` | 358 | 954 | 0.667 | +0.000 [+0.000, +0.000] n.d. | 0.519 | +0.000 [+0.000, +0.000] n.d. |
| `baseline+repair_lam_alef` | 357 | 932 | 0.667 | +0.000 [-0.074, +0.074] n.d. | 0.537 | +0.019 [-0.042, +0.076] n.d. |
| `baseline+remove_repeated_lines` | 353 | 962 | 0.648 | -0.019 [-0.056, +0.000] n.d. | 0.511 | -0.008 [-0.034, +0.012] n.d. |
| `baseline+join_broken_lines` | 356 | 1026 | 0.556 | -0.111 [-0.204, -0.037] lower | 0.481 | -0.037 [-0.094, +0.020] n.d. |
| `baseline+remove_tatweel` | 324 | 823 | 0.722 | +0.056 [-0.056, +0.167] n.d. | 0.586 | +0.068 [-0.025, +0.159] n.d. |
| `baseline+remove_diacritics` | 357 | 961 | 0.685 | +0.019 [-0.037, +0.074] n.d. | 0.528 | +0.009 [-0.028, +0.056] n.d. |
| `baseline+normalize_alef` | 358 | 969 | 0.593 | -0.074 [-0.148, -0.019] lower | 0.520 | +0.002 [-0.045, +0.051] n.d. |
| `baseline+normalize_alef_maqsura` | 358 | 969 | 0.667 | +0.000 [+0.000, +0.000] n.d. | 0.519 | +0.000 [-0.005, +0.005] n.d. |
| `baseline+normalize_persian_forms` | 358 | 954 | 0.667 | +0.000 [+0.000, +0.000] n.d. | 0.519 | +0.000 [+0.000, +0.000] n.d. |
| `baseline+normalize_digits` | 358 | 954 | 0.667 | +0.000 [+0.000, +0.000] n.d. | 0.519 | +0.000 [+0.000, +0.000] n.d. |
| `baseline+normalize_punctuation` | 358 | 949 | 0.648 | -0.019 [-0.056, +0.000] n.d. | 0.506 | -0.012 [-0.037, +0.005] n.d. |
| `baseline+normalize_ta_marbuta` | 358 | 1008 | 0.537 | -0.130 [-0.222, -0.056] lower | 0.441 | -0.077 [-0.137, -0.023] lower |
| `baseline+normalize_hamza_seats` | 358 | 993 | 0.537 | -0.130 [-0.222, -0.056] lower | 0.435 | -0.083 [-0.159, -0.019] lower |
| `mizan-no-remove_invisible_chars` | 320 | 815 | 0.667 | +0.000 [-0.111, +0.111] n.d. | 0.559 | +0.040 [-0.052, +0.134] n.d. |
| `mizan-no-unicode_nfkc` | 320 | 811 | 0.667 | +0.000 [-0.111, +0.111] n.d. | 0.559 | +0.040 [-0.052, +0.134] n.d. |
| `mizan-no-remove_repeated_lines` | 322 | 830 | 0.759 | +0.093 [-0.019, +0.204] n.d. | 0.600 | +0.082 [-0.014, +0.176] n.d. |
| `mizan-no-join_broken_lines` | 320 | 794 | 0.685 | +0.019 [-0.074, +0.111] n.d. | 0.563 | +0.045 [-0.042, +0.134] n.d. |
| `mizan-no-remove_tatweel` | 351 | 1027 | 0.630 | -0.037 [-0.148, +0.056] n.d. | 0.520 | +0.002 [-0.076, +0.079] n.d. |
| `mizan-no-remove_diacritics` | 321 | 822 | 0.667 | +0.000 [-0.111, +0.111] n.d. | 0.557 | +0.039 [-0.054, +0.133] n.d. |
| `mizan-no-normalize_alef` | 320 | 825 | 0.685 | +0.019 [-0.093, +0.130] n.d. | 0.552 | +0.034 [-0.063, +0.134] n.d. |
| `mizan-no-normalize_alef_maqsura` | 320 | 804 | 0.685 | +0.019 [-0.093, +0.130] n.d. | 0.565 | +0.046 [-0.048, +0.139] n.d. |
| `mizan-no-normalize_persian_forms` | 320 | 811 | 0.667 | +0.000 [-0.111, +0.111] n.d. | 0.559 | +0.040 [-0.052, +0.134] n.d. |
| `mizan-no-normalize_digits` | 320 | 811 | 0.667 | +0.000 [-0.111, +0.111] n.d. | 0.559 | +0.040 [-0.052, +0.134] n.d. |
| `mizan-no-normalize_punctuation` | 320 | 810 | 0.667 | +0.000 [-0.111, +0.111] n.d. | 0.559 | +0.040 [-0.052, +0.134] n.d. |

What the table shows, and what it does not:
- **The full presets are not distinguishable from baseline** on hit@k or MRR (`mizan`: +0.000 and +0.040, both intervals include zero), while sending about 15% fewer retrieved tokens (811 and 804 vs 954).
- **Only `remove_tatweel` changes the amount of text materially** (954 to 823 tokens, 358 to 324 chunks) and has the highest add-one point estimate (+0.056 hit, +0.068 MRR), but its interval includes zero. Removing it from the full preset raises tokens to 1,027 and chunks to 351, with no distinguishable change in hit@k.
- **Four steps change nothing measurable on this corpus** after baseline cleanup: `unicode_nfkc`, `normalize_persian_forms`, `normalize_digits` give identical retrieval and token counts; `normalize_alef_maqsura` changes tokens slightly and hit@k not at all. This text has no presentation forms to fold (0% in every document).
- **Intervals that exclude zero are all on the lower side:** `join_broken_lines` (hit -0.111), `normalize_alef` (hit -0.074, MRR unchanged), and the two lossy folds `normalize_ta_marbuta` (-0.130 / -0.077) and `normalize_hamza_seats` (-0.130 / -0.083). The last two are the steps the preset keeps off because they merge distinct words, and this is consistent with that. `join_broken_lines` and `normalize_alef` have no such explanation and may be chance or a chunk-boundary effect.
- **Caveats:** 27 comparisons, none corrected for multiple testing; with no true effects about one or two intervals would exclude zero by chance, so four is not clear evidence. Chunk boundaries move whenever text length changes, so a step's effect and its chunking effect are entangled. Hit@k depends on a gold phrase landing inside one chunk.
- **Not supported by this table:** that any single Arabic-specific step improves retrieval, or that the full preset does. Supported: the lossy folds are not worth turning on, and kashida removal is the only step that changes token volume appreciably.

**Incident found while running this (recorded because it nearly produced a wrong table).** The first attempt kept all 28 pipelines' Chroma collections alive in one in-memory client and queried them in turn. Each pipeline's first query returned 4 passages and every later query returned none, which scored as "evidence not found" (baseline hit@k 0.019). The numbers were discarded. Retrieval now raises when Chroma returns fewer results than requested, and the ablation builds, evaluates and drops one pipeline at a time. Earlier experiments in this log used at most a handful of pipelines at once and gave plausible retrieval, so they are not believed affected, but that was not re-checked pipeline by pipeline.

## CPU profile of the notebook: a different embedder gives a different answer (one run)

The notebook's `cpu` profile (no GPU, retrieval only) uses `intfloat/multilingual-e5-small` with no reranker. On the 51 generated questions (45 answerable, unreviewed), same chunk titles and settings as the other runs:

| | Standard RAG | Mizan | Difference [95% CI] |
|---|---|---|---|
| hit@4 | 0.578 | 0.756 | +0.178 [+0.022, +0.356] |
| MRR | 0.419 | 0.620 | +0.202 [+0.078, +0.330] |

Retrieved tokens per query: 841 vs 636. This is the opposite of the Qwen3-Embedding runs, where hit@4 was not distinguishable (for example 0.667 vs 0.600 with the 0.6B embedder, interval [-0.200, +0.067]). One run, a different embedder, an unreviewed question set, and many other comparisons were made in this project without correction, so treat it as a lead, not a finding. The hypothesis it suggests: cleaning helps a small embedder more than a larger one. Testing it needs the same questions on both embedders in one run, plus more than one corpus.

## (Earlier) what the harness showed on the SYNTHETIC sample (illustration of the method, not a result)
Measured with the real e5 embedder, mock LLM, 8 questions, one run:

| | baseline | +remove_repeated_lines only | mizan | mizan − remove_repeated_lines |
|---|---|---|---|---|
| hit@4 | 0.857 | 1.000 | 1.000 | 0.857 |
| MRR | 0.690 | 0.750 | 0.750 | 0.690 |
| retrieved tokens/query | 420 | 276 | 265 | 410 |

Observation: on this corpus nearly the entire difference between baseline and "Mizan" is reproduced by **one generic step (header/footer removal)** — the Arabic-specific folds contributed ≈ nothing, and removing NFKC from Mizan changed nothing (see `results/`). With the offline *lexical* hash embedder the gap was large (hit@4 0.29 vs 0.86), which suggests Arabic normalization matters for lexical matching but is largely absorbed by e5's own tokenizer (SentencePiece NFKC-normalizes). 11 chunks and top-4 means 36 % of the corpus is retrieved, so hit@k is inflated. This is exactly the kind of confound the ablations exist to expose; do not quote it as evidence about Arabic RAG.

## Web corpus, FAQ questions, Colab T4 run (2026-10-09)

Notebook: `Mizan_Web_Evaluation_Colab.ipynb` (first version), retrieval only, 250 questions written by the Ministry (its FAQ), gold = start of the Ministry's own answer inside that answer's document, top-4, chunks 600/100 characters, chunk titles off, one run. **The six Bureau of Experts law pages timed out from Colab and the notebook continued without them, so the "web" corpus here is 562 pages / 496,457 characters / 1,297 baseline chunks (1,292 Mizan), not the 739 pages / 1,569 chunks of the earlier local run.** Standard = `baseline`, Mizan = `mizan+repair_lam_alef` (on web text the lam-alef repair changes nothing).

Web corpus (no PDFs), hit@4, Standard vs Mizan, difference [95% CI]: e5-small 0.524 vs 0.508, −0.016 [−0.044, +0.012]; Qwen3-Embedding-0.6B + reranker 0.608 vs 0.588, −0.020 [−0.048, +0.008]; Qwen3-Embedding-4B + reranker 0.632 vs 0.608, −0.024 [−0.056, +0.008]. No difference distinguishable from zero on any of the 15 metric rows; 14 of 15 point estimates are slightly negative. The earlier local run of the 0.6B pair on the 739-page corpus had given −0.052 [−0.084, −0.024]: it did not replicate here, so it is a corpus- or run-dependent lead, not a finding.

Web corpus plus the 8 PDFs as distractors (same 250 questions, gold still only the FAQ answers): Mizan lower on hit@4 in all three: e5-small −0.060 [−0.100, −0.024]; 0.6B pair −0.088 [−0.128, −0.052]; 4B pair −0.108 [−0.152, −0.068]. **Do not read this as Mizan hurting retrieval.** The FAQ answers paraphrase the regulations in the PDFs, so a correct PDF chunk counts as a miss; cleaning the PDF text probably makes those chunks match the questions better. The mechanism was not measured (per-question retrieved documents were not available when this was written); the notebook now prints the share of the top 4 that comes from PDFs for each pipeline.

One-step ablations (0.6B pair, web corpus without laws, 17 pipelines, 59 minutes): no step changes hit@4 distinguishably from zero. Largest: `baseline+normalize_hamza_seats` +0.020 [+0.000, +0.040] (a step that is not in the Mizan preset), `baseline+remove_tatweel` +0.008 [+0.000, +0.020], `baseline+normalize_ta_marbuta` −0.016 (retrieved tokens +8%). Noise floor: `baseline+repair_lam_alef` is a no-op on this text yet differed from `baseline` by one question (−0.004), so differences of one question are noise (cause not isolated; GPU nondeterminism is a suspect). About 17 uncorrected comparisons.

Timing on the T4: e5-small 55 s, 0.6B pair 434 s, 4B pair 850 s (web corpus); ablations 3,536 s; whole notebook 124.6 minutes.


## PDF questions built from the Ministry FAQ (2026-10-09)

Purpose: the web-corpus runs showed no effect on clean text, and the PDF-distractor run could not be interpreted because the gold was in the FAQ answers while the same facts sit in the PDFs. This set puts the gold inside the PDFs, where the extraction damage is (1,464 lam-alef repairs, lost letters, stray glyphs).

Method: for the 196 FAQ questions in the six categories that map to our PDFs (hospitality facility, hospitality management, consultation, travel and tourism services, tour guide, tourist visa), a BM25 search restricted to the category's own regulation proposed PDF passages; the evidence phrase was chosen by hand by reading the FAQ answer next to the passage (all 196 candidate lists were read, 93 aligned; the rest answer process or portal questions that the regulations do not state, or the best passage did not support the answer). A question is kept only if the phrase is found, after the fixed evaluation canonicalizer, in the chunks of both pipelines, and in at most 4 PDFs. 77 kept; 16 dropped: 5 not found in either pipeline (typing or chunk-boundary problems), 3 too generic (the clause is repeated in every regulation), 8 found only in Mizan's repaired text. Those 8 are phrases whose words are too damaged in Standard RAG's text to match (for example a lost `ل`); dropping them keeps the set fair but understates Mizan's advantage.

Limits: one reader made the alignment, so every question carries `needs_review`; 77 questions give a paired-difference standard error of about 0.05; several answers in the FAQ differ in detail from the PDF (for example the FAQ gives a maximum licence of 5 years for travel services while the PDF clause says 3 years), so a question counts the clause, not the FAQ answer; digits and a few words in the PDFs have lost letters (`خال` for `خلال`), so phrases were chosen to avoid them.

Check of the harness only (not a result): with the offline lexical hash embedder, Standard 0.221 against Mizan 0.416 hit@4 on these questions (difference +0.195, interval +0.091 to +0.299), while the same embedder showed no such gap on the web questions. That shows the set can register a preprocessing effect when one exists. The real embedders run in Colab (`Mizan_Web_Evaluation_Colab.ipynb`, section 5b); no such result exists yet.


## Colab run 2 (2026-10-09, full web corpus incl. laws; PDF questions added)

Web corpus 1569 chunks (baseline) / 1565 (Mizan). PDF corpus 358 chunks (baseline) / 320 (Mizan). Hit@4 and 95% paired-bootstrap intervals; n=250 web, n=77 PDF questions (PDF questions are `needs_review`, one reader).

| embedder | corpus | Standard | Mizan | diff [95% CI] |
|---|---|---|---|---|
| e5-small | web | 0.508 | 0.500 | -0.008 [-0.036, +0.020] |
| Qwen3-0.6B + rerank | web | 0.616 | 0.568 | -0.048 [-0.080, -0.016] Mizan lower |
| Qwen3-4B + rerank | web | 0.636 | 0.596 | -0.040 [-0.072, -0.008] Mizan lower |
| e5-small | pdf questions | 0.312 | 0.545 | +0.234 [+0.130, +0.351] Mizan higher |
| Qwen3-0.6B + rerank | pdf questions | 0.623 | 0.636 | +0.013 [-0.091, +0.117] n.d. |
| Qwen3-4B + rerank | pdf questions | 0.701 | 0.675 | -0.026 [-0.117, +0.065] n.d. |

Reading: Mizan helps a weak embedder on damaged PDF text; with the stronger Qwen3 models the hit@4 gain is not distinguishable from zero (candidate_recall@20 of 4B: +0.052 [+0.013, +0.104]). On clean web text, the Mizan preset is slightly worse with the Qwen3 models. Mizan indexes ~35-40% fewer tokens on the PDFs (embedding-model tokens 72,706 -> 46,567) and retrieves ~26% fewer tokens (1021 -> 756 with the 0.6B model).
PDF ablations (0.6B, n=77): no add-one step improves hit@4; `normalize_hamza_seats` -0.117 [-0.195, -0.052] and `remove_repeated_lines` -0.052 are significantly lower.
The "all" (web+PDF) run is still a flawed design (gold only in FAQ answers); Mizan lower there, not interpreted.


### Correction and Mizan-lite (2026-10-09)

**Correction to the run-2 reading above.** I said the loss on clean web text "points at" `normalize_hamza_seats`. That is wrong: the step is not in the Mizan preset (it is an add-one ablation only), so it cannot explain the web loss. The first-run web ablation (hit@4, 250 questions, 0.6B) shows each step individually indistinguishable from zero (largest: `normalize_ta_marbuta` -0.016, `normalize_hamza_seats` +0.020, both outside the preset), so the cause of the -0.04 to -0.05 with the Qwen3 models is not identified. A leave-one-out of the full preset on web text has not been run.

**What the steps touch** (share of pages changed / net length, add-one on baseline, local measurement): on the 8 PDFs `remove_tatweel` changes 67% of pages and removes 12.3% of all characters (the main reason the Mizan index is smaller); `remove_invisible_chars` 15%, `unicode_nfkc` 2.5%. On the web corpus kashida changes 12% of pages (-0.08%), and the spelling-folding steps (`normalize_alef` 94%, `normalize_alef_maqsura` 73%, `normalize_punctuation` 81%, `remove_diacritics` 61%) change most pages but not their length. `normalize_persian_forms` changes nothing in either corpus.

**Mizan-lite** (`src/preprocessing.py`): `collapse_whitespace`, `remove_invisible_chars`, `unicode_nfkc`, `remove_tatweel`, `normalize_persian_forms`, `normalize_digits`; evaluated as `mizan-lite+repair_lam_alef`. Chosen by reasoning (repair damage, do not fold correct spelling, do not delete or reshape text) plus the PDF add-one result that `remove_repeated_lines` was significantly lower, before any run of lite on real embedders. Pre-specified test: Colab section 6c compares baseline, full Mizan and lite on the 77 PDF and the 250 web questions for each embedder, and a cheap e5-small leave-one-out on the PDF questions (section 6c, `RUN_LOO`) says which steps the e5-small gain depends on. Not run on real models yet. If lite is edited after seeing those numbers, the edit needs a new test set. Offline hash-embedder smoke run: wiring only.


### Colab run 3: Mizan-lite and leave-one-out (2026-10-09)

**Corpus caveat.** In this run the web corpus again lacked the six law pages (1,297 chunks, fingerprint 2080d1ad5501, vs 1,569 in run 2); the notebook went on without them. All arms inside run 3 share that corpus, so the within-run comparisons are valid, but the web rows below are on a smaller corpus than run 2 and are not comparable with it. The PDF rows are identical to run 2 (same corpus, deterministic). Run-to-run difference on the web corpus alone (Standard e5-small hit@4 0.508 vs 0.524) comes from the corpus change.

hit@4, difference [95% CI], paired bootstrap; lite = `mizan-lite+repair_lam_alef`, set fixed before this run:

| embedder | questions | lite - Standard | lite - full Mizan | full Mizan - Standard |
|---|---|---|---|---|
| e5-small | PDF (77) | +0.234 [+0.130, +0.351] | +0.000 [-0.052, +0.052] | +0.234 [+0.130, +0.351] |
| Qwen3-0.6B + rerank | PDF | +0.000 [-0.104, +0.104] | -0.013 [-0.091, +0.065] | +0.013 [-0.091, +0.117] |
| Qwen3-4B + rerank | PDF | -0.039 [-0.130, +0.065] | -0.013 [-0.091, +0.065] | -0.026 [-0.117, +0.065] |
| e5-small | web (250, no laws) | +0.008 [+0.000, +0.020] | +0.024 [-0.004, +0.052] | -0.016 [-0.044, +0.012] |
| Qwen3-0.6B + rerank | web | +0.012 [+0.000, +0.028] | +0.032 [+0.004, +0.060] | -0.020 [-0.048, +0.008] |
| Qwen3-4B + rerank | web | +0.008 [+0.000, +0.020] | +0.032 [+0.004, +0.060] | -0.024 [-0.056, +0.008] |

Reading: on the PDF questions lite matches the full preset (identical hit@4 for e5-small; MRR -0.050 [-0.102, -0.001], borderline). On web text lite is not distinguishable from Standard (lower bounds at +0.000) and beats the full preset for the two Qwen3 models (+0.032, interval just excludes zero). Not a significant gain over Standard anywhere except e5-small on damaged PDFs.

Leave-one-out of the full preset (e5-small, PDF questions, 77, vs `mizan`; note `mizan` here has no lam-alef repair and still scores 0.545): removing `remove_tatweel` is the only step that matters (hit@4 0.545 -> 0.351, -0.195 [-0.299, -0.091]; chunks 320 -> 351). Every other step is indistinguishable from zero; `normalize_punctuation` and `remove_diacritics` removed gave +0.026 and +0.013 (not significant). So for e5-small the whole PDF gain is kashida removal; the lam-alef repair is not needed for hit@4 here. Mechanism (kashida splits words into fragments for the tokenizer and inflates character-counted chunks) is plausible but not tested.


### Default changed to Mizan-lite (2026-10-09)

`MIZAN_PIPELINES` (demo, evaluation CLI default), `.env`, `.env.example`, `src/comparison.py` and the main notebook (`scripts/build_notebook.py`) now use `baseline` vs `mizan-lite+repair_lam_alef`. Not changed on purpose: the web-evaluation notebook, ablations, question builders and fine-tuning scripts, which keep naming the full preset explicitly. Not re-run: the main notebook's ten answer questions and the demo's prepared questions (r3/r4/r5) with lite; the earlier main-notebook numbers are for the full preset. The offline check built both default pipelines (358 and 323 chunks) and the 52 tests pass; no Ollama or real-embedder run was done here.


### Citation check added to the evaluation (2026-10-09)

`src/citations.py` parses the `[file, page N]` markers the prompt asks for and compares them with the passages the model was shown; `src/evaluation.py` now scores, per non-refused answer, `citation_present`, `citation_valid_share`, `invalid_citation` and, for answerable questions, `cites_gold` (a valid citation points at a passage holding the gold evidence, judged with the fixed canonicalizer) and `cites_gold_given_hit` (the same, among answers where the gold passage was retrieved). Refusals and retrieval-only runs are not scored. No LLM or judge is involved; it checks the marker, not whether the cited text supports the claim. Shortened file names match only when at least 8 characters long (to avoid false matches such as "Tour").

Retroactive pass over the earlier real-model answers in `results/` (doc and page only; passage text was not stored, so `cites_gold` is not available for them): 31 pipeline-runs, repeats included, so a corpus of answers rather than a comparison of arms. 644 non-refusal answers, every one with at least one citation; 922 citations of which 816 (88.5%) named a shown (file, page); 53 answers (8.2%) held at least one citation to a page that was not shown. The Qwen3-4B generator therefore follows the citation format reliably but cites a page it was not given in roughly one answer in twelve. Not yet compared between Standard and Mizan.


## Final audit work (2026-10-10)

**Version control and backup.** The project was not under version control. `git init`, first commit before any change; a zip of the git-ignored outputs (results, adapters, web data, eval, docs: 127 files, 109 MB) outside the project in a folder outside the project. Colab result files kept inside the project in `results/colab_run2/` and `results/colab_run3/` (git-ignored, in the backup).

**Data profile** (`scripts/profile_data.py`, `docs/data_audit/profile.*`, section Q of `docs/DATA_AUDIT.md`). Web corpus 739 records, 591,913 characters, 1,569 chunks; PDFs 159 pages, 139,053 characters, 358 chunks. Kashida is 12.31% of PDF characters (0.0 to 0.26% on the web) and 29.7% of PDF tokens; the PDFs cost 3.60 tokens per word, the web 2.27. Only organisational emails found (datadesk@mt.gov.sa, info@stats.gov.sa). Exact duplicates: PDF chapter-title pages repeated across regulations; seven identical articles in the two association laws; GASTAT boilerplate shared by three reports; one duplicated news item.

**Token analysis** (`scripts/token_analysis.py`, `docs/data_audit/token_analysis.*`, `EXPERIMENT_RESULTS.md` section 5). Qwen3-Embedding and Qwen3-4B-Instruct tokenizers are identical (70 of 70 texts), so retrieved tokens are the generator's tokens. Retrieved tokens per query with Mizan-lite: −23% to −31% on the PDFs (fewer for 95% to 96% of questions, all 8 documents), about 0 on the web. Real generator run, 51 questions, full preset: LLM input tokens −228 (−19.3%) [−275, −179]; input = 1.007 × retrieved + 252 tokens (r = 0.999); latency −5.3% not distinguishable from zero; input tokens correlate weakly with LLM latency (r = 0.244). Corrected claim: the Submission 1 slide's "16% less text to embed" is 12.5% fewer characters and 32% to 42% fewer tokens.

**Failure analysis** (PDF questions, Qwen3-0.6B + reranker). 21 questions missed by both arms, 8 fixed by lite, 8 broken by lite. Lite lowers first-stage misses from 19 to 11 and raises rank misses (gold in the top 20, not the top 4) from 10 to 18. Most questions missed by both are FAQ questions that do not name their regulation.

**Safeguards implemented** (`src/safety.py`): instruction-like passages are withheld from the model; if none is left the answer is the standard refusal with no model call; upload warnings (injection-like text, personal-data patterns, counts only); prompt v4 (untrusted-text rule); citations are checked against the passages the model was shown; monitor events and two alert rules (security, ingestion); UI rows for citation status, withheld passages and insufficient evidence. Executed tests: 17 of 17 attack strings detected; 0 of 8 ordinary sentences and 0 of 3,819 real chunks flagged; a real `Pipeline` never passes an injected passage on; a webhook alert delivered over HTTP to a local server. Not tested: any real-model behaviour.

**Adaptation tooling** (`scripts/run_adaptation.py`, notebook section 6d). 554 of 556 pairs map onto Mizan-lite text. Leakage report on the real files: the generated (45) and hand-written (9) questions point only at the held-out PDFs; 71 of the 77 Ministry FAQ questions touch a training document and are excluded, so only 15 style-independent held-out questions exist. The re-run needs a GPU.

**Notebook smoke tests and the bugs they found.** Both notebooks were executed top to bottom in a clean folder with downloads disabled, the hash embedder and the mock generator: main 47 code cells, web 54, 0 errors. They exposed four crashes that would have happened on Colab: the main notebook did not write `src/corpus.py` and `src/web_corpus.py` (nor, later, `safety`, `citations`, `monitoring`); an empty `finetune/__init__.py` made `%%writefile` fail; the `finetune/` folder was not created. `tests/test_notebook_modules.py` now prevents this class of bug. **One local run without disabled downloads fetched 8 GB of models (the notebook's model start-up downloads on any machine); it was stopped and the files deleted.**

**Metrics checked against hand-worked examples** (`tests/test_metrics_manual.py`): hit, MRR, precision, coverage, first-stage hit, candidate recall, keyword coverage, abstention rates, paired bootstrap. All matched.

**Not done or not verifiable here:** anything with real models, the prompt comparison, the adaptation re-run, real e-mail delivery, the blind questions, human grading, the permission request.

**Chroma reliability (2026-10-10).** While smoke-testing the web notebook offline, `retrieval.search` raised "Chroma returned 0 of 4 results ... Too many collections in one client?" in two consecutive runs (the guard from the earlier ablation work doing its job). Reproduced in isolation: with three collections alive in one in-memory client, 76 of 1,200 queries returned nothing in one run and 0 of 480 in another, so the fault is intermittent and not related to timing alone. Fix: `src/retrieval.py` keeps each index's vectors in memory and rebuilds a lost or empty collection from them (no re-embedding), retrying up to three times and still raising if that does not help (`tests/test_retrieval_recovery.py`). The same 1,200-query reproduction then gave 0 errors; the rebuild path ran twice. Earlier Colab runs were not affected (real embedders are slower than the query rate that triggers it), but a rebuild path costs nothing and removes the risk of a crash in the middle of a 2-hour run. Also: tests now run with `HF_HUB_OFFLINE=1` after a faulty test downloaded a 1.2 GB embedder (deleted).


### Colab run 4 (web notebook rerun) and the first end-to-end main-notebook run (2026-10-10)

**Received:** `mizan_web_results rerun.zip` (36 files, now `results/colab_run4/`), `grading_sheets.zip` (blank sheets for the 10 answer questions), and the executed main notebook (now `results/final/Mizan_Arabic_RAG_Optimization_executed_20261010.ipynb`).

**Run 4 (web notebook).** Complete web corpus, fingerprint `b3871676ff02` (1,569 chunks), the first run with Mizan-lite on it. PDF results are identical to run 3 to the last digit (deterministic). Web lite − Standard hit@4: e5 +0.012 [+0.000, +0.028], 0.6B + rerank +0.004 [−0.008, +0.020], 4B + rerank +0.008 [−0.008, +0.024]: not distinguishable from zero; lite − full Mizan on web +0.052 and +0.048 with the Qwen3 stacks (intervals exclude zero). The run-3 web rows (corpus without laws) are superseded in `EXPERIMENT_RESULTS.md` section 3 and in `docs/data_audit/token_analysis.*`, which was regenerated from run 4. **Missing from the zip:** any adaptation (section 6d) output and any blind-set output; section 6d either did not run or its output was not zipped.

**Main notebook, first real end-to-end run.** 48 of 48 code cells, no error, 54.2 minutes on a T4. Retrieval on 51 generated questions: hit@4 0.733 → 0.844 (+0.111 [+0.022, +0.200], n=45), the opposite sign to the 77-question FAQ result for the same kind of stack. Answer run (10 questions): the Mizan arm had one wrong answer and one refusal of an answerable question, keyword coverage 0.889 vs 0.611 (n.d.); the granite judge made two visible errors in 20 judgments. Prompt versions on 61 questions: coverage unchanged, citations naming a retrieved page 0.767 (v1) to 0.967 (v4) at +20% input tokens. Details and the full table: `EXPERIMENT_RESULTS.md` section 6b.

**What changed in our claims.** (1) The strong-stack claim is "mixed", not "no effect". (2) "No loss of answer quality" is not demonstrated: on the 10 questions the point estimates favour Standard. (3) The −19% input-token figure belongs to the full preset; lite gave −6% here. (4) v1 does not meet our own ≥90% valid-citation target on this run (0.767 of citations); v4 does (0.967).


### Gold-phrase survival and a larger safety measurement (2026-10-10, local, no model)

**Gold-phrase survival** (`scripts/gold_survival.py`, `docs/data_audit/gold_survival.*`; `EXPERIMENT_RESULTS.md` section 5c). Share of answerable questions whose gold phrase is present verbatim in the indexed text: PDF FAQ 0.117 (Standard) to 0.571 (lite); generated questions 0.178 to 0.933; with the canonical matcher 1.000 for every pipeline (no evidence destroyed). On the web set the strict measure drops for the normalising pipelines (lite 0.920, full 0.092) because its gold phrases were copied from raw text: strict measures surface-form agreement, not quality; quote it only for the PDF sets.

**Safety measurement** (`scripts/safety_eval.py`, `eval/safety/` frozen with hashes, `docs/safety_eval/`; `docs/RESPONSIBLE_AI.md` section 4c). Written and run before changing anything; fixes guided by the development half only. In-scope attack catch rate 0.837 (dev) and **0.841 (held-out, untouched)** before; 1.000 (dev, tuned) and 0.932 (held-out, partly affected) after. Out-of-scope attacks 0/41 before and after. Hard benign false positives 6/30 and 6/30 before, 1/30 and 2/30 after; real chunks 0/3,819. Personal-data recall in scope 22/31 before (dev 12/16, held-out 10/15), 31/31 after. Findings that were real bugs: zero-width and bidi characters hid attacks; "يتجاهل" (a verb in a rule) matched the order "تجاهل"; spaced or Arabic-Indic phone numbers and dashed IBANs were not found. Findings that stay: paraphrase, other languages, encodings and goal hijacking pass completely; three English in-scope held-out attacks are missed on purpose (held-out must not drive changes). The suite grew from 170 to 214 tests.


### Run-4 diagnostics (2026-10-10, local, no model)

`scripts/run_diagnostics.py`, `docs/data_audit/run_diagnostics.*`, `EXPERIMENT_RESULTS.md` section 5d. Index cost on the PDFs: chunks −9.8%, characters −12.0%, embedding tokens −41.5% (e5-small) and −31.8% (Qwen3) for Mizan-lite; web text ±0%. Retrieval latency on the PDFs −14% (−0.129 s [−0.138, −0.119], 0.6B stack) with web arms at about 0 as a control; Standard ran first, so order is a possible but small confound. First-stage hit +0.182 [+0.065, +0.299] with the 0.6B embedder, absorbed by the reranker (final hit@4 +0.000). Reproducibility: run 4 equals run 3 on all 54 PDF values; against run 2, 91 of 108 web values are identical and the rest differ by at most 0.008. Step tally: of 16 single steps none helps, two hurt (`remove_repeated_lines`, `normalize_hamza_seats`), 14 do nothing; only tatweel removal matters for the weak embedder. Earlier note "latency: no difference shown" referred to the generator stage on ten questions and still holds there; retrieval latency on the PDFs is now a measured difference. Tests: 218.


### Method fixes for the five weaknesses (2026-10-10, late; no model run)

Pre-registered analysis plan (`docs/ANALYSIS_PLAN.md`, committed before any blind question exists): which sets are development data, the final stack, five primary endpoints with fixed reading rules, the adaptation and prompt decision rules, how the mixed strong-stack result is handled (not pooled; decided by the human-written blind set alone), the grading protocol. Tools: `tools/blind_question_form.template.html` with `scripts/make_blind_form.py` (live evidence-phrase check; its JavaScript canonicalizer was compared with the Python one on 269 real and adversarial strings, 0 mismatches), `tools/grading_form.html` (tested on the real blank sheet), `scripts/decide_prompt.py` (the prompt rule, mechanical), `scripts/run_adaptation.py --blind` (one-shot test on the frozen blind PDF questions, split by held-out and training documents; refuses a second run, a changed freeze and a question equal to a training query), `Mizan_Final_Colab.ipynb` (one session: adaptation, blind retrieval on three stacks, real answers, grading sheets, zip). Section 6d of the web notebook now releases GPU memory first and keeps its log: run 4 produced no adaptation output and the cause is unknown (the executed notebook was not provided); the leading suspect is GPU memory still held by the 4B embedder. **Still needs people or Colab:** the blind questions, three rounds of human grading, the final Colab run. Tests: 238.


### Blind set frozen, with deviations from the analysis plan (2026-10-12, before any run on it)

**Source.** The three of us (Faisal Alghamdi, Nasser Alkhaliwi, Ahmad Al Faida) wrote the questions and expected answers; an LLM was used afterwards only to sort and format them into two workbooks (`GenAI_Eval_Questions_Only.xlsx`, `GenAI_Eval_Answer_Key.xlsx`; 277 questions: 80 PDF, 90 HTML and 50 JSON answerable, 57 unanswerable, with a supporting quote and location for every answerable one). No pipeline had been run on these questions when they were frozen.

**Conversion (by script, no model).** Each answer-key row was converted to the columns of `eval/blind_test/template.csv`. The evidence phrase is the first 4 to 7 word window of the authors' supporting quote that occurs inside one chunk of every arm and in at most four documents (the checker's own rule), preferring the named source file; the reference answer is the authors' expected answer; the type comes from the key (number_date split into fee, duration and number; multi_part as list; the key's type and difficulty kept in `notes`). HTML and JSON files are the web corpus. Dropped before the freeze: PDF-A-021, PDF-A-043, PDF-A-048 (supporting quotes from fee tables whose extracted text matched no phrase) and PDF-A-012, 026, 031, 033, 036, 052, 061, 067 (their evidence phrase is the gold phrase of a development question, so they are not an independent test). Frozen: 266 questions (69 PDF answerable, 140 web answerable, 57 unanswerable) in `eval/blind_test/joint_authors.csv`. Seven rows keep the checker's warning that the evidence phrase largely repeats the question.

**Deviations from `docs/ANALYSIS_PLAN.md` section 2.** (1) 266 questions instead of 45 to 60: more power, same rules. (2) No per-row author: the file is marked as joint work, so the per-author quotas (15 to 25 each, three authors) cannot be checked; `make_blind_test.py --build --skip-quota` was added for this, keeps every row check, and writes the unmet quotas into `FROZEN.json`. (3) Answer keywords are empty, so keyword coverage is not scored on this set; retrieval endpoints (P1, P2, P5) and refusals (P4) are unaffected, and P3 rests on human grading as planned. Nothing else in the plan changes: the set is used once, in `Mizan_Final_Colab.ipynb`, and is not used to choose any setting.


### Final blind run (2026-10-12, Colab A100)

`Mizan_Final_Colab.ipynb` ran once on the frozen set: 52 of 52 cells, verify passed, fingerprints matched, prompt v1 (no graded prompt sheet existed, so v1 stayed by the rule of `docs/ANALYSIS_PLAN.md` section 5). The law and GASTAT pages could not be fetched from Colab and were uploaded from `html_for_colab.zip`; the web fingerprint afterwards was the expected `b3871676ff02`. Hardware: A100 instead of the T4 of earlier runs (not a setting of the plan). Results: `EXPERIMENT_RESULTS.md` section 0. **P5 did not run:** `finetune/train_lora.py` stopped in `model.add_adapter` with "Found an incompatible version of torchao. Found version 0.10.0, but only versions above 0.16.0 are supported" (peft checks torchao when it is installed); the notebook's hint about GPU memory was wrong for this failure. No blind question was used by the adaptation step, so P5 can still be run once: the final notebook now uninstalls torchao before training, and section 6 is rerun alone with the same settings. P3 waits for the two graders.


### P3: human grading of the blind answers (2026-10-13)

Two team members graded every row of both blind sheets alone with `tools/grading_form.html` (8 of 1,064 `correct`/`supported` cells left empty), then `scripts/human_grading.py merge`. Kappa on `correct`: 0.649 (PDF), 0.794 (web), both above the 0.6 bar; on `supported`: 0.608 and 0.507. Before adjudication, Mizan-lite minus Standard on answerable questions: PDF +0.073 [−0.036, +0.182] (n=55 paired), web +0.016 [−0.024, +0.055] (n=127). Disagreeing cells (37 PDF, 34 web) are left out by the merge until a third person adjudicates them; the numbers above are therefore provisional. The LLM judge was not used.

### P5 attempt 2 (2026-10-13, Colab): adapter trained, blind test still not run

With torchao removed, training ran (554 pairs, 3 epochs, 105 steps, loss 1.15 at step 1 to 0.01 at the end). Two problems stopped the test, and neither used the blind set. (1) Colab saved the re-uploaded frozen files as `questions_final_test_pdf (1).json` and so on, so the notebook found no frozen set; the upload cell now strips the " (n)" suffix. (2) `save_pretrained` wrote the full model and no `adapter_config.json`, so `run_adaptation.py` reported "no adapter"; `finetune/train_lora.py` now writes the adapter in PEFT format with `save_lora`, and `tests/test_lora_save.py` checks that a saved adapter reloads with identical outputs. Settings are unchanged; section 6 is run once more.


### P5: adaptation on the blind set (2026-10-13, Colab T4, third attempt, used once)

Sections 1 to 6 of the rebuilt `Mizan_Final_Colab.ipynb`: verify passed, fingerprints `b3871676ff02` / `c1b846432f4f` (law pages again from `html_for_colab.zip`), adapter trained with the unchanged settings (554 pairs, 3 epochs, 105 steps) and saved in PEFT format. Development held-out questions (n=60): hit@4 0.683 to 0.867, +0.183 [+0.067, +0.300]; generated +0.222 [+0.067, +0.378], hand-written +0.000 (n=9), Ministry FAQ +0.167 [+0.000, +0.500] (n=6). **Blind PDF (P5, n=69): 0.841 to 0.855, +0.014 [−0.072, +0.101]**; held-out documents +0.062 [−0.125, +0.250] (n=16); training documents +0.000 [−0.113, +0.113] (n=53). By the plan's rule the adaptation is not shown to help and the demo keeps the base embedder. Sections 7 and 8 were skipped as instructed. The last cell (zip of `results/`) stopped with "NameError: name 'shutil' is not defined" because `shutil` is imported in the skipped section 8; the cell now imports it. The P5 output was read from the executed notebook, which is kept in `results/final_blind/`.

### P3 adjudication input prepared for the existing HTML form; waiting on the third grader; not committed (2026-10-13)

`scripts/prepare_adjudication.py` compared the two graders cell by cell and sent to a third grader every cell where they disagree or one left it empty: PDF 17 `correct`, 4 `correct_refusal`, 17 `supported` (16 disagreements, 1 empty), 28 pairwise picks; web 21 `correct` (19 disagreements, all grader 1 = 1 and grader 2 = 0, plus 2 empty), 1 `correct_refusal`, 19 `supported` (14 disagreements, 5 empty), 23 picks. That is the 71 disagreeing and 8 empty binary cells the merge had left out, in 65 rows. The sheet `adjudication/p3_adjudication_input.csv` has the format of the grader sheets, opens in `tools/grading_form.html` (checked: 65 rows load), has new ids and a new A/B order per row, and passed a check for pipeline names, condition names and result paths; the private mapping is `adjudication/p3_adjudication_key.csv`. `scripts/human_grading.py merge` gained `--adjudication-key` to map the form's export back, and now also uses the adjudicator's value for a cell one grader left empty (`tests/test_adjudication.py`). Instructions: `adjudication/p3_adjudication_README.md`. P3 stays provisional until the output is merged.


### P3 adjudicated (2026-10-13)

The third grader's export (`adjudication/p3_adjudication_output.csv`, 65 rows, header and texts unchanged, every `correct` cell filled) was merged with `--adjudication-key`: 38 PDF and 41 web cells decided, 0 unresolved, 0 incomplete. Answerable accuracy, Mizan-lite minus Standard: PDF +0.014 [−0.101, +0.130] (n=69), web +0.029 [−0.007, +0.071] (n=140). By the rule of `docs/ANALYSIS_PLAN.md` (P3: "no loss" only when the lower bound is above −0.10) the claim is **"no loss of answer quality" for web** and **"not distinguishable, small sample" for PDF** (lower bound −0.1014). Correct refusals: PDF 20/24 → 23/24, web 30/33 both. Pairwise pick (secondary, descriptive): PDF 26 Mizan-lite wins against 10, sign test p = 0.011; web 12 against 6, p = 0.24. On the web `correct` cells where only grader 1 had said yes, the third grader sided with grader 2 in 16 of 19. Also received: a `final-adaptation.log` that ends with "no adapter at /content/mizan/finetune/out/q06_lite: run with --train", i.e. a run with the old save code (it prints "Writing model shards"); it holds no P5 result, and P5 stays as recorded from the third attempt.
