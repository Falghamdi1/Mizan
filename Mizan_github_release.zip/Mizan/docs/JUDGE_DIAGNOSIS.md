# Why the LLM judge did not work, and what replaces it

Measured on the stored answers (`python scripts/judge_diagnosis.py`, table in `docs/data_audit/judge_diagnosis.md`). No model was run for this diagnosis. Status: the causes below are measured or read by hand; the fix (judge v2, section 4) is built and unit-tested but **not yet validated against humans**.

## 1. What went wrong, with numbers

| judge | verdicts | said "correct" | when key facts are present | when few key facts are present | few key facts and gold passage not retrieved |
|---|---|---|---|---|---|
| Qwen3-4B (also the generator) | 273 | 91% | 210/216 | 38/57 | 17/25 |
| Gemma 3 4B | 243 | 99% | 196/196 | 45/47 | 19/19 |

("Key facts present" = keyword coverage of at least 0.5. Keyword coverage is only a proxy, so some low-coverage answers may be right paraphrases. By hand, the clear cases were wrong: g6 says "Minister" for "Ministry", g2 gives a date instead of a decision number, g9 and g19 do not answer the question.)

Two more facts:
- No verdict failed to parse (0 of 691), so this is not a parsing bug. The judge understood the format and still said yes.
- Cohen's kappa between the two judges was 0.00 because Gemma almost never says no. The granite-3.3-2B judge in run M1 made two visible errors in 20 verdicts: it called a wrong answer (r1, "two years" instead of three) correct and a right answer (r3, 1,000 riyals) incorrect.

## 2. The causes

1. **Yes-bias from a bare verdict.** The v1 prompt asks a 2B to 4B model for `{"correct": 0|1, "faithful": 0|1}` with no reasoning and no evidence. Small models default to "1" when they cannot decide. Nothing in the prompt makes "1" costly.
2. **The task needs exact Arabic facts.** Telling "Minister" from "Ministry", or a date from a decision number, is a precise reading task. Models of this size do it unreliably.
3. **Two judgments in one call, over the whole context.** Correctness and faithfulness are asked together over four passages. Faithfulness ("every claim supported") is where a small model is most lenient.
4. **The reference is sometimes the problem.** For generated questions (g12, g18, g23) the question itself is ill-posed, so even a perfect judge compares against a bad reference. This is question noise, not judge noise, and human grading with the blind set removes it.
5. **Self-judging.** Qwen3-4B judged its own answers. In this data Qwen was the stricter judge (91% against 99%), so we found no sign of self-inflation, but a self-judge cannot be called independent.
6. **Never validated.** No judge score was ever compared with human labels, so nothing told us its error rate.

## 3. What the project now relies on, in order

1. **Human grading** (two blind graders, `tools/grading_form.html`) is the only correctness evidence we quote.
2. **Deterministic checks** that need no judge: refusal rule, citation present and valid, citation points at the gold passage, key-fact coverage, gold-phrase survival.
3. **The LLM judge** is a triage and screening tool only. It may not be quoted as accuracy unless it passes the gate below.

## 4. The fix: judge v2 (`MIZAN_JUDGE_PROMPT=v2`, default stays v1 so old runs are reproducible)

Changes, each aimed at one cause above:
- The judge must list the key facts of the reference and, for each, **copy the exact words from the answer** that state the same value. Code checks that the quote really is in the answer (cause 1: saying yes without evidence now scores 0).
- The judge must copy the sentence from the context that supports the answer's main claim. Code checks that it is really in the context (cause 3).
- Code adds a **numbers guard**: every number in the reference must appear in the answer (causes 1 and 2).
- "When unsure, the fact is NOT in the answer", and a different person or body does not count (cause 2).
- A verdict that cannot be parsed is counted as failed, never guessed.

Limits: the faithfulness check covers the main claim, not every claim. The numbers guard is strict: a reference with a number the answer omits scores wrong. The judge can still copy a real but irrelevant sentence. Hence the gate.

## 5. The gate: when may a judge replace a human?

`scripts/human_grading.py merge` now reports, for the LLM judge and for keyword coverage, against the final human labels:

- at least 50 graded answers (the lecture "Evaluating LLMs" asks for 50 human-scored answers to check a judge),
- Cohen's kappa of at least 0.6,
- at most 10% of the answers the humans marked wrong accepted by the score (false accept).

The report prints "may replace a human grader: yes/no". Only a "yes" lets us call the score validated. Otherwise it stays a screening aid, and the answer-quality claim rests on the human labels alone. This is decided by the rule above, not after seeing a number we like.

## 6. What to run (needs Colab or the grading)

1. Grade the 10-question sheet and the prompt sheet as already planned.
2. Re-judge the same answers with v2 on Colab (`MIZAN_JUDGE_PROMPT=v2`, a judge different from the generator, for example Gemma 3 4B or a larger local model) and run `human_grading.py merge` to see the gate.
3. If v2 fails the gate, we say so in the final report and keep the human-only claim. We do not tune the prompt on the blind answers.
