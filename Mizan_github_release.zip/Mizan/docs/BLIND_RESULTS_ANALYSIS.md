# Blind test: where Standard and Mizan-lite succeed or fail

Written 2026-10-13 from the raw files of the final run. Every number below was recomputed from per-question records; nothing is copied from an earlier summary. Script: `scripts/analyse_blind_run.py` (reads the raw files, writes nothing into them).

## 0. Sources and what was checked

| what | file | check |
|---|---|---|
| frozen questions | `eval/questions_final_test_pdf.json` (93, 69 answerable), `eval/questions_final_test_web.json` (173, 140 answerable) | sha256 `5b83d599…` / `4ea38d39…` equal the hashes stored in every result file and in `eval/blind_test/FROZEN.json` |
| retrieval run, final stack (P1, P2) | `results/final_blind/eval-20261012-162146.json` (PDF), `eval-20261012-162404.json` (web) | Qwen3-Embedding-0.6B + Qwen3-Reranker-0.6B, top 4, **`chunk_title=False`**, retrieval only |
| answer run, same stack | `results/final_blind/answers_blind_pdf.json`, `answers_blind_web.json` (identical to `eval-20261012-165337.json`, `eval-20261012-172359.json`) | **`chunk_title=True`**, generator Qwen3-4B-Instruct-2507 4-bit, prompt v1, `llm_max_tokens=300` |
| secondary stacks | `eval-20261012-162443.json` / `-162511` (e5-small), `-162724` / `-163023` (Qwen3-Embedding-4B + reranker) | titles off |
| human grading | `results/final_blind/graded/g{1,2}_{pdf,web}.csv`, `grading_{pdf,web}/KEY.json`, `grading_{pdf,web}/human_grading_report.{json,md}` | rubric `eval/human_grading/RUBRIC.md`; arm identity only from KEY |
| corpus | fingerprints in every result file: PDF `c1b846432f4f`, web `b3871676ff02` | equal to the freeze |
| LoRA (P5) | executed notebook `results/final_blind/Mizan_Final_Colab_P5_executed_20261013.ipynb`, section 6 output | the adaptation JSON files were not downloaded from Colab; the numbers below are the printed tables |

`results/` is git-ignored: the raw files exist on this machine and in `Downloads/mizan_final_results.zip`, not in the repository.

## 1. Conflict found: the PDF gain depends on chunk titles

The retrieval run (P1) and the answer run use the same embedder, reranker and questions but differ in one setting: `chunk_title` (the regulation title prepended to each chunk before embedding). `src/colab.py:237` turns titles on for the answer profile; the P1 cell of the final notebook turns them off.

| corpus, n answerable | setting | Standard hit@4 | Mizan-lite hit@4 | difference [95% CI] | MRR difference | candidate recall (gold in top 20) difference |
|---|---|---|---|---|---|---|
| PDF, 69 | titles off (P1 as pre-specified) | 0.681 | 0.797 | **+0.116 [+0.029, +0.217]** | +0.080 [−0.006, +0.165] | **+0.116 [+0.029, +0.203]** |
| PDF, 69 | titles on (the configuration that produced the graded answers) | 0.812 | 0.855 | +0.043 [−0.043, +0.145] | −0.018 [−0.095, +0.059] | **+0.058 [+0.014, +0.116]** |
| web, 140 | titles off (P2) | 0.729 | 0.736 | +0.007 [+0.000, +0.021] | +0.002 [−0.009, +0.013] | −0.007 [−0.021, +0.000] |
| web, 140 | titles on | 0.793 | 0.800 | +0.007 [+0.000, +0.021] | +0.005 [−0.002, +0.014] | +0.000 [+0.000, +0.000] |

- Titles raise Standard on PDF by 0.131 and Mizan-lite by 0.058. With titles on, the top-4 difference is **not distinguishable from zero**; the gain in the 20-candidate pool remains.
- P1 as reported in `EXPERIMENT_RESULTS.md` section 0 is the titles-off number. That is the configuration the notebook fixed before the run, so P1 stands, but the claim must be qualified: **the PDF retrieval gain is shown without titles and is smaller and not distinguishable at top 4 with titles.**
- Discordant questions (hit for one arm only): PDF titles off 2 Standard-only vs 10 Mizan-only; titles on 4 vs 7. Web: 0 vs 1 in both settings.
- Index cost is unaffected in direction: PDF index tokens 72,706 → 49,619 (−31.8%, titles off) and 77,134 → 53,610 (−30.5%, titles on); generator input tokens per PDF question (answer run, titles on, all 93 questions), mean 1,333 → 1,122 (−15.9%), median 1,359 → 1,131 (corrected 2026-10-15: an earlier version gave a median of 1,320 → 1,084, which the per-question records do not reproduce).

## 2. Verified comparison (final stack)

| metric | PDF Standard | PDF Mizan-lite | web Standard | web Mizan-lite | source |
|---|---|---|---|---|---|
| hit@4, titles off (n 69 / 140) | 0.681 | 0.797 | 0.729 | 0.736 | retrieval run |
| hit@4, titles on | 0.812 | 0.855 | 0.793 | 0.800 | answer run |
| first-stage hit (before reranker), titles on | 0.696 | 0.841 | 0.714 | 0.714 | answer run |
| human `correct` on answerable, adjudicated (n) | 0.754 (69) | 0.768 (69) | 0.779 (140) | 0.807 (140) | merge report with `--adjudicated` |
| paired human accuracy difference (n paired) | | +0.014 [−0.101, +0.130] (69) | | +0.029 [−0.007, +0.071] (140) | merge report with `--adjudicated` |
| before adjudication (agreed labels only, kept for reference) | 0.794 (63) | 0.828 (58), paired +0.073 [−0.036, +0.182] (55) | 0.829 (129) | 0.846 (130), paired +0.016 [−0.024, +0.055] (127) | first merge |
| refused an unanswerable question (n 24 / 33) | 21/24 | 24/24 | 30/33 | 30/33 | `abstained` field |
| same, human-graded correct (adjudicated) | 20/24 | 23/24 | 30/33 | 30/33 | merge report with `--adjudicated` |
| refused an **answerable** question | 4/69 | 4/69 | 25/140 | 23/140 | `abstained` field |
| answers flagged as cut off at 300 tokens | 7/93 | 3/93 | 2/173 | 2/173 | `possibly_truncated` |
| secondary: e5-small hit@4 (discordant Std-only / Mizan-only) | 0.391 | 0.652 (1 / 19) | 0.714 | 0.721 (0 / 1) | e5 runs |
| secondary: Qwen3-Embedding-4B + reranker hit@4 | 0.739 | 0.841 (1 / 8) | 0.786 | 0.793 (1 / 2) | 4B runs |

## 3. Examples

**Selection rule (no hand-picking).** Retrieval categories use the answer run (titles on), because its answers were graded. Every discordant question is listed. For "both succeed" and "both fail" the first two question ids are shown. "Text difference" is measured on the page that contains the gold phrase in each arm's preprocessed text (`src/preprocessing.py`): presentation-form characters were 0 on every gold page in both arms, so the only character-level difference found on PDF gold pages is the kashida (tatweel, U+0640) count.

### 3a. Every PDF question with a hit for one arm only (titles on)

| id | type | hit Std / Lite (rank) | gold in top 20 Std / Lite | human correct Std / Lite (g1,g2) | tatweel on gold page Std → Lite | what happened |
|---|---|---|---|---|---|---|
| pdf-011 | duration | 0 / 1 (4) | 1 / 1 | 1,1 / 1,0 | 260 → 0 | both answered "30 days" from the travel-services directory; Lite's top 4 also held the hospitality-management page |
| pdf-012 | list | 0 / 1 (2) | 0 / 1 | 0,0 / 1,1 | 180 → 0 | Standard: gold not among 20 candidates, refused; Lite retrieved page 13 and answered "180 days" |
| pdf-014 | direct | 0 / 1 (2) | 0 / 1 | 1,1 / 1,1 | 260 → 0 | both answered "30 days"; only Lite cited the gold page |
| pdf-025 | duration | 0 / 1 (1) | 0 / 1 | 0,0 / 0,0 | 221 → 0 | Lite retrieved the gold at rank 1 and **still refused** (generator failure) |
| pdf-048 | fee | 0 / 1 (4) | 1 / 1 | 0,0 / 1,1 | 219 → 0 | Standard answered 800,000 SAR (a category's guarantee, not the cap); Lite answered "two million" with the gold citation |
| pdf-061 | list | 0 / 1 (1) | 1 / 1 | 0,0 / 1,1 | 187 → 0 | gold in both pools; the reranker put it first only for Lite |
| pdf-064 | list | 0 / 1 (4) | 1 / 1 | 1,1 / 1,0 | 148 → 0 | both listed requirements; graders split on Lite |
| pdf-013 | direct (dialect) | 1 (4) / 0 | 1 / 1 | 1,1 / 0,1 | 173 → 0 | gold in both pools; reranked out for Lite; Lite answered with a different rule |
| pdf-051 | direct | 1 (1) / 0 | 1 / 1 | 1,1 / 0,0 | 41 → 0 | Lite's top 4 came from four other regulations; Lite refused |
| pdf-067 | definition | 1 (4) / 0 | 1 / 1 | 1,1 / 1,1 | 167 → 0 | both gave the right definition; Lite cited the near-identical definition in the Management regulation |
| pdf-084 | direct | 1 (4) / 0 | 1 / 1 | 0,0 / 0,0 | 223 → 0 | both answered wrongly ("may work independently"), Standard despite citing the gold page |

Web (titles on): one discordant question, **web-031** (hit Std 0 / Lite 1 at rank 4, both refused, both graded 0). Its gold is in `law/accommodation-association`, which is near-identical to `law/travel-association` (source note in the answer key); the top 4 of both arms came from the wrong association. No character difference on web gold pages (tatweel 0 or 1).

### 3b. Both succeed / both fail (first two ids)

| id | corpus | hit Std / Lite | human correct Std / Lite | observation |
|---|---|---|---|---|
| pdf-001 | PDF | 1 / 1 | 0,0 / 1,1 | same gold page at rank 1; Standard's answer listed fees for transferring ownership as guarantees (wrong), Lite listed the guarantee categories (right). Retrieval equal, generation differed |
| pdf-002 | PDF | 1 / 1 | 1,1 / 1,1 | both: category A, gold cited |
| pdf-007 | PDF | 0 / 0 | 0,0 / 0,0 | gold ("no replacement-licence service") not among 20 candidates in either arm; both refused |
| pdf-022 | PDF | 0 / 0 | 0,0 / 1,1 | neither top 4 held a gold page (11, 14); Lite answered "two working days" from page 6, which states the same fact: **the gold list is incomplete** |
| web-001 | web | 1 / 1 | 1,1 / 1,1 | identical retrieval and answer |
| web-002 | web | 1 / 1 | 1,1 / 1,1 | identical retrieval and answer |
| web-010 | web | 0 / 0 | 1,1 / 1,1 | gold in `definitions`, both retrieved the Umrah methodology and still answered correctly: again a gold list that misses an equivalent passage |
| web-011 | web | 0 / 0 | 0,0 / 0,0 | the right document (tourism law) in all four slots, wrong page; both refused |

### 3c. Questions where the human grade differs between arms (agreed labels)

| corpus | Mizan-lite correct only | Standard correct only |
|---|---|---|
| PDF | pdf-001, 010, 012, 022, 048, 061, 086 (7) | pdf-008, 051, 052 (3) |
| web | web-030, 110, 125, 143 (4; in all four Standard refused) | web-063, 144 (2; in both Lite refused) |

## 4. Failure patterns

**Observed (counts from the files, titles on):**

| pattern | PDF Std | PDF Lite | web Std | web Lite |
|---|---|---|---|---|
| retrieval misses (answerable) | 13 | 10 | 29 | 28 |
| … gold not among the 20 candidates (first stage) | 7 | 3 | 18 | 18 |
| … gold among 20, reranked out of the top 4 | 6 | 7 | 11 | 10 |
| … right document in top 4, wrong passage | 8 | 8 | 20 | 21 |
| retrieval hit but human-graded wrong | 5 | 5 | 8 | 7 |
| retrieval miss but human-graded right (gold list incomplete or another page states the fact) | 5 | 4 | 9 | 8 |
| answerable question refused | 4 | 4 | 25 | 23 |

- Mizan-lite's PDF advantage sits in the **first stage**: gold among 20 candidates 0.899 → 0.957 (titles on), first-stage hit 0.696 → 0.841. Reranker drop-outs are equal (6 vs 7).
- On web the two arms behave the same at every stage; failures are near-duplicate documents (the two association laws), the right document with the wrong passage, and refusals.
- The generator refuses 1 in 6 answerable web questions in both arms (25 and 23 of 140). This is the largest single answer-level failure and it is not affected by preprocessing.
- Hit@4 and human correctness disagree in 11% to 16% of graded answers (per arm and corpus), in both directions; retrieval scores here are a proxy for answer quality, not a measure of it.

**Hypotheses (not established by these files):**
- Kashida removal is the plausible cause of the PDF first-stage gain: 65 of the 69 PDF gold pages carry kashidas in Standard (up to 352 per page; 4 have none) and none in Mizan-lite, and the index has 31% fewer embedding tokens. But kashidas are on *all* PDF pages, including the 52 questions both arms got right and the 4 Standard-only ones, so the files show a correlation across the corpus, not a per-question cause. The leave-one-out on development data (`EXPERIMENT_RESULTS.md` section 4: removing `remove_tatweel` costs −0.195 with e5-small) supports the hypothesis on other questions.
- Titles probably supply the document identity that kashida-damaged text hides from Standard, which would explain why titles narrow the gap. Not tested directly.

## 5. Human grading

- **Protocol** (`docs/ANALYSIS_PLAN.md` section 7, `eval/human_grading/RUBRIC.md`): two graders, alone, blind sheets (answers in shuffled A/B columns, arm names only in `KEY.json`), `correct` 0/1 for every answer, `supported` 0/1 for non-refusals, pairwise A/B/tie as a secondary view. Graded with `tools/grading_form.html`, merged with `scripts/human_grading.py merge`.
- **Coverage:** every row of both sheets (93 PDF, 173 web); 8 of 1,064 cells empty (1 PDF, 7 web).
- **Agreement:**

| sheet | `correct` agreement / kappa | `supported` agreement / kappa | disagreeing cells | direction of `correct` disagreements |
|---|---|---|---|---|
| PDF | 0.887 / **0.649** | 0.879 / 0.608 | 37 | grader 1 = 1, grader 2 = 0: 12; reverse: 9 (balanced) |
| web | 0.942 / **0.794** | 0.940 / 0.507 | 34 | grader 1 = 1, grader 2 = 0: 19; reverse: 1 (**grader 1 systematically more lenient on web**) |

- Disagreements are spread over both arms (PDF `correct`: 8 Standard, 13 Mizan-lite; web: 11 and 9).
- **Adjudication (2026-10-13):** a third team member graded every cell where the two graders disagreed or one left it empty (79 cells: 38 PDF, 41 web) on a re-blinded sheet (`scripts/prepare_adjudication.py`, new ids and a new A/B order per row, opened in `tools/grading_form.html`), then `merge --adjudicated --adjudication-key`. Result: 0 unresolved, 0 incomplete. On the 19 web `correct` cells where only grader 1 said yes, the third grader sided with the stricter grader 2 in 16; on PDF `correct` the third grader sided with grader 2 in 11 of 17. Final P3: PDF +0.014 [−0.101, +0.130] (n=69), web +0.029 [−0.007, +0.071] (n=140). The PDF lower bound (−0.1014) misses the plan's −0.10 line, so "no loss" is claimed for web only.
- `supported` on web has kappa 0.507, below the 0.6 bar: web "cited source supports the answer" figures should not be quoted.
- The LLM judge was not used.

## 6. LoRA (P5)

| set (adapter vs base, same text: Mizan-lite, titles on, no reranker) | n | base hit@4 | adapter | difference [95% CI] |
|---|---|---|---|---|
| development, generated questions (same model family and style as the training pairs) | 45 | 0.689 | 0.911 | +0.222 [+0.067, +0.378] |
| development, hand-written | 9 | 0.778 | 0.778 | +0.000 |
| development, Ministry FAQ on held-out documents | 6 | 0.500 | 0.667 | +0.167 [+0.000, +0.500] |
| **blind PDF, all documents (P5)** | 69 | 0.841 | 0.855 | **+0.014 [−0.072, +0.101]** |
| blind PDF, documents held out of training | 16 | 0.875 | 0.938 | +0.062 [−0.125, +0.250] |
| blind PDF, documents used in training | 53 | 0.830 | 0.830 | +0.000 [−0.113, +0.113] |

- Matched comparison (same text, settings and questions in both arms); training: 554 pairs from six regulations, 3 epochs, 105 steps, loss 1.15 → 0.01.
- **No meaningful improvement on independent questions.** The large development gain appears only on generated questions written like the training pairs; the hand-written development questions and the blind set show none. The likeliest reading is that the adapter learned the style of the generated queries; the data cannot rule out a small real effect (upper bound +0.101).
- The held-out-documents row is too small (16) to say anything about generalisation.
- Three attempts were needed (incompatible torchao; renamed uploads; full-model save); the blind set was used once, in the third. The adaptation JSON files were not downloaded; the table comes from the notebook's printed output.

## 7. For the presentation

**Findings**
1. On damaged PDF text, Mizan-lite finds the gold evidence more often: +0.116 hit@4 [+0.029, +0.217] (n=69) on the pre-specified configuration, +0.26 with a small embedder, +0.10 with a 4B embedder; the gain is in the first retrieval stage.
2. With regulation titles added to chunks, Standard closes most of the gap (+0.043, not distinguishable); Mizan-lite still keeps more gold passages among the 20 candidates (+0.058 [+0.014, +0.116]).
3. On clean web text the two pipelines are the same: +0.007, one discordant question in 140.
4. Answer quality, graded by two people and adjudicated by a third: no loss on web (+0.029 [−0.007, +0.071]); on PDF not distinguishable from zero (+0.014 [−0.101, +0.130]), a sample too small to rule out a loss just above 0.10. Correct refusals of unanswerable PDF questions: Mizan-lite 23/24, Standard 20/24.
5. Mizan-lite cuts the PDF index by about 31% of embedding tokens and the generator input by about 18%.
6. The fine-tuned embedder does not help on independent questions (+0.014, interval includes 0), although it gained +0.22 on questions in its training style.

**Limitations**
- One run; questions treated as independent (many share a page or document), so intervals are optimistic.
- The set was written by the team and formatted by an LLM; 266 questions instead of the planned 45 to 60; no answer keywords (deviations logged in `docs/EXPERIMENT_LOG.md`).
- The P1 gain depends on a setting (titles) that was not part of the pre-registered stack description; both readings are reported.
- All three graders are team members; before adjudication web grader leniency was systematic and `supported` on web was below the agreement bar (kappa 0.507).
- Gold lists miss equivalent passages (examples pdf-022, web-010), so hit@4 understates both pipelines.
- 1 in 6 answerable web questions is refused by the generator in both arms; 7 Standard and 3 Mizan-lite PDF answers hit the 300-token limit.
- The kashida explanation is a hypothesis supported by development ablations, not a per-question cause shown by these files.

**Not verifiable from the available files:** the adaptation JSON outputs (only printed tables), any result for the full preset beyond the retrieval tables.
