# Public release audit (2026-10-13)

Checked before making the repository public on GitHub. Decisions below were made by the team on 2026-10-13.

## Decisions and what was done

| # | finding | decision | done |
|---|---|---|---|
| 1 | No licence | MIT for code and documentation; it does not cover the source documents or model weights | `LICENSE` |
| 2 | Permission for tourism.sa content recorded inconsistently | the request was **sent and approved** (team record; the approval e-mail is kept by the team) | `docs/PERMISSION_REQUEST.md`, `FINAL_AUDIT.md`, `FINAL_CHECKLIST.md`, `docs/DATA_AUDIT.md`, `docs/RESPONSIBLE_AI.md`, `TEAM_HANDOFF.md`, README updated |
| 3 | Tracked files quote or derive from the source documents | keep them out of the public repository without breaking anything | untracked and git-ignored (still on the team's machines): `eval/questions.json`, `eval/questions_large.json`, `eval/questions_large_review.md`, `eval/questions_combined.json`, `eval/pdf_faq_alignment.json`, `eval/questions_final_test_{pdf,web}.json`, `eval/blind_test/joint_authors.csv`, `adjudication/p3_adjudication_{input,output}.csv`, and the three older notebooks that embed them (`Mizan_Arabic_RAG_Optimization.ipynb`, `Mizan_Web_Evaluation_Colab.ipynb`, `Mizan_Final_Colab.ipynb`). The team copy is `mizan_private_eval.zip` (git-ignored; unzip into the repository root). Without these files the app runs without prepared questions, `demo.py` stops with a clear message, evaluation scripts stop with a clear message, and tests that need them are skipped |
| 4 | Personal e-mail as commit author | accepted by the author | none |
| 5 | Local machine paths in `docs/Mizan_notebook_local_run.html` | remove the file | deleted |
| – | Notebook duplicating the codebase | new `Mizan_Demo_Colab.ipynb` (built by `scripts/build_demo_notebook.py`) clones the repository and runs the app; no code or data copied into cells | done |

## Important: the git history still contains the removed files

Untracking stops future commits from carrying these files, but **every earlier commit still contains them** (and the deleted HTML with local paths). Pushing this repository's full history would publish them. Publish a fresh history instead (non-destructive: the private history stays on the team's machine):

```bash
git checkout --orphan public-main
git commit -m "Mizan: Arabic-aware preprocessing for RAG (capstone release)"
git push -u origin public-main:main
git checkout master
```

Run this only after the current changes are committed, and check on GitHub that no `eval/questions*.json`, notebook with embedded data, or adjudication CSV appears in the file list.

## Other findings

| finding | status |
|---|---|
| Secrets: no API keys, tokens, webhooks or passwords in tracked files or in any commit (pattern scan of the full history); `.env` was never committed | none found |
| Model weights, adapters, vector stores, caches | none tracked (`finetune/out/`, `results/`, `logs/`, `data/raw/`, `data/web/` are git-ignored) |
| `eval/safety/pii.jsonl` | synthetic placeholders and public organisation addresses; no real person |
| Short regulation snippets inside tests and `eval/blind_test/examples.csv` (3 development rows) | kept: a few words each, needed by the tests, covered by the approved permission |
| `data/sample/`: four synthetic PDFs of 8 to 13 MB each (46 MB) because the full Arial font is embedded | done 2026-10-15: fonts subset (about 90 KB per file, 0.36 MB in all); every page's text, the loader's output and the corpus fingerprint are unchanged, and `scripts/make_sample_pdfs.py` now subsets too |
| `Mizan_Submission2.pptx`, `docs/individual_report/INDIVIDUAL_REPORT_TEMPLATE.docx` are tracked although `*.pptx` is ignored | course material; remove if it should not be public |
| `requirements.txt` allowed Gradio 4.40, but `app.launch()` uses the Gradio 6 API | fixed: `gradio>=6.0` (tested 6.9.0) |
| The local `.env` (never tracked) uses the LoRA adapter and no reranker | set `MIZAN_EMBEDDING_ADAPTER=` and `MIZAN_RERANKER=Qwen/Qwen3-Reranker-0.6B` before the demo |
| Older status documents contradict the final results | the README states that it and `EXPERIMENT_RESULTS.md` are current |
| Model licences | Qwen3: Apache-2.0; multilingual-e5-small: MIT (model cards); not redistributed |

## Verified on 2026-10-13 in a simulated public clone (the staged files only, plus the downloaded PDFs)
- `python -m pytest tests`: 397 passed, 10 skipped (team-only files, local training pairs, real web corpus).
- `python app.py` (offline embedder and mock generator): HTTP 200, no prepared questions.
- `python demo.py`: stops with the message to unzip the team files.
- `Mizan_Demo_Colab.ipynb` executed outside Colab with the offline embedder and the mock generator: every cell ran, without and with `mizan_private_eval.zip`; with it, 10 prepared questions load and `make_blind_test.py --verify` passes.
- Not verified: the notebook on Colab with the real models, and a GitHub rendering of the README.

## GitHub readiness check before publishing (2026-10-15, final integration)

Run on the staged tree (210 files: the 171 committed at `8b56462` plus the integration changes), exported with `git checkout-index` into an empty folder. Nothing is committed or pushed.

| # | check | how | result |
|---|---|---|---|
| 1 | Secrets in the files to publish | pattern scan (API keys, `sk-`, `hf_`, AWS, GitHub, Slack and Discord webhooks, private keys, password assignments) over every staged file | none; the only match is the deliberately fake key in `tests/test_insights.py` that tests the Insights validator |
| 2 | Secrets in the history | the same scan over `git log -p --all` (30 commits) | none |
| 3 | Local machine paths | scan for user folders, `AppData`, home directories | none in staged files (two audit scripts fixed in this integration) |
| 4 | `.env` | `git check-ignore` | ignored, never committed; `.env.example` holds only empty keys and offline defaults |
| 5 | Virtual environments, caches, build output | `.gitignore` | `.venv/`, `__pycache__/`, `.pytest_cache/`, `.mypy_cache/`, `.ruff_cache/`, `.ipynb_checkpoints/`, `node_modules/`, `dist/`, `build/`, `*.egg-info/`, Office lock files, `logs/`, `results/`, `data/raw/`, `data/web/`, model output `finetune/out/` are all ignored; none is staged |
| 6 | Large files | sizes of staged files and of every blob in the history | largest staged file 0.5 MB (`Mizan_Submission2.pptx`) after the sample PDFs were font-subset; the older commits still hold the 12.8 MB originals, which a fresh history (step 1 below) leaves out; all below GitHub's 50 MB warning; no model weights, adapters, vector stores or videos are tracked (the project video and its media are ignored under `video/`) |
| 7 | Team-only evaluation data | the list in decision 3 above | still untracked; `eval/blind_test/FROZEN.json` (hashes only) and the adjudication key (ids and pipeline names, no text) are tracked as evidence |
| 8 | Reproducibility from a clean checkout | new Python 3.11 virtual environment; `pip install torch` (CPU) and `pip install -r requirements.txt`; `pip check`; `cp .env.example .env`; `python scripts/fetch_corpus.py`; `python -m pytest tests`; `python app.py` with the evaluated configuration | see `INTEGRATION_REPORT.md` section 5 |
| 9 | Static checks | `ruff check --select F,E9` (undefined names, unused imports and variables, syntax) | clean after removing 18 unused imports and variables |
| 10 | Licences and attribution | `LICENSE` (MIT); README section 13; model licences (Qwen3 Apache-2.0, e5 MIT); video fonts (OFL) and HyperFrames (Apache-2.0) credited in `video/README.md` | present |

**Before the first push (for the team):**

1. Commit the staged changes, then publish a fresh history as described above (`git checkout --orphan public-main`), because the older commits still contain the files removed in decision 3.
2. Delete the empty stray file `web/grader_N.csv` (untracked, 0 bytes; it was left out of the staged tree).
3. Decide whether the course decks (`Mizan_Submission2.pptx`, `docs/Mizan_Technical_Design_Final.pptx`) and `docs/individual_report/` should be public.
4. Add the GitHub remote (none is configured), push, and check on GitHub that the README and its Mermaid diagram render.
