> **STALE (2026-10-10): historical briefing for the first mentor meeting.** Its numbers are from the first notebook run with the full preset on the PDFs only (and its keyword-coverage and judge figures could not be traced to a result file). Current numbers: `EXPERIMENT_RESULTS.md`.

# Mizan: MVP briefing for the bootcamp presentation

**Message:** we built a working prototype that can test the idea fairly, and we now want expert guidance on what to refine next. The prototype shows that the *measurement setup works*; it does not yet show that Arabic-aware preprocessing improves RAG. Say that yourself before anyone asks.

Everything below is measured in one run on the author's laptop (RTX 3070, 8 GB, generator in 4-bit). The notebook has **not** been run on Colab yet (see "Before you present").

---

## 1. MVP overview

**What Mizan is.** An Arabic RAG experiment. It asks one question: *can Arabic-specific text preprocessing improve the retrieval quality or the efficiency of a RAG system compared with a standard pipeline?*

**The setup.** Two pipelines, identical in everything except the preprocessing:

| | Standard RAG | Mizan |
|---|---|---|
| Documents | 8 public Saudi Ministry of Tourism regulation PDFs (159 pages) | same |
| Questions | 10 reference questions (9 answerable, 1 unanswerable) + 51 generated questions for retrieval-only | same |
| Models | Qwen3 embedder, Qwen3 reranker, Qwen3-4B generator | same |
| Preprocessing | trim and collapse whitespace | invisible-character removal, Unicode NFKC, repair of reversed lam-alef ligatures, header/footer and line-wrap cleanup, kashida and diacritics removal, alef / ya / digit / punctuation normalisation |

Mizan here is text normalisation. It is not a tokenizer and nothing was trained for this notebook.

## 2. What we built (architecture)

- **Two-stage local retrieval.** Stage 1: a Qwen3 embedding model finds the top 20 passages. Stage 2: Qwen3-Reranker-0.6B re-scores them. The best 4 go to the generator.
- **Generator.** Qwen3-4B-Instruct in 4-bit, greedy decoding.
- **Evaluator.** Retrieval metrics against gold evidence phrases (a fixed normalisation independent of both pipelines), keyword coverage, and an independent judge (IBM Granite 3.3 2B, not a Qwen model).
- **Measured configuration.** Qwen3-Embedding-**0.6B** + Qwen3-Reranker-0.6B + Qwen3-4B (4-bit). The notebook also has a profile with the 4B embedder (chosen automatically on a T4); it is built but was **not run** here, so no number below comes from it.
- **Cost.** No API, no key, no paid endpoint. Model weights (about 22 GB for the full stack) are downloaded once from the Hugging Face Hub.
- **Memory safety.** The notebook plans GPU memory, keeps only one of generator or judge loaded, tests each model at worst-case size, and steps down to a smaller profile if memory runs out.
- **Interface.** A notebook UI with "Add PDF", a question box and "Ask Mizan", side by side, with sources and measured values.

## 3. Results (single run, small sample: observations, not conclusions)

**Where it helped: token efficiency.**

| Per query | Standard RAG | Mizan | Change |
|---|---|---|---|
| Retrieved tokens | 999 | 827 | -17% |
| LLM input tokens | 1,262 | 1,089 | -14% |
| LLM output tokens | 77 | 70 | -9% |

The one-step ablations point to kashida removal as the step that does most of this (kashida is about 13% of the characters in these PDFs).

**Where it did not (clearly) help: retrieval.** 45 answerable generated questions, paired bootstrap, 95% interval for Mizan minus Standard:

| Retrieval metric | Standard | Mizan | Difference [95% CI] |
|---|---|---|---|
| Hit@4 before reranking | 0.667 | 0.600 | -0.067 [-0.200, +0.067] |
| Hit@4 after reranking | 0.756 | 0.756 | +0.000 [-0.089, +0.089] |
| MRR | 0.578 | 0.624 | +0.046 [-0.050, +0.141] |
| Gold evidence inside the top-20 candidates | 0.822 | 0.933 | +0.111 [-0.022, +0.244] |

Every interval includes zero. The last row is the only one that leans toward Mizan; it is suggestive, not established. The reranker did help both pipelines (Standard 0.667 to 0.756).

**Answer run, 10 questions (too few to test anything).** Hit@4 1.000 vs 1.000. Keyword coverage 0.944 vs 0.833. Independent judge "correct" 0.90 vs 0.90 (the judge is small and unvalidated). No refusals of answerable questions.

**Latency, medians, one run.** Retrieval 0.82 s vs 0.72 s; generation 3.98 s vs 3.61 s; end to end 4.74 s vs 4.32 s. Not a conclusion: single run, noisy, and a shorter prompt may explain part of it.

**Trade-offs and cases where normalisation hurt** (one-step ablations, 54 answerable questions, base 0.6B embedder, single-stage; 27 comparisons, none corrected for multiple testing):

- The two lossy folds, **ta marbuta** and **hamza seats**, lowered hit@4 by 0.13 each (intervals exclude zero). They are off in the Mizan preset for exactly this reason.
- **Line-joining** (-0.11) and **alef folding** (-0.07) also scored lower on their own. We do not have a good explanation yet.
- **Unicode NFKC, Persian-letter and digit folding changed nothing** on this corpus: it contains no presentation-form glyphs.
- Cleaning shortens the text, so the same page yields fewer chunks (320 vs 358). Chunk size is counted in characters, so preprocessing and chunking are entangled: a known confound.

## 4. Data and parser bottlenecks

- **Reversed lam-alef ligatures.** 1,464 places across the 8 PDFs (for example "ثلاثة" extracted as "ثالثة"). Repaired from glyph geometry; it helped retrieval little, but it changes the words the model sees.
- **Kashida elongation.** About 10-14% of characters in every document. Pure noise for retrieval.
- **Tables lose their structure.** Fee tables come out as fused text (for example "إصدار الترخيص500 750 1,000"), so the amount is separated from its row and column labels. Table questions are the hardest and the most important.
- **Other defects.** Repeated headers and footers, hard line wraps, a text-less last page in every PDF. Right-to-left order mostly survived extraction in this corpus; the damage is in letters, ligatures and tables.
- **Lightweight-model trade-offs.** The 4-bit generator sometimes slips (an answer wrote "القابل المالي" instead of "المقابل المالي"); the effect of 4-bit on answers was not measured. The 0.6B embedder and reranker are small; the 4B embedder was not tested. The judge is a small model with no human validation. Embedder, reranker and generator are all Qwen, so a shared bias is possible.

## 5. Questions for mentors and experts

**Data engineering.**
1. Which free, open-source tools give the cleanest Arabic PDF to Markdown, with tables kept as tables, before chunking? (We have not compared candidates such as Docling, Marker or pymupdf4llm; which would you try first?)
2. Is it better to fix extraction defects (ligatures, kashida) at parse time or as a text preprocessing step we can measure?
3. How would you chunk regulation documents with tables and numbered articles: by token budget, by article, or by layout?

**Domain and BI.**
1. Which public Arabic datasets (Saudi open data portals, other ministries, tourism statistics, FAQs) would make a stronger V2 benchmark, ideally with real user questions?
2. Who could review and write gold answers for a human-checked question set?
3. What kinds of questions would tourism or BI users actually ask (numbers, fees, eligibility, deadlines)?

**ML and RAG.**
1. Which zero-cost refinements should come first: hybrid BM25 + dense retrieval, Arabic stop-word and clitic handling, query rewriting, or a larger candidate pool for the reranker?
2. How should we validate an LLM judge for Arabic with little human labelling?
3. Is it worth testing the 4B embedder and 4B reranker, given the 0.6B models already retrieve the gold passage in most top-20 lists?

## 6. V2 roadmap

1. **Fix the parsing first.** Compare two or three open-source Arabic PDF-to-Markdown parsers on our tables; keep table rows intact; switch to token-based chunking so cleaning no longer changes chunk sizes. This addresses the biggest data bottleneck and the biggest confound.
2. **Add the baselines normalisation should matter most for.** BM25 and hybrid BM25 + dense retrieval, plus Arabic stop-word and clitic handling, with the same one-step ablations. Run each configuration several times and report intervals.
3. **Build a bigger, human-reviewed benchmark.** At least 100 questions written or checked by people from a second corpus, a human-graded sample of answers to validate the judge, and the 4B embedder and reranker tested properly.

## Before you present

- **Run the notebook once on Colab (T4) before the day.** It was verified end to end only on a laptop GPU with the smaller embedder. Not yet confirmed on Colab: the 4B-embedder profile, the notebook widgets, the download from the ministry site (if blocked, upload the PDFs into `mizan/data/raw/`), and the first-run download time.
- Describe results as "no distinguishable difference in retrieval; fewer tokens sent to the model". Do not say "Mizan improves retrieval".
- The 51 generated questions were not reviewed by a person; the 10 reference questions cover 2 of the 8 documents.
