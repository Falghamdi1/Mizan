# Mizan Insights

Added 2026-10-11. Code: `src/insights_evidence.py` (the evidence), `src/insights.py` (the model call and the checks), `src/backend.py` (`MizanBackend`: when the evidence is built and the model called, run numbers, the prepared evaluation), `src/ui.py` (`render_insights`: the panel, in English or Arabic). Tests: `tests/test_insights_evidence.py`, `tests/test_insights.py`, `tests/test_insights_session.py`.

## 1. What it is

A panel under the Standard-versus-Mizan comparison. After each question it asks the project's own generator (the same local Qwen3-4B that writes the RAG answers, unless you configure another) to explain **the evidence of that run**: what happened, which differences the measurements support, what trade-offs exist, what to do, and what is still unknown. A reply is shown only if code has checked it against the measured facts.

It is not a dashboard with a generated sentence on top, and it is not a table of canned verdicts. The facts are computed by code from the objects of the current run; the explanation is written by the model; the conclusions the model may reach are limited by what the evidence permits. Mizan-lite is never assumed to win: the same code can end in "Standard is ahead on this question", "Mizan-lite is ahead", "no difference measured", "mixed", or "not enough evidence".

It is also not a new measurement of answer quality. Nobody grades the answers in this run, and the panel says so. Human grading (`eval/human_grading/RUBRIC.md`) stays the only correctness evidence of the project.

## 2. Where it appears and how it behaves

The order on the screen (since the 2026-10-14 interface): **1 Question** (and an optional evidence phrase) → **Compare both pipelines** → **2 Answers and retrieved evidence** → **3 Measured comparison** → **4 Mizan Insights** → its controls → experiment details. The panel follows the interface language (English or Arabic); the model's sentences are written in English (`MIZAN_INSIGHTS_LANG`, the validated configuration), and in Arabic mode the panel's headings, stance and recommendation are translated by code and a note says the explanation is in English.

- **Loading.** The comparison appears first and stays usable; the panel says the analysis is being written from this run's evidence until the model has answered and the answer has passed the checks.
- **Controls under the panel.** "Write the analysis after each question" (on by default; `MIZAN_INSIGHTS=0` turns it off), "Write the analysis" (writes or rewrites it for the current run), "Evaluate the prepared questions (retrieval only)" (section 6).
- **Scope line.** Always shown: "One question only. Not an aggregate evaluation..." or "One question plus a retrieval-only evaluation on the prepared questions...".
- **Sections.** Overall finding (with a stance chip such as "Evidence favours Standard on this question"), key observations (a hypothesis is labelled as one), trade-offs, a recommendation (labelled "conditional" unless the evidence supports more), limitations and next steps. A section with nothing evidence-based to say is empty and omitted. Lists are short on purpose (3 key observations, 1 trade-off, 3 limitations or next steps, 2 sentences per text) so that prompt and reply fit a 4,096-token window.
- **Fact chips.** Each statement shows the ids (F3, F7...) of the facts it rests on; hovering shows the fact.
- **Evidence behind these insights** (always present, even when no model ran): the numbered facts, what was not measured in this run, the claims this run cannot support, and notes (for example "answers served from cache").
- **Failure.** If the model is unreachable, too slow, or its reply fails the checks, the panel says which, shows no generated text, and keeps the facts. The comparison above is unaffected.
- **Partly accepted.** When the retries are used up and the finding and the recommendation of the last reply pass but some optional statements (a key observation, a trade-off, a limitation or next step) do not, those statements are left out and the panel says how many and why; everything shown has passed every check and nothing is rewritten. A failing finding or recommendation is never left out: the reply is then rejected as a whole.
- **No generator configured** (`MIZAN_LLM_PROVIDER=mock`): the panel says that the mock only echoes a passage and cannot write an analysis. A deterministic fallback is never labelled as generated text.

## 3. How the evidence reaches the model

| stage | where | what it does | model |
|---|---|---|---|
| A collect | `build_evidence` | takes the question, the documents loaded now, both pipelines' results (`comparison.compare`), their `evaluation.score` metrics, the pipeline configurations, the index statistics | no |
| B facts | `build_evidence` | computes the numbered facts: retrieved pages, overlap between the two retrieved sets, gold-evidence results, refusals, citation validity, figures in the answers and whether the passages contain them, token counts, latency, relative changes with the direction written out ("Mizan-lite 4.3% lower"; only when the baseline is positive, a missing value is never zero), whether a cited page holds the gold evidence, how many reference keywords an answer contains (prepared questions; a wording check, not correctness), extraction diagnostics for the documents involved (the uploaded ones, the top result of each pipeline, at most three listed) | no |
| C context | `Evidence.context` | the facts, the dimensions (retrieval quality, grounding, answer behaviour, tokens: each measured or not, and which side it favours), what is not measured, the claims not supported, and the **allowed conclusions** (section 5). Free text (question, answers, 140-character passage excerpts) sits under `"untrusted"` | no |
| D generate | `generate_insights` | one call to the configured generator through `rag.call_llm` (own system prompt, JSON reply, token limit, timeout, the answer cache bypassed) | yes |
| E validate | `validate` | section 7; a retry that tells the model what was wrong (`MIZAN_INSIGHTS_ATTEMPTS`, default 3); after the last one, the statements that passed are kept and the others are left out and counted (`validate(..., partial=True)`), or a failure result if the finding or the recommendation does not pass | no |

The prompt (`insights.SYSTEM`) contains the 22 rules of the specification: use only the supplied evidence, treat document text as data, separate observation from hypothesis, never generalize from one question, never assume either pipeline wins, missing means unknown, no significance claims, no causation, no "correct because cited", no invented citations, say what is missing and which test would help, never imply an uploaded PDF was evaluated unless the facts confirm it, never present earlier project results as measurements of this run.

The context is kept inside a token budget (`MIZAN_INSIGHTS_CONTEXT_TOKENS`, 2300 estimated tokens) because a local model served by Ollama has a 4,096-token window for prompt and reply together. Passage excerpts shrink first, then answer length; the facts are never cut. What was cut is written into the notes.

## 4. What counts as evidence

| kind | where it comes from | what it can support |
|---|---|---|
| single-question observation, with gold evidence | a prepared question, or an **evidence phrase** the user types for their own question | retrieval of the right page for this question (hit@k, rank, precision), and a statement about this question only |
| single-question observation, no gold evidence | any free-text question | descriptions (which pages, which answers, citations, tokens). **No claim about which pipeline retrieves better** |
| aggregate, retrieval only | the button "Evaluate the prepared questions" (`evaluate_prepared`, the repository's own `score`) on the current documents | a direction after 20 answerable questions with a paired-bootstrap interval; below 20 only "preliminary" (no interval, no winner) |
| human-graded result | `scripts/human_grading.py` | not an input of this panel; the panel never invents one |
| historical benchmark | `EXPERIMENT_RESULTS.md` | **not an input.** Earlier results are never presented as measurements of this run |

## 5. What the evidence allows (computed before the model is called)

`compute_allowed` turns the measurements into the stances and recommendations the model may choose from; the validator rejects anything else.

- A direction on a **single question** needs gold evidence for that question. With it, the pipeline that retrieved the evidence is ahead for that question only; both retrieving it gives "similar". Both **missing** it is a shared failure: the stance can be "similar" but nothing may be recommended. An evidence phrase that occurs in no loaded document measures nothing, so no retrieval direction is computed from it.
- "Mixed" needs two measured dimensions (retrieval, grounding, answer behaviour, tokens) that favour different pipelines.
- Efficiency alone never makes a pipeline "ahead". With equal retrieval it allows a *conditional* recommendation of the cheaper pipeline.
- A single question never allows an unconditional recommendation.
- **A recommendation belongs to the scope of the finding it follows** (`allowed.recommendation` is listed per scope). A reply whose finding is about one question cannot recommend what only the aggregate supports, and the aggregate cannot be recommended for one question: a real reply once wrote "for this single question Mizan-lite is preferred because of the aggregate" while Mizan-lite had missed that question.
- An **aggregate** needs 20 answerable questions (`MIN_N_INTERVAL`). Then the paired-bootstrap interval on hit@k decides: excludes zero, a direction (and an unconditional recommendation for this document set); includes zero, "similar" (not proof of equality, and the facts say so). Fewer than 20: only "mixed" or "insufficient evidence".
- Questions are treated as independent (as everywhere in `src/stats.py`); that is optimistic and is stated in the evidence.

## 6. Uploaded PDFs

Upload goes through the existing path (`ingest_pdfs` in `src/backend.py`): file checks (type, size, duplicate), text extraction, rejection of scanned or damaged files (the corpus stays as it was), the personal-data and instruction scan, and a re-index of **both** pipelines from the same pages. New in this feature:

1. Every index records the fingerprint of the pages it was built from (`index_stats["pages_sha256"]`, `ingestion.pages_fingerprint`). The evidence compares it with the documents loaded now. If it differs (for example the second rebuild failed), the panel refuses to analyse and says why; an index that records nothing is reported as unverifiable.
2. When the document set changes, the previous comparison, its insights and any earlier prepared-question evaluation are removed from the screen and from memory, and a late result of the old run is dropped (run numbers). Nothing old can sit under a new run.
3. The uploaded file names and the upload-scan result (counts and page numbers, never content) enter the facts. Documents involved in the comparison get an extraction check measured on their text: share of presentation forms, share of kashida, invisible characters, pages where the lam-alef repair changes the text, and one example of what the repair changes (`الئحة -> لائحة`). A clean document is reported as clean, not assumed damaged.
4. To measure retrieval on **your own question and PDF**, open "Optional: say which words in the documents answer the question" and paste 3 to 8 words from the answering page. The evidence check (same canonical matcher as the evaluation) then gives hit@k, rank and precision for both pipelines, and the evidence says on how many pages the phrase occurs in the raw text and after each pipeline's preprocessing (a phrase in no document is flagged). If you type a phrase it is used even when the question is one of the prepared ones. Without it (and without a prepared question) the panel says relevance was not measured.

Not covered: OCR of scanned PDFs (rejected, as before); a PDF whose text is right but whose answers need reasoning across documents.

## 7. Checks on the model's reply

Valid JSON with the expected sections; stance and recommended pipeline among the allowed ones (whether a recommendation is conditional is set by the code from the evidence, never by the model: only a supported aggregate lifts the condition, and the panel prints the scope limit next to every conditional one); fact ids exist and are cited; **every number is in the evidence**, a measurement-like number (a decimal, or 10 and above) and every count of things ("one pair", "2 pages", "three documents", in digits or words) must be in a fact the statement cites, and a page number only has to be in the evidence; no "significant", "proves", "always"; no "correct", "wrong" or "accurate" about an answer (the noun "correctness" is allowed, so the model can say it was not measured; "the correct page" is allowed only when a gold evidence exists, because then what was retrieved or cited is measured); on one question no "in general"/"on average"; no citation, file name or pipeline that the evidence does not contain; no long verbatim copy of a passage or answer; no instruction-like text or credential; at least one limitation. **Direction and hit checks** (`check_claims`): a clause that names one pipeline, a measured quantity (generator input or output tokens, retrieved tokens, generation or retrieval latency, index tokens or chunks) and a direction word (higher, longer, fewer, faster...) is compared with the measured direction, and a clause about whether a pipeline retrieved the gold evidence is compared with the measured hit. **Causal claims** (added 2026-10-13): a sentence that joins a causal word (because, due to, leads to, explains...) to a preprocessing step (kashida, normalization, lam-alef repair, cleaning...) is rejected in the finding, the recommendation, the trade-offs and observations, and accepted only as a key observation of kind "hypothesis": the run compares two pipelines and does not isolate a step. This was added after the real-model checks (section 13): a 4B model twice wrote that Mizan-lite's generation was longer when the fact said it was 0.68 s shorter. The check is deliberately conservative: it reports only an explicit contradiction and skips a clause that is hedged (could, may, whether, if), negated, or ambiguous, so many wrong sentences will still pass. The number check is an existence check against the supplied evidence, not proof that the sentence around the number is right. Lists longer than the limits are cut to the first items.

## 8. Staleness and cache

- Results are tagged with a run number. A model reply that arrives after a newer question or a document change is dropped. On the screen, the answers, the panel, the translation and the upload report are kept in separate states and each event writes only its own, so an event that ends late (the analysis, a translation) cannot restore what it read when it started (`tests/test_ui_event_order.py`).
- The only cache is in memory and holds **validated** replies, keyed by the fingerprint of everything the model was given (question, answers, excerpts, facts, allowed conclusions, language), the prompt version, the analysis version, the model and the token limit. Any change gives a new key; a reply that failed validation is never stored. "Write the analysis" bypasses it. Nothing is written to disk, and the answer cache of `src/rag.py` is not used for this call.
- One consequence: asking the same question again gives different latency numbers, hence a different fingerprint, hence a new analysis.

## 9. Privacy and safety

- The model receives the facts, the question, the answers and 140-character excerpts of at most three passages per pipeline. With a local provider nothing leaves the machine; with `anthropic` or `openai` this text goes to that service, as the passages already do for the RAG answer.
- Instruction-like text (the scan of `src/safety.py`) in the question, an answer or a passage is replaced by a marker before the model sees it. E-mail addresses, Saudi mobile numbers, national ID numbers with a label and IBANs are replaced by `[email]`, `[mobile]`, `[national_or_iqama_id]`, `[iban_sa]`.
- The reply is scanned for instruction-like text and credentials. The existing withholding of passages from the RAG model, the refusal behaviour and the monitoring log are unchanged; the monitoring log gets no insights entry and no text.

## 10. Configuration

`.env.example` lists them: `MIZAN_INSIGHTS` (0 = no automatic analysis), `MIZAN_INSIGHTS_LANG` (`en` or `ar`), `MIZAN_INSIGHTS_MAX_TOKENS` (800), `MIZAN_INSIGHTS_TIMEOUT_S` (300), `MIZAN_INSIGHTS_ATTEMPTS` (3; each retry tells the model what its previous reply got wrong), `MIZAN_INSIGHTS_CONTEXT_TOKENS` (2300), `MIZAN_INSIGHTS_PROVIDER` and `MIZAN_INSIGHTS_MODEL` (default: the generator). It never falls back to a different model when one fails. For a local Ollama model the 4,096-token default window was enough in the real-corpus checks (2,700 to 3,100 prompt tokens as counted by Ollama, and 450 to 630 generated, in the runs that passed); a run with many uploaded documents may need `OLLAMA_CONTEXT_LENGTH=8192`.

## 11. Run and demonstrate

```bash
python -m pytest tests/test_insights_evidence.py tests/test_insights.py tests/test_insights_session.py     # under a minute, offline
python app.py                                  # with MIZAN_LLM_PROVIDER=ollama (or hf) in .env; open http://127.0.0.1:7860
```
Demonstration order: ask a prepared question ("Fee, 3-year licence") and read the panel together with the facts; press "Evaluate the prepared questions" and see the scope change and the "preliminary" wording; add a PDF, watch the old comparison disappear, ask a question about the new PDF with an evidence phrase, and read the extraction facts; stop Ollama and ask again to show the honest failure state.

## 12. Known limits

- The panel explains measurements; it adds none. Its sentences are checked by rules (section 7), not graded by people, and the rules cannot see every wrong sentence (13.3).
- Answer correctness is not measured here. The automatic signals are whether the gold evidence was retrieved (when it is known), whether a cited page holds it, and whether the reference keywords appear in an answer (a wording check). Human grading (`scripts/human_grading.py`) is a separate process and not an input of the panel.
- One question never supports a general claim. The aggregate is the retrieval-only evaluation of the 61 prepared questions (54 answerable), it treats questions as independent, and it exists only for the repository's documents: an upload drops it, because the fingerprint of the document set no longer matches.
- An uploaded PDF is explained for the question asked about it. Without an evidence phrase nothing about relevance is measured for it, and one question says nothing about how either pipeline handles the rest of that PDF. Scanned PDFs without a text layer are rejected, as before.
- State belongs to the server process, not to a browser tab. Two people using one server share the document set (as uploads already did) and the current run; the later question wins and the earlier result is dropped. That is fine for a demo and wrong for a service with several users.
- A local 4B model on a CPU needs 80 to 264 s per analysis in the runs that passed, and a run that fails the checks costs up to three such calls (up to 281 s in the failed runs, which stopped early). A faster or larger model should do better; none was tried.
- Arabic panel text (`MIZAN_INSIGHTS_LANG=ar`): the switch of the prompt, the digit handling and the right-to-left rendering are tested offline. No real model was asked to write Arabic, and the word and direction checks of section 7 are written for English, so they do not read Arabic sentences. The structural checks (JSON, allowed stance and recommendation, fact ids, numbers, names of files, pipelines and citations) still apply.

## 13. What was and was not verified (2026-10-11 and 2026-10-12)

### 13.1 Offline tests: run, 395 passed

`python -m pytest tests` passes: 395 tests in about 50 seconds. 147 of them are the three Insights files (36 on the evidence layer, 91 on the prompt, the checks, the retries and the cache, 20 on the session and the screen), and one is the masking of personal data in `tests/test_safety.py`. They run without a network, with a hash embedder and a fake generator that either writes a reply from the evidence it is given or returns a scripted bad reply. They cover:

- **Evidence:** Mizan-lite better, Standard better, similar, conflicting dimensions, efficiency only, a missing metric (unknown, not zero), a zero baseline (no percentage, no division), one question against an aggregate, a small aggregate (preliminary), an aggregate from other documents (dropped and said so), a pipeline with no usable passage, citation differences, figures that the passages do not contain, cached answers, upload metadata, extraction artifacts and a clean document, an index built from other documents (blocks the analysis), an index that records no fingerprint (unverifiable).
- **Generation:** what goes into the prompt and that the cache key changes with every input; replies that break each rule are rejected (unknown fact id, invented number or count, significance and proof words, correctness words, a wrong direction, a wrong hit claim, a recommendation the scope does not allow, a copied passage, a credential, instruction-like text, a wrong schema, a cut-off reply); retries carry the reasons; statements that fail after the last attempt are left out and counted; a timeout or a model failure leaves the comparison usable; the mock generator gets a message that it cannot write an analysis.
- **Upload:** a PDF added through the upload handler is indexed by both pipelines from the same pages and both indexes carry the new fingerprint; the old comparison, insights and aggregate disappear; a late result of the old run is dropped; a failed re-index blocks the analysis; a PDF without text is rejected and nothing is marked as uploaded; instructions inside a PDF do not reach the model.
- **Screen:** the panel sits after the comparison with its controls, and one test starts the Gradio server and drives it over HTTP with a generated PDF.

These tests show the plumbing and the rules. They say nothing about how a real model writes.

### 13.2 Real-model runs: 19 hand-run invocations, not part of the test suite

**Setup.** The real corpus (8 PDFs, 159 pages) copied to a temporary folder; the offline hash embedder and no reranker, because the real embedding weights were not available on that machine (so which pages were retrieved says nothing about the real retrieval stack; the evidence says "embedder hash (offline smoke-test embedder); reranker none" in fact F5); the generator `qwen3:4b-instruct-2507-q4_K_M` through a local Ollama server on a CPU with its default 4,096-token window. Scenarios: a prepared question ("Fee, 3-year licence"); a PDF added through the upload handler (a 3-page Arabic sample, 97.6% of whose letters are presentation forms) with an evidence phrase; the prepared-question aggregate (61 questions, 54 answerable, retrieval only).

**Outcome of the whole series.** 10 validated panels, 8 runs that ended in the "did not pass the checks" state, and 1 invocation that crashed in my test script, not in the application. The series ran while the checks were being changed, so it is not a success rate of the final code.

**What the failures and near-misses taught.** Each row is now a rule, a test, or both.

| what a real reply did | what changed |
|---|---|
| wrote "statistically significant" | the words are named in the prompt and rejected by the validator |
| set `"conditional": false` while the evidence allowed only a conditional recommendation | the code sets `conditional`; the model's value is ignored |
| left an extra closing brace after the JSON | the parser takes the first JSON value |
| called Mizan-lite's generation latency longer, twice, when the fact said it was 0.68 s shorter | the direction is written into the facts ("Mizan-lite 0.68 s shorter"), and `check_claims` rejects a clause that contradicts it |
| called answers "correct" although nobody graded them | correctness words are rejected; "the correct page" is allowed only when the gold evidence is known and the measurement says so |
| wrote "one pair" for a count that was not one | a count must match a cited fact |
| recommended Mizan-lite while its own stance was "insufficient evidence" | prompt rule; the validator requires `no_recommendation` for that stance |
| was cut off at the 800-token limit, and copied the context key `scope` as its value | the key is now `run_scope`; lists are limited to 3, 1 and 3 items; a cut-off reply is recognised and the model is told |
| wrote "for this single question Mizan-lite is preferred because of the aggregate" while Mizan-lite had missed that question | recommendations are allowed per scope |
| (false alarms of my own checks) read "compared to Standard" as the subject of a clause, "top-4 passage" as a count of four, a clause about where a phrase sits in the documents as a retrieval claim, "missing retrieval" as a hit, and banned "definitive" | comparator and parenthesis masking, identifier stripping, location words, more miss words, the word removed from the ban list |
| said "correctly" in every attempt, so one word killed the whole panel | statements that fail after the last attempt are left out and counted (a failing finding or recommendation still rejects everything); three attempts by default |

**The last cycle.** The prepared, upload and aggregate scenarios were run again on the code as it stood, then once more after the last change (removing "definitive" and "conclusive" from the banned words, which can only accept more).

| scenario | result | attempts | time | tokens in / out | code state |
|---|---|---|---|---|---|
| prepared question | validated | 3 | 200 s | 2,853 / 524 | before the last change |
| upload of the Arabic sample PDF, with an evidence phrase | validated; both pipelines were re-indexed in 7 s and both indexes verified by fingerprint; neither pipeline retrieved the phrase (offline embedder), both refused, and the finding said "insufficient evidence" | 1 | 80 s | 2,745 / 570 | before the last change |
| aggregate | failed state: "definitive" in the recommendation, and a wrong direction on retrieved tokens | 3 | 281 s | not summed | before the last change |
| aggregate, again | validated; one trade-off left out because it said Mizan-lite's retrieval latency was lower where the facts say the two are equal | 3 | 231 s | 3,090 / 492 | last code |
| the Gradio app over HTTP: `/ask`, then `/write_insights` | validated; two statements left out: Standard's retrieval latency called shorter, and Mizan-lite's generation latency called higher, where the facts say Standard's is the higher in both | 3 | 3 s and 206 s | 2,867 / 446 | last code |

In the runs that passed: 80 to 264 s, 1 to 3 attempts, 2,745 to 3,096 prompt tokens and 446 to 629 generated tokens as counted by Ollama. Everything on the screen had passed the checks; where statements were left out, the panel said so and gave the reason.

### 13.3 What the checks do not catch

The checks reject explicit contradictions and unsupported claims. They cannot read meaning, so a wrong or over-reaching sentence can still pass:

1. The direction check reads one clause at a time and fires only when the clause names one pipeline, one measured quantity and one direction word. A sentence built differently can slip through, and hedged ("might be faster") or negated clauses are skipped on purpose, so a wrong hedged statement passes.
2. The number check asks whether a number occurs in the evidence, and in a cited fact for measurements and counts. It does not know which pipeline or quantity a number belongs to when two figures sit in the same cited fact.
3. The model labels its statements "observation" or "hypothesis". Code cannot check the label, and causal wording ("because", "due to") is only discouraged in the prompt; nothing rejects it.
4. Wording that goes a little beyond a measurement passes when the measurement exists. In the last HTTP run the panel says both pipelines "cited the correct page containing the answer". What was measured is that each cited page holds the gold-evidence phrase of the question; whether the page answers the question as a reader would judge it was not.
5. A fluent statement that is true but irrelevant to the decision passes. Nothing scores usefulness.

### 13.4 Not verified

- A run with the Colab stack (Qwen3-Embedding-0.6B, a reranker, a GPU generator), or with another model or provider (`hf`, `anthropic`, `openai`). Only the local 4B model was used.
- The notebooks. They were regenerated so that they include the two new modules (`tests/test_notebook_modules.py` checks that the included code matches the sources), but they were not run on Colab.
- Arabic panel text with a real model.
- The screen at phone width, keyboard use and screen readers. The panel states were rendered and looked at in the browser pane at desktop widths only.
- Human judgement of the generated text. Nobody graded whether the explanations are right or useful.
- The failure rate of the final code with a real model. Two runs after the last change, both validated, is a sample too small to quote a rate; the earlier runs of the series are on code that changed.
- Uploads other than the one Arabic sample on a real model (long, badly extracted, or several uploads in one session; the offline tests cover several), and two people using one server at once.
