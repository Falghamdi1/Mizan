# Needs analysis, user flow, wireframe and functional specifications (core requirement 1; Submission 2 material)

Written from the application as built (`src/ui.py`, `src/comparison.py`, verified in a browser session on 2026-10-10 with the offline embedder and the mock generator). Where a statement needs a real model it says so.

## 1. Users and needs

| User | Goal | Usage scenario | What they need from the tool |
|---|---|---|---|
| **Arabic AI builder** at a tourism-sector team (Ministry of Tourism, Saudi Tourism Authority, GASTAT) | decide whether their Arabic documents need cleaning before they go into a RAG system, and which steps | uploads or selects their documents, asks the questions their users ask, compares two pipelines that differ only in preprocessing | same documents, same questions, same models; the measured difference (retrieved tokens, evidence found or not); sources to check; honest "n/a" instead of invented numbers |
| **Evaluator / instructor** | judge whether the claim is supported | reads the side-by-side result and the evidence behind it | every number traceable to a file or measured in the call; limitations visible |
| **Business user** (secondary) | check a licence rule quickly | asks a question in Arabic, reads the answer and the cited page | a cited page to verify, a clear "the documents do not say" when they do not, a notice that this is not official advice |

Problem evidence available in the repository: the 8 Ministry regulation PDFs lose 12.3% of their characters to kashida padding (30% of their tokens) and carry 1,464 swapped lam-alef ligatures (`docs/DATA_AUDIT.md` Q2); on those files a small embedder finds the right passage for 31% of questions with Standard cleaning and 55% with Mizan-lite (`EXPERIMENT_RESULTS.md` section 3).

## 2. User flow

```mermaid
flowchart TD
  A[Open the app] --> B[See the notices, the corpus summary<br/>8 documents, 159 pages, 358 / 323 passages]
  B --> C{Choose a question}
  C -->|prepared question| D[Question box filled]
  C -->|type an Arabic question| D
  B -->|optional| U[Add PDF] --> V{Readable and safe?}
  V -->|no: not a PDF, scanned, too large| W[Rejected with a reason, logged as an event]
  V -->|yes| X[Warnings: instruction-like text, personal data] --> Y[Both pipelines re-indexed] --> C
  D --> E[Ask Mizan]
  E --> F[Standard and Mizan answer from the same documents]
  F --> G[Read both answers, the evidence found or not,<br/>sources, tokens, latency, citation check]
  G --> H{Answer supported?}
  H -->|insufficient evidence| I[Refusal tag: nothing cited]
  H -->|cited| J[Open the cited passage and verify the page]
  G --> K[Monitoring panel and any alert]
```

## 3. Wireframe of the main screen (as built)

```
+--------------------------------------------------------------------------------+
| MIZAN مِيزان   Arabic RAG Optimization        "Put Arabic AI on the scale."     |
| [Mock LLM banner, only when the generator is the mock]                          |
| [Notice: check before you rely on an answer / تحقق من الصفحة ...]                |
| 1 Documents: 8 docs, 159 pages, 358 / 323 passages | 2 Question | 3 Comparison   |
| [Add PDF]  note: uploads stay on this runtime's disk, no personal data          |
| [Fee, 3-year licence] [Maximum licence term] [Renewal deadline] [Not in docs]   |
| Question: [ Arabic text, right to left                                   ]      |
| [ Ask Mizan ]                                                                   |
+---------------------------------------+----------------------------------------+
| Standard RAG  baseline                | Mizan  mizan-lite+repair_lam_alef       |
|  Preprocessing: 1 step (details)      |  Preprocessing: 7 steps (details)       |
|  Answer  [tag: abstained if refused]  |  Answer                                 |
|  Evidence check | LLM tokens | Latency |  Evidence check | LLM tokens | Latency  |
|  Sources: n of m cited pages valid    |  Sources: ...   Withheld: ...           |
|  Retrieved evidence (top 4) v         |  Retrieved evidence (top 4) v           |
+---------------------------------------+----------------------------------------+
| Measured for this question: hit, precision, top-1 similarity, retrieved tokens,  |
| LLM input/output tokens, latencies  (n/a when not measurable)                    |
| Reminder: verify the cited page in the official document                        |
| Monitoring: last 20 entries per pipeline (answers, errors, refusal %, p50/p95,   |
|             valid citations, mean input tokens) + alert banner                   |
| > Experiment details (embedder, adapter, chunking, top-k, generator, prompt)     |
+--------------------------------------------------------------------------------+
```

## 4. Functional specifications

| # | Feature | Context | Usage scenario | Acceptance criterion | How it is verified |
|---|---|---|---|---|---|
| F1 | Ask a question | the user wants to compare two pipelines on one question | types or picks a question, presses Ask Mizan | both pipelines return an answer (or a visible error message, never a stack trace) for the same question and the same documents | `tests/test_colab.py` UI tests; browser session 2026-10-10 |
| F2 | Side-by-side answers with sources | the user must be able to check an answer | reads each answer and opens the evidence list | each card shows the answer, the top-4 passages with file, page, similarity and token count, and the cited sources; a citation check row says how many cited pages were really shown to the model | `tests/test_citations.py`, `tests/test_safety.py`; browser session |
| F3 | Measured values only | the project must not invent numbers | looks at tokens, latency, evidence check | every value is measured in that call or marked n/a (mock generator: LLM tokens and latency are n/a; free-text question: evidence check n/a); the difference column is plain arithmetic, never a verdict | `tests/test_colab.py`; browser session with the mock generator showed n/a |
| F4 | Add a PDF | the user wants their own documents | uploads one or more PDFs | duplicates, non-PDFs, scanned or damaged files and files over 60 MB are rejected with a reason and the existing corpus is unchanged; accepted files re-index both pipelines; instruction-like text and personal data are reported by category and count | `tests/test_colab.py` (add_pdf tests), `tests/test_safety.py` (upload warnings) |
| F5 | Insufficient evidence and safe answering | the documents may not contain the answer, or may contain hostile text | asks a question outside the documents; or retrieves a passage that tells the model to ignore its rules | a refusal is labelled "abstained" and shows "nothing cited"; passages with instruction-like text are withheld from the model and the UI says how many; with nothing safe left the answer is the standard refusal and the model is not called | `tests/test_safety.py` (17 of 17 attacks, 0 of 3,819 real chunks flagged); real-model behaviour not tested |
| F6 | Monitoring and alerts | the team must notice failures | uses the app; reads the monitoring panel | one log line per answer or failure with no question, answer or document text; an alert fires on errors, refusal rate, p95 latency, missing citations, empty retrieval, rejected uploads and withheld passages, and is delivered to the log, the screen and (if configured) a webhook or e-mail | `tests/test_monitoring.py` (including a webhook delivered to a local HTTP server) |
| F7 | Responsible-use notices | users must not treat this as official advice | opens the app and reads an answer | the not-legal-advice notice (English and Arabic) is on every screen and a verify-the-page reminder is under every answer | `tests/test_colab.py::test_responsible_use_notice_is_always_shown` |

Not features (so not promised): a hosted deployment, user accounts, automatic recommendation of a preprocessing recipe for an uploaded corpus.

## 5. Architecture (UML component view)

```mermaid
flowchart LR
  subgraph UI[Interface]
    APP[app.py / notebook] --> UIM[src/ui.py + ui_theme.py]
  end
  UIM --> CMP[src/comparison.py compare]
  CMP --> PIPE[src/rag.py Pipeline x 2]
  CMP --> MON[src/monitoring.py]
  PIPE --> PRE[src/preprocessing.py]
  PIPE --> CHK[src/chunking.py]
  PIPE --> EMB[src/embeddings.py]
  PIPE --> VDB[(Chroma, src/retrieval.py)]
  PIPE --> RR[src/rerank.py]
  PIPE --> SAF[src/safety.py]
  PIPE --> LLM[src/rag.py call_llm -> local_llm.py / Ollama]
  CORP[src/corpus.py + ingestion.py + web_corpus.py] --> PIPE
  EVAL[src/evaluation.py + citations.py + stats.py] --> PIPE
  FT[finetune/ LoRA] -. adapter .-> EMB
```

## 6. One request (UML sequence view)

```mermaid
sequenceDiagram
  participant U as User
  participant UI as ui.py
  participant C as comparison.compare
  participant P as Pipeline (x2)
  participant V as Chroma
  participant R as Reranker
  participant S as safety
  participant L as Generator
  participant M as monitoring
  U->>UI: Arabic question
  UI->>C: compare(pipelines, question)
  loop each pipeline
    C->>P: ask(question)
    P->>P: preprocess query with the pipeline's own steps
    P->>V: top-20 by cosine
    P->>R: score the 20, keep 4
    P->>S: filter_passages(top 4)
    alt nothing safe left
      P-->>C: standard refusal, no model call
    else
      P->>L: system prompt + shown passages + original question
      L-->>P: answer with [file, page N] citations
    end
    C->>M: record answer (hashes, ids, tokens, latency, citation check)
  end
  C->>M: evaluate alert rules, notify
  C-->>UI: results
  UI-->>U: side-by-side answers, sources, measured values, notices, monitoring panel
```

Input: one Arabic (or English) text question. Output: for each pipeline an Arabic answer with `[file, page N]` markers, the retrieved passages, and the numbers measured in that call.
