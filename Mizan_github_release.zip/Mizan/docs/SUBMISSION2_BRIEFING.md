# Submission 2 briefing (Sunday 11 Oct 2026)

For the team, before the session. What is done, what is not, and how to answer questions about the blind test and the grading honestly.

## 1. One-line status

We are in the evaluation phase with a working, tested prototype. We are not training or fine-tuning a language model. The only trained part is an optional small embedding adapter, and its proof (a one-shot blind test) is still to run.

## 2. What the project is

Mizan is an Arabic RAG optimizer for Saudi tourism content, using local open models only. Two pipelines differ only in preprocessing:

- **Standard** (`baseline`): text as extracted.
- **Mizan-lite** (`mizan-lite+repair_lam_alef`): Arabic repair and normalization before chunking. The full preset (`mizan+repair_lam_alef`) is kept as a reference.

Final stack for both: Qwen3-Embedding-0.6B, Qwen3-Reranker-0.6B (top 20, keep 4), Qwen3-4B-Instruct-2507 4-bit, chunks 600/100, Chroma.

## 3. What we did

**Pipeline and tooling**
- Preprocessing, ingestion, retrieval with reranking, answer generation with citations and refusal, a safety scan, a demo app, Colab notebooks.
- 238 automated tests pass offline.

**Evaluation method**
- Metrics: hit@k, MRR, candidate recall, first-stage hit, paired bootstrap intervals, Wilson intervals.
- Datasets are frozen and hashed. A canonical matcher decides whether a retrieved chunk contains the gold evidence.
- The analysis plan (`docs/ANALYSIS_PLAN.md`) was committed (646117a) before any blind question existed. Its decision rules cannot change after the blind set is frozen.

**Results (development data, honest reading)**
- Clear win: with the weak embedder on damaged PDFs, hit@4 rises by +0.234.
- Cost saving: PDF indexes have 9.8% fewer chunks and 31.8% to 41.5% fewer tokens, and PDF retrieval is about 14% faster (0.129 s).
- Strong stack: the effect is mixed. We do not claim a gain there.
- Lite beats full by about 0.05 on web content.
- Gold-phrase survival: on PDF FAQ the strict match rises from 0.117 to 0.571 (generated 0.178 to 0.933). The canonical match is 1.000 everywhere. On web, strict survival drops because the gold phrases were copied from raw text. That is a matcher artifact, not lower quality.
- Answers: only 10 questions were graded by hand. The Mizan arm had 1 wrong answer and 1 refusal. Answer quality is not proven.
- Run 4 repeated run 3 on all PDF values and most web values. Of 16 single preprocessing steps, none helped on its own and two hurt.

**Safety (`docs/RESPONSIBLE_AI.md` section 4c)**
- Prompt-injection catch on held-out in-scope attacks: 84.1% to 93.2%.
- False alarms on benign text: 6 of 30 down to 1 or 2 of 30.
- Real corpus chunks flagged: 0 of 3,819.
- PII recall: 22 of 31 up to 31 of 31.
- Out-of-scope attacks (0 of 41 caught) are a stated limit. Three English held-out misses are left on purpose, because tuning on held-out data would invalidate it.

**Deliverables**
- `Mizan_Submission2.pptx` (Template 2, filled and polished) and the online deck (version 13). Both carry the run-4 numbers.
- Commit `7372a8c` added the tools for the final evidence run. No remote exists, so nothing is pushed.

## 4. What is still to do (needs people or Colab)

| step | who | what |
|---|---|---|
| 1 | each of the three | Write 15 to 20 blind questions with the form, download the CSV |
| 2 | a teammate | Read 5 of each person's rows as a check |
| 3 | Person 2 | `make_blind_test.py --check`, then `--build`, then `--verify`; commit the frozen set |
| 4 | two graders | Grade the prompt sheet; run `scripts/decide_prompt.py` |
| 5 | Person 1 | Run `Mizan_Final_Colab.ipynb` once on a T4 (adaptation, blind retrieval, real answers) |
| 6 | two graders | Grade the blind answers; merge with kappa |
| 7 | Person 2 | Update EXPERIMENT_RESULTS and the slides from the result files |

Also open: the files `prompts-20261010-160638.json`, its grading sheet and KEY, and the executed web notebook (for the adaptation failure in run 4). Decide whether to add `MIZAN_RERANKER=Qwen/Qwen3-Reranker-0.6B` to the demo `.env`. Provide a remote URL if we want to push.

## 5. The five weaknesses and where each stands

| weakness | fixed | still open |
|---|---|---|
| Adaptation re-run missing | One-shot blind test (`run_adaptation.py --blind`), better logging, GPU memory release, final notebook | The Colab run |
| No untouched test set | Pre-registered plan; blind kit and form | Writing and freezing 45 to 60 questions |
| No human grading | Grading form, blind sheets, merge with kappa | Two people must grade |
| Mixed strong-stack effect | Decided only by the human-written blind set; no pooling | The blind run |
| Prompt default v1 misses the 90% citation target | Mechanical rule in `decide_prompt.py` | Grading the prompt sheet |

## 6. How to do the blind test correctly

**What it is.** A set of questions that nobody tuned anything on. It is the only data that can honestly say whether Mizan helps on questions we did not shape the system around.

**Rules**
1. Write questions from the documents only. Do not look at any pipeline output, retrieved chunk or earlier result. The form shows none.
2. Each question needs an evidence phrase copied from one document page. The form checks it live against the document text with the same canonicalizer as the evaluation.
3. Do not copy or paraphrase a development question. The form warns when you do.
4. Avoid generic phrases and phrases that repeat the question.
5. Aim for 15 to 20 per person, 45 to 60 in total, mixing PDF and web as the quota says.
6. Include some questions the corpus cannot answer, so refusals can be measured.
7. `make_blind_test.py --check` is the authority. After `--build`, the set is frozen with hashes (`FROZEN.json`). Never edit it after that.
8. **Use once.** The blind run refuses a second run, a changed freeze, and any blind question that equals a training query. If the result is bad, we report it as is. We do not tune and re-run.
9. The generated form contains corpus text. Do not share or publish it.

## 7. How to do the grading correctly

- Two graders, working alone, using `tools/grading_form.html` in a browser. It works offline and saves in the browser.
- Never open `KEY.json`. It maps the anonymous arms (A, B) to Standard and Mizan. Graders must not know which is which.
- Mark each answer correct or not, and check that each citation supports the claim. The rubric is `eval/human_grading/RUBRIC.md`.
- Refusals on answerable questions count as wrong. Refusals on unanswerable questions count as right.
- Person 2 merges with `scripts/human_grading.py merge`, which reports agreement (kappa) and paired differences with intervals. Disagreements are settled by discussion and logged.
- Disclose: the 10-question sheet key was partly read by the assistant that built the tools, so that sheet is not fully blind. The assistant is not a grader.
- Read the result by the plan: we claim "no loss of quality" only if the lower bound is above -0.10. The adapter counts as helping only if the blind all-docs lower bound is above 0.

## 8. Likely questions and honest answers

- **Are you training or fine-tuning?** No LLM training. Preprocessing is rule-based. There is an optional embedding adapter, not yet proven.
- **Is it better than standard RAG?** Clearly on weak embedders with damaged PDFs, and it cuts index size and PDF latency. On the strong stack the effect is mixed. Answer quality is not yet proven.
- **Why is there no untouched test yet?** Because the plan was fixed first. The blind questions must be written by people, not generated or tuned. The tools are ready.
- **Why not just use generated questions?** They are exploratory. They were made from the same text we tuned on, so they cannot be the final proof.
- **Why did strict gold survival drop on web?** The gold phrases were copied from raw text, and the strict matcher compares raw characters. The canonical matcher, which is the evaluation standard, shows 1.000.
- **Only 10 graded answers?** Yes. That is a stated limit. The final run adds human-graded blind answers.
- **Safety?** Held-out catch 93.2%, false alarms 1 or 2 of 30, no flags on 3,819 real chunks. Limits: out-of-scope attacks and three English misses.
- **Ministry permission?** Sent and approved.
- **What if the blind result is bad?** We report it as it is. The plan fixes this in advance.

## 9. Do not say

- "Mizan is better" without "on weak embedders and damaged PDFs".
- Anything about answer accuracy beyond n=10.
- That the adapter helps. It is unproven.
- That the blind test is done. It is not.
