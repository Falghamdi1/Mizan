# Mizan data-source audit

Date of audit: 2026-10-08. Every number below was measured in this audit (scripts in `scripts/audit/`, raw measurements in `docs/data_audit/`) unless it is marked as a judgement. Scores are judgements, but each one is tied to the measurements next to it.

## A. Executive recommendation

**Do not build the main corpus on PDFs. Build it on the Ministry's web-native Arabic text.**

If we were the three-person team with one week:

- **Primary corpus: the Ministry of Tourism web corpus on tourism.sa**, which is already clean text.
  - 256 official Arabic FAQ question-and-answer pairs (about 72,000 characters of answers).
  - The 152 Arabic press items (the first 100 are about 207,000 characters; the 52 older ones were not pulled).
  - Both are served as JSON by the portal's own public CMS. No OCR, no layout repair, no chunking surprises.
- **Add the 6 tourism-related laws from the Bureau of Experts portal** (laws.boe.gov.sa, about 110,000 characters of HTML, article by article). The Tourism Law is the anchor.
- **Keep our current 8 regulation PDFs as a deliberate "noisy" second corpus**, not as the main one. They are the only place where Arabic preprocessing has a real defect to fix (1,464 broken lam-alef ligatures), so they are where the experiment can say something. The web-native text is the control.
- **Use the three Excel files only as a small, explicitly licensed supplement** (a handful of fact sentences and the 14 bilingual definitions).

Sections O and P add a licensed fallback (GASTAT, Arabic Wikipedia) and an external benchmark (MIRACL-ar) to this plan.

Two things must happen on day 1:

1. **Ask the Ministry for written permission** (section K). The tourism.sa terms of use restrict copying site content into other systems without it. We can work locally meanwhile, but we cannot treat the licence as clear.
2. **Do not publish the corpus text** in a public repository. The notebook should keep downloading at run time, as it does now.

Why this changes the project: the new corpus has about 3.3 times the text of the 8 PDFs (about 390,000 characters measured, versus 117,000; more if the 52 unmeasured press items are similar), 255 independent human-written questions instead of 10 hand-written plus 51 unreviewed LLM questions, and almost zero cleaning.

## B. How good are our current 8 PDFs?

Verdict: **usable, but a mediocre RAG corpus, and not the best we can get.** They are better than most Ministry PDFs, which is a low bar.

| PDF (V012/V014) | Pages | Pages with <50 chars | Characters | Tatweel (ـ) | Lam-alef repairs | Chunks (600/100) |
|---|---|---|---|---|---|---|
| Hospitality Facilities Regulations | 37 | 8 | 27,059 | 4,068 | 335 | 84 |
| Management of Hospitality Facilities | 23 | 7 | 12,380 | 1,964 | 187 | 41 |
| Mgmt of Hospitality, service directory | 13 | 1 | 11,375 | 1,369 | 132 | 32 |
| Tour Guide Regulations | 17 | 7 | 8,352 | 1,257 | 135 | 30 |
| Tourism Consultation Regulations | 19 | 7 | 10,785 | 1,599 | 198 | 35 |
| Tourist Visa Regulations | 7 | 1 | 6,097 | 942 | 82 | 18 |
| Travel and Tourism Services Regulations | 30 | 8 | 20,354 | 3,271 | 166 | 62 |
| Travel and Tourism, service directory | 21 | 1 | 20,701 | 2,644 | 229 | 54 |
| **Total** | **167** | **40 (24%)** | **117,103** | **17,114** | **1,464** | **356** |

What the measurements say:

- **Extraction.** Text is real selectable Arabic (94 to 95% of non-space characters are in the Arabic block, no presentation forms), so no OCR is needed.
- **Defects we must repair.** In every file, the lam-alef ligature is mapped to the wrong characters (`الئحة` for `لائحة`). The geometry-based repair in `src/ingestion.py` found 1,464 cases, about 106 per 10,000 characters. Without that repair, a user typing `اللائحة` cannot match the document text.
- **Tatweel.** 17,114 kashida characters, about 15% of all characters, which is why 600-character chunks hold less meaning than they appear to.
- **Empty pages.** 40 of 167 pages (24%) have under 50 characters: covers and full-page graphics.
- **Images and drawings.** 102 embedded images and roughly 60,000 vector drawings (borders and ornaments). Lines are short (about 5 words per line). In the Tourism Law PDF sample (same publisher and layout family) punctuation and list numbers are displaced from their sentences, so expect some of that here too; I did not re-inspect reading order file by file in this audit.
- **Tables.** 49 detected, mostly in the two service directories; they come out as fragmented lines.
- **Page citations are reliable** (physical page index, fixed PDF, SHA-256 in `data/corpus_manifest.json`).
- **Size.** 117,103 characters is a small corpus: about 700 characters per page, about 356 chunks.
- **Evaluation potential is real but thin.** Regulations contain checkable facts (durations, fees, deadlines). Our 10 hand-written questions touch only 2 of the 8 documents.
- **Possible staleness (not verified for content).** The Ministry's regulation list shows revised files published 9 to 16 September 2026 for the hospitality facility, tour guide, and travel and tourism regulations (titles say "revised" or 2026). Our files are the August 2025 versions. We did not diff the content. The new files cannot be read without OCR (section D, item I). Record the version in the manifest and say so in the demo.
- **Licensing:** the same site terms as the Ministry's other content (section K). Unclear for redistribution.

## C. The three files you provided

They are **one dataset, not three**. All three are the Ministry of Tourism workbook "Tourism Demand Indicators in the Kingdom of Saudi Arabia" (2021 to 2025).

| File | Sheets | Non-empty cells | Content |
|---|---|---|---|
| `…664d024f55.xlsx` | 24 | 26,269 | the full workbook: general (G1, G2), inbound (I1 to I9), domestic (D1 to D8), secondary visits (S1), definitions, metadata, country list |
| `…9ad6b9b454.xlsx` | 13 | 14,478 | domestic-only subset (G1, G2, D1 to D8, Definitions, Metadata) |
| `…ced37390cc.xlsx` | 13 | 14,478 | **identical to 9ad…**: zero differing cells (different file hash only) |

The two small files are a strict subset of the large one (the shared sheets match; only the Content index differs). **Use the large one and ignore the other two.**

Facts about the dataset:

- **Publisher and source:** "Data and Decision Support Deputy, Ministry of Tourism" (Metadata sheet). Collection: administrative records and field surveys. Reference framework: UN Tourism IRTS 2008. Frequency: monthly. Last update: 12-04-2026 (sheet S1: 20-08-2026). Open-data page given in the file: mt.gov.sa/tic/open-data (it now redirects to tourism.sa/ar/open-data). Contact: DataDesk@mt.gov.sa.
- **Language:** every label is bilingual English and Arabic (often both in one cell, separated by a line break). Arabic is 38.5% of text characters. Arabic text quality is fine; there is simply very little of it.
- **Numeric share: 76.9% of all non-empty cells are numbers.** Text cells are labels (province, city, indicator, unit, month). Only 46 text cells have 12 or more words, and 34 of them are in Definitions and Metadata.
- **Structure:** 936 merged-cell ranges, multi-row bilingual headers, blocks that fill only 29 to 72% of their rectangle, 98 formulas (all have cached values, so reading is safe). Not a flat table: it needs per-sheet parsing.
- **Duplicates and typos:** the duplicated files above; label typos ("Avergae Sending per Trip", "Provinve", "Filed Surveys"). One value looks like an outlier worth checking before anyone quotes it (Baha province, average stay 60.1 nights in 2025, against 6.7 in 2024). We did not verify it against another source.
- **Encoding:** clean UTF-8 inside the xlsx; no mojibake.
- **Useful for RAG?** Not as the main corpus. It supports numeric lookup questions ("domestic tourists in Makkah province in 2024"), but that is table lookup, not passage retrieval, and Arabic preprocessing barely touches numbers and labels. The Definitions sheet is the one text-like part: 14 concepts, each with an English and an Arabic definition (a small aligned bilingual set, longest 615 characters).
- **Licence: the clearest of everything we found** (section K).
- **Suitable for our research question?** Weakly.

## D. What else exists (search results, with evidence)

Searched and inspected directly: tourism.sa (the Ministry's current portal, which now serves the old mt.gov.sa content), its open-data library, its publications list and its public CMS, the Bureau of Experts laws portal, and sample GASTAT pages. I downloaded and measured 36 PDFs, 6 law pages in HTML and three JSON endpoints from the portal's CMS.

| | Source | What it is | Measured evidence | Cleaning effort |
|---|---|---|---|---|
| G | **tourism.sa FAQ** | 256 official Arabic Q&A pairs in 11 categories (travel services 75, hospitality facility 60, consultation 22, private hospitality 22, visa packages 19, …) | answers 72,287 chars (mean 282, median 184, longest 2,061); 96.6% Arabic; 0 presentation forms; 0 broken lam-alef; 255 unique questions; 285 chunks | **Plug-and-play** |
| H | **tourism.sa press items** | 152 Arabic news items (2023-10 to 2026-07); first 100 measured | 206,813 chars, mean 2,068 per item; 97.1% Arabic; 0 presentation forms; 1,360 diacritics; 2,893 Western digits; 148 percent signs; about 400 year mentions | **Plug-and-play** |
| F | **Bureau of Experts laws (HTML)** | Tourism Law (royal decree M/18, 1444 AH), Organisation of the Ministry of Tourism, two Saudi tourism associations, the temporary-work visa regulation for Hajj and Umrah services, and the Antiquities, Museums and Urban Heritage Law | 110,564 chars in 6 documents, 228 chunks; 94 to 95% Arabic; 0 presentation forms; 0 broken lam-alef (`الئحة` 0 against `اللائحة` 24 in the Tourism Law); article structure intact | **Plug-and-play** (strip a few menu lines) |
| A | Our 8 regulation PDFs | see section B | | Moderate |
| C | Annual Statistical Reports 2021 to 2025 (PDF, Arabic) | tourism indicators with narrative callouts | 2025 interactive: 70 pages, 79,138 chars, about 3 words per line, 433,705 vector drawings, 17.8% of lines repeated headers; 10,519 presentation-form characters; 806 lam-alef repairs; infographic layout | **Heavy** |
| D | Narrative reports: Q1 2026 sector performance, "Global investment in Saudi tourism" (June 2026) | readable Arabic prose | letters extract after NFKC, but **numbers are corrupted**: decimals come out as a private glyph (`ɟ`, 71 stray glyphs in the 11-page Q1 report), digit order is reversed (`2%-` for −2%; 17 cases), dates are displaced inside sentences. Facts from this text would be wrong. | **Heavy** |
| E | Hospitality performance reports (quarterly, half-yearly, yearly) | tables and charts | 134 detected tables in 30 pages; every heading appears twice, once with the lam-alef defect (`المقدمة` / `املقدمة`); English alt-text noise ("A grey line on a white background…"); 15% of lines repeated | **Heavy** |
| I | **Revised regulations published Sep 2026** (hospitality, travel, tour guide) | the current official versions | **garbled Arabic**: the font maps letters to foreign glyphs (`ال؅فخيص` for `الترخيص`, `ɲشاط` for `نشاط`). Only OCR would recover them | **Not recommended** |
| K | Ministry circulars (تعاميم) | short official notices | scanned images: one sampled circular had 0 characters, two others 1,780 to 3,631 mixed characters | **Not recommended** |
| J | Reports filed under the Arabic locale | WTTC/UN Tourism-style studies ("Future of Work", "Social impact", "Environmental impact", white papers, solar studies) | **English text**: 0.0% Arabic in every sampled file despite the Arabic label | **Not recommended** (wrong language) |
| B | The 3 xlsx files | section C | | Moderate to verbalise |
| – | GASTAT tourism pages, Saudi Tourism Authority open-data page, open.data.gov.sa | statistics portals | **Not inspected in depth.** What I could confirm: GASTAT's tourism content is surveys and statistical tables (e.g. the Tourism Establishments Survey), and the portals are catalogues of data files. I found no narrative Arabic report there. The web search could not reach their files, so this is an absence of evidence, not proof. | not scored |

Observations worth sharing with the team:

1. **The Ministry's PDFs are getting harder to use, not easier.** Our V012 files are about the cleanest it ever published. Everything newer is either garbled by font mapping, built from presentation-form glyphs with scrambled numbers, or a scan.
2. **The portal's own text is the cleanest Arabic available.** The HTML and JSON have none of the PDF problems.
3. **The CMS is public but undocumented.** `cms.tourism.sa/api/faq-categories`, `/news`, `/publications`, `/tourism-regulations` are the calls the site's own front end makes. There is no stated stability or rate limit; fetch politely and save the raw responses with a hash.

## E. Final ranking

Weights: Arabic text quality 20, RAG suitability 20, clean extraction 15, text density 10, domain relevance 10, evaluation potential 10, traceability 5, licensing 5, low cleaning effort 5. Scores 1 to 10 are my judgement from the measurements above (full table in `docs/data_audit/candidate_scores.json`).

| Rank | Candidate | Score | Cleaning |
|---|---|---|---|
| 1 | tourism.sa press items (JSON) | 8.55 | Plug-and-play |
| 2 | **tourism.sa FAQ (JSON)** | 8.50 | Plug-and-play |
| 3 | Bureau of Experts tourism laws (HTML) | 8.20 | Plug-and-play |
| 4 | **Our current 8 regulation PDFs** | 6.50 | Moderate |
| 5 | MT narrative reports (Q1 2026, June 2026 special) | 5.70 | Heavy |
| 6 | MT Annual Statistical Reports (PDF) | 5.60 | Heavy |
| 7 | MT Tourism Demand workbook (the 3 xlsx) | 5.35 | Moderate (to verbalise) |
| 8 | "Arabic" reports that are English | 4.55 | Not recommended |
| 9 | Hospitality performance reports | 4.35 | Heavy |
| 10 | Revised regulations, Sep 2026 | 4.05 | Not recommended |
| 11 | Scanned circulars | 3.45 | Not recommended |

The ranking is only as fair as the licensing scores. Items 1 to 3 score 3, 3 and 5 on licensing; on a licensing-first ranking, the xlsx (9) would move up. That is why the primary recommendation comes with a permission step.

## F. Cleaning effort

| Class | Candidates |
|---|---|
| Plug-and-play | tourism.sa FAQ, tourism.sa press items, Bureau of Experts laws |
| Light cleaning | none |
| Moderate cleaning | our 8 PDFs (lam-alef repair, drop empty pages, strip kashida); the xlsx (verbalise rows into sentences) |
| Heavy cleaning | Annual Statistical Reports, narrative reports (numbers corrupted), hospitality performance reports |
| Not recommended | revised Sep 2026 regulations (garbled fonts, OCR), scanned circulars, English-only reports filed as Arabic |

## G. Direct comparison

| | Current 8 PDFs | The 3 xlsx files | Best new: tourism.sa web corpus + laws |
|---|---|---|---|
| RAG suitability | medium | low | high |
| Arabic quality | medium (ligature defect, 15% kashida) | fine, but only labels | high (0 extraction defects) |
| Cleaning effort | moderate (already coded) | moderate | almost none |
| Text density | 117k chars in 167 pages (24% empty) | 76.9% numbers | about 390k chars measured, no empty pages |
| Retrieval potential | 356 chunks, one publisher | numeric lookup only | 989 chunks (476 press, 285 FAQ, 228 laws), three document types |
| Evaluation potential | 10 hand + 51 LLM questions | numeric questions only | 255 human-written questions with their own gold answers |
| Data diversity | 8 regulations, 1 genre | tables | FAQ, news prose, legal articles |
| Source credibility | official | official | official |
| Licensing | unclear (site terms) | **explicit, permissive** | unclear: written permission needed |
| Implementation difficulty | done | medium | low (new loaders) |
| Overall (my score) | 6.5 | 5.35 | 8.2 to 8.55 |

## H. Why the winner suits retrieval and generation

- Answers and press items are short, self-contained paragraphs with their own headings. A 600-character chunk usually holds one complete thought, which the generator can quote.
- Laws keep their article structure. A citation reads "المادة 5" instead of "page 12", which is easier to verify.
- Named entities, places, dates, percentages and Hijri/Gregorian dates are everywhere in the news, which is the kind of content where questions are concrete and checkable.
- No extraction noise reaches the model, so a wrong answer is the model's or the retriever's fault, not the PDF's.

## I. Evaluation suitability

Strong, and independent of us.

- The 255 unique FAQ questions were written by the Ministry. Gold is the paired answer. That removes the weakest part of the present evaluation (LLM-written questions nobody reviewed) and it follows the team rule that the preprocessing designer must not author the gold alone.
- Caveats to handle: FAQ questions and answers share vocabulary, so retrieval will look easier than reality (identical for both arms, so the comparison stays fair, but do not quote absolute scores as real-world accuracy). 3 answers are shared by several questions (do not count a hit on a duplicate as a miss). Index the FAQ answers together with the news, laws and PDFs so there are real distractors.
- Add about 30 team-written questions on the news and the laws: dates ("when was…"), numbers, comparisons across two press items, "not in the documents". Two people write, the third verifies each gold passage.
- Keep the 10 existing PDF questions for the PDF arm.
- All earlier cautions stay: small samples, uncorrected comparisons, a bootstrap interval on every difference.

## J. Fine-tuning and model adaptation

What the corpus can honestly support:

- **Best fit: contrastive fine-tuning of the embedder** on (question → answer passage) pairs. 255 FAQ pairs split into 200 for training and about 55 held out, plus extra pairs generated by an LLM from law articles and news paragraphs (label them synthetic and unreviewed). Evaluate on the held-out human FAQ questions and the 30 hand questions. It uses a LoRA adapter on the 0.6B Qwen embedder or a full tune of e5-small, which fits a free Colab T4.
- **Interesting for Mizan:** train and test with both preprocessing arms and report whether adaptation and normalisation overlap or add.
- **Not recommended:** fine-tuning the generator. The FAQ answers are free-form and have no retrieved context, so a (context, answer) set would have to be invented, and 255 examples is too few to show an effect.
- Be explicit in the slides that 200 training pairs is a proof of concept, not a strong result.

## K. Recommended corpus, links and provenance

**Primary**

| Part | Official source | Download method | Licence / access | Likely stable? |
|---|---|---|---|---|
| FAQ (256 Q&A) | https://tourism.sa/ar/knowledge-center/faqs | `GET https://cms.tourism.sa/api/faq-categories?locale=ar&populate[faqs]=true&pagination[pageSize]=100` | tourism.sa terms of use (https://tourism.sa/ar/terms-of-use): content owned by the Ministry; copy, print, download only for personal or internal use; **saving content into other systems to extract data needs prior written permission**. No login. | undocumented API: may change |
| Press items (152) | https://tourism.sa/ar/news-events | `GET https://cms.tourism.sa/api/news?locale=ar&pagination[limit]=100&pagination[start]=0` (then 100) | same terms | same |
| Tourism laws (6), by Bureau of Experts id | https://laws.boe.gov.sa/BoeLaws/Laws/LawDetails/`<id>`/1 | plain HTTP GET, server-rendered HTML. Ids: Tourism Law `7d777c66-d28b-43de-9305-af23013b1738`; Ministry organisation `898062b9-805f-4bab-974c-ac4500ed4262`; Saudi Travel and Tourism Association `c4a35dbe-fa16-4cd3-b539-a9a700f27af5`; Saudi Tourist Accommodation Association `9b96a85d-7a9e-4adb-9379-a9a700f27a9c`; temporary-work visa regulation (Hajj and Umrah) `9bfa5aa2-77cb-4e3d-a3e7-b20a00c3dccb`; Antiquities law `a7d4493b-7c03-4c2d-b3c6-a9a700f275cd` | BOE terms (https://www.boe.gov.sa/ar/Pages/TermsOfUse.aspx): portal "available for your personal use"; I found **no open licence and no explicit ban on copying** | very likely stable |

**Primary, fully licensed add-on (from the second round)**

| Part | Official source | Download method | Licence |
|---|---|---|---|
| GASTAT methodology and quality reports: tourism establishments, Umrah, Hajj | https://www.stats.gov.sa/ar/w/methodology-and-quality-report-of-tourism-establishments-statistics ; https://stats.gov.sa/ar/w/methodology-and-quality-report-for-umrah-statistics ; https://www.stats.gov.sa/w/methodology-and-quality-report-for-hajj-statistics | plain HTTP GET, server-rendered HTML | GASTAT usage policy, https://www.stats.gov.sa/ar/use-policy, clause 1.2.2: copy, adapt, translate, reuse for any purpose with attribution and a note of changes |
| Tourism definitions and methodologies | `GET https://cms.tourism.sa/api/tourism-definitions-page?locale=ar&populate[cards]=true` and `…/tourism-methodologies-page?locale=ar&populate[cards][populate][card]=true` | JSON | tourism.sa terms (permission needed) |

**Secondary (backup, and the noisy arm)**

The 8 PDFs already in `data/corpus_manifest.json` (URLs on cdn.mt.gov.sa/mtportal/…, SHA-256 recorded). Same terms question as above. The Tourism Law PDF (Saudi-Tourism-Regulation-Ar-V014.pdf, 12 pages, 14,503 characters, 175 lam-alef repairs) is the same text as the Bureau of Experts HTML version, so it gives a **same-text clean-versus-extracted comparison**: the best natural experiment in the project.

**Optional supplement**

`All_provinces_2021_2025_664d024f55.xlsx` only (the other two are copies of part of it). Source: Ministry of Tourism open data, https://tourism.sa/ar/open-data (the library page lists hospitality KPIs, economic indicators, tourist-flow indicators). Terms (the only explicit ones we found): free of charge, attribution required, no alteration of data or source, no claim of official status, no guarantee of availability. Use: the Definitions and Metadata sheets (about 28 passages) and about 50 fact sentences generated from sheet G1 for numeric questions. Do not rebuild the regional tables.

**Permission email (send on day 1):** to DataDesk@mt.gov.sa, or through the data-request form at https://tourism.sa/ar/ucc/new-case. Ask in one paragraph: a Tuwaiq capstone project, non-commercial, local models only, text indexed privately and not redistributed, requesting written permission to use the FAQ, press items and regulation documents. Attach the list of sources above.

I am not a lawyer; these are my readings of the terms on the pages as of 2026-10-08.

## L. Implementation plan

1. **Day 1: permission and fetch.** Send the email. Write `scripts/fetch_web_corpus.py` (same pattern as `fetch_corpus.py`): download the CMS JSON and the six law pages, save raw responses under `data/raw/`, record URL, retrieval date and SHA-256 in `data/corpus_manifest.json`. Do not commit the text.
2. **Documents.** Map everything onto the existing `Page(doc, title, page, text)`: one law per `doc` with one `Page` per article; one press item per `doc` with its date in the title; one FAQ answer per `Page` with `doc` = category (the question is kept as metadata and is not indexed with its answer). Citations then show category, date or article number, plus the official URL.
3. **Preprocessing.** Keep `baseline` and `mizan+repair_lam_alef` as the two arms. Report results per stratum (web-native, PDF, combined). On web-native text `repair_lam_alef` will find 0 defects; say so rather than hiding it.
4. **Chunks.** Keep 600/100 characters for comparability, and note the existing limitation (characters, not tokens). Measured size: 285 FAQ chunks, 476 chunks for the first 100 press items, 228 law chunks and 356 PDF chunks, so 1,345 chunks.
5. **Embeddings and vector store.** Unchanged (Qwen3-Embedding-4B or the profile chosen by `memory.py`, Chroma, 20 candidates, reranker to 4).
6. **Evaluation.** Primary set: the 255 FAQ questions, with a fixed 20% dev split. Add the 10 PDF questions and about 30 new reviewed questions. Judge unchanged and still labelled unvalidated.
7. **Local LLM.** Unchanged.
8. **Adaptation.** Embedder fine-tune as in section J, with held-out evaluation. Reserve one day, and cut it first if the schedule slips.
9. **UI.** Gradio stays. Source cards show category, date or article and the official link. Add PDF stays for the PDF arm.

Suggested schedule: day 1 permission and fetch; day 2 loaders and tests; day 3 questions and review; day 4 full runs and ablations; day 5 adaptation; day 6 notebook, UI and demo; day 7 slides and rehearsal.

## M. The experiment, honestly

What Arabic variation exists in each source (measured, not assumed):

| Phenomenon | 8 PDFs | FAQ | Press items |
|---|---|---|---|
| Broken lam-alef ligature | 1,464 repairs | 0 | 0 |
| Tatweel | 17,114 (about 15% of characters) | 195 | 35 |
| Diacritics | 288 | 233 | 1,360 |
| Western / Arabic-Indic digits | not measured | 403 / 195 | 2,893 / 11 |
| Alef forms (أ / إ / آ) and ى | not measured | 1,015 / 596 / 33; ى 437 | not measured |
| Latin characters (Arabic/English mixing) | under 1% in the 8 files (0 to 1.0% by file) | 0.9% (e.g. "Tourism.sa") | 0.2% |
| Presentation-form glyphs | 0 | 0 | 0 |

- **Expect a smaller Mizan effect on clean web text.** Most of the preprocessing that earlier looked useful targets PDF extraction damage, not Arabic itself. On the web corpus only normalisation (alef, ya, digits, diacritics, kashida) has anything to act on. A null result there is a legitimate finding, and the clean-versus-extracted Tourism Law pair shows where the damage comes from.
- **Do not edit data to help Mizan.** No synthetic noise injection in the main results. If the team wants a robustness test with injected noise, report it separately and label it synthetic.
- **Earlier results are about the PDF corpus only.** The lead that Mizan helped a small embedder (hit@4 0.578 to 0.756 on 51 unreviewed questions) and the "no distinguishable difference" with Qwen3 embedders both came from the 8 PDFs. They do not carry over automatically.

## N. What I did not verify

- GASTAT, the Saudi Tourism Authority and open.data.gov.sa files were not inspected in depth.
- The remaining 52 press items and the other roughly 59 regulation entries were listed, not measured. The inventory file `docs/data_audit/mt_file_inventory.json` has the newest 100 regulation items.
- Whether the September 2026 revised regulations differ in content from our August 2025 files.
- Legal reuse rights. Everything above is my reading of public terms pages.
- The CMS endpoints may change without notice.
- Scores are my judgement.

## O. Second search round (added after the first report)

Scope: GASTAT, Saudi Tourism Authority, the national open-data platform, the Tourism Development Fund, the Royal Commission for AlUla, Vision 2030 documents, the Ministry of Hajj and Umrah, and the Ministry's own definitions and methodology pages. I downloaded or fetched and measured 11 more PDFs, 5 HTML pages and 79 GASTAT pages.

**1. GASTAT has the best licence of anything in this audit.** Its usage policy (https://www.stats.gov.sa/ar/use-policy, clause 1.2.2) lets users copy, reproduce, publish, distribute, adapt, modify, translate and reuse site materials "for any purpose, including commercial", under the open-data principle. The conditions are attribution to GASTAT as the official source, a clear statement of any changes, and no use of its logos. Modified copies must not be presented as official statistics. (Some indicators carry their own policies on their pages.) The national Open Data License (https://open.data.gov.sa/en/pages/policies/license) is similarly permissive, with attribution.

**2. But GASTAT's tourism content is mostly numbers, not text.**
- I fetched 76 tourism, Hajj and Umrah publication pages: each has about 360 characters of generic description (27,468 characters in total). The content sits in attached PDF and xlsx tables.
- Sampled attachments: Hajj 2025 bulletin 1 page; Umrah 2019 bulletin 3 pages (3,431 characters); Tourism Establishments Q1 2026 1 page; the 2018 Tourism Establishments Survey 60 pages, 51,280 characters, 41 detected tables, 13% digits, about 2.7 words per line.
- **The useful text-like part is three "methodology and quality reports"** (tourism establishments 20,102 characters, Umrah 18,395, Hajj 9,547; 94% Arabic, 0 presentation forms, 0 broken lam-alef, server-rendered HTML). They are clean explanatory prose about how tourism statistics are defined, sampled and checked. About 48,000 characters in total, fully licensed.

**3. Saudi Tourism Authority:** its open-data page sends users to the national platform; I found no narrative Arabic report on it. The Visit Saudi pages I tried timed out or returned 404 and I did not pursue them.

**4. The Ministry's own definitions and methodology pages** exist as JSON (`tourism-definitions-page`: 27 glossary entries; `tourism-methodologies-page`: 8 cards): about 10,500 characters, 97 to 98% Arabic, clean. They overlap with the bilingual Definitions sheet in the xlsx. Same tourism.sa terms of use as the FAQ.

**5. Every other PDF I sampled has extraction damage, each with a different fault:**

| Document | Size sampled | Measured faults | Verdict |
|---|---|---|---|
| Royal Commission for AlUla, annual report 2024 (Arabic) | 65 pages, 99,012 chars in 60 pages, 7.4 words per line | lam-alef defect 166 per 10,000 chars; 1,033 presentation-form characters; stray tanween marks inside words; numbers displaced (`م2024 في عام`); 9,660 embedded images | readable prose, heavy repair |
| Vision 2030 annual report 2025 | 164 pages, 114,911 chars in the first 60 | lam-alef 136 per 10,000; 7,106 presentation-form characters | heavy repair; general (not tourism) content |
| Vision 2030 Quality of Life program document | 60 pages, 94,807 chars | **letters are lost, not just swapped**: `على` never appears correctly (108 `عى`), 228 words with the article swapped (`املبادرات`); words like `التريعية` for `التشريعية` | **not recoverable without OCR** |
| Tourism Development Fund destination reports (Jeddah, Aseer, 2025) | 13 to 15 pages | split words (`الق / ادمة`), lam-alef 94 to 117 per 10,000, mixed English, **the page I read and both search-result titles carry the marking "مقيّد – Restricted"** | do not use: the classification marking makes the intended audience unclear |
| Ministry of Hajj and Umrah guides | Umrah visit guide 18 pages; rights and duties guide 46 pages | the rights guide has 39,500 presentation-form characters (NFKC fixes the letters); the Umrah guide extracts cleanly (0 lam-alef defects) but is image-heavy (129 images in 18 pages) | usable after NFKC; religious-tourism audience, small |
| GASTAT Hajj bulletin | 1 page | split words (`إ جمالي`), lam-alef 85 per 10,000 | tiny table-style document |

**6. Scores for the new candidates** (same method; full table in `docs/data_audit/candidate_scores.json`):

| Candidate | Score |
|---|---|
| GASTAT methodology and quality reports, tourism (HTML) | 7.85 |
| tourism.sa definitions and methodology (JSON) | 7.30 |
| RCU AlUla annual report 2024 | 5.70 |
| Ministry of Hajj and Umrah guides | 5.60 |
| Vision 2030 annual report 2025 | 5.50 |
| GASTAT publications (table PDFs, xlsx) | 5.10 |
| Tourism Development Fund destination reports | 4.55 |
| Vision 2030 Quality of Life program document | 3.40 |

**What this round changes**
- **The primary recommendation stands.** Nothing found in the second round beats the tourism.sa JSON and Bureau of Experts HTML on cleanliness, density and evaluation potential. The new ranking top five: press items 8.55, FAQ 8.50, Bureau of Experts laws 8.20, GASTAT methodology reports 7.85, tourism.sa definitions 7.30.
- **There is now a licence-first fallback.** If the Ministry does not answer in time, a smaller corpus made only of explicitly licensed material is possible: the GASTAT methodology reports (about 48,000 characters), the xlsx Definitions and Metadata sheets under the Ministry's open-data terms (about 28 passages) and the national open datasets. It is far too small to be the main corpus (under 100,000 characters, mostly numbers). It would work as a demo-safe subset, not as the evaluation base.
- **Add GASTAT as the fourth source in the recommended corpus.** It brings clean, licensed prose about tourism statistics, which suits questions like "how does GASTAT define an establishment" or "what is the survey's unit of analysis". Attribute it in the UI.
- **Reinforced finding:** across about 55 PDFs from six Saudi publishers, none was fully clean (the nearest were the Ministry of Hajj and Umrah Umrah guide and the GASTAT Umrah bulletin, which had no lam-alef defects but are small or image-heavy). The defect families are lam-alef swap, article swap with letter loss, presentation forms, displaced numbers, private-glyph decimals and garbled font maps. A project that depends on PDFs spends its week on repair; web-native text does not.

Not done in this round: the national open-data platform's individual tourism datasets (tables, not text); the Visit Saudi destination pages (unreachable); a licence check for the Royal Commission, Vision 2030, the Tourism Development Fund and the Ministry of Hajj and Umrah sites (I did not read their terms, so none of them is recommended).

## P. Third search round: a licensed corpus and a benchmark

Goal of this round: something strong that also has a clear licence. Two finds. Neither is an official Saudi government source, so they are supplements to the official corpus, not replacements.

**1. Arabic Wikipedia, Saudi tourism places (a text corpus, explicit licence).**
- Pulled through the public MediaWiki API (script: `scripts/audit/wiki_sample.py`) from 8 categories: world heritage sites, regions, cities, festivals, hotels, national parks, nature reserves, archaeological sites. List pages excluded, at most 60 articles per category.
- Measured on the 221 articles pulled: **1,422,193 characters** (12 times the 8 PDFs), mean 6,435 and median 2,395 characters per article, 66 articles over 5,000 characters, 20 under 500; **3,102 chunks** at 600/100; 96.4% Arabic, 0.2% Latin; **0 broken lam-alef**; 16 presentation-form characters in all; no layout problems because the API returns plain text.
- It has the richest Arabic variation of anything measured: **10,014 diacritics**, 1,406 tatweel, alef forms 18,695 (أ) / 7,094 (إ) / 1,589 (آ), 9,323 alef maqsura (ى), 22,644 Western digits against 68 Arabic-Indic digits. Place names, dates, distances and named entities are everywhere. This is where normalisation flags (diacritics, alef, ya, digits) have real material to act on.
- **Licence:** Wikipedia text is released under Creative Commons Attribution-ShareAlike (version 3.0 or 4.0 depending on the revision) according to Wikimedia's terms. I did not re-read the terms page today. Obligations: attribute, and share derived text under the same licence if we publish it. Using it privately in the notebook is the same pattern as now.
- **Weaknesses:** not official; the questions would have to be written by us (no gold); pretrained models have almost certainly seen this text, so a generator might answer without retrieval (retrieval metrics are unaffected, and both arms have the same advantage, but write questions about facts that are specific and check the "no retrieval" answer).
- Score 8.35.

**2. MIRACL Arabic (an external, human-judged benchmark).**
- From the Hugging Face dataset `miracl/miracl` (Apache-2.0 on the dataset card, ungated), Arabic dev set: **2,896 queries**, 29,197 human relevance judgments (5,658 relevant, 23,539 not relevant), 25,881 distinct judged passages; every query has at least one relevant passage. The passages come from Arabic Wikipedia (`miracl/miracl-corpus`, Apache-2.0 on the card, 320 MB compressed for Arabic; I measured one 7 MB shard).
- Measured on that shard: 61,414 passages, mean 236 characters (median 164), 94.8% Arabic, about 10 diacritics per 1,000 characters.
- Why it matters: it is the only candidate with thousands of independent, human-judged questions, so a Mizan versus Standard comparison on it has real statistical power, and results can be compared with the literature on Arabic retrieval. Use only the judged passages as the pool (about 26,000 passages, not the full 2 million), which makes it a distractor-rich but not leaderboard-comparable setting. Passages are short, and the topics are general, not tourism.
- It shows whether any effect on the tourism corpus is specific to the domain or general to Arabic text. That is the "optimizer" claim the project is making.
- The dataset is Apache-2.0 on its card, but its passages are Wikipedia text, so the CC BY-SA attribution point above applies to the text.
- Score 8.00.

**Updated ranking (top 8):** press items 8.55; FAQ 8.50; Wikipedia Saudi tourism 8.35; Bureau of Experts laws 8.20; MIRACL-ar 8.00; GASTAT methodology reports 7.85; tourism.sa definitions 7.30; our current PDFs 6.50. (The press, FAQ, laws and definitions rows are the ones that need the Ministry's permission or have no explicit licence.)

**What this changes**
- **The licence-first fallback is now a real corpus.** If the Ministry does not reply: Arabic Wikipedia Saudi tourism (about 1.4 million characters, CC BY-SA) + GASTAT methodology reports (about 48,000, open reuse with attribution) + xlsx definitions (open-data terms) is a fully licensed set, with plenty of text. It lacks the regulation-and-service flavour of the Ministry's FAQ and press items, which is what makes the demo "tourism-regulatory"; say so on the slide.
- **A defensible three-layer design:**
  1. *Official corpus* (permission pending): FAQ + press items + Bureau of Experts laws + GASTAT methodology, for the demo and for domain evaluation.
  2. *Noisy arm:* the 8 PDFs plus the Tourism Law PDF, for the extraction-damage question.
  3. *External check:* MIRACL-ar subset, for the general-Arabic claim. The Wikipedia tourism subset can serve as a licensed stand-in for layer 1 if needed.
- **Report each layer separately.** A positive result on one layer must not be presented as a result on the others.
- **Evaluation on the Wikipedia layer:** the team writes about 40 questions with a named source article and passage; two people write, one verifies.

**Still not done:** individual datasets on the national open-data platform (its search could not be queried from outside, and the ones visible are small tables such as entertainment-venue counts); the licence terms of RCU, Vision 2030, the Tourism Development Fund and the Ministry of Hajj and Umrah sites; the 52 unmeasured press items.

## Side effect to know about

During the audit the C: drive reached 100% full (95 MB free). I freed about 290 MB by deleting my own old notebook test-run folders from this session's scratch directory (`t_cpu`, `t_cpu2`, `t_new`, `cleanrun`). In the second round, at your request, I also removed three Ollama models (Qwen2.5 7B Instruct, Qwen2.5-VL 7B, Gemma 3 4B), which freed about 14 GB. The Ollama server was reporting zero models, so I deleted their manifests and exclusive blobs directly; `qwen3:4b-instruct-2507` was kept. I then deleted the candidate PDFs I had downloaded for testing (they can be re-fetched from the URLs in `docs/data_audit/mt_file_inventory.json`). The drive still shows 99% used with about 6.6 GB free, which is mostly not ours to fix here.

## Q. Verified data profile and preprocessing decisions (2026-10-10)

Everything in this section was measured on the files on disk with `scripts/profile_data.py` (outputs: `docs/data_audit/profile.json`, `profile.md`). It supersedes the estimates of sections A to P where they differ: the earlier "about 390,000 characters and 989 chunks" referred to a smaller selection; the frozen web corpus is **739 records, 592,646 characters, 1,569 chunks** (fingerprint `b3871676ff02…`, the corpus of Colab run 2). Tokens are counted with the Qwen3-Embedding tokenizer, which is identical to the Qwen3-4B-Instruct tokenizer (checked: same vocabulary, 70 of 70 texts tokenized identically; `scripts/token_analysis.py`).

### Q1. Inventory

| corpus | source | docs | records | characters | words | Qwen3 tokens | tokens/word | Arabic letters | tatweel % of chars | median record (chars) |
|---|---|---|---|---|---|---|---|---|---|---|
| web | definitions | 1 | 27 | 7,600 | 1,218 | 2,828 | 2.322 | 100.0% | 0.0 | 213 |
| web | faq | 11 | 253 | 71,973 | 11,750 | 26,498 | 2.255 | 99.07% | 0.26 | 187 |
| web | gastat | 3 | 122 | 54,924 | 8,438 | 19,794 | 2.346 | 98.42% | 0.01 | 293 |
| web | law | 6 | 177 | 95,632 | 15,705 | 35,593 | 2.266 | 100.0% | 0.17 | 302 |
| web | methodologies | 1 | 8 | 4,895 | 738 | 1,659 | 2.248 | 100.0% | 0.0 | 466 |
| web | news | 152 | 152 | 357,622 | 55,892 | 126,422 | 2.262 | 99.73% | 0.03 | 2234 |
| pdf | pdf | 8 | 159 | 139,053 | 19,720 | 71,046 | 3.603 | 99.77% | 12.31 | 1016 |

The 256 FAQ question-answer pairs become 253 indexed answer pages (three repeated answers are indexed once; the question text is never indexed). The 152 news items are one record each. Six laws give 177 pages: 171 start with the word المادة (one page per article) and 6 are preambles or headings. The 8 PDFs give 159 text pages (the last page of each PDF has no text layer).

### Q2. Arabic-specific variation (occurrences per 10,000 characters)

| corpus / source | tatweel | diacritics | alef with hamza or madda | alef maqsura | ta marbuta | Arabic-Indic digits | ASCII digits | presentation forms | orphan ال (swapped lam-alef proxy) | Arabic-Latin mixed words |
|---|---|---|---|---|---|---|---|---|---|---|
| web / definitions | 0.0 | 39.5 | 246 | 62 | 433 | 0.0 | 53 | 0.0 | 0.0 | 0.0 |
| web / faq | 26.3 | 28.8 | 200 | 51 | 322 | 23.9 | 56 | 0.0 | 0.0 | 0.0 |
| web / gastat | 1.3 | 46.8 | 209 | 51 | 348 | 0.0 | 83 | 0.4 | 0.2 | 0.2 |
| web / law | 16.5 | 39.8 | 222 | 55 | 361 | 33.7 | 109 | 0.0 | 0.0 | 0.0 |
| web / methodologies | 0.0 | 49.0 | 157 | 47 | 366 | 0.0 | 0 | 0.0 | 0.0 | 0.0 |
| web / news | 2.8 | 55.5 | 169 | 59 | 378 | 1.8 | 119 | 0.0 | 0.1 | 0.1 |
| pdf / pdf | 1230.8 | 20.7 | 151 | 35 | 294 | 0.1 | 142 | 0.0 | 5.3 | 8.1 |

What the numbers say:
- **The PDFs are a different kind of text, not a noisier version of the web text.** Kashida is 12.3% of all PDF characters (1,231 per 10,000) against 0.0 to 0.26% on the web; it alone accounts for **29.7% of all PDF tokens** (21,109 of 71,046), which is why the PDFs cost 3.60 tokens per word against 2.27 on the web. The stand-alone ال count (a symptom of the swapped lam-alef ligature) is 5.3 per 10,000 in the PDFs and about 0 on the web, and mixed Arabic-Latin words (stray glyphs inside words) are 8.1 per 10,000 against 0 to 0.2.
- **The web text is not free of variation.** It carries diacritics (29 to 55 per 10,000), hamza forms on alef (157 to 246), ta marbuta, Arabic-Indic digits in the FAQ and the laws (24 and 34 per 10,000) and a little kashida in the FAQ (26) and the laws (17). That is real material for normalization steps; the experiments found no measurable benefit from them (see Q4).
- Presentation forms (U+FB50 to FEFF) are essentially absent (0.4 per 10,000 in GASTAT only), so NFKC does almost nothing on this data. Persian look-alike letters: none.

### Q3. Duplicates, boilerplate, structure, personal data

- **Exact duplicate records:** PDFs: 29 pages in 8 groups (21 redundant copies), all of them chapter title pages or a page holding only a number (2 to 33 characters, for example "الفصل الأول أحكام تمهيدية") repeated across regulations, so near-empty and identical; laws: 7 groups of articles that are word for word identical in the two association laws (accommodation and travel); GASTAT: 7 groups of boilerplate shared by the three methodology reports; news: 1 pair (the same article under two ids). Near-duplicates (Jaccard 0.9 on 5-word shingles): none in the PDFs, 6 in laws, 9 in GASTAT, 1 in news. **Consequence:** a question about an association-law article, or a GASTAT quality statement, has several equally correct passages, so the gold documents of such questions must name all of them. The PDFs' cross-regulation clause duplicates (licence term, renewal days) are the known retrieval confusion.
- **Boilerplate:** no line repeats on at least a quarter of the pages of any source, so header and footer removal had little to remove; the cookie banner is dropped by the GASTAT loader.
- **Structure preserved:** law pages keep the article number as the first line; FAQ answers keep their category as the document id; news records are prefixed with their title; chunks never cross a page; every chunk keeps document, page and title (metadata complete for 100% of chunks). Tables in the PDFs flatten (a fee row loses its labels): not repaired.
- **Empty or tiny records:** none on the web; 5 tiny PDF pages (title pages).
- **Personal data:** none found. Pattern scans for emails, Saudi mobile numbers, labelled national or residence ids and Saudi IBANs find only **organisational contact emails** (datadesk@mt.gov.sa in one FAQ answer, info@stats.gov.sa in the three GASTAT reports); no mobile number, id or IBAN anywhere. The scan is a pattern check, not proof of absence.

### Q4. Which defects affect retrieval, which are cosmetic, which steps are risky

| Step | What it touches here | Evidence | Decision |
|---|---|---|---|
| Kashida removal | 12.3% of PDF characters; 30% of PDF tokens | leave-one-out, e5-small: removing it cost 0.195 hit@4 [0.091, 0.299] (the only significant step); chunks 320 to 351 | **keep** (this is the effect) |
| Lam-alef repair (from glyph geometry) | 1,464 ligatures in the PDFs | helped Qwen3-0.6B alone in an earlier run, not needed for e5-small | keep: it restores real words and changes no spelling convention |
| Invisible marks, NFKC, Persian letters, digit forms | 15% of PDF pages have invisible characters; presentation forms and Persian letters about 0; digits on 5% of web pages | no measurable change | keep: harmless and cheap |
| Diacritics, alef-hamza, alef-maqsura, ta marbuta, hamza seats, punctuation | most pages of both corpora | no step improved hit@4 alone; hamza seats and (with Qwen3 + reranker on clean text) the full folding set lowered it; they merge distinct words (إلى / الى, أن / إن, ة / ه) | **drop** from the default (Mizan-lite) |
| Repeated-line removal, line joining | little boilerplate; PDF hard wraps | repeated-line removal significantly lower on the PDF questions (-0.052) | **drop** |
| Chunk size counted in characters | cleaning changes how many chunks a page makes (358, 323, 320 on the PDFs) | known confound, reported with every token number | keep and state |

### Q5. Chunks (600 characters, overlap 100, sentence based, never across a page)

| corpus | arm | chunks | median chars | p10 to p90 chars | median tokens | total tokens | chunks under 100 chars |
|---|---|---|---|---|---|---|---|
| web | `baseline` | 1,569 | 417 | 136 to 575 | 147 | 215,854 | 76 |
| web | `mizan+repair_lam_alef` | 1,565 | 415 | 135 to 574 | 146 | 214,167 | 74 |
| web | `mizan-lite+repair_lam_alef` | 1,569 | 417 | 136 to 575 | 147 | 214,742 | 76 |
| pdf | `baseline` | 358 | 453 | 72 to 579 | 235 | 72,706 | 43 |
| pdf | `mizan+repair_lam_alef` | 320 | 444 | 32 to 583 | 169 | 46,567 | 44 |
| pdf | `mizan-lite+repair_lam_alef` | 323 | 447 | 34 to 580 | 178 | 49,619 | 44 |

Cleaning does not change the web corpus's chunking (1,569 / 1,569 / 1,565 chunks) but changes the PDFs' (358 / 323 / 320), because kashida removal shortens the text; the median PDF chunk falls from 235 to 178 tokens at about the same number of characters.

### Q6. Clean versus noisy: the design that is defensible

- **Primary corpus: the clean web text.** Born digital, structured (FAQ pairs, articles, sections) and traceable to a URL, date and SHA-256 (`data/web/manifest.json`, 14 files). It tests whether preprocessing matters when extraction is not the problem: it does not.
- **Secondary corpus: the 8 PDFs, kept separate.** They are where the extraction damage is, and where every measurable effect appeared. They are never mixed into the web index: a mixed index made the FAQ answers (the gold of the web questions) compete with the PDFs they paraphrase, which produced a misleading "Mizan loses" result in Colab run 2.
- **Controlled link between the two:** 77 Ministry FAQ questions whose answer is stated in a PDF (`data/web/questions_pdf.json`): the same question and the same underlying regulation, evaluated only on the damaged PDF text, with the evidence phrase taken from the PDF. No sentence-by-sentence pairing of a clean and a damaged copy of the same passage exists, and building one is not worth the time left.
- Same questions, models, chunker and retrieval settings for both arms; the single changed variable is the preprocessing.

### Q7. Licensing and what is in the repository

Unchanged from section K, with the status made explicit: tourism.sa content (FAQ, news, definitions, methodology cards): written permission requested and approved (team record; the approval e-mail is kept by the team) (updated 2026-10-13); GASTAT: open reuse with attribution; Bureau of Experts laws and the Ministry PDFs: terms not verified. **Verified 2026-10-10:** the git repository tracks no raw web text, no PDF and no result file (`data/web/`, `data/raw/`, `results/`, `finetune/*.jsonl` and the adapters are git-ignored). Short quotations from the regulation PDFs (evidence phrases of a few words, a few reference answers) appear in `eval/`; review them before publishing the repository.

### Q8. Data dictionary

| object | fields |
|---|---|
| `Page` (`src/ingestion.py`) | `doc` (PDF file name, or `faq/<category>`, `news/<date>/<id>`, `law/<slug>`, `gastat/<slug>`, `definitions`, `methodologies`), `title`, `page` (1-based; FAQ answers number within their category; articles within their law), `text` (as extracted), `text_repaired` (lam-alef repaired, PDFs only) |
| `Chunk` (`src/chunking.py`) | `doc`, `title`, `page`, `text` (after the arm's preprocessing, titled if `MIZAN_CHUNK_TITLE=1`), id |
| question (`eval/*.json`, `data/web/questions_*.json`) | `id`, `type`, `question`, `gold_evidence` (list of groups of phrases; any phrase of a group counts), `gold_docs` (only chunks of these documents can be relevant), `answer_keywords`, `reference_answer`, `category`, `needs_review` |
| result file (`results/eval-*.json`) | `settings` (every shared setting), `run` (corpus and question SHA-256, library versions), `pipelines.<name>.index` (chunks, characters, tokens), `.aggregate`, `.per_question` (metrics, retrieved doc/page/score, answer) |
| monitoring log (`logs/queries.jsonl`) | `ts`, `pipeline`, `q_hash`, `q_chars`, `kind` (answer, error, event), sources as `doc#page`, token counts, latencies, `refused`, `n_cited`, `n_valid_cited`, `prompt`; never question, answer or document text |
| source manifest (`data/web/manifest.json`, `data/corpus_manifest.json`) | URL, retrieval date, bytes, SHA-256 per file |

### Q9. Frozen for the final experiment

Web corpus: the local `data/web/raw/` (14 files, 739 records, fingerprint `b3871676ff02…`), uploaded to Colab together with `data/web/html_for_colab.zip` so the law and GASTAT pages are present. PDF corpus: the 8 files of `data/corpus_manifest.json` (fingerprint `c1b846432f4f…`). No more data is needed for the claims we can make.
