# Mizan: final RAG architecture

Written 2026-10-10; updated 2026-10-15 for the final submission (interface and backend layer, Mizan Insights, blind-test outcome; 419 tests pass offline). It says what the system is, what it is configured to do, and which parts have only been checked offline. For stage-by-stage status see `MIZAN_PIPELINE.md`; for results see `EXPERIMENT_RESULTS.md`.

## 1. The idea

Two pipelines that differ **only** in how text is preprocessed. Same documents, same questions, same chunker, same embedder, same reranker, same generator, same prompt, temperature 0. Any difference in retrieval, tokens or answers can therefore be attributed to preprocessing.

| | Standard (`baseline`) | Mizan (`mizan-lite+repair_lam_alef`) |
|---|---|---|
| Preprocessing | whitespace collapse only | whitespace, invisible characters, Unicode NFKC, tatweel (kashida) removal, Persian-form folding, digit normalization, **plus** the reversed lam-alef repair (documents only, from glyph geometry) |
| Everything else | identical | identical |

The full preset (`mizan`) exists and is measured, but is not the demo default: it was not distinguishable from Mizan-lite and costs more steps.

## 2. Architecture

```mermaid
flowchart TB
  subgraph APP["Application (app.py)"]
    UI["Gradio interface · src/ui.py<br/>render functions, English/Arabic (src/i18n.py), dark/light (src/ui_style.py)"]
    BE["MizanBackend · src/backend.py<br/>state, run numbers, upload, prepared questions, translation"]
    UI <--> BE
  end

  subgraph DATA["Data (offline, once)"]
    W["Web corpus: 739 records<br/>FAQ, news, laws, GASTAT"] --> PG
    P["8 Ministry PDFs, 159 pages<br/>PyMuPDF"] --> PG
    UP["PDFs added in the app<br/>file checks, upload scan"] --> PG
    PG["Pages: doc, title, page, text<br/>source URL + SHA-256 + corpus fingerprint"]
  end
  BE --> UP

  subgraph INDEX["Index, built twice (one Chroma collection per pipeline)"]
    PG --> PRE["Preprocess<br/>(Standard: whitespace | Mizan-lite: extraction repair)"]
    PRE --> CH["Chunk 600 chars, overlap 100<br/>never across a page; keeps doc, title, page"]
    CH --> EMB["Embed: Qwen3-Embedding-0.6B<br/>(base model; LoRA adapter optional, off)"]
    EMB --> DB[("Chroma, cosine,<br/>in memory")]
  end

  BE -->|"question"| CMP["comparison.compare<br/>same question to both pipelines"]
  CMP --> QP["Same preprocessing as that pipeline's index"]
  QP --> QE["Embed query (same model)"] --> DB
  DB -->|"top 20"| RR["Rerank: Qwen3-Reranker-0.6B<br/>keep top 4"]
  RR --> SF["Safety filter<br/>instruction-like passages withheld"]
  SF -->|"none left"| REF["Standard refusal sentence<br/>no model call"]
  SF -->|"safe passages"| PR["Prompt v1<br/>passages with [file, page N] headers<br/>+ the ORIGINAL question"]
  PR --> LLM["Qwen3-4B-Instruct-2507, 4-bit (base model)<br/>temperature 0, max 600 tokens"]
  LLM --> CC["Citation check<br/>each [file, page] vs passages shown"]
  REF --> OUT
  CC --> OUT["Result per pipeline: answer, sources, tokens, latency<br/>+ evaluation.score when gold evidence is known"]
  OUT --> BE
  OUT --> MON["Monitor: JSON log line, no text<br/>7 alert rules, banner, optional webhook / e-mail"]

  subgraph INS["Mizan Insights"]
    EV["insights_evidence.build_evidence<br/>numbered facts, not-measured list,<br/>allowed conclusions (compute_allowed)"]
    AG["evaluate_prepared<br/>retrieval-only aggregate, paired bootstrap"]
    GEN["insights.generate_insights<br/>same generator, JSON reply"]
    VAL["insights.validate<br/>reject contradictions, invented numbers,<br/>causal and significance claims"]
    AG --> EV --> GEN --> VAL
  end
  BE -->|"current run, documents, index fingerprints"| EV
  BE -->|"Evaluate the prepared questions"| AG
  VAL -->|"checked panel, or facts only"| BE

  subgraph EVAL["Evaluation (calls the same Pipeline.ask)"]
    E2["hit@k, MRR, precision, first-stage hit,<br/>candidate recall, tokens, paired bootstrap,<br/>citation metrics, frozen blind set, human grading"]
  end
  E2 -.-> DB
  E2 -.-> OUT
```

## 3. Final configuration

| Item | Value | Where |
|---|---|---|
| Embedder | `Qwen/Qwen3-Embedding-0.6B`, max sequence 512, query instruction about Saudi tourism regulations | `src/config.py`, `src/embeddings.py` |
| Adapter | optional LoRA (r=16, 3 epochs) on the embedder, **off**: on the blind set it was not shown to help (+0.014 [−0.072, +0.101], P5) | `MIZAN_EMBEDDING_ADAPTER` |
| Chunking | 600 characters after preprocessing, overlap 100, sentence-based, never across a page | `src/chunking.py` |
| Vector store | Chroma, cosine, in memory, one collection per pipeline, self-healing on an empty result | `src/retrieval.py` |
| First stage | top 20 | `MIZAN_RERANK_TOP_N` |
| Reranker | `Qwen/Qwen3-Reranker-0.6B`, keeps 4 | `src/rerank.py` |
| Generator | `Qwen3-4B-Instruct-2507`, 4-bit, temperature 0, 600 tokens; via Ollama (laptop) or Hugging Face in process (Colab) | `src/local_llm.py` |
| Prompt | v1 (the evaluated default); v2 to v4 compared on 61 questions with a real model: coverage unchanged, v4 cites a shown page more often at about 20% more input tokens; v1 kept because the blind set was run with it | `src/rag.py` `PROMPTS`, `MIZAN_PROMPT` |
| Judge (evaluation only) | tried and rejected (Gemma kappa 0.00); answers are graded by people (two graders and an adjudicator) | `scripts/human_grading.py` |
| Safety | deterministic Arabic and English injection scan; withheld passages; no-model refusal path; personal-data scan on uploads (counts only) | `src/safety.py` |
| Citations | checked against the passages the model was shown | `src/citations.py` |
| Monitoring | log line per answer or failure (hashes, ids, tokens, latency), 7 alert rules, 5 minutes between repeats of an alert | `src/monitoring.py` |
| Mizan Insights | an LLM explains the evidence of one comparison (and of the prepared-question aggregate); code computes the facts and the conclusions allowed and rejects replies that contradict them; no analysis without a configured generator | `src/insights_evidence.py`, `src/insights.py`, `src/backend.py`, `src/ui.py` (`render_insights`) |
| Interface | Gradio 6.9; English and Arabic (full right-to-left), dark and light, remembered in the browser; switching never calls a model; optional English reading-aid translation of Arabic answers | `src/ui.py`, `src/i18n.py`, `src/ui_style.py`, `src/backend.py` |
| Cost to run | all local, open models, no API key | |

## 4. One request, in order

1. The UI sends the question to each pipeline (`Pipeline.ask`).
2. The question is preprocessed exactly like that pipeline's documents; the embedder turns it into a vector.
3. Chroma returns the 20 nearest chunks; the reranker keeps the 4 best.
4. The safety filter removes any passage that contains instruction-like text. If none is left, the standard refusal is the answer and the model is not called.
5. The prompt contains the surviving passages, each headed `[file, page N]`, and the user's **original** question (only retrieval uses the preprocessed one).
6. The generator answers; the citation check compares each cited `[file, page]` with the passages it was actually shown.
7. The monitor logs one line (no question or answer text) and may raise an alert; the backend turns both results into plain dicts and the interface renders both columns with measured values only (`n/a` when not measurable).
8. The backend builds the Insights evidence for this run (`insights_evidence.build_evidence`), asks the generator for an explanation (`insights.generate_insights`), and shows it only if `insights.validate` accepts it; otherwise the panel shows the facts and says why. A newer question or a document change drops a late result (run numbers).

## 5. What the evidence supports (frozen blind test, 266 questions, one run)

The authoritative numbers are in `EXPERIMENT_RESULTS.md` section 0 and `docs/BLIND_RESULTS_ANALYSIS.md`; this is a summary.

- **PDF retrieval (P1):** hit@4 0.681 → 0.797, **+0.116 [+0.029, +0.217]** (n = 69, chunk titles off, the pre-specified setting). With chunk titles on, the configuration that produced the graded answers, 0.812 → 0.855, +0.043 [−0.043, +0.145]: not distinguishable. The gain is in the first retrieval stage.
- **Clean web text (P2):** +0.007 [+0.000, +0.021] (n = 140): no difference, no loss.
- **Answers, human-graded and adjudicated (P3):** web +0.029 [−0.007, +0.071], no loss; PDF +0.014 [−0.101, +0.130], not distinguishable (the lower bound misses the −0.10 margin, so no "no loss" claim for PDF).
- **Refusals (P4):** correct refusal of unanswerable PDF questions 20/24 → 23/24 (human-graded).
- **LoRA (P5):** +0.014 [−0.072, +0.101] on blind PDF questions: not shown to help, although it gained +0.22 on development questions written in the training style. The demo runs the base embedder.
- **Cost:** PDF index 72,706 → 49,619 embedding tokens (−31.8%); generator input per PDF question 1,333 → 1,122 (−15.9%). No latency or cost saving is claimed.

So the claim the system can defend: Arabic-aware repair of extraction damage helps retrieval on damaged PDFs when titles are not added, does no measurable harm on clean text, and costs fewer tokens; it does not make answers measurably better.

## 6. Decisions taken for the final system

1. **Configuration:** `.env` matches the evaluated stack (Qwen3-Embedding-0.6B + Qwen3-Reranker-0.6B over 20 candidates, chunk titles on, Qwen3-4B-Instruct through Ollama, prompt v1).
2. **Adapter:** off, by the pre-registered rule (P5 interval includes zero).
3. **Prompt:** v1 stays the default; v4 is documented as the better-grounded candidate for future work.
4. **Mizan Insights** stays on the screen, with the scope line on every panel: one question is an observation, an aggregate needs 20 answerable questions and an interval.

## 7. Known limits (state them in the presentation)

- Chunk size counts characters after cleaning, so the two arms get different chunk counts (a confound).
- Document titles come from a filename table, not from the documents.
- No OCR, no table repair, no BM25 or hybrid search, no query rewriting, no hosted deployment.
- The injection scan does not stop paraphrased or encoded instructions; its effect on a real model is untested.
- Embedder, reranker and generator are all Qwen (pre-trained models used as published; nothing was trained from scratch, and only the optional embedder adapter was fine-tuned).
- Every number above is one run; questions are treated as independent, so intervals are optimistic.
- The blind set was written by the team; all three graders are team members.
- Mizan Insights checks numbers, directions and wording against the facts, but a 4B model can still write a misleading sentence that passes the checks; its text is an explanation, not a measurement.
