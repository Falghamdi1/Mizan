# Run diagnostics

Computed by `scripts/run_diagnostics.py` from `colab_run4`. No model was run.

## 1. Index cost (change against Standard, measured on the indexes)

| embedder | corpus | pipeline | chunks | characters | embedding tokens |
|---|---|---|---|---|---|
| e5-small | pdf | Mizan-lite | 323 (-9.8%) | 123,443 (-12.0%) | 37,698 (-41.5%) |
| e5-small | pdf | Mizan full | 320 (-10.6%) | 121,507 (-13.4%) | 37,234 (-42.2%) |
| e5-small | web | Mizan-lite | 1569 (+0.0%) | 598,194 (-0.1%) | 166,109 (-0.5%) |
| e5-small | web | Mizan full | 1565 (-0.3%) | 594,170 (-0.8%) | 164,864 (-1.3%) |
| Qwen3-Embedding-0.6B | pdf | Mizan-lite | 323 (-9.8%) | 123,443 (-12.0%) | 49,619 (-31.8%) |
| Qwen3-Embedding-0.6B | pdf | Mizan full | 320 (-10.6%) | 121,507 (-13.4%) | 46,567 (-36.0%) |
| Qwen3-Embedding-0.6B | web | Mizan-lite | 1569 (+0.0%) | 598,194 (-0.1%) | 214,742 (-0.5%) |
| Qwen3-Embedding-0.6B | web | Mizan full | 1565 (-0.3%) | 594,170 (-0.8%) | 214,167 (-0.8%) |
| Qwen3-Embedding-4B | pdf | Mizan-lite | 323 (-9.8%) | 123,443 (-12.0%) | 49,619 (-31.8%) |
| Qwen3-Embedding-4B | pdf | Mizan full | 320 (-10.6%) | 121,507 (-13.4%) | 46,567 (-36.0%) |
| Qwen3-Embedding-4B | web | Mizan-lite | 1569 (+0.0%) | 598,194 (-0.1%) | 214,742 (-0.5%) |
| Qwen3-Embedding-4B | web | Mizan full | 1565 (-0.3%) | 594,170 (-0.8%) | 214,167 (-0.8%) |

## 2. Candidate pool and first stage (difference to Standard, paired bootstrap 95%)

| embedder | corpus | metric | pipeline | Standard | pipeline | difference | n |
|---|---|---|---|---|---|---|---|
| e5-small | pdf | candidate_recall | Mizan-lite | 0.312 | 0.545 | +0.234 [+0.130, +0.351] * | 77 |
| e5-small | pdf | candidate_recall | Mizan full | 0.312 | 0.545 | +0.234 [+0.130, +0.351] * | 77 |
| e5-small | pdf | first_stage_hit | Mizan-lite | 0.312 | 0.545 | +0.234 [+0.130, +0.351] * | 77 |
| e5-small | pdf | first_stage_hit | Mizan full | 0.312 | 0.545 | +0.234 [+0.130, +0.351] * | 77 |
| e5-small | pdf | hit | Mizan-lite | 0.312 | 0.545 | +0.234 [+0.130, +0.351] * | 77 |
| e5-small | pdf | hit | Mizan full | 0.312 | 0.545 | +0.234 [+0.130, +0.351] * | 77 |
| e5-small | web | candidate_recall | Mizan-lite | 0.504 | 0.516 | +0.012 [+0.000, +0.028] | 250 |
| e5-small | web | candidate_recall | Mizan full | 0.504 | 0.500 | -0.004 [-0.032, +0.024] | 250 |
| e5-small | web | first_stage_hit | Mizan-lite | 0.504 | 0.516 | +0.012 [+0.000, +0.028] | 250 |
| e5-small | web | first_stage_hit | Mizan full | 0.504 | 0.500 | -0.004 [-0.032, +0.024] | 250 |
| e5-small | web | hit | Mizan-lite | 0.504 | 0.516 | +0.012 [+0.000, +0.028] | 250 |
| e5-small | web | hit | Mizan full | 0.504 | 0.500 | -0.004 [-0.032, +0.024] | 250 |
| Qwen3-Embedding-0.6B | pdf | candidate_recall | Mizan-lite | 0.753 | 0.857 | +0.104 [+0.000, +0.208] | 77 |
| Qwen3-Embedding-0.6B | pdf | candidate_recall | Mizan full | 0.753 | 0.805 | +0.052 [-0.039, +0.156] | 77 |
| Qwen3-Embedding-0.6B | pdf | first_stage_hit | Mizan-lite | 0.481 | 0.662 | +0.182 [+0.065, +0.299] * | 77 |
| Qwen3-Embedding-0.6B | pdf | first_stage_hit | Mizan full | 0.481 | 0.636 | +0.156 [+0.039, +0.273] * | 77 |
| Qwen3-Embedding-0.6B | pdf | hit | Mizan-lite | 0.623 | 0.623 | +0.000 [-0.104, +0.104] | 77 |
| Qwen3-Embedding-0.6B | pdf | hit | Mizan full | 0.623 | 0.636 | +0.013 [-0.091, +0.117] | 77 |
| Qwen3-Embedding-0.6B | web | candidate_recall | Mizan-lite | 0.724 | 0.732 | +0.008 [+0.000, +0.020] | 250 |
| Qwen3-Embedding-0.6B | web | candidate_recall | Mizan full | 0.724 | 0.720 | -0.004 [-0.024, +0.016] | 250 |
| Qwen3-Embedding-0.6B | web | first_stage_hit | Mizan-lite | 0.608 | 0.608 | +0.000 [-0.012, +0.012] | 250 |
| Qwen3-Embedding-0.6B | web | first_stage_hit | Mizan full | 0.608 | 0.580 | -0.028 [-0.060, +0.000] | 250 |
| Qwen3-Embedding-0.6B | web | hit | Mizan-lite | 0.616 | 0.620 | +0.004 [-0.008, +0.020] | 250 |
| Qwen3-Embedding-0.6B | web | hit | Mizan full | 0.616 | 0.568 | -0.048 [-0.080, -0.016] * | 250 |
| Qwen3-Embedding-4B | pdf | candidate_recall | Mizan-lite | 0.883 | 0.922 | +0.039 [-0.013, +0.104] | 77 |
| Qwen3-Embedding-4B | pdf | candidate_recall | Mizan full | 0.883 | 0.935 | +0.052 [+0.013, +0.104] * | 77 |
| Qwen3-Embedding-4B | pdf | first_stage_hit | Mizan-lite | 0.727 | 0.779 | +0.052 [-0.013, +0.130] | 77 |
| Qwen3-Embedding-4B | pdf | first_stage_hit | Mizan full | 0.727 | 0.740 | +0.013 [-0.078, +0.104] | 77 |
| Qwen3-Embedding-4B | pdf | hit | Mizan-lite | 0.701 | 0.662 | -0.039 [-0.130, +0.065] | 77 |
| Qwen3-Embedding-4B | pdf | hit | Mizan full | 0.701 | 0.675 | -0.026 [-0.117, +0.065] | 77 |
| Qwen3-Embedding-4B | web | candidate_recall | Mizan-lite | 0.792 | 0.792 | +0.000 [-0.012, +0.012] | 250 |
| Qwen3-Embedding-4B | web | candidate_recall | Mizan full | 0.792 | 0.780 | -0.012 [-0.032, +0.004] | 250 |
| Qwen3-Embedding-4B | web | first_stage_hit | Mizan-lite | 0.632 | 0.640 | +0.008 [+0.000, +0.020] | 250 |
| Qwen3-Embedding-4B | web | first_stage_hit | Mizan full | 0.632 | 0.644 | +0.012 [-0.012, +0.040] | 250 |
| Qwen3-Embedding-4B | web | hit | Mizan-lite | 0.636 | 0.644 | +0.008 [-0.008, +0.024] | 250 |
| Qwen3-Embedding-4B | web | hit | Mizan full | 0.636 | 0.596 | -0.040 [-0.072, -0.008] * | 250 |

`*` = interval excludes zero. `candidate_recall` = gold evidence is among the 20 candidates the reranker sees (single-stage embedders: the top 4).

## 3. Retrieval latency per question (seconds; one run each on a shared Colab GPU)

| embedder | corpus | pipeline | n | median | p95 | max |
|---|---|---|---|---|---|---|
| e5-small | pdf | Standard | 77 | 0.01 | 0.02 | 0.06 |
| e5-small | pdf | Mizan-lite | 77 | 0.01 | 0.02 | 0.05 |
| e5-small | pdf | Mizan full | 77 | 0.01 | 0.02 | 0.05 |
| e5-small | web | Standard | 250 | 0.01 | 0.02 | 0.03 |
| e5-small | web | Mizan-lite | 250 | 0.01 | 0.02 | 0.03 |
| e5-small | web | Mizan full | 250 | 0.01 | 0.02 | 0.02 |
| Qwen3-Embedding-0.6B | pdf | Standard | 77 | 0.93 | 0.96 | 3.65 |
| Qwen3-Embedding-0.6B | pdf | Mizan-lite | 77 | 0.79 | 0.87 | 0.90 |
| Qwen3-Embedding-0.6B | pdf | Mizan full | 77 | 0.77 | 0.85 | 0.92 |
| Qwen3-Embedding-0.6B | web | Standard | 250 | 0.71 | 0.77 | 3.32 |
| Qwen3-Embedding-0.6B | web | Mizan-lite | 250 | 0.70 | 0.78 | 0.82 |
| Qwen3-Embedding-0.6B | web | Mizan full | 250 | 0.70 | 0.77 | 0.82 |
| Qwen3-Embedding-4B | pdf | Standard | 77 | 0.95 | 1.00 | 4.95 |
| Qwen3-Embedding-4B | pdf | Mizan-lite | 77 | 0.82 | 0.91 | 0.91 |
| Qwen3-Embedding-4B | pdf | Mizan full | 77 | 0.79 | 0.88 | 0.91 |
| Qwen3-Embedding-4B | web | Standard | 250 | 0.73 | 0.81 | 5.84 |
| Qwen3-Embedding-4B | web | Mizan-lite | 250 | 0.72 | 0.80 | 0.90 |
| Qwen3-Embedding-4B | web | Mizan full | 250 | 0.72 | 0.80 | 0.86 |

Paired difference in retrieval seconds against Standard (first question of each pipeline dropped as warm-up; paired bootstrap 95%). The Standard pipeline always ran first in the notebook, so run order is a possible confound; the PDF differences also follow the smaller index (fewer tokens for the reranker):

| embedder | corpus | pipeline | Standard mean s | pipeline mean s | difference | n |
|---|---|---|---|---|---|---|
| e5-small | pdf | Mizan-lite | 0.014 | 0.014 | -0.000 [-0.001, -0.000] * | 76 |
| e5-small | pdf | Mizan full | 0.014 | 0.014 | -0.000 [-0.000, +0.000] | 76 |
| e5-small | web | Mizan-lite | 0.016 | 0.015 | -0.000 [-0.000, -0.000] * | 249 |
| e5-small | web | Mizan full | 0.016 | 0.015 | -0.000 [-0.000, +0.000] | 249 |
| Qwen3-Embedding-0.6B | pdf | Mizan-lite | 0.927 | 0.798 | -0.129 [-0.138, -0.119] * | 76 |
| Qwen3-Embedding-0.6B | pdf | Mizan full | 0.927 | 0.781 | -0.147 [-0.157, -0.137] * | 76 |
| Qwen3-Embedding-0.6B | web | Mizan-lite | 0.703 | 0.699 | -0.004 [-0.007, -0.002] * | 249 |
| Qwen3-Embedding-0.6B | web | Mizan full | 0.703 | 0.697 | -0.006 [-0.010, -0.002] * | 249 |
| Qwen3-Embedding-4B | pdf | Mizan-lite | 0.947 | 0.822 | -0.125 [-0.135, -0.115] * | 76 |
| Qwen3-Embedding-4B | pdf | Mizan full | 0.947 | 0.793 | -0.155 [-0.165, -0.145] * | 76 |
| Qwen3-Embedding-4B | web | Mizan-lite | 0.726 | 0.721 | -0.005 [-0.008, -0.002] * | 249 |
| Qwen3-Embedding-4B | web | Mizan full | 0.726 | 0.722 | -0.004 [-0.009, -0.000] * | 249 |

## 4. Reproducibility against earlier runs

- **colab_run2**: 108 metric values compared across matching files; **91 of 108 identical** where the corpus fingerprint is the same; 0 values are on a different corpus (not comparable).
  - the 17 differing values are in `eval-Qwen3-Embedding-0.6B-all.json`, `eval-Qwen3-Embedding-4B-all.json`, `eval-Qwen3-Embedding-4B-web.json`, `eval-e5-small-all.json`, `eval-e5-small-web.json`; largest difference in hit/MRR/precision/recall: 0.0080 (one question of 250 = 0.004).
- **colab_run3**: 108 metric values compared across matching files; **54 of 54 identical** where the corpus fingerprint is the same; 54 values are on a different corpus (not comparable).

## 5. Which steps move retrieval (tally of the notebook's own bootstrap labels)

| table | reference | variants | higher | lower | not distinguishable |
|---|---|---|---|---|---|
| `ablations-pdf.md` | `baseline` | 16 | 0 | 2 | 14 |
| `leave-one-out-e5-pdf.md` | `mizan` | 12 | 0 | 2 | 10 |
- `ablations-pdf.md`: `baseline+remove_repeated_lines` is **lower**: -0.052 [-0.104, -0.013] lower
- `ablations-pdf.md`: `baseline+normalize_hamza_seats` is **lower**: -0.117 [-0.195, -0.052] lower
- `leave-one-out-e5-pdf.md`: `baseline` is **lower**: -0.234 [-0.351, -0.130] lower
- `leave-one-out-e5-pdf.md`: `mizan-no-remove_tatweel` is **lower**: -0.195 [-0.299, -0.091] lower
