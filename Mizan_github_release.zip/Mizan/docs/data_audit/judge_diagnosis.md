# Judge diagnosis (measured on stored answers, no model run)

Source: every `results/eval-*.json` with judge verdicts; refusals excluded (they are graded by rule). Answers repeat across files (the same question in several runs), so counts are verdicts, not distinct questions.

| judge | verdicts | said correct | key facts present (coverage >= 0.5): said correct | few key facts (< 0.5): said correct | few key facts AND gold passage not retrieved: said correct |
|---|---|---|---|---|---|
| qwen3-4b-instruct (the generator itself) | 273 | 91% | 210/216 | 38/57 | 17/25 |
| gemma3:4b | 243 | 99% | 196/196 | 45/47 | 19/19 |

Reading: a judge that is useful says "correct" mostly when the key facts are there and rarely when they are not. The table shows it says "correct" in both cases. Keyword coverage is a proxy, so some of the low-coverage answers may be right paraphrases; the by-hand reading of the disagreements is in `docs/JUDGE_DIAGNOSIS.md`.
