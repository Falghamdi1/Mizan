# Gold-phrase survival

Generated 2026-10-10 19:43 by `scripts/gold_survival.py`. Differences are to `baseline`, paired bootstrap 95% over questions; `*` = interval excludes zero.
`strict` = verbatim in correct Arabic (a diagnostic of extraction damage that favours a repairing pipeline by construction); `canonical` = the evaluation matcher (the fair upper bound on what retrieval can find).

## 77 Ministry FAQ questions answered inside the PDFs

77 answerable questions; corpus fingerprint `c1b846432f4f…`; chunks per pipeline: `baseline` 358, `mizan-lite+repair_lam_alef` 323, `mizan+repair_lam_alef` 320.

| pipeline | strict: any evidence present | strict: coverage | canonical: any | canonical: coverage |
|---|---|---|---|---|
| `baseline` | 0.117  | 0.117 | 1.000  | 1.000 |
| `mizan-lite+repair_lam_alef` | 0.571 +0.455 [+0.338, +0.571] * | 0.571 | 1.000 +0.000 [+0.000, +0.000] | 1.000 |
| `mizan+repair_lam_alef` | 0.221 +0.104 [+0.000, +0.221] | 0.221 | 1.000 +0.000 [+0.000, +0.000] | 1.000 |

## 10 hand-written questions

9 answerable questions; corpus fingerprint `c1b846432f4f…`; chunks per pipeline: `baseline` 358, `mizan-lite+repair_lam_alef` 323, `mizan+repair_lam_alef` 320.

| pipeline | strict: any evidence present | strict: coverage | canonical: any | canonical: coverage |
|---|---|---|---|---|
| `baseline` | 0.111  | 0.111 | 1.000  | 1.000 |
| `mizan-lite+repair_lam_alef` | 0.667 +0.556 [+0.222, +0.889] * | 0.667 | 1.000 +0.000 [+0.000, +0.000] | 1.000 |
| `mizan+repair_lam_alef` | 0.333 +0.222 [+0.000, +0.556] | 0.278 | 1.000 +0.000 [+0.000, +0.000] | 1.000 |

## 51 LLM-generated questions

45 answerable questions; corpus fingerprint `c1b846432f4f…`; chunks per pipeline: `baseline` 358, `mizan-lite+repair_lam_alef` 323, `mizan+repair_lam_alef` 320.

| pipeline | strict: any evidence present | strict: coverage | canonical: any | canonical: coverage |
|---|---|---|---|---|
| `baseline` | 0.178  | 0.178 | 0.956  | 0.956 |
| `mizan-lite+repair_lam_alef` | 0.933 +0.756 [+0.622, +0.867] * | 0.933 | 1.000 +0.044 [+0.000, +0.111] | 1.000 |
| `mizan+repair_lam_alef` | 0.311 +0.133 [+0.000, +0.267] | 0.311 | 1.000 +0.044 [+0.000, +0.111] | 1.000 |

## 250 web FAQ questions

250 answerable questions; corpus fingerprint `b3871676ff02…`; chunks per pipeline: `baseline` 1569, `mizan-lite+repair_lam_alef` 1569, `mizan+repair_lam_alef` 1565.

| pipeline | strict: any evidence present | strict: coverage | canonical: any | canonical: coverage |
|---|---|---|---|---|
| `baseline` | 1.000  | 1.000 | 1.000  | 1.000 |
| `mizan-lite+repair_lam_alef` | 0.920 -0.080 [-0.116, -0.048] * | 0.920 | 1.000 +0.000 [+0.000, +0.000] | 1.000 |
| `mizan+repair_lam_alef` | 0.092 -0.908 [-0.944, -0.872] * | 0.092 | 1.000 +0.000 [+0.000, +0.000] | 1.000 |
