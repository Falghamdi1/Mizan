# Analysis plan for the final evidence (written before the blind questions exist)

Written 2026-10-10, before any blind question has been written and before any pipeline has seen one. The git history is the timestamp: this file is committed first. Anything we later do differently is a **deviation** and is listed under it in `docs/EXPERIMENT_LOG.md`, with the reason. A negative or neutral result is reported exactly like a positive one.

## 1. What is development data and what is not

Every question set used so far was used to choose or tune something, so none of them can support a final claim:

| set | used to |
|---|---|
| 250 web FAQ questions | choose and check preprocessing steps; the lite preset was fixed before run 3, but ablations had run on them |
| 77 Ministry FAQ questions inside the PDFs | leave-one-out of steps, which produced the lite preset |
| 51 LLM-generated, 10 hand-written | prompt versions, answer runs, adaptation checks |
| the 61-question prompt set | choosing the prompt (section 5) |

They stay **development data**. Numbers from them are reported as such. The only untouched evidence will be the **blind set** (`eval/blind_test/`, human-written, frozen by hash, used once).

## 2. The blind set and how it is used

- 45 to 60 questions written by the three of us from the documents, checked only against document text (`scripts/make_blind_test.py`), frozen with `--build`, verified with `--verify` before the run.
- Used **once**, in the final run (`Mizan_Final_Colab.ipynb`). Not used to choose a pipeline, prompt, threshold, adapter or setting. If something goes wrong in the run, the run is repeated with the same settings and both runs are reported; settings are not changed after seeing blind results.
- Questions written by an LLM are not part of it. LLM-generated questions are **exploratory only** (section 6).

## 3. Settings fixed now (nothing below may change after the blind set is frozen)

- Pipelines: `baseline` (Standard) against `mizan-lite+repair_lam_alef` (Mizan-lite). PDF questions are evaluated on the PDF corpus, web questions on the web corpus, never in one index. The full preset is reported as a reference arm, not as a candidate.
- Final stack: Qwen3-Embedding-0.6B, Qwen3-Reranker-0.6B (top 20 to top 4), Qwen3-4B-Instruct-2507 in 4-bit, temperature 0, chunk 600/100 characters. Secondary stacks, reported but not decisive: e5-small single stage, Qwen3-Embedding-4B + reranker.
- Prompt for the blind answers: the version chosen by section 5 on development data, fixed before the run.

## 4. Primary endpoints and how they are read

All differences are paired bootstrap 95% intervals over questions (`src/stats.py`); questions are treated as independent, which is optimistic.

| # | endpoint | data | reading rule, fixed now |
|---|---|---|---|
| P1 | hit@4, Mizan-lite minus Standard, final stack | blind answerable PDF questions | lower bound above 0: "gain shown"; interval includes 0: "not distinguishable from zero" (never "equal"); upper bound below 0: "loss". The target of +0.10 is a goal and is reported as met or not met. |
| P2 | hit@4, Mizan-lite minus Standard, final stack | blind answerable web questions | same rule. A clean-text loss worse than −0.02 would break our own target and is reported. |
| P3 | answer correctness, graded by two people, Mizan-lite minus Standard | blind answerable questions, both arms, final stack and prompt | estimate and interval only. With about 40 to 50 answerable questions only differences of roughly 0.15 or more are detectable, so **no "no loss of quality" claim is allowed unless the lower bound is above −0.10**; otherwise we write "not distinguishable, small sample". |
| P4 | refusal on unanswerable blind questions | blind unanswerable questions, both arms | proportion with Wilson interval; target at least 90%. |
| P5 | hit@4, adapter minus base model | blind answerable PDF questions, **the adaptation configuration** (Mizan-lite text, titles on, no reranker, as trained) | lower bound above 0: "adaptation shown to help"; otherwise the adapter is described as not shown to help and the final demo runs the base model. Documents held out of training (Tour-Guide, Tourist-Visa) are reported as a separate row: that row measures generalisation to unseen documents, the other rows measure use on the known corpus. |

Secondary, reported without a decision rule: MRR, precision@4, candidate recall (gold in the top 20), index tokens, retrieved and generator input tokens, retrieval and generation latency, citation validity, the same endpoints for the secondary stacks, and everything on the full preset.

## 5. The prompt decision (development data, before the blind run)

The prompt is a setting, so it must be chosen on development data. Candidates: v1 (current default) and v4. The 61-question prompt comparison already exists; two people grade its blind sheet (`prompts-20261010-160638-grading-sheet.csv`).

Switch the default to v4 if and only if all of these hold on the development sheet: (a) citations naming a retrieved page at least 0.90 for v4 (v1 measured 0.767, v4 0.967); (b) human-graded correctness of v4 minus v1 has a point estimate of at least −0.05; (c) v4 does not refuse more than two additional answerable questions than v1; (d) the cost (about 20% more input tokens, about 0.8 s more per answer) is accepted. Otherwise v1 stays and its citation shortfall is stated as a limit. v2 and v3 are not candidates (v3 refuses more, v2 and v3 add output length). The decision is written in the experiment log before the blind run.

## 6. The mixed strong-stack result

On the 77 Ministry FAQ questions the strong stack shows no gain from Mizan-lite; on 45 LLM-generated questions it shows +0.11. These are different questions written by different authors, and the generated ones come from the same model family as the system, so they may favour cleaned text. We do **not** pool them and we do **not** pick the favourable one. The claim for strong stacks is decided by P1 alone. Until then the claim stays "mixed". LLM-generated questions are exploratory only.

## 7. Human grading protocol

Two graders work independently on blind sheets (answers shuffled, arm names hidden), label `correct` (0/1) and `supported` (0/1, not for refusals), using `eval/human_grading/RUBRIC.md`. `scripts/human_grading.py merge` reports Cohen's kappa; disagreements go to a third person. The key file is never given to graders. The LLM judge is not used for any claim (it failed its own check: kappa 0.00, and two visible errors in 20 judgments in the main-notebook run).

Added 2026-10-11, before any blind question or blind answer existed: two-arm sheets also carry a pairwise column `better (A, B or tie)`. It is **secondary and descriptive** (wins, ties, exact sign test). It does not change P3 and no decision rule uses it; if it disagrees with the 0/1 correctness, both are reported.

## 8. What would count as a bad outcome, and what we do

- P1 and P2 not distinguishable from zero: the claim becomes "Mizan-lite repairs extraction damage and saves tokens and retrieval time on damaged PDFs; it did not improve retrieval on the final stack." That is a limited but true result.
- P3 shows a loss or cannot rule one out: the presentation says so, and the recommendation is to use Mizan only for the token and time savings, with the quality risk stated.
- P5 not shown to help: the adaptation requirement is still met (the experiment was run, with a held-out design, and is reported honestly), and the final demo uses the base model.

## 9. Order of work

1. Commit this plan. 2. Each of us writes 15 to 20 blind questions (`eval/blind_test/README.md`), a teammate checks five rows each, `--build` freezes. 3. Two graders grade the prompt sheet; the prompt decision (section 5) is logged. 4. One run of `Mizan_Final_Colab.ipynb` produces P1 to P5 and the blind answer sheets. 5. Two graders grade the blind answers (P3). 6. The numbers go into `EXPERIMENT_RESULTS.md` and the slides, from the files.
