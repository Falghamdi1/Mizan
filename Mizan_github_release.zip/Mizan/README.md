# مِيزان · Mizan: Arabic-aware preprocessing for RAG, measured honestly

Mizan runs the **same** Arabic retrieval-augmented generation (RAG) system twice on Saudi tourism regulations: once on the text as a PDF extractor delivers it (**Standard**), once after Arabic-aware repair and normalization (**Mizan-lite**). Everything else is identical, so any difference in retrieval, answers or cost comes from the text preprocessing. A Gradio app shows both answers side by side; an evaluation harness measures the difference on a frozen blind test set with human grading.

Tuwaiq Academy capstone, 2026. Team: Faisal Alghamdi, Ahmad Al Faida, Nasser Alkhaliwi.

**Headline (blind test, 2026-10-12/13):** on damaged Arabic PDF text, Mizan-lite retrieves the right passage more often (+0.116 hit@4 [+0.029, +0.217], n = 69) and cuts the index by about a third; on clean web text there is no difference; graded answer quality shows no loss on web text and no distinguishable difference on PDF text; the fine-tuned embedder did not help. Details, sample sizes and caveats: [Results](#7-results).

---

## Contents
1. [The problem](#1-the-problem) · 2. [What Mizan does](#2-what-mizan-does) · 3. [Architecture](#3-architecture) · 4. [Models and tools](#4-models-and-tools) · 5. [Data](#5-data) · 6. [Quick start](#6-quick-start) · 7. [Results](#7-results) · 8. [Reproducing the evaluation](#8-reproducing-the-evaluation) · 9. [Limitations](#9-limitations) · 10. [Safety](#10-safety-and-responsible-ai) · 11. [The interface](#11-the-interface) · 12. [Repository structure](#12-repository-structure) · 13. [Licence, data rights, AI assistance](#13-licence-data-rights-and-ai-assistance)

## 1. The problem

Official Arabic documents are usually PDFs, and PDF text extraction damages Arabic. In the eight Ministry of Tourism regulations used here the extracted text has kashida (tatweel) padding from justified lines (up to 13 % of the characters of one document), a lam-alef ligature extracted in reverse order (`ثلاثة` becomes `ثالثة`, 1,464 places), mixed digit systems and invisible marks. A RAG system embeds, searches and quotes this damaged text. The question: **does repairing it before indexing improve retrieval and answers, or only change cost?** The project does not train a tokenizer or a language model; Mizan is a preprocessing layer, tested under controlled conditions.

## 2. What Mizan does

| held constant (shared by both pipelines) | differs |
|---|---|
| documents, questions, chunker (600 characters, overlap 100, never crossing a page), embedder, reranker, top-k = 4, generator, prompt, temperature 0 | the text preprocessing applied to the documents **and** to the question before search |

| pipeline | preprocessing steps (`src/preprocessing.py`, each a named flag, deterministic) |
|---|---|
| **Standard** (`baseline`) | collapse whitespace |
| **Mizan-lite** (`mizan-lite+repair_lam_alef`) | collapse whitespace, remove invisible characters, Unicode NFKC, **lam-alef repair** (re-extracted from glyph geometry at ingestion), **kashida removal**, Persian/look-alike letter forms, digit forms |
| Mizan-full (`mizan+repair_lam_alef`, reference only) | Mizan-lite plus header/footer removal, line joining, diacritics removal, alef / alef-maqsura folding, punctuation |

Mizan-lite was fixed before the blind test: only extraction-repair steps, no spelling folds (development ablations showed the folds did not help and cost about 5 points on clean web text).

## 3. Architecture

```mermaid
flowchart TB
  classDef det fill:#e8f4ea,stroke:#2e7d32,color:#1b3d1f
  classDef model fill:#fdeee0,stroke:#c25e00,color:#4a2400
  classDef store fill:#e7eef8,stroke:#2f5f98,color:#13304f
  classDef ui fill:#f1ecf9,stroke:#6a4c9c,color:#2b1a47

  subgraph APP["Application · app.py"]
    B["Browser: Gradio interface · src/ui.py<br/>English/Arabic (src/i18n.py) · dark/light (src/ui_style.py)"]
    BE["Backend · src/backend.py (MizanBackend)<br/>session state, run numbers, upload, prepared questions"]
    B -- "ask · write insights · evaluate prepared · add PDF · translate" --> BE
    BE -- "plain dicts: results, Insights panel, upload report" --> B
  end

  subgraph IN["Ingestion · shared"]
    D["8 Ministry PDFs, or PDFs added in the app"] --> X["Text per page, file, title<br/>PyMuPDF · src/ingestion.py"]
    X --> U["Upload scan: personal data, instruction-like text<br/>src/safety.py"]
  end
  BE -- "add PDF" --> D

  X --> PA["Standard preprocessing<br/>whitespace only"]
  X --> PB["Mizan-lite preprocessing<br/>lam-alef repair, kashida, invisible marks, NFKC, digits"]
  PA --> CA["Chunking 600/100 chars"] --> EA["Embedding<br/>Qwen3-Embedding-0.6B"] --> VA[("Chroma index<br/>Standard")]
  PB --> CB["Chunking 600/100 chars"] --> EB["Embedding<br/>same model"] --> VB[("Chroma index<br/>Mizan-lite")]

  BE -- "question (+ optional evidence phrase)" --> CMP["comparison.compare: same question to both pipelines<br/>src/comparison.py · Pipeline.ask in src/rag.py"]
  CMP --> QA["Standard preprocessing"] --> VA
  CMP --> QB["Mizan-lite preprocessing"] --> VB
  VA --> RA["Top 20 candidates"] --> RR["Reranker Qwen3-Reranker-0.6B<br/>keeps top 4 · shared model"]
  VB --> RB["Top 20 candidates"] --> RR
  RR --> S["Safety filter: instruction-like passages withheld"]
  S --> G["Generator Qwen3-4B-Instruct (base model, local) · same prompt v1<br/>answer with [file, page] citations, or refusal"]
  G --> C["Citation check: cited page among passages shown<br/>src/citations.py"]
  C --> SC["Metrics for this question: evaluation.score<br/>(hit@k, rank) when gold evidence is known"]
  C --> M["Monitoring: log line per answer, alerts<br/>src/monitoring.py · logs/queries.jsonl"]
  SC --> BE

  subgraph INS["Mizan Insights"]
    EVD["insights_evidence.build_evidence<br/>numbered facts F1…Fn, what is not measured,<br/>allowed conclusions (compute_allowed)"]
    AGG["evaluate_prepared: retrieval-only aggregate<br/>on the prepared questions, paired bootstrap"]
    LLM["insights.generate_insights<br/>same local generator, JSON reply"]
    VAL["insights.validate: numbers, fact ids, direction,<br/>causal and wording checks; retries; partial accept"]
    AGG --> EVD
    EVD --> LLM --> VAL
  end
  BE -- "current run + documents + index fingerprints" --> EVD
  BE -- "button: evaluate prepared questions" --> AGG
  VAL -- "checked panel, or facts only on failure" --> BE

  subgraph EV["Evaluation · offline"]
    F["Frozen blind questions with gold evidence"] --> R["Both pipelines, same settings"] --> MET["hit@k, MRR, candidate recall, tokens, latency<br/>paired bootstrap · src/evaluation.py, src/stats.py"]
    R --> H["Blind human grading, 2 graders + adjudicator<br/>scripts/human_grading.py"]
  end

  class D,X,U,PA,PB,CA,CB,QA,QB,RA,RB,S,C,SC,M,F,R,MET,H,CMP,EVD,AGG,VAL det
  class EA,EB,RR,G,LLM model
  class VA,VB store
  class B,BE ui
```

A rendered copy: [docs/architecture_diagram.png](docs/architecture_diagram.png); the component, flowchart and sequence diagrams are also in the updated technical design deck, [docs/Mizan_Technical_Design_Final.pptx](docs/Mizan_Technical_Design_Final.pptx).

Purple: the application layer. Green: deterministic code, no model. Orange: model-based. Blue: vector indexes (one per pipeline, everything else shared). The embedding, reranker and generator models are loaded once and used by both pipelines; Mizan Insights calls the same generator. 

**Request flow for one question** (`src/rag.py`, `Pipeline.ask`):
1. The question is preprocessed with the pipeline's own steps (the same steps as its documents).
2. Chroma returns the 20 nearest chunks by cosine similarity; the reranker (if configured) keeps the best 4.
3. `safety.filter_passages` withholds any passage containing instruction-like text; the rest are shown to the generator with their file and page.
4. The generator answers in Arabic with `[file, page N]` citations, or with a fixed refusal sentence when the passages do not contain the answer.
5. Code checks every citation against the passages shown, and the monitor logs ids, token counts and latency (no answer or document text).
6. The backend (`src/backend.py`) turns both results into plain dicts (answer, cited pages marked as verified or not, the top-4 passages, tokens, latency, and hit@k and rank when gold evidence is known); the interface (`src/ui.py`) renders them side by side; Mizan Insights then explains the difference (below).

**Mizan Insights** (`src/insights_evidence.py`, `src/insights.py`, [docs/MIZAN_INSIGHTS.md](docs/MIZAN_INSIGHTS.md)): code computes numbered facts from the current run (retrieved pages, gold-evidence hits when known, refusals, citation validity, tokens, latency, settings) and decides which conclusions they allow (one question never names a general winner; an aggregate needs 20 answerable questions and an interval). The LLM writes the explanation; code rejects any statement that contradicts the facts, invents a number, claims significance or a cause, or recommends what the evidence does not support. If the model is unavailable or fails the checks, the panel shows the facts only.

Insights has two scopes, and the panel always says which one it is reporting. **One question** (after every Ask): a retrieval direction is allowed only when gold evidence is known (a prepared question, or an *evidence phrase* the user pastes from the answering page), and only for that question; a free question gets descriptions (pages, citations, tokens) and no winner. **Aggregate** (button *Evaluate the prepared questions*, `insights_evidence.evaluate_prepared`): both pipelines are scored with `evaluation.score` on the prepared questions over the documents loaded now; a direction is allowed only from 20 answerable questions with a paired-bootstrap interval that excludes zero, otherwise *similar* or *not enough evidence*. Insights never reads `EXPERIMENT_RESULTS.md` or the human grades: the blind-test results in section 7 are separate evidence.

| module | role |
|---|---|
| `src/ingestion.py`, `src/corpus.py`, `src/web_corpus.py`, `src/titles.py` | PDF and web-corpus loading, lam-alef repair, corpus fingerprint, regulation titles |
| `src/preprocessing.py` | all text steps as flags; the presets; the evaluation-only canonicalizer |
| `src/chunking.py`, `src/embeddings.py`, `src/retrieval.py`, `src/rerank.py` | chunking, embedder (optional LoRA adapter, offline hash fallback), Chroma search, reranker |
| `src/rag.py`, `src/local_llm.py` | pipeline, prompts, generator providers (`hf`, `ollama`, `anthropic`, `openai`, `mock`), answer cache |
| `src/safety.py`, `src/citations.py`, `src/monitoring.py` | injection and personal-data scan, citation check, logging and alerts |
| `src/evaluation.py`, `src/comparison.py`, `src/stats.py` | metrics, runs, paired bootstrap, Wilson intervals |
| `app.py`, `src/backend.py` | entry point; the application state and logic behind the interface (`MizanBackend`: ask, insights, prepared evaluation, upload, translation) |
| `src/ui.py`, `src/i18n.py`, `src/ui_style.py`, `src/ui_theme.py` | Gradio interface (shared with the Colab notebook), English and Arabic strings, dark and light design tokens; `ui_theme.py` styles the terminal demo report |
| `src/insights_evidence.py`, `src/insights.py` | Mizan Insights |

## 4. Models and tools

| component | used in the final evaluation | why |
|---|---|---|
| Text extraction | PyMuPDF | per-page text and glyph geometry (needed for the lam-alef repair) |
| Embedder | `Qwen/Qwen3-Embedding-0.6B` | strong multilingual retrieval at a size that fits an 8 GB GPU; `intfloat/multilingual-e5-small` and `Qwen3-Embedding-4B` as secondary stacks |
| Reranker | `Qwen/Qwen3-Reranker-0.6B`, top 20 to top 4 | recovers passages the first stage ranks low |
| Generator | `Qwen/Qwen3-4B-Instruct-2507`, 4-bit (`hf`), or `qwen3:4b-instruct-2507-q4_K_M` through Ollama | local, Arabic-capable, no API key |
| Vector store | Chroma, cosine, in memory (one collection per pipeline) | simple, no server |
| App | Gradio 6 | fast to build, works in Colab |
| LoRA adapter (experiment) | `finetune/train_lora.py` on 554 generated pairs | tested on the blind set and **not used**: not shown to help (P5) |

All models are open-weight and run locally (laptop RTX 3070 8 GB, or Colab T4/A100). No data leaves the machine unless you configure the `anthropic` or `openai` provider.

## 5. Data

| data | size | where |
|---|---|---|
| Ministry of Tourism regulations (8 PDFs) | 159 pages with text; 358 Standard / 323 Mizan-lite chunks | downloaded by `scripts/fetch_corpus.py` into `data/raw/` (git-ignored); URLs and sha256 in `data/corpus_manifest.json` |
| Web corpus: tourism.sa FAQ (256 Q&A), news, definitions, methodology cards; 6 laws (Bureau of Experts); 3 GASTAT methodology reports | 739 pages, 1,569 chunks | `scripts/fetch_web_corpus.py` into `data/web/` (git-ignored) |
| **Blind test set**, frozen 2026-10-12 | 266 questions: PDF 93 (69 answerable), web 173 (140 answerable); 57 unanswerable | `eval/questions_final_test_{pdf,web}.json`, hashes in `eval/blind_test/FROZEN.json` |
| Development sets (used to choose settings, so not used for final claims) | 250 FAQ, 77 PDF-FAQ, 51 generated, 10 hand-written | `eval/`, `data/web/` |
| Synthetic sample (4 invented PDFs, for tests and offline runs) | | `data/sample/` |

The blind questions were written by the three team members and sorted and formatted with an LLM; the evidence phrases were taken by script from the authors' supporting quotes and checked against the extracted text of every pipeline. Deviations from the pre-registered plan (266 questions instead of 45 to 60, no per-row author) are logged in [docs/EXPERIMENT_LOG.md](docs/EXPERIMENT_LOG.md).

## 6. Quick start

Python 3.11. Install PyTorch for your CUDA version from pytorch.org first (tested: 2.11.0+cu128).

```bash
pip install -r requirements.txt
```
```bash
cp .env.example .env
```
```bash
python scripts/fetch_corpus.py
```
```bash
python -m pytest tests
```
```bash
python app.py
```

`requirements.txt` has loose bounds; `requirements-tested.txt` the exact versions the results were produced with. The app opens at http://127.0.0.1:7860. Without `data/raw/` PDFs it falls back to the synthetic sample.

**Configuration** (`.env`, all keys documented in `.env.example`). The template defaults are small and offline-friendly (e5-small, `mock` generator, which only echoes a passage). The configuration evaluated on the blind set:

```
MIZAN_EMBEDDING_MODEL=Qwen/Qwen3-Embedding-0.6B
MIZAN_RERANKER=Qwen/Qwen3-Reranker-0.6B
MIZAN_LLM_PROVIDER=ollama                      # or hf (in-process, 4-bit)
MIZAN_LLM_MODEL=qwen3:4b-instruct-2507-q4_K_M  # for hf: Qwen/Qwen3-4B-Instruct-2507
MIZAN_EMBEDDING_ADAPTER=                       # empty: the LoRA adapter was not shown to help
MIZAN_CHUNK_TITLE=1                            # see the titles caveat in Results
MIZAN_PIPELINES=baseline,mizan-lite+repair_lam_alef
```

With Ollama: install it, run `ollama pull qwen3:4b-instruct-2507-q4_K_M`, and check `ollama ps` shows the model on the GPU. The first launch downloads the embedder and reranker from Hugging Face (about 2.5 GB).

**Offline smoke test** (no model downloads): `MIZAN_EMBEDDER=hash MIZAN_LLM_PROVIDER=mock python app.py` or `python demo.py` (terminal report and `results/demo.html`). Verified 2026-10-13: the app answers HTTP 200 after about 15 s.

**No GPU?** Open [`Mizan_Demo_Colab.ipynb`](Mizan_Demo_Colab.ipynb) in Google Colab (T4 or A100) and choose Run all. It gets this repository (set `REPO_URL`, or upload a zip made with `git archive --format=zip -o mizan_repo.zip HEAD`), installs it, downloads the PDFs, loads the evaluated configuration, checks both pipelines and Mizan Insights once, and launches the same app with a public link. Team members can upload `mizan_private_eval.zip` to get the prepared questions.

## 7. Results

All numbers below come from the files of the final run and the human grading, recomputed in [docs/BLIND_RESULTS_ANALYSIS.md](docs/BLIND_RESULTS_ANALYSIS.md); every number in the project with its source is in [EXPERIMENT_RESULTS.md](EXPERIMENT_RESULTS.md). The reading rules were committed before the blind set existed ([docs/ANALYSIS_PLAN.md](docs/ANALYSIS_PLAN.md)). Intervals are paired bootstrap 95 % over questions; one run, Colab A100, prompt v1.

### Retrieval (final stack: Qwen3-Embedding-0.6B + Qwen3-Reranker-0.6B, top 4)

| | PDF, 69 answerable | web, 140 answerable |
|---|---|---|
| hit@4 Standard → Mizan-lite, chunk titles off (P1 / P2 as pre-specified) | 0.681 → 0.797, **+0.116 [+0.029, +0.217]** | 0.729 → 0.736, +0.007 [+0.000, +0.021] |
| same, chunk titles on (the setting used for the answers) | 0.812 → 0.855, +0.043 [−0.043, +0.145] | 0.793 → 0.800, +0.007 [+0.000, +0.021] |
| gold passage among the 20 candidates, titles on | **+0.058 [+0.014, +0.116]** | +0.000 |
| secondary: e5-small, titles off | 0.391 → 0.652, **+0.261 [+0.145, +0.377]** | +0.007 [+0.000, +0.021] |
| secondary: Qwen3-Embedding-4B + reranker, titles off | 0.739 → 0.841, **+0.101 [+0.014, +0.188]** | +0.007 [−0.014, +0.029] |
| index size (embedding tokens) | 72,706 → 49,619 (−31.8 %) | 215,854 → 214,742 |

**Conflict, stated rather than resolved by choosing a number:** the PDF gain depends on whether the regulation title is embedded with each chunk. Without titles (the pre-specified P1) Mizan-lite is clearly ahead; with titles Standard closes most of the gap at top 4, and Mizan-lite's advantage remains only in the 20-candidate pool. Both are reported.

### Answers, human-graded (blind sheets, two graders, a third grader for every disagreement)

| | PDF | web |
|---|---|---|
| correct, answerable: Standard → Mizan-lite (n) | 0.754 → 0.768 (69) | 0.779 → 0.807 (140) |
| difference [95 % CI] | +0.014 [−0.101, +0.130] | +0.029 [−0.007, +0.071] |
| reading by the pre-registered rule (P3) | not distinguishable from zero; the lower bound misses −0.10, so **no "no loss" claim** | **no loss of answer quality** |
| correct refusal of unanswerable questions (P4) | 20/24 → **23/24** | 30/33 → 30/33 |
| answerable questions refused by the generator | 4/69 → 4/69 | 25/140 → 23/140 |

- **Grading:** graders worked alone on sheets with the two answers in random A/B order and no pipeline names (`eval/human_grading/RUBRIC.md`). Agreement on `correct`: Cohen's kappa 0.649 (PDF), 0.794 (web); on `supported` 0.608 and 0.507 (web below the 0.6 bar). On web, one grader was systematically lenient (19 of 20 disagreements in one direction). A third team member re-graded all 79 open cells on a re-blinded sheet (`scripts/prepare_adjudication.py`) and sided with the stricter grader in 16 of those 19.
- **Secondary, no decision rule:** when asked which answer is better, graders preferred Mizan-lite on PDF 26 times and Standard 10 times (56 ties).
- **Generator input:** mean 1,333 → 1,122 tokens per PDF question (−15.9 %; median 1,359 → 1,131); the LLM judge was not used for any claim (it rated 91 to 99 % of answers correct, [docs/JUDGE_DIAGNOSIS.md](docs/JUDGE_DIAGNOSIS.md)).

### LoRA adapter on the embedder (P5)

Matched comparison (same text, settings and questions): on the blind PDF set, adapter minus base **+0.014 [−0.072, +0.101]** (n = 69); on documents held out of training +0.062 (n = 16, too small to read). On development questions the same adapter gained +0.183, almost entirely on LLM-generated questions in the style of its training pairs. **Not shown to help; the recommended configuration uses the base embedder (`MIZAN_EMBEDDING_ADAPTER` empty).**

### What the evidence supports

- Arabic-aware repair helps retrieval on damaged PDF text, most with a small embedder and still with a 4B embedder; its effect is largest in the first retrieval stage. It is partly offset by adding titles to chunks.
- It does not change retrieval on clean web text.
- It reduces index and prompt size on PDFs.
- Answers are not shown to be better; on web they are shown not to be worse.

**Not supported:** that kashida removal *caused* the gain on any specific question (kashida is on almost every PDF page; development ablations point to it, the blind files show correlation only); any statement about other corpora or larger models.

## 8. Reproducing the evaluation

| step | command or file | output |
|---|---|---|
| check the frozen blind set | `python scripts/make_blind_test.py --verify` | "frozen blind set is unchanged" |
| final run (retrieval on three stacks, adaptation, answers, grading sheets) | `python scripts/build_final_notebook.py` (needs the team files), then `Mizan_Final_Colab.ipynb` in Colab, Run all | `mizan_final_results.zip` |
| merge human grading (with adjudication) | `python scripts/human_grading.py merge <grading dir> --grader1 g1.csv --grader2 g2.csv --adjudicated adjudication/p3_adjudication_output.csv --adjudication-key adjudication/p3_adjudication_key.csv` | `human_grading_report.md` |
| per-question analysis | `python scripts/analyse_blind_run.py <out dir>` (reads `results/final_blind/`) | `analysis.json` |
| development runs and ablations | `python -m src.evaluation --pipelines baseline,mizan-lite+repair_lam_alef`, `python scripts/run_ablations.py`, `Mizan_Web_Evaluation_Colab.ipynb` | `results/eval-*.json` |

Raw result files are in `results/` (git-ignored; the final run is in `results/final_blind/` on the team's machine and in `mizan_final_results.zip`). The question files, the blind set and the adjudication sheets quote the source documents, so they are **not in the public repository**: the team keeps them (`mizan_private_eval.zip`, unzip into the repository root). The adjudication key, its instructions and the frozen hashes (`eval/blind_test/FROZEN.json`) are public.

## 9. Limitations

1. **One corpus, one run.** Eight regulations from one ministry; one generator seed; questions treated as independent (many share a page), so intervals are optimistic.
2. **Team-written test set,** formatted with an LLM; graders and adjudicator were team members; blinding by shuffling only (answer style can hint at the pipeline).
3. **Configuration sensitivity:** the PDF retrieval gain shrinks when titles are embedded (see Results).
4. **Chunking is by characters after preprocessing,** so Mizan-lite text yields fewer, different chunks; part of the token saving is chunk count.
5. **The generator refuses about 1 in 6 answerable web questions** in both pipelines.
6. **Gold evidence lists are incomplete:** some answers are correct from a page the gold list does not name (hit@4 understates both pipelines).
7. **No lexical (BM25) baseline,** no OCR for scanned PDFs, no repair for displaced digits.
8. **The citation check reads file names only** (`src/citations.py`): a marker that names the regulation by its title, which the generator sometimes writes when chunk titles are on, counts as not among the shown passages even when that page was shown. Both pipelines are scored by the same rule, so the comparison is fair, but the absolute citation rates understate valid citations (seen in a live run on 2026-10-15: `[لائحة الإرشاد السياحي، صفحة 8]` with page 8 of the Tour Guide Regulations retrieved).
9. **Mizan Insights** checks generated text by rules, not by people; a wrong sentence can pass ([docs/MIZAN_INSIGHTS.md](docs/MIZAN_INSIGHTS.md), section 13); its checks read English only.

## 10. Safety and responsible AI

- **Prompt injection:** retrieved passages and uploaded PDFs are scanned for instruction-like text (Arabic and English); flagged passages are withheld from the generator. Held-out catch rate 84 to 93 %; out-of-scope attacks are a stated gap ([docs/RESPONSIBLE_AI.md](docs/RESPONSIBLE_AI.md)).
- **Personal data:** e-mail, Saudi mobile, ID and IBAN patterns are counted in uploads and masked before anything reaches the Insights model.
- **Grounding:** answers must cite `[file, page]`; citations are checked against the passages shown; the generator refuses when the passages do not contain the answer.
- **Monitoring:** `logs/queries.jsonl` holds ids, token counts and latency, never answer or document text; rule-based alerts for errors, refusals, latency and missing citations.
- **Scope:** not legal advice; answers can be wrong and must be checked against the cited regulation.

## 11. The interface

One screen, in the order of the workflow: **1 Question** (type one or pick a prepared example; optionally paste an evidence phrase) → **2 Answers and retrieved evidence** (the two pipelines side by side, citations marked as the code verified them, the top-4 passages with the page that holds the reference evidence) → **3 Measured comparison** (what was measured on this question, and a table of tokens and latency) → **4 Mizan Insights** → experiment details and monitoring. Controls at the top switch the language (English / العربية, full right-to-left layout) and the appearance (dark / light); both are remembered in the browser and switching keeps the question and results without calling a model. In English mode, Arabic answers can be translated on request as a labelled reading aid that is not part of the comparison. The brand mark in the top corner (a balance scale on a green tile) comes from the team's alternative interface.

| what | where |
|---|---|
| entry point | `app.py` (loads documents, builds both pipelines, calls `build_ui(...).launch(...)`) |
| interface | `src/ui.py` (layout, events, pure render functions: result dict + language → HTML), `src/i18n.py` (every string in English and Arabic), `src/ui_style.py` (design tokens, Gradio theme, CSS) |
| application logic | `src/backend.py` (`MizanBackend`: ask, write and regenerate insights, evaluate the prepared questions, upload, translate; run numbers drop late results) |
| Insights panel | rendered by `render_insights` in `src/ui.py` from the backend's panel dict |
| launch | `python app.py`, http://127.0.0.1:7860; offline: `MIZAN_EMBEDDER=hash MIZAN_LLM_PROVIDER=mock python app.py` |
| tests to run after a change | `python -m pytest tests/test_ui_i18n.py tests/test_insights_session.py tests/test_ui_event_order.py tests/test_colab.py tests/test_notebook_modules.py` (then the full suite) |
| Colab | `Mizan_Demo_Colab.ipynb` clones the repository and runs `src/ui.py` itself, so a UI change needs no notebook change. It is built by `scripts/build_demo_notebook.py` |

Dependencies: `requirements.txt` (Gradio 6). Data: `data/raw/` after `scripts/fetch_corpus.py`, or the synthetic sample automatically. Models: none needed for UI work (use the offline command); a real generator is needed to see Insights text.

## 12. Repository structure

```
app.py, demo.py               app and scripted demo
src/                          pipeline, evaluation, safety, monitoring, backend, interface, Mizan Insights
scripts/                      corpus fetch, question building, blind-set tools, grading, analysis, notebook builders
finetune/                     LoRA training of the embedder (outputs git-ignored)
eval/                         question sets, frozen blind set, grading rubric, safety test sets
adjudication/                 P3 adjudication sheet, key, output and instructions
tests/                        offline tests on synthetic data (a few need the team files and skip without them)
tools/                        offline HTML forms: blind-question writing, grading
data/                         corpus manifest, synthetic sample (real corpora are downloaded, git-ignored)
docs/                         analysis plan, experiment log, blind-results analysis, architecture, Insights, responsible AI, data audit, technical design deck
Mizan_Demo_Colab.ipynb        Colab demo: clones the repository, launches the app with every feature (older evaluation notebooks embed the team files and are generated locally)
EXPERIMENT_RESULTS.md         every measured number with its source
```

Older planning and status documents (`FINAL_AUDIT.md`, `FINAL_CHECKLIST.md`, `TEAM_HANDOFF.md`, `MIZAN_PIPELINE.md`, `docs/SUBMISSION2_BRIEFING.md`) record the project's history; where they disagree with this README or `EXPERIMENT_RESULTS.md`, the latter are current.

## 13. Licence, data rights and AI assistance

- **Licence:** code and documentation under the [MIT licence](LICENSE). It does not cover the source documents or the model weights.
- **Data:** the Ministry PDFs and the web corpus are **not** redistributed; scripts download them from their public sources. The tourism.sa terms require the Ministry's written permission to copy content into other systems; the team requested it and it was approved. Files that quote the documents (question sets, the blind set, grading sheets) are still kept out of the public repository ([docs/PUBLIC_RELEASE_AUDIT.md](docs/PUBLIC_RELEASE_AUDIT.md)). GASTAT reports: attribution to the General Authority for Statistics. Models: see each model card (Qwen3: Apache-2.0; e5: MIT).
- **AI assistance:** large parts of the code, tests and documents were written with Claude (Anthropic) through Claude Code, from the team's instructions; the team made the design decisions, wrote the blind questions, ran the Colab experiments and did the grading. The 51 development questions and the LoRA training pairs were generated by Qwen3-4B.
