"""Arabic display titles of the regulations, used to give every chunk its document context.

Chunks are embedded as bare text, so near-identical clauses in different regulations (license term,
renewal period, fees) look the same to any embedding model. With MIZAN_CHUNK_TITLE=1 each chunk is
embedded as "<regulation title>\n<chunk text>". The mapping is by filename; unknown files fall back to
the filename stem. This is a prototype shortcut: a real system would read titles from the PDF itself.
"""

TOPICS = [  # order matters: most specific filename first
    ("Management-of-Hospitality-Facilities-Regulations-service-directory", "دليل خدمات لائحة إدارة مرافق الضيافة السياحية"),
    ("Travel-and-Tourism-Services-Regulations-service-directory", "دليل خدمات لائحة خدمات السفر والسياحة"),
    ("Management-of-Hospitality-Facilities", "لائحة إدارة مرافق الضيافة السياحية"),
    ("Hospitality-Facilities", "لائحة مرافق الضيافة السياحية"),
    ("Travel-and-Tourism-Services", "لائحة خدمات السفر والسياحة"),
    ("Tourism-Consultation", "لائحة الاستشارات السياحية"),
    ("Tour-Guide", "لائحة الإرشاد السياحي"),
    ("Tourist-Visa", "لائحة تأشيرة الزيارة لغرض السياحة"),
]


def topic_of(doc: str) -> str:
    return next((t for key, t in TOPICS if key in doc), doc.rsplit(".", 1)[0])
