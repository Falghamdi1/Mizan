"""Evaluation framework. Measures only what can be measured reliably; everything else is None.

Question file schema (eval/questions*.json):
  {"id", "type", "question",
   "gold_evidence": [["phrase", "alt phrase"], ["second required fact"]],   # [] for unanswerable questions
   "gold_docs": ["file.pdf"],                                                # optional: restrict relevance to these files
   "answer_keywords": ["word", ["alt a", "alt b"], ...],                     # optional; a list = any of the alternatives
   "reference_answer": "..."}                                                # optional, used only by --judge

Retrieval metrics (need gold_evidence). A retrieved chunk is "relevant" if, after the FIXED
pipeline-independent canonicalizer (preprocessing.canonical_for_eval), it contains any gold phrase.
  hit@k      1 if at least one evidence group is found in the top-k chunks
  coverage   fraction of evidence groups found in the top-k chunks (matters for multi-section questions)
  MRR        1/rank of first relevant chunk (0 if none)
  precision  fraction of the top-k chunks that are relevant
Known weakness: a gold phrase split across two chunks, or broken by a PDF line/hyphen artifact,
counts as a miss for that chunk. Choose short gold phrases.

Answer metrics:
  keyword_coverage  fraction of answer_keywords present in the answer (surface check, not correctness)
  abstained         answer says the context lacks the information (substring check)
  judge_*           optional LLM-as-judge (--judge) by MIZAN_JUDGE_PROVIDER/MODEL (should differ from the generator). Unvalidated until hand-checked.
Efficiency: retrieved tokens (embedding tokenizer), LLM input/output tokens (API usage; None for mock),
retrieval / LLM / total latency (wall clock, single run -> noisy).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import statistics
from datetime import datetime
from pathlib import Path

from . import citations
from .config import CORPUS, DEMO_PIPELINES, RESULTS_DIR, SETTINGS, resolve_data_dir, resolve_questions_path
from .corpus import corpus_fingerprint, load_corpus
from .preprocessing import canonical_for_eval, get_config
from .rag import LLMError, Pipeline, RAGResult, build_pipelines, call_llm

ABSTAIN_MARKER = canonical_for_eval("لا يحتوي السياق المتاح على إجابة")


def load_questions(path=None, missing_ok: bool = False) -> list[dict]:
    """The question file. The team's question files quote the documents and are not in the public repository (README, section 13):
    the app passes missing_ok=True and runs without prepared questions; an evaluation stops with this message instead."""
    path = Path(path or resolve_questions_path()[0])
    if not path.exists():
        if missing_ok:
            print(f"note: {path.name} is not here (the team's question files are not in the public repository); no prepared questions.")
            return []
        raise FileNotFoundError(f"{path} is missing. The team's question files are kept out of the public repository: unzip "
                                "mizan_private_eval.zip into the repository root, write your own (schema in this module), or remove the PDFs "
                                "from data/raw to use the synthetic sample.")
    return json.loads(path.read_text(encoding="utf-8"))


def score(q: dict, r: RAGResult) -> dict:
    """Per-question measured values for one pipeline. None = not measurable for this question."""
    k = len(r.passages)
    groups = q.get("gold_evidence") or []
    gold_docs = q.get("gold_docs")  # optional: exact filenames; a chunk from another file is never relevant
    out: dict = {"hit": None, "coverage": None, "mrr": None, "precision": None, "first_relevant_rank": None,
                 "candidate_recall": None, "first_stage_hit": None,
                 "n_cited": None, "citation_present": None, "citation_valid_share": None, "invalid_citation": None, "cites_gold": None}
    rel = None
    if groups:
        canon_groups = [[canonical_for_eval(ph) for ph in g] for g in groups]

        def canon(p):  # canonical text of an allowed passage, or None if it comes from a document that cannot be relevant
            return canonical_for_eval(p.text) if (not gold_docs or p.doc in gold_docs) else None

        def hits(plist) -> tuple[list[bool], list[bool]]:
            """(per passage: contains any gold phrase, per evidence group: found in any passage)"""
            cs = [canon(p) for p in plist]
            rel = [c is not None and any(ph and ph in c for g in canon_groups for ph in g) for c in cs]
            found = [any(ph and ph in c for c in cs if c is not None for ph in g) for g in canon_groups]
            return rel, found

        rel, found = hits(r.passages)
        first = next((i for i, x in enumerate(rel, start=1) if x), None)
        out.update(hit=int(any(found)), coverage=sum(found) / len(found), mrr=(1 / first) if first else 0.0,
                   precision=sum(rel) / k if k else 0.0, first_relevant_rank=first)
        # two-stage diagnostics: is the gold passage among the reranker's candidates, and where did stage 1 put it?
        cands = r.meta.get("candidates") or r.passages
        out["candidate_recall"] = int(any(hits(cands)[1]))
        out["first_stage_hit"] = int(any(hits(sorted(cands, key=lambda p: p.first_stage_rank or p.rank)[:k])[1]))
    ans = canonical_for_eval(r.answer)
    kws = [[canonical_for_eval(a) for a in ([w] if isinstance(w, str) else w)] for w in q.get("answer_keywords") or []]
    out["keyword_coverage"] = (sum(any(a in ans for a in alts) for alts in kws) / len(kws)) if kws else None
    out["abstained"] = ABSTAIN_MARKER in ans
    if (r.answer or "").strip() and not out["abstained"]:
        # Citation check (src/citations.py): no LLM, no judge. Only for answers that assert something (a refusal cites nothing).
        shown = r.meta.get("shown", r.passages)                             # what the model was shown (withheld passages excluded)
        c = citations.check(r.answer, shown)
        out.update(n_cited=c["n_cited"], citation_present=int(c["n_cited"] > 0), invalid_citation=int(c["n_invalid"] > 0),
                   citation_valid_share=(c["n_valid"] / c["n_cited"]) if c["n_cited"] else None)
        if rel is not None:  # answerable question: does a valid citation point at a passage that holds the gold evidence?
            relevant = {id(p) for p, flag in zip(r.passages, rel) if flag}
            out["cites_gold"] = int(any(id(shown[i]) in relevant for i in c["matched"]))
    out["answerable"] = bool(groups)
    out["retrieved_tokens"] = r.retrieved_tokens
    out["input_tokens"] = r.llm.input_tokens
    out["output_tokens"] = r.llm.output_tokens
    out["possibly_truncated"] = (r.llm.output_tokens or 0) >= SETTINGS.llm_max_tokens  # answer may be cut off
    out["retrieval_latency_s"] = r.retrieval_latency_s
    out["llm_latency_s"] = r.llm.latency_s
    out["total_latency_s"] = r.total_latency_s
    out["llm_cached"] = r.llm.cached  # cached answers keep the tokens/latency measured when first generated
    return out


JUDGE_SYSTEM = (
    "You grade a RAG answer. Reply with JSON only: {\"correct\": 0|1, \"faithful\": 0|1}. "
    "correct=1 if the answer agrees with the reference answer on the key facts. "
    "faithful=1 if every claim in the answer is supported by the given context."
)


def judge_config() -> dict:
    """Which model grades. Independent = a different model than the generator (avoids self-preference bias)."""
    provider = SETTINGS.judge_provider or SETTINGS.llm_provider
    model = SETTINGS.judge_model or SETTINGS.llm_model
    return {"provider": provider, "model": model,
            "independent": (provider, model) != (SETTINGS.llm_provider, SETTINGS.llm_model)}


JUDGE_SYSTEM_V2 = (
    "You check a RAG answer against a reference answer. Be strict: when unsure, the fact is NOT in the answer. "
    "Reply with JSON only: {\"facts\": [{\"fact\": \"<one key fact of the reference answer: a number, name, period or decision>\", "
    "\"answer_quote\": \"<the exact words copied from the model answer that state this same fact with the same value, or empty>\"}], "
    "\"contradicts\": 0|1, \"support_quote\": \"<the exact words copied from the context that support the main claim of the model answer, or empty>\"}. "
    "A different value, a different person or body (a Minister is not a Ministry), or a related but different fact does NOT count. "
    "contradicts=1 if the model answer states something that conflicts with the reference answer. Copy quotes exactly; never invent them."
)


def _numbers(text: str) -> set[str]:
    return set(re.findall(r"\d+", canonical_for_eval(text or "")))


def judge_v2(q: dict, r: RAGResult, jc: dict) -> dict:
    """Stricter judge whose claims are checked by code: a fact counts only when the quote the judge gives is really in the answer,
    and the answer counts as supported only when the support quote is really in the context. A judge that says yes without evidence scores 0.
    Still unvalidated until scripts/human_grading.py merge compares it with two human graders."""
    ctx = "\n\n".join(p.text for p in r.passages)
    prompt = (f"Question: {q['question']}\nReference answer: {q['reference_answer']}\n"
              f"Context:\n{ctx}\n\nModel answer: {r.answer}\n\nJSON:")
    try:
        txt = call_llm(prompt, r.passages, system=JUDGE_SYSTEM_V2, provider=jc["provider"], model=jc["model"]).text
        d = json.loads(txt[txt.index("{"): txt.rindex("}") + 1])
        facts = [f for f in (d.get("facts") or []) if isinstance(f, dict)]
    except LLMError:
        raise
    except Exception:
        return {"judge_correct": None, "judge_faithful": None, "judge_failed": True}
    ans, cx = canonical_for_eval(r.answer), canonical_for_eval(ctx)

    def quote_in(quote, text: str) -> bool:
        c = canonical_for_eval(str(quote or ""))
        return len(c) >= 3 and c in text

    verified = [f for f in facts if quote_in(f.get("answer_quote"), ans)]
    no_contradiction = not int(d.get("contradicts") or 0)
    numbers_ok = _numbers(q["reference_answer"]) <= _numbers(r.answer)               # every number of the reference is in the answer
    correct = bool(facts) and len(verified) == len(facts) and no_contradiction and numbers_ok
    faithful = quote_in(d.get("support_quote"), cx) and no_contradiction
    return {"judge_correct": int(correct), "judge_faithful": int(faithful)}


def judge(q: dict, r: RAGResult) -> dict:
    jc = judge_config()
    if jc["provider"] == "mock" or not q.get("reference_answer"):
        return {"judge_correct": None, "judge_faithful": None}
    if ABSTAIN_MARKER in canonical_for_eval(r.answer):
        # Refusals are graded by rule, not by the LLM (a 4B judge marked a wrong refusal "correct"):
        # refusing an answerable question is incorrect; refusing an unanswerable one is correct.
        # A refusal asserts nothing, so it is trivially faithful.
        return {"judge_correct": 0 if q.get("gold_evidence") else 1, "judge_faithful": 1}
    if os.getenv("MIZAN_JUDGE_PROMPT", "v1") == "v2":
        return judge_v2(q, r, jc)
    ctx = "\n\n".join(p.text for p in r.passages)
    prompt = (f"Question: {q['question']}\nReference answer: {q['reference_answer']}\n"
              f"Context:\n{ctx}\n\nModel answer: {r.answer}\n\nJSON:")
    try:
        txt = call_llm(prompt, r.passages, system=JUDGE_SYSTEM, provider=jc["provider"], model=jc["model"]).text
        d = json.loads(txt[txt.index("{"): txt.rindex("}") + 1])
        return {"judge_correct": int(d["correct"]), "judge_faithful": int(d["faithful"])}
    except LLMError:
        raise  # judge unreachable: stop, do not silently average over nothing
    except Exception:
        return {"judge_correct": None, "judge_faithful": None, "judge_failed": True}  # unparsable verdict, counted in the report


def _mean(xs):
    xs = [x for x in xs if x is not None]
    return statistics.fmean(xs) if xs else None


METRICS = ["hit", "first_stage_hit", "candidate_recall", "coverage", "mrr", "precision", "keyword_coverage", "retrieved_tokens", "input_tokens",
           "output_tokens", "retrieval_latency_s", "llm_latency_s", "total_latency_s",
           "judge_correct", "judge_faithful", "citation_present", "citation_valid_share", "invalid_citation"]


def aggregate(per_question: list[dict]) -> dict:
    agg = {m: _mean([row.get(m) for row in per_question]) for m in METRICS}
    for m in METRICS:  # latency: median, because one cold model load (~30 s) would dominate a mean of 10 calls
        if m.endswith("_latency_s"):
            vals = [row[m] for row in per_question if row.get(m) is not None]
            agg[m] = statistics.median(vals) if vals else None
    ans_rows = [r for r in per_question if r["answerable"]]
    unans_rows = [r for r in per_question if not r["answerable"]]
    agg["answers_from_cache"] = sum(bool(r.get("llm_cached")) for r in per_question)
    agg["judge_failed"] = sum(bool(r.get("judge_failed")) for r in per_question)
    agg["possibly_truncated"] = sum(bool(r.get("possibly_truncated")) for r in per_question)
    ans_cited = [r for r in ans_rows if r.get("cites_gold") is not None]          # answerable, not refused, has an answer text
    agg["cites_gold"] = _mean([r["cites_gold"] for r in ans_cited])
    agg["cites_gold_given_hit"] = _mean([r["cites_gold"] for r in ans_cited if r.get("hit")])   # right passage retrieved: did the answer cite it?
    agg["n_answers_checked_for_citation"] = sum(r.get("citation_present") is not None for r in per_question)
    agg["n_questions"] = len(per_question)
    agg["n_answerable"] = len(ans_rows)
    agg["false_abstain_rate"] = _mean([int(r["abstained"]) for r in ans_rows if r["abstained"] is not None])
    agg["correct_abstain_rate"] = _mean([int(r["abstained"]) for r in unans_rows if r["abstained"] is not None])
    return agg


def retrieval_only_result(p: Pipeline, name: str, question: str) -> RAGResult:
    """Retrieval (and reranking) without the generator: a RAGResult with an empty answer, enough for the retrieval metrics of `score`."""
    from .rag import LLMResult

    pq, passages, t_ret, cands = p.retrieve(question)
    return RAGResult(name, question, pq, passages, "", t_ret, LLMResult("", None, None, 0.0), sum(x.tokens for x in passages), meta={"candidates": cands})


def run_eval(names: list[str], judge_answers: bool = False, pipelines: dict[str, Pipeline] | None = None,
             questions_path=None, retrieve_only: bool = False, save: bool = True) -> dict:
    """Run every question through every pipeline.
    pipelines   already built pipelines (the notebook builds them once); default: build from the data folder
    questions_path  question file; default: the file chosen by resolve_questions_path()
    retrieve_only  skip the LLM: retrieval metrics only (answer, token and LLM-latency fields stay None)"""

    data_dir, synthetic = resolve_data_dir()
    synthetic = synthetic and CORPUS == "pdf"  # the web corpus has no synthetic sample
    q_path, q_sample = (Path(questions_path), False) if questions_path else resolve_questions_path()
    print(f"Data: {data_dir} {'(SYNTHETIC SAMPLE)' if synthetic else ''}"); print(f"Questions: {q_path.name}")
    if pipelines is None:
        pipelines = build_pipelines(load_corpus(data_dir), names)
    questions = load_questions(q_path)
    rows: dict[str, list[dict]] = {n: [] for n in names}
    answered: list[tuple[dict, RAGResult, dict]] = []  # (question, result, its row), for the judging pass
    for i, q in enumerate(questions, start=1):
        for n in names:
            p = pipelines[n]
            if retrieve_only:
                r = retrieval_only_result(p, n, q["question"])
            else:
                r = p.ask(q["question"])
            s = score(q, r)
            if retrieve_only:
                s.update(llm_latency_s=None, total_latency_s=None, keyword_coverage=None, abstained=None)
            s.update(id=q["id"], type=q.get("type"), question=q["question"], answer=r.answer,
                     retrieved=[{"rank": x.rank, "doc": x.doc, "page": x.page, "score": round(x.score, 4)}
                                for x in r.passages])
            rows[n].append(s)
            answered.append((q, r, s))
        if i % 10 == 0 or i == len(questions):
            print(f"  {i}/{len(questions)} questions done", flush=True)
    if judge_answers and not retrieve_only:
        # Judging is a second pass AFTER every answer exists. With a local judge model this means the generator is
        # unloaded once and the judge loaded once, instead of swapping them for every answer (and never both in memory).
        jc = judge_config()
        print(f"  judging {len(answered)} answers with {jc['provider']}:{jc['model']}"
              + ("" if jc["independent"] else " (SAME model as the generator: self-preference bias)"), flush=True)
        for q, r, s in answered:
            s.update(judge(q, r))
        from . import memory

        memory.free()  # return the judge's working memory before the next stage
    result = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "run": {"corpus_sha256": corpus_fingerprint(data_dir), "questions_file": str(q_path.name),
                "questions_sha256": hashlib.sha256(q_path.read_bytes()).hexdigest(), "versions": _versions()},
        "synthetic_data": synthetic, "synthetic_questions": q_sample,
        "settings": SETTINGS.as_dict(),
        "judge": judge_config() if judge_answers else None,
        "pipelines": {n: {"preprocessing": get_config(n).enabled(), "index": pipelines[n].index_stats,
                          "aggregate": aggregate(rows[n]), "per_question": rows[n]} for n in names},
    }
    if save:
        RESULTS_DIR.mkdir(exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        (RESULTS_DIR / f"eval-{stamp}.json").write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding="utf-8")
    return result


def _versions() -> dict:
    from importlib import metadata
    import platform

    v = {"python": platform.python_version()}
    for pkg in ("torch", "transformers", "sentence-transformers", "chromadb", "pymupdf", "peft"):
        try:
            v[pkg] = metadata.version(pkg)
        except metadata.PackageNotFoundError:
            pass
    return v


def fmt(v, digits=3):
    return "n/a" if v is None else (f"{v:.{digits}f}" if isinstance(v, float) else str(v))


def render_markdown(result: dict) -> str:
    names = list(result["pipelines"])
    lines = ["# Evaluation result", ""]
    if result["synthetic_data"] or result["synthetic_questions"]:
        lines += ["> **SYNTHETIC SAMPLE DATA/QUESTIONS.** This run validates the machinery only. "
                  "It says nothing about real Saudi tourism documents.", ""]
    s = result["settings"]
    lines += [f"Shared settings: embedder `{s['embedding_model'] if s['embedder'] == 'st' else 'hash (offline fallback)'}`, "
              f"chunk {s['chunk_size']}/{s['chunk_overlap']} chars, top-k {s['top_k']}, "
              f"LLM `{s['llm_provider']}:{s['llm_model']}`.", ""]
    jd = result.get("judge")
    if jd:
        lines += [f"Judge: `{jd['provider']}:{jd['model']}` "
                  + ("(independent of the generator)." if jd["independent"] else
                     "(**same model as the generator: self-preference bias possible**)."), ""]
    n0 = result["pipelines"][names[0]]["aggregate"]
    lines += [f"{n0['n_questions']} questions ({n0['n_answerable']} answerable). Single run, tiny sample: "
              "differences below are observations, not statistically supported conclusions.", ""]
    if s["llm_provider"] == "mock":
        lines += ["> Mock LLM: answer-based rows (keyword coverage, judge, abstain rates, LLM tokens/latency) are NOT meaningful. "
                  "Retrieval rows and retrieved-token rows are real.", ""]
    lines += ["| Metric | " + " | ".join(names) + " |", "|---|" + "---|" * len(names)]
    rows = [("Hit@k", "hit"), ("Hit@k before reranking (stage 1)", "first_stage_hit"), ("Gold in candidates (recall@N)", "candidate_recall"), ("Evidence coverage", "coverage"), ("MRR", "mrr"), ("Precision@k", "precision"),
            ("Answer keyword coverage", "keyword_coverage"), ("Judge: correct (unvalidated)", "judge_correct"),
            ("Judge: faithful (unvalidated)", "judge_faithful"), ("Retrieved tokens / query", "retrieved_tokens"),
            ("LLM input tokens / query", "input_tokens"), ("Retrieval latency s (median)", "retrieval_latency_s"),
            ("LLM latency s (median)", "llm_latency_s"), ("False abstain rate", "false_abstain_rate"),
            ("Correct abstain rate", "correct_abstain_rate"),
            ("Answers with a citation (non-refusals)", "citation_present"), ("Citations naming a retrieved page (mean share)", "citation_valid_share"),
            ("Answers citing a page that was not retrieved", "invalid_citation"), ("Answers citing the passage with the gold evidence", "cites_gold"),
            ("... of those where the gold passage was retrieved", "cites_gold_given_hit")]
    rows += [("Answers served from cache (tokens/latency from first run)", "answers_from_cache"),
             ("Judge verdicts that could not be parsed", "judge_failed"),
             ("Answers that may be cut off at the token limit", "possibly_truncated")]
    for label, key in rows:
        lines.append(f"| {label} | " + " | ".join(fmt(result["pipelines"][n]["aggregate"].get(key)) for n in names) + " |")
    run = result.get("run") or {}
    if run:
        lines += ["", f"Corpus sha256 `{run['corpus_sha256'][:12]}`, questions `{run['questions_file']}` "
                      f"(sha256 `{run['questions_sha256'][:12]}`). Retrieval is deterministic; LLM output is cached per prompt."]
    lines += ["", "Index (whole corpus):", "", "| | " + " | ".join(names) + " |", "|---|" + "---|" * len(names)]
    for label, key in [("chunks", "chunks"), ("characters", "chars"), ("tokens", "tokens")]:
        lines.append(f"| {label} | " + " | ".join(fmt(result["pipelines"][n]["index"][key]) for n in names) + " |")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser(description="Run the evaluation set through one or more pipelines.")
    ap.add_argument("--pipelines", default=",".join(DEMO_PIPELINES),
                    help="comma list: baseline, mizan, mizan+<flag>, mizan-no-<flag>, baseline+<flag>  (ablations); "
                         "default = MIZAN_PIPELINES (baseline,mizan-lite+repair_lam_alef)")
    ap.add_argument("--judge", action="store_true", help="add unvalidated LLM-as-judge scores (needs a real LLM)")
    args = ap.parse_args()
    try:
        res = run_eval([x.strip() for x in args.pipelines.split(",")], judge_answers=args.judge)
    except (LLMError, FileNotFoundError, RuntimeError, ValueError) as e:
        raise SystemExit(f"ERROR: {e}")
    md = render_markdown(res)
    RESULTS_DIR.joinpath("latest.md").write_text(md, encoding="utf-8")
    print("\n" + md)


if __name__ == "__main__":
    main()
