"""The Gradio interface, used by `python app.py` and by the Colab demo notebook: one screen, English or Arabic, dark or light.

    build_ui(pages, pipes, questions, synthetic, data_dir).launch(**launch_kwargs())

How it is put together
- src/backend.py runs everything (pipelines, citations, uploads, Mizan Insights) and returns plain, language-free dicts.
- The render_* functions below turn those dicts into HTML for one language. They are pure: switching the language re-renders the
  session's stored results; no model is called, nothing is re-indexed, and no answer, passage or measured value changes.
- The appearance switch never reaches the server: it toggles Gradio's own `.dark` class in the browser (src/ui_style.py holds the
  tokens for both). Both preferences are kept in the browser's localStorage and restored on the next visit.
"""
from __future__ import annotations

import html
import re
from pathlib import Path

from .backend import PREPARED, MizanBackend, add_pdfs, ingest_pdfs  # noqa: F401 - add_pdfs/ingest_pdfs re-exported for notebooks and tests
from .config import RAW_DIR
from .i18n import t
from .ui_style import CSS, gradio_theme

# The brand mark from the team's alternative interface (Nasser's release, 2026-10-14): a balance scale drawn in white on a
# rounded green tile. Paths, viewBox and stroke are his; only the class names are ours.
BRAND_MARK = ('<span class="mark" aria-hidden="true"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" '
              'stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v18M7 21h10M4 7h16"/>'
              '<path d="m4 7-3 7a4 3 0 0 0 6 0Z"/><path d="m20 7-3 7a4 3 0 0 0 6 0Z"/><circle cx="12" cy="5" r="1.4"/></svg></span>')
INFO_SVG = ('<svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="6.6" fill="none" stroke="currentColor" stroke-width="1.4"/>'
            '<rect x="7.3" y="7" width="1.4" height="4.6" rx=".7" fill="currentColor"/><circle cx="8" cy="4.9" r=".9" fill="currentColor"/></svg>')
ARABIC = re.compile(r"[؀-ۿ]")
# A citation as the prompt asks for it: [file name، صفحة N] (an ASCII comma and "ص" are accepted too).
CITE = re.compile(r"\[([^\[\]\n]{3,160}?)\s*[،,]\s*(صفحة|ص\.?|page|p\.)\s*(\d{1,4})\s*\]")

HEAD_JS = """<script>
(function () {
  var S = { get: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
            set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} } };
  var light = window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches;
  var nav = (navigator.language || '').toLowerCase();
  var M = window.mizan = { theme: S.get('mizan.theme') || (light ? 'light' : 'dark'), lang: S.get('mizan.lang') || (nav.indexOf('ar') === 0 ? 'ar' : 'en') };
  function body(f) { if (document.body) f(); else document.addEventListener('DOMContentLoaded', f); }
  M.applyTheme = function (th) {
    M.theme = th === 'light' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', M.theme);
    body(function () { document.body.classList.toggle('dark', M.theme === 'dark'); });
  };
  M.applyLang = function (l) {
    M.lang = l === 'ar' ? 'ar' : 'en';
    var r = document.documentElement, d = M.lang === 'ar' ? 'rtl' : 'ltr';
    r.setAttribute('lang', M.lang); r.setAttribute('dir', d);
    body(function () { document.querySelectorAll('.gradio-container').forEach(function (e) { e.setAttribute('dir', d); }); });
  };
  M.setTheme = function (th) { S.set('mizan.theme', th); M.applyTheme(th); };
  M.setLang = function (l) { S.set('mizan.lang', l); M.applyLang(l); };
  M.applyTheme(M.theme); M.applyLang(M.lang);
  // Gradio sets its own .dark class from the system preference while it starts: keep the user's choice.
  body(function () {
    new MutationObserver(function () {
      var want = M.theme === 'dark';
      if (document.body.classList.contains('dark') !== want) document.body.classList.toggle('dark', want);
    }).observe(document.body, { attributes: true, attributeFilter: ['class'] });
  });
})();
</script>"""

# The appearance switch runs here only (no server call); the language switch first flips the direction, then the server re-renders the text.
JS_THEME = "(th) => { window.mizan && window.mizan.setTheme(th); return th; }"
JS_LANG = "(...a) => { window.mizan && window.mizan.setLang(a[0]); return a; }"
JS_LOAD = "(...a) => { const m = window.mizan || {}; a[0] = m.lang || 'en'; a[1] = m.theme || 'dark'; if (m.applyLang) m.applyLang(a[0]); return a; }"


def esc(s) -> str:
    return html.escape("" if s is None else str(s), quote=True)


def is_ar(text: str) -> bool:
    return bool(text) and len(ARABIC.findall(text)) >= max(3, len(text) // 6)


def content(text: str, cls: str = "", tag: str = "div") -> str:
    """Text produced by a model or taken from a document: its own direction, never translated."""
    lang = ' lang="ar"' if is_ar(text) else ""
    return f'<{tag} class="{cls}" dir="auto"{lang}>{esc(text)}</{tag}>'


def num(v, digits: int = 0) -> str:
    if v is None:
        return "—"
    return f'<bdi class="num">{v:,.{digits}f}</bdi>' if isinstance(v, float) or digits else f'<bdi class="num">{v:,}</bdi>'


def pipe_name(p: dict, lang: str) -> str:
    pid = p.get("id", "")
    if pid == "baseline":
        return t("pipe.standard", lang)
    if "lite" in pid:
        return t("pipe.mizan", lang)
    return pid


def pipe_desc(p: dict, lang: str) -> str:
    return t("pipe.standard_desc" if p.get("kind") == "standard" else "pipe.mizan_desc", lang)


def marker(kind: str) -> str:
    return f'<span class="mz-mk {esc(kind)}" aria-hidden="true"></span>'


# ---------------------------------------------------------------------------------------------------------------------------
# Static parts
# ---------------------------------------------------------------------------------------------------------------------------
def render_brand(info: dict, lang: str) -> str:
    return (f'<div class="mz mz-brand">{BRAND_MARK}<div><div class="name">{esc(t("brand.name", lang))}</div>'
            f'<div class="tag">{esc(t("brand.tag", lang))}</div></div></div>')


def render_corpus(info: dict, lang: str) -> str:
    c = info["corpus"]
    text = esc(t("corpus.status", lang, docs="\x00", pages="\x01"))
    text = text.replace("\x00", f"<b>{num(c['documents'])}</b>").replace("\x01", f"<b>{num(c['pages'])}</b>")
    return f'<div class="mz mz-corpus" title="{esc(t("corpus.source", lang))}">{text}</div>'


def render_notices(info: dict, lang: str) -> str:
    rows = []
    if info.get("synthetic"):
        rows.append(("warn", t("notice.synthetic", lang)))
    if info.get("mock"):
        rows.append(("warn", t("notice.mock", lang)))
    rows.append(("", t("notice.verify", lang)))
    return '<div class="mz mz-notices" role="note">' + "".join(f'<div class="mz-notice {c}">{INFO_SVG}<span>{esc(x)}</span></div>' for c, x in rows) + "</div>"


def render_ask_head(info: dict, lang: str) -> str:
    return (f'<div class="mz"><div class="mz-step"><span class="n">1</span><h2>{esc(t("step.ask", lang))}</h2></div></div>')


def render_examples_head(info: dict, lang: str) -> str:
    if not info.get("examples"):
        return ""
    return f'<div class="mz mz-label">{esc(t("ask.examples", lang))}</div>'


def render_answer_lang(lang: str, warn: str = "") -> str:
    msg = f'<div class="mz-msg warn" role="alert">{esc(warn)}</div>' if warn else ""
    return f'<div class="mz">{msg}<div class="mz-hint">{esc(t("ask.answer_lang", lang))}</div></div>'


def render_intro(info: dict, lang: str) -> str:
    pipes = info["pipelines"]
    rows = "".join(f'<div class="mz-pipe">{marker(p["kind"])}<span class="nm">{esc(pipe_name(p, lang))}</span>'
                   f'<span class="ds">{esc(pipe_desc(p, lang))}</span></div>' for p in pipes)
    # a real line from the regulations (Tour-Guide-Regulations-Ar-V012.pdf, page 8, extracted with PyMuPDF), before and after the repair
    return (f'<div class="mz mz-diff"><h3>{esc(t("intro.title", lang))}</h3><div class="mz-pipes">{rows}</div>'
            f'<div class="mz-example-line"><div class="cap">{esc(t("intro.example", lang))}</div>'
            f'<div class="row"><span class="lbl">{esc(t("intro.as_extracted", lang))}</span>'
            '<span class="txt bad-txt" lang="ar"><b>ال</b> تزيد مدة سريان الترخيص على ثلاث سنوات</span></div>'
            f'<div class="row"><span class="lbl">{esc(t("intro.repaired", lang))}</span>'
            '<span class="txt good-txt" lang="ar"><b>لا</b> تزيد مدة سريان الترخيص على ثلاث سنوات</span></div></div>'
            f'<p class="mz-gloss">{esc(t("intro.gloss", lang))}</p></div>')


def render_docs(info: dict, lang: str, report: dict | None = None) -> str:
    c = info["corpus"]
    parts = [f'<div class="mz-docs"><span class="k">{esc(t("docs.title", lang))}</span>'
             f'<span class="mz-muted">{esc(t("corpus.status", lang, docs=c["documents"], pages=c["pages"]))} · {esc(t("corpus.source", lang))}</span></div>']
    if c.get("uploaded"):
        parts.append(f'<div class="mz-small">{esc(t("docs.uploaded", lang, names="، ".join(c["uploaded"]) if lang == "ar" else ", ".join(c["uploaded"])))}</div>')
    if report:
        parts.append('<div class="mz-up" role="status">' + "".join(f'<div class="{cls}">{msg}</div>' for cls, msg in upload_lines(report, lang, info)) + "</div>")
    parts.append(f'<p class="mz-hint">{esc(t("docs.note", lang))}</p>')
    return '<div class="mz">' + "".join(parts) + "</div>"


def upload_lines(r: dict, lang: str, info: dict) -> list[tuple[str, str]]:
    out = []
    if r.get("added"):
        out.append(("ok", esc(t("up.added", lang, names=", ".join(r["added"]), s=r.get("seconds") or 0))))
    for s in r.get("skipped", []):
        out.append(("bad" if s["reason"] != "duplicate" else "warn",
                    esc(t(f"up.{s['reason']}", lang, name=s["name"], mb=info.get("upload_max_mb", 60)))))
    for w in r.get("warnings", []):
        key = "up.injection" if w["kind"] == "injection" else "up.personal"
        out.append(("warn", esc(t(key, lang, name=w["name"], pages=", ".join(map(str, w.get("pages") or [])), detail=w.get("detail", "")))))
    if r.get("error"):
        out.append(("bad", esc(t("up.error", lang, detail=r["error"]))))
    if not out:
        out.append(("warn", esc(t("up.nothing", lang))))
    if r.get("stale"):
        out.append(("warn", esc(t("up.stale", lang))))
    return out


def render_footer(lang: str) -> str:
    return f'<div class="mz mz-foot">{esc(t("footer", lang))}</div>'


# ---------------------------------------------------------------------------------------------------------------------------
# Results
# ---------------------------------------------------------------------------------------------------------------------------
def render_empty(lang: str) -> str:
    items = "".join(f'<li><b>{i}</b>{esc(t(f"flow.{i}", lang))}</li>' for i in range(1, 5))
    return f'<div class="mz"><ol class="mz-flow">{items}</ol></div>'


def _source_key(doc: str) -> str:
    return re.sub(r"\s+", "", doc or "").lower()


def render_answer_text(p: dict, lang: str) -> str:
    """The answer exactly as generated; each [file, page] citation is set apart and marked with what the code verified about it."""
    text = p["answer"]
    shown = {(_source_key(s["doc"]), s["page"]): s for s in p.get("sources", [])}
    out, pos = [], 0
    for m in CITE.finditer(text):
        out.append(esc(text[pos:m.start()]))
        src = shown.get((_source_key(m.group(1)), int(m.group(3))))
        cls, tip = ("gold", t("cite.gold", lang)) if src and src.get("relevant") else (("ok", t("cite.valid", lang)) if src else ("bad", t("cite.invalid", lang)))
        cdir = "rtl" if ARABIC.search(m.group(2)) else "ltr"          # «[file، صفحة 8]» reads right to left, «[file, page 8]» left to right
        out.append(f'<span class="mz-cite {cls}" dir="{cdir}" title="{esc(tip)}">[<bdi dir="ltr">{esc(m.group(1).strip())}</bdi>'
                   f'{esc(text[m.end(1):m.start(3)])}{esc(m.group(3))}]</span>')
        pos = m.end()
    out.append(esc(text[pos:]))
    body = "".join(out)
    paras = "".join(f"<p>{x}</p>" for x in body.split("\n") if x.strip())
    ar = ' lang="ar"' if is_ar(text) else ""
    return f'<div class="mz-answer{" refused" if p.get("abstained") else ""}" dir="auto"{ar}>{paras}</div>'


def _fact(cls: str, icon: str, text: str) -> str:
    return f'<div class="mz-fact {cls}"><span class="ic" aria-hidden="true">{icon}</span><span>{esc(text)}</span></div>'


def render_translation(text: str, model: str, lang: str) -> str:
    """A reading aid under an answer: labelled, outside the comparison, never stored with the answer."""
    return (f'<div class="mz-tr"><div class="lbl">{esc(t("tr.label", lang, model=model))}</div>'
            f'<p lang="en" dir="ltr">{esc(text)}</p></div>')


def render_card(p: dict, k: int, lang: str, tr_text: str = "", tr_model: str = "") -> str:
    facts = []
    ev = p.get("evidence")
    if ev == "found":
        facts.append(_fact("good", "✓", t("ev.found", lang, k=k, r=p.get("evidence_rank") or "?")))
    elif ev == "missing":
        facts.append(_fact("bad", "✗", t("ev.missing", lang, k=k)))
    elif ev == "unanswerable":
        facts.append(_fact("good" if p.get("abstained") else "bad", "✓" if p.get("abstained") else "✗", t("ev.unanswerable", lang)))
    else:
        facts.append(_fact("neutral", "–", t("ev.na", lang)))
    c = p.get("citations")
    if c is not None:
        if c["cited"]:
            facts.append(_fact("good" if not c["invalid"] else "warn", "✓" if not c["invalid"] else "!", t("cite.ok", lang, v=c["valid"], c=c["cited"])))
        else:
            facts.append(_fact("warn", "!", t("cite.none", lang)))
    if p.get("withheld"):
        facts.append(_fact("warn", "!", t("card.withheld", lang, n=p["withheld"])))
    if p.get("cached"):
        facts.append(_fact("neutral", "↺", t("card.cached", lang)))
    label = t("card.passage", lang) if p.get("answer_kind") == "passage" else t("card.answer", lang)
    refused = f'<div class="mz-fact neutral"><span class="ic">∅</span><span>{esc(t("card.refused", lang))}</span></div>' if p.get("abstained") else ""
    return (f'<article class="mz-ans {esc(p["kind"])}" aria-label="{esc(pipe_name(p, lang))}">'
            f'<header>{marker(p["kind"])}<span class="nm">{esc(pipe_name(p, lang))}</span><span class="ds">{esc(pipe_desc(p, lang))}</span></header>'
            f'<div class="body"><div class="lbl">{esc(label)}</div>{render_answer_text(p, lang)}{refused}'
            f'{render_translation(tr_text, tr_model, lang) if tr_text else ""}<div class="mz-facts-row">{"".join(facts)}</div></div></article>')


def render_sources(p: dict, other: dict | None, k: int, lang: str) -> str:
    theirs = {(s["doc"], s["page"]) for s in (other or {}).get("sources", [])}
    items = []
    for s in p.get("sources", []):
        title = s.get("title") if lang == "ar" else (s.get("title_en") or s.get("title"))
        score = s.get("score")
        width = max(0.0, min(1.0, score or 0.0)) * 100
        tags = []
        if s.get("relevant"):
            tags.append(f'<span class="mz-tag gold">✓ {esc(t("src.gold", lang))}</span>')
        if other is not None and (s["doc"], s["page"]) not in theirs:
            tags.append(f'<span class="mz-tag only">{esc(t("src.only", lang))}</span>')
        if s.get("withheld"):
            tags.append(f'<span class="mz-tag held">{esc(t("src.withheld", lang))}</span>')
        meta = [t("src.page", lang, p=s.get("page")), t("src.tokens", lang, n=s.get("tokens"))] if s.get("tokens") is not None else [t("src.page", lang, p=s.get("page"))]
        sc = (f'<span>{esc(t("src.similarity", lang, v=f"{score:.3f}"))}</span><span class="mz-bar" aria-hidden="true"><i style="width:{width:.0f}%"></i></span>'
              if score is not None else "")
        items.append(
            f'<details class="mz-src"><summary><span class="rk">{s.get("rank")}</span>'
            f'<span class="tt"><span class="t1" dir="auto">{esc(title)}</span><span class="t2">{esc(" · ".join(meta))} · <bdi dir="ltr">{esc(s.get("doc"))}</bdi></span></span>'
            f'<span class="sc">{sc}</span>' + (f'<span class="mz-tags">{"".join(tags)}</span>' if tags else "") + '</summary>'
            f'<div class="mz-passage"><div class="cap">{esc(t("src.source_lang", lang))}</div>{content(s.get("text", ""), "txt")}</div></details>')
    return (f'<section class="mz-srcs"><div class="hd">{esc(t("src.title", lang, k=k))}</div>{"".join(items)}</section>')


def summary_facts(res: dict, k: int, lang: str) -> list[str]:
    pipes = res["pipelines"]
    if len(pipes) != 2:
        return []
    a, b = pipes
    out = []
    ea, eb = a.get("evidence"), b.get("evidence")
    if ea is None and eb is None:
        out.append(t("sum.no_gold", lang))
    elif ea == "unanswerable":
        out.append(t("sum.unanswerable", lang))
    elif ea == "found" and eb == "found":
        out.append(t("sum.both_found", lang) + " " + t("sum.ranks", lang, a=pipe_name(a, lang), ra=a.get("evidence_rank"), b=pipe_name(b, lang),
                                                          rb=b.get("evidence_rank")))
    elif ea == "found" or eb == "found":
        w = a if ea == "found" else b
        out.append(t("sum.only", lang, name=pipe_name(w, lang)) + " " + t("sum.rank", lang, r=w.get("evidence_rank")))
    else:
        out.append(t("sum.neither", lang, k=k))
    norm = lambda s: re.sub(r"\s+", " ", s or "").strip()  # noqa: E731
    out.append(t("sum.same_answer" if norm(a["answer"]) == norm(b["answer"]) else "sum.diff_answer", lang))
    sa = {(s["doc"], s["page"]) for s in a.get("sources", [])}
    sb = {(s["doc"], s["page"]) for s in b.get("sources", [])}
    if sa and sb:
        out.append(t("sum.shared", lang, n=len(sa & sb), k=max(len(sa), len(sb))))
    ia, ib = a["tokens"].get("input"), b["tokens"].get("input")
    if ia and ib is not None and ia != ib:
        d = ib - ia
        out.append(t("sum.fewer" if d < 0 else "sum.more", lang, name=pipe_name(b, lang), n=f"{abs(d):,}", pct=f"{abs(d) / ia:.0%}"))
    return out


def render_measurements(res: dict, lang: str) -> str:
    pipes = res["pipelines"]
    two = len(pipes) == 2
    rows = [("m.retrieved", lambda p: p["tokens"].get("retrieved"), 0), ("m.input", lambda p: p["tokens"].get("input"), 0),
            ("m.output", lambda p: p["tokens"].get("output"), 0), ("m.ret_s", lambda p: p["latency"].get("retrieval_s"), 2),
            ("m.gen_s", lambda p: p["latency"].get("generation_s"), 2)]
    head = "".join(f'<th scope="col" class="num">{marker(p["kind"])} {esc(pipe_name(p, lang))}</th>' for p in pipes)
    if two:
        head += (f'<th scope="col" class="num">{esc(t("m.diff", lang))}<span class="hint">'
                 f'{esc(t("m.diff_hint", lang, a=pipe_name(pipes[0], lang), b=pipe_name(pipes[1], lang)))}</span></th>')
    body = []
    for key, get, digits in rows:
        vals = [get(p) for p in pipes]
        cells = "".join(f'<td class="num">{num(v, digits) if v is not None else "—"}</td>' for v in vals)
        if two:
            if vals[0] is None or vals[1] is None:
                cells += '<td class="num">—</td>'
            else:
                d = round(vals[1] - vals[0], digits)
                sign = "+" if d > 0 else ("−" if d < 0 else "")
                cells += f'<td class="num"><bdi class="num" dir="ltr">{sign}{abs(d):,.{digits}f}</bdi></td>'
        unit = f' <span class="mz-muted">({esc(t("m.s", lang, v="").strip())})</span>' if digits else ""
        body.append(f'<tr><th scope="row">{esc(t(key, lang))}{unit}</th>{cells}</tr>')
    elapsed = res.get("elapsed_s")
    el = f'<div class="elapsed">{esc(t("m.elapsed", lang, s=t("m.s", lang, v=f"{elapsed:.1f}")))}</div>' if elapsed is not None else ""
    return (f'<div class="mz-tablewrap"><table class="mz-table"><caption>{esc(t("m.title", lang))}</caption><thead><tr><th scope="col">'
            f'{esc(t("m.metric", lang))}</th>{head}</tr></thead><tbody>{"".join(body)}</tbody></table>{el}</div>')


def can_translate(res: dict | None, info: dict, lang: str, tr: dict | None = None) -> bool:
    """The translate button exists only where it can work: English interface, a generator, Arabic generated answers, not done yet."""
    if lang != "en" or info.get("mock") or not res or not res.get("pipelines"):
        return False
    if tr and tr.get("run_id") == res.get("run_id") and tr.get("status") == "ok":
        return False
    return any(p.get("answer_kind") == "generated" and ARABIC.search(p.get("answer") or "") for p in res["pipelines"])


def render_results(res: dict | None, info: dict, lang: str, tr: dict | None = None, part: str = "all") -> str:
    """Step 2 (the answers and their passages) and step 3 (what was measured). The screen shows them as two blocks, part="answers"
    and part="measured", so the translate button can sit under the answers; part="all" is both, one after the other."""
    if not res or res.get("stale") or res.get("error"):
        if part == "measured":
            return ""
        if not res:
            return render_empty(lang)
        if res.get("stale"):
            return f'<div class="mz"><div class="mz-alert" role="status">{esc(t("up.stale", lang))}</div></div>'
        return (f'<div class="mz"><div class="mz-alert bad" role="alert"><p>{esc(t("res.error", lang))}</p>'
                f'<p class="detail" dir="ltr" lang="en">{esc(res["error"])}</p></div></div>')
    k = info["settings"]["top_k"]
    pipes = res["pipelines"]
    ref = (f'<div class="ref">{esc(t("res.reference", lang))}: {content(res["reference"], "", "span")}</div>' if res.get("reference") else "")
    q = f'<section class="mz-qstrip"><div class="mz-small">{esc(t("res.question", lang))}</div>{content(res["question"], "q")}{ref}</section>'
    facts = summary_facts(res, k, lang)
    summ = ""
    if facts:
        summ = (f'<section class="mz-summary" aria-label="{esc(t("sum.title", lang))}"><h3>{esc(t("sum.title", lang))}</h3><ul>'
                + "".join(f"<li>{esc(f)}</li>" for f in facts) + f'</ul><div class="note">{esc(t("sum.note", lang))}</div></section>')
    tr = tr if (tr and lang == "en" and tr.get("run_id") == res.get("run_id")) else None
    texts = tr["texts"] if tr and tr.get("status") == "ok" else {}
    model = tr.get("model", "") if tr else ""
    cols = []
    for i, p in enumerate(pipes):
        other = pipes[1 - i] if len(pipes) == 2 else None
        cols.append(f'<div class="mz-col {esc(p["kind"])}">{render_card(p, k, lang, texts.get(p["id"], ""), model)}'
                    f'{render_sources(p, other, k, lang)}</div>')
    tr_note = ""
    if tr and tr.get("status") in ("failed", "unavailable"):
        msg = t("tr.failed", lang) if tr["status"] == "failed" else t("tr.unavailable", lang)
        detail = f'<p class="detail" dir="ltr" lang="en">{esc(tr["message"])}</p>' if tr.get("message") else ""
        tr_note = f'<div class="mz-alert" role="status"><p>{esc(msg)}</p>{detail}</div>'
    step2 = (f'<div class="mz-step"><span class="n">2</span><h2>{esc(t("step.answers", lang))}</h2>'
             f'<span class="sub">· {esc(t("step.evidence", lang))}</span></div>')
    step3 = f'<div class="mz-step"><span class="n">3</span><h2>{esc(t("step.compare", lang))}</h2></div>'
    answers = (f'<div class="mz mz-results">{step2}{q}{tr_note}<div class="mz-cols" style="--n:{len(pipes)}">{"".join(cols)}</div>'
               f'<p class="mz-small mz-reminder" role="note">{esc(t("res.reminder", lang))}</p></div>')
    measured = f'<div class="mz mz-results mz-measured">{step3}{summ}{render_measurements(res, lang)}</div>'
    return {"answers": answers, "measured": measured}.get(part, answers + measured)


# ---------------------------------------------------------------------------------------------------------------------------
# Mizan Insights
# ---------------------------------------------------------------------------------------------------------------------------
def _fids(ids: list[str], facts: dict[str, str], lang: str) -> str:
    if not ids:
        return ""
    chips = "".join(f'<span class="mz-fid" tabindex="0" title="{esc(facts.get(i, ""))}" aria-label="{esc(i)}: {esc(facts.get(i, ""))}">{esc(i)}</span>'
                    for i in ids)
    return f'<span class="mz-fids" dir="ltr">{chips}</span>'


def _gen(text: str, lang_text: str) -> str:
    return f'<span class="mz-gen" dir="auto" lang="{esc(lang_text)}">{esc(text)}</span>'


def _gdir(lang_text: str) -> str:
    """dir/lang for a block of model-written statements (its language is known: the evidence's)."""
    return f'dir="{"rtl" if lang_text == "ar" else "ltr"}" lang="{esc(lang_text)}"'


def render_ledger(ev: dict, lang: str) -> str:
    facts = "".join(f'<li><span class="mz-fid">{esc(f["id"])}</span> {esc(f["text"])}</li>' for f in ev["facts"])
    lst = lambda xs: "".join(f"<li>{esc(x)}</li>" for x in xs)  # noqa: E731
    note = t("ins.facts_lang", lang)
    return (f'<details class="mz-ledger"><summary>{esc(t("ins.facts", lang, n=len(ev["facts"])))}</summary><div class="in">'
            + (f'<p class="mz-small">{esc(note)}</p>' if note else "")
            + f'<ol dir="ltr" lang="en">{facts}</ol>'
            + (f'<h4>{esc(t("ins.not_measured", lang))}</h4><ul dir="ltr" lang="en">{lst(ev["not_measured"])}</ul>' if ev["not_measured"] else "")
            + (f'<h4>{esc(t("ins.unsupported", lang))}</h4><ul dir="ltr" lang="en">{lst(ev["unsupported"])}</ul>' if ev["unsupported"] else "")
            + (f'<h4>{esc(t("ins.notes", lang))}</h4><ul dir="ltr" lang="en">{lst(ev["notes"])}</ul>' if ev["notes"] else "")
            + "</div></details>")


def _status_message(r: dict, lang: str) -> tuple[str, str]:
    """(localized message, technical detail in the original English) for an analysis that did not produce text."""
    st, msg = r.get("status"), r.get("message") or ""
    if st == "unavailable":
        return t("ins.unavailable", lang), ""
    if st == "blocked":
        return t("ins.blocked", lang), msg
    if msg.startswith("The model's reply"):
        return t("ins.failed_checks", lang), ""
    if "longer than" in msg:
        return t("ins.failed_timeout", lang), msg
    return t("ins.failed_other", lang), msg


def render_insights(pm: dict | None, info: dict, lang: str) -> str:
    head = (f'<div class="hd"><h2><span class="n">4</span>Mizan Insights</h2><span class="mz-small">{esc(t("ins.subtitle", lang))}</span></div>'
            f'<p class="how">{esc(t("ins.how", lang))}</p>')
    pm = pm or {"state": "none"}
    st = pm.get("state")
    wrap = lambda inner: f'<div class="mz mz-ins" aria-live="polite">{head}{inner}</div>'  # noqa: E731
    if st == "none":
        return wrap(f'<p class="mz-muted">{esc(t("ins.none", lang))}</p>')
    if st == "stale":
        return wrap(f'<div class="mz-alert" role="status">{esc(t("up.stale", lang))}</div>')
    if st == "message":
        detail = pm.get("message") or ""
        return wrap(f'<div class="mz-alert" role="status">{esc(t("ins." + pm.get("code", "evidence_failed"), lang))}</div>'
                    + (f'<p class="mz-small" dir="ltr" lang="en">{esc(detail)}</p>' if detail else ""))
    ev = pm.get("evidence") or {}
    facts = {f["id"]: f["text"] for f in ev.get("facts", [])}
    scope = f'<span class="mz-scope">{esc(t("scope." + ev.get("scope", "single_question"), lang))}</span>' if ev else ""
    fp = f'<bdi dir="ltr">{esc(ev.get("corpus_fp"))}</bdi>' if ev else ""            # a hash that starts with digits would be split by bidi
    run = (f'<span class="mz-small">{esc(t("ins.run", lang, fp=chr(0), docs=ev.get("documents"), pages=ev.get("pages"))).replace(chr(0), fp)}</span>'
           if ev else "")
    meta = f'<div style="display:flex;flex-wrap:wrap;gap:8px 14px;align-items:center">{scope}{run}</div>'
    ledger = render_ledger(ev, lang) if ev else ""
    if st == "loading":
        return wrap(meta + f'<div class="mz-loading" role="status"><p>{esc(t("ins.loading", lang))}</p><div class="mz-skel"></div>'
                    '<div class="mz-skel"></div><div class="mz-skel"></div></div>' + ledger)
    if st == "idle":
        return wrap(meta + f'<p class="mz-muted">{esc(t("ins.idle", lang))}</p>' + ledger)
    r = pm.get("result") or {}
    if r.get("status") != "ok":
        msg, detail = _status_message(r, lang)
        rej = ""
        if r.get("errors") and r.get("status") == "failed" and (r.get("message") or "").startswith("The model's reply"):
            rej = (f'<details class="mz-ledger"><summary>{esc(t("ins.rejected", lang))}</summary><div class="in"><ul dir="ltr" lang="en">'
                   + "".join(f"<li>{esc(e)}</li>" for e in r["errors"][:8]) + "</ul></div></details>")
        det = f'<p class="mz-small" dir="ltr" lang="en">{esc(detail)}</p>' if detail else ""
        return wrap(meta + f'<div class="mz-alert" role="status">{esc(msg)}</div>{det}{rej}' + ledger)
    s = r.get("sections") or {}
    tl = ev.get("lang", "en")
    of = s.get("overall_finding") or {}
    stance, where = of.get("stance"), of.get("scope")
    mk = {"standard_ahead": marker("standard"), "mizan_ahead": marker("mizan")}.get(stance, '<span class="eq" aria-hidden="true"></span>')
    label = (t(f"stance.{stance}", lang) + (" " + t(f"where.{where}", lang) if where in ("single_question", "aggregate") else "")) if stance else ""
    finding = (f'<section class="mz-finding"><div class="mz-small">{esc(t("ins.finding", lang))}</div><div class="mz-stance">{mk}<span>{esc(label)}</span></div>'
               f'<div {_gdir(tl)}>{_gen(of.get("text", ""), tl)}{_fids(of.get("facts", []), facts, lang)}</div></section>')
    secs = []
    if s.get("key_observations"):
        items = "".join(f'<li {_gdir(tl)}>{"<span class=mz-kind>" + esc(t("ins.hypothesis", lang)) + "</span>" if o.get("kind") == "hypothesis" else ""}'
                        f'{_gen(o["text"], tl)}{_fids(o.get("facts", []), facts, lang)}</li>' for o in s["key_observations"])
        secs.append(f'<section class="mz-isec"><h3>{esc(t("ins.observations", lang))}</h3><ul>{items}</ul></section>')
    if s.get("trade_offs"):
        items = "".join(f'<li {_gdir(tl)}>{_gen(o["text"], tl)}{_fids(o.get("facts", []), facts, lang)}</li>' for o in s["trade_offs"])
        secs.append(f'<section class="mz-isec"><h3>{esc(t("ins.tradeoffs", lang))}</h3><ul>{items}</ul></section>')
    rec = s.get("recommendation") or {}
    if rec.get("text"):
        rp = rec.get("pipeline")
        rmk = {"standard": marker("standard"), "mizan": marker("mizan")}.get(rp, "")
        cond = f'<p class="mz-small">{esc(t("rec.conditional", lang))}</p>' if rec.get("conditional") else ""
        secs.append(f'<section class="mz-isec mz-rec"><h3>{esc(t("ins.recommendation", lang))}</h3><span class="pill">{rmk}{esc(t("rec." + (rp or "no_recommendation"), lang))}</span>'
                    f'<div {_gdir(tl)}>{_gen(rec["text"], tl)}{_fids(rec.get("facts", []), facts, lang)}</div>{cond}</section>')
    if s.get("limitations_and_next_steps"):
        items = "".join(f'<li {_gdir(tl)}><span class="mz-kind">{esc(t("ins.next_step" if o.get("type") == "next_step" else "ins.limitation", lang))}</span>'
                        f'{_gen(o["text"], tl)}</li>' for o in s["limitations_and_next_steps"])
        secs.append(f'<section class="mz-isec"><h3>{esc(t("ins.limits", lang))}</h3><ul>{items}</ul></section>')
    removed = s.get("removed") or []
    rem = f'<p class="mz-small">{esc(t("ins.removed", lang, n=len(removed)))}</p>' if removed else ""
    prov = [t("ins.written_by", lang, model="\x00"), t("ins.attempts", lang, n=r.get("attempts"))]
    if r.get("input_tokens") is not None and r.get("output_tokens") is not None:
        prov.append(t("ins.tokens", lang, i=r["input_tokens"], o=r["output_tokens"]))
    if r.get("latency_s") is not None and not r.get("from_cache"):
        prov.append(t("ins.latency", lang, s=r["latency_s"]))
    if r.get("from_cache"):
        prov.append(t("ins.reused", lang))
    lang_note = f"<span>{esc(t('ins.text_lang', lang))}</span>" if lang == "ar" and tl == "en" else ""
    model = f'<bdi dir="ltr">{esc(r.get("model", ""))}</bdi>'                    # «ollama:qwen3…» keeps its order inside Arabic text
    provenance = f'<div class="mz-prov"><span>{esc(" · ".join(prov)).replace(chr(0), model)}</span><span>{esc(t("ins.checked", lang))}</span>{lang_note}</div>'
    return wrap(meta + finding + f'<div class="mz-igrid">{"".join(secs)}</div>' + rem + provenance + ledger)


# ---------------------------------------------------------------------------------------------------------------------------
# Monitoring and experiment details
# ---------------------------------------------------------------------------------------------------------------------------
def render_details(info: dict, monitor: dict | None, lang: str) -> str:
    st = info["settings"]
    titles = t("det.titles", lang) if st["chunk_title"] else ""
    rer = t("det.reranker_v", lang, m=st["reranker"], n=st["rerank_top_n"], k=st["top_k"]) if st["reranker"] else t("det.none", lang)
    kv = [(t("det.embedder", lang), st["embedder"]), (t("det.reranker", lang), rer),
          (t("det.chunking", lang), t("det.chunking_v", lang, size=st["chunk_size"], overlap=st["chunk_overlap"], titles=titles)),
          (t("det.retrieval", lang), t("det.retrieval_v", lang, k=st["top_k"])),
          (t("det.generator", lang), st["generator"] or t("det.none", lang)), (t("det.prompt", lang), st["prompt"])]
    shared = "".join(f"<dt>{esc(k)}</dt><dd><bdi>{esc(v)}</bdi></dd>" for k, v in kv)
    blocks = []
    for p in info["pipelines"]:
        items = "".join(f"<li>{esc(t('flag.' + step, lang))}</li>" for step in p["steps"])
        chunks = esc(t("det.chunks", lang, n=p.get("chunks") or "—"))
        blocks.append(f'<div><div>{marker(p["kind"])} <b>{esc(pipe_name(p, lang))}</b> <span class="mz-small">· {chunks}</span></div><ul>{items}</ul></div>')
    steps = "".join(blocks)
    exp = (f'<details><summary>{esc(t("det.experiment", lang))}</summary><div class="in"><div class="mz-small">{esc(t("det.shared", lang))}</div>'
           f'<dl class="mz-kv">{shared}</dl><div class="mz-small">{esc(t("det.preprocessing", lang))}</div>'
           f'<div class="mz-steps" style="--n:{len(info["pipelines"])}">{steps}</div>'
           f'<p class="mz-small">{esc(t("det.note_chunks", lang))}</p><p class="mz-small">{esc(t("det.note_gold", lang))}</p></div></details>')
    return f'<div class="mz mz-more">{render_monitor(monitor, info, lang)}{exp}</div>'


def render_monitor(m: dict | None, info: dict, lang: str) -> str:
    if not m:
        inner = f'<p class="mz-small">{esc(t("det.monitor_empty", lang))}</p>'
    else:
        names = {p["id"]: p for p in info["pipelines"]}
        pct = lambda v: "—" if v is None else f"{v:.0%}"  # noqa: E731
        sec = lambda v: "—" if v is None else t("m.s", lang, v=f"{v:.1f}")  # noqa: E731
        head = "".join(f'<th scope="col"{" class=num" if i else ""}>{esc(t(k, lang))}</th>' for i, k in enumerate(
            ("mon.pipeline", "mon.answers", "mon.errors", "mon.refusals", "mon.p50", "mon.p95", "mon.citations", "mon.tokens")))
        rows = []
        for pid, x in m["pipelines"].items():
            if pid not in names:
                continue
            tok = "—" if x["mean_input_tokens"] is None else f"{x['mean_input_tokens']:,.0f}"
            rows.append(f'<tr><th scope="row">{esc(pipe_name(names[pid], lang))}</th><td class="num">{x["answers"]}</td><td class="num">{x["errors"]}</td>'
                        f'<td class="num">{pct(x["refusal_rate"])}</td><td class="num">{esc(sec(x["p50_s"]))}</td><td class="num">{esc(sec(x["p95_s"]))}</td>'
                        f'<td class="num">{pct(x["citation_rate"])}</td><td class="num">{tok}</td></tr>')
        rows = "".join(rows)
        alerts = "".join(f'<div class="mz-alert" role="status"><b>{esc(t("mon.alert", lang))}: {esc(t("rule." + a["rule"], lang))}</b>'
                         f' <span dir="ltr" lang="en">{esc(a["message"])}</span></div>' for a in m.get("alerts", []))
        inner = (alerts + f'<div class="mz-tablewrap"><table class="mz-table"><caption>{esc(t("det.monitor_cap", lang, n=m["window"]))}</caption>'
                 f"<thead><tr>{head}</tr></thead><tbody>{rows}</tbody></table></div>")
    return f'<details><summary>{esc(t("det.monitor", lang))}</summary><div class="in">{inner}</div></details>'


# ---------------------------------------------------------------------------------------------------------------------------
# The app
# ---------------------------------------------------------------------------------------------------------------------------
def launch_kwargs() -> dict:
    return {"theme": gradio_theme(), "css": CSS, "head": HEAD_JS}  # Gradio 6 takes these in launch()


def build_ui(pages, pipes, questions: list[dict], synthetic: bool = False, data_dir: Path = RAW_DIR):
    """Return a gr.Blocks. Models and indexes are the ones already loaded in `pipes`; nothing is reloaded per question or per setting."""
    import gradio as gr

    be = MizanBackend(pages, pipes, questions, synthetic, data_dir)
    info0 = be.info()
    examples = info0["examples"]
    lang0 = "en"

    def theme_choices(lang):
        return [(t("theme.dark", lang), "dark"), (t("theme.light", lang), "light")]

    with gr.Blocks(title="Mizan · مِيزان") as ui:
        # What the screen shows, one state per part: an event writes only the parts it owns, so one that ends late (the analysis, a
        # translation) cannot put back what it read when it started. Gradio reads an event's inputs at its start and writes its outputs at its end.
        s_res, s_panel, s_tr, s_up = gr.State(None), gr.State(None), gr.State(None), gr.State(None)
        rid = gr.State(0)
        with gr.Row(elem_id="mz-top"):
            with gr.Column(scale=1, min_width=200, elem_id="mz-brandcol"):
                brand = gr.HTML(render_brand(info0, lang0), padding=False)
            with gr.Column(scale=0, min_width=0, elem_id="mz-corpuscol"):
                corpus = gr.HTML(render_corpus(info0, lang0), padding=False)
            lang = gr.Radio([("English", "en"), ("العربية", "ar")], value=lang0, label=t("ctrl.language", lang0), show_label=False,
                            container=False, elem_classes=["mz-seg"], scale=0, min_width=150)
            theme = gr.Radio(theme_choices(lang0), value="dark", label=t("ctrl.theme", lang0), show_label=False, container=False,
                             elem_classes=["mz-seg"], scale=0, min_width=140)
        notices = gr.HTML(render_notices(info0, lang0), padding=False)
        with gr.Row(equal_height=False):
            with gr.Column(scale=3, elem_classes=["mz-card"]):
                ask_head = gr.HTML(render_ask_head(info0, lang0), padding=False)
                question = gr.Textbox(label=t("ask.label", lang0), placeholder=t("ask.placeholder", lang0), lines=2, max_lines=6, elem_id="mz-question")
                ex_head = gr.HTML(render_examples_head(info0, lang0), padding=False, elem_id="mz-exhead")
                with gr.Row(elem_id="mz-examples", visible=bool(examples)):
                    ex_btns = [gr.Button(t(f"example.{e['id']}", lang0) if f"example.{e['id']}" in _EXAMPLE_KEYS else e["label"], size="sm",
                                         variant="secondary") for e in examples]
                with gr.Accordion(t("ask.phrase_toggle", lang0), open=False, elem_id="mz-phrase-acc") as phrase_acc:
                    phrase = gr.Textbox(label=t("ask.phrase_label", lang0), info=t("ask.phrase_info", lang0), lines=1, elem_id="mz-phrase")
                with gr.Row():
                    run = gr.Button(t("ask.run", lang0), variant="primary", elem_id="mz-run", scale=3)
                    clear = gr.Button(t("ask.clear", lang0), variant="secondary", elem_id="mz-clear", scale=1)
                ask_msg = gr.HTML(render_answer_lang(lang0), padding=False, elem_id="mz-asknote")
            with gr.Column(scale=2, elem_classes=["mz-card"]):
                intro = gr.HTML(render_intro(info0, lang0), padding=False)
        with gr.Row(equal_height=False, elem_classes=["mz-card"]):
            with gr.Column(scale=5):
                docs = gr.HTML(render_docs(info0, lang0), padding=False)
            upload = gr.UploadButton(t("docs.add", lang0), file_types=[".pdf"], file_count="multiple", size="sm", scale=0, min_width=140,
                                     elem_id="mz-upload")
        results = gr.HTML(render_results(None, info0, lang0, part="answers"), padding=False)
        translate_btn = gr.Button(t("tr.button", lang0), size="sm", variant="secondary", visible=False, elem_id="mz-translate")
        measured = gr.HTML("", padding=False, elem_id="mz-measured")
        with gr.Column(elem_classes=["mz-card"]):
            ins = gr.HTML(render_insights(None, info0, lang0), padding=False)
            with gr.Row(elem_id="mz-ins-controls"):
                auto = gr.Checkbox(label=t("ins.auto", lang0), value=info0["insights_auto"], container=False, scale=0, min_width=240,
                                   elem_id="mz-auto")
                gen = gr.Button(t("ins.generate", lang0), size="sm", variant="secondary", scale=0, min_width=160)
                evaluate = gr.Button(t("ins.evaluate", lang0), size="sm", variant="secondary", scale=0, min_width=260,
                                     visible=info0["can_evaluate"])
        details = gr.HTML(render_details(info0, be.monitor(), lang0), padding=False)
        footer = gr.HTML(render_footer(lang0), padding=False)

        def tr_button(lg: str, visible: bool):
            return gr.update(value=t("tr.button", lg), interactive=True, visible=visible)

        # ---- language: re-render from the stored states, no model call -----------------------------------------------------
        static_out = [brand, corpus, theme, notices, ask_head, question, ex_head, *ex_btns, phrase_acc, phrase, run, clear, ask_msg,
                      intro, docs, upload, results, translate_btn, measured, ins, auto, gen, evaluate, details, footer]

        def relabel(lg, res, pm, tr, up):
            info = be.info()
            return [render_brand(info, lg), render_corpus(info, lg), gr.update(choices=theme_choices(lg)), render_notices(info, lg),
                    render_ask_head(info, lg), gr.update(label=t("ask.label", lg), placeholder=t("ask.placeholder", lg), rtl=lg == "ar"),
                    render_examples_head(info, lg), *[gr.update(value=example_label(e, lg)) for e in examples],
                    gr.update(label=t("ask.phrase_toggle", lg)), gr.update(label=t("ask.phrase_label", lg), info=t("ask.phrase_info", lg), rtl=lg == "ar"),
                    gr.update(value=t("ask.run", lg)), gr.update(value=t("ask.clear", lg)), render_answer_lang(lg),
                    render_intro(info, lg), render_docs(info, lg, up), gr.update(label=t("docs.add", lg)),
                    render_results(res, info, lg, tr, part="answers"),
                    tr_button(lg, can_translate(res, info, lg, tr)), render_results(res, info, lg, part="measured"),
                    render_insights(pm, info, lg), gr.update(label=t("ins.auto", lg)),
                    gr.update(value=t("ins.generate", lg)), gr.update(value=t("ins.evaluate", lg)), render_details(info, be.monitor(), lg),
                    render_footer(lg)]

        shown = [s_res, s_panel, s_tr, s_up]
        # The analysis of a newer question is triggered while the older one may still be running. Gradio's default for an event is to ignore a
        # trigger while the same event is pending, which would drop the newer analysis and leave its panel "being written"; queue the latest.
        LATEST = "always_last"
        lang.input(relabel, [lang, *shown], static_out, js=JS_LANG, show_progress="hidden", api_visibility="undocumented")
        theme.input(None, theme, None, js=JS_THEME, api_visibility="undocumented")

        def on_load(lg, th, res, pm, tr, up):
            lg = lg if lg in ("en", "ar") else "en"
            th = th if th in ("dark", "light") else "dark"
            out = relabel(lg, res, pm, tr, up)
            out[2] = gr.update(choices=theme_choices(lg), value=th)      # the theme switch shows the stored choice
            # Gradio 6.9: a load-time visible=False on a component that starts hidden makes it ignore every later visible=True.
            # A fresh page has no answers, so the translate button keeps its initial (hidden) state and only its label is set.
            out[next(i for i, c in enumerate(static_out) if c is translate_btn)] = gr.update(value=t("tr.button", lg), interactive=True)
            return [lg] + out

        ui.load(on_load, [lang, theme, *shown], [lang, *static_out], js=JS_LOAD,
                show_progress="hidden", api_visibility="undocumented")

        # ---- asking ---------------------------------------------------------------------------------------------------
        def ask(q, ph, auto_on, lg):
            info = be.info()
            if not (q or "").strip():
                return (gr.skip(), gr.skip(), render_answer_lang(lg, t("ask.empty", lg)), gr.skip(), gr.skip(), gr.skip(), gr.skip(), gr.skip(),
                        gr.skip(), gr.skip())
            res, pm, r = be.ask(q, ph, auto_on)
            return (render_results(res, info, lg, part="answers"), render_insights(pm, info, lg), render_answer_lang(lg), res, pm, None, r,
                    render_details(info, res.get("monitor"), lg), tr_button(lg, can_translate(res, info, lg)),
                    render_results(res, info, lg, part="measured"))

        def write(r, auto_on, lg):
            pm = be.generate(r, auto_on)
            if pm is None:                                   # superseded or not wanted: the screen keeps whatever is on it now
                return gr.skip(), gr.skip()
            return render_insights(pm, be.info(), lg), pm

        def rerender_insights(lg, pm):
            return render_insights(pm, be.info(), lg)

        ask_args = dict(fn=ask, inputs=[question, phrase, auto, lang],
                        outputs=[results, ins, ask_msg, s_res, s_panel, s_tr, rid, details, translate_btn, measured],
                        show_progress_on=[results], scroll_to_output=True)
        run.click(**ask_args, api_name="ask") \
            .then(write, [rid, auto, lang], [ins, s_panel], trigger_mode=LATEST, show_progress="minimal", api_name="write_insights") \
            .then(rerender_insights, [lang, s_panel], ins, trigger_mode=LATEST, show_progress="hidden", api_visibility="private")
        question.submit(**ask_args, api_visibility="undocumented") \
            .then(write, [rid, auto, lang], [ins, s_panel], trigger_mode=LATEST, show_progress="minimal", api_visibility="private") \
            .then(rerender_insights, [lang, s_panel], ins, trigger_mode=LATEST, show_progress="hidden", api_visibility="private")
        for e, b in zip(examples, ex_btns):
            b.click(lambda q=e["question"]: q, None, question, api_visibility="undocumented") \
                .then(**{**ask_args, "api_visibility": "undocumented"}) \
                .then(write, [rid, auto, lang], [ins, s_panel], trigger_mode=LATEST, show_progress="minimal", api_visibility="private") \
                .then(rerender_insights, [lang, s_panel], ins, trigger_mode=LATEST, show_progress="hidden", api_visibility="private")

        def do_clear(lg):
            info = be.info()
            return ("", "", render_answer_lang(lg), render_results(None, info, lg, part="answers"), render_insights(None, info, lg), None, None,
                    None, tr_button(lg, False), "")

        clear.click(do_clear, [lang], [question, phrase, ask_msg, results, ins, s_res, s_panel, s_tr, translate_btn, measured],
                    api_visibility="undocumented")

        # ---- reading aid: English translation of Arabic answers, on request -------------------------------------------------
        def translate_start(lg):
            return gr.update(value=t("tr.working", lg), interactive=False)

        def do_translate(r, lg, res):
            tr = be.translate(r)
            if tr is None:                                   # a newer question or an upload replaced that run, and has set the button
                return gr.skip(), gr.skip(), gr.skip()
            info = be.info()
            return render_results(res, info, lg, tr, part="answers"), tr_button(lg, can_translate(res, info, lg, tr)), tr

        translate_btn.click(translate_start, lang, translate_btn, show_progress="hidden", api_visibility="private") \
            .then(do_translate, [rid, lang, s_res], [results, translate_btn, s_tr], show_progress="hidden", api_name="translate_answers")

        # ---- Mizan Insights controls ---------------------------------------------------------------------------------------
        def regen_start(lg):
            pm, r = be.regenerate_start()
            return render_insights(pm, be.info(), lg), pm, r

        def regen(r, lg):
            pm = be.regenerate(r)
            if pm is None:
                return gr.skip(), gr.skip()
            return render_insights(pm, be.info(), lg), pm

        gen.click(regen_start, [lang], [ins, s_panel, rid], api_name="regenerate_start") \
            .then(regen, [rid, lang], [ins, s_panel], trigger_mode=LATEST, show_progress="minimal", api_name="regenerate") \
            .then(rerender_insights, [lang, s_panel], ins, trigger_mode=LATEST, show_progress="hidden", api_visibility="private")

        def do_evaluate(auto_on, lg):
            pm, r = be.evaluate_prepared(auto_on)
            return render_insights(pm, be.info(), lg), pm, r

        evaluate.click(do_evaluate, [auto, lang], [ins, s_panel, rid], show_progress_on=[ins], api_name="evaluate_prepared") \
            .then(write, [rid, auto, lang], [ins, s_panel], trigger_mode=LATEST, show_progress="minimal", api_visibility="private") \
            .then(rerender_insights, [lang, s_panel], ins, trigger_mode=LATEST, show_progress="hidden", api_visibility="private")

        # ---- documents -------------------------------------------------------------------------------------------------
        def on_upload(paths, lg):
            rep, changed, r = be.upload({Path(p).name: Path(p).read_bytes() for p in (paths or [])})
            info = be.info()
            rep = {**rep, "stale": changed}
            out_res = out_ins = out_tr = out_meas = s_res_v = s_panel_v = s_tr_v = gr.skip()
            if changed:                                      # the answers on the screen describe the old documents
                s_res_v, s_panel_v, s_tr_v = {"stale": True}, {"state": "stale"}, None
                out_res, out_ins = render_results(s_res_v, info, lg, part="answers"), render_insights(s_panel_v, info, lg)
                out_tr, out_meas = tr_button(lg, False), ""
            return (render_docs(info, lg, rep), render_corpus(info, lg), out_res, out_ins, rep, s_res_v, s_panel_v, s_tr_v,
                    (r if r is not None else gr.skip()), out_tr, out_meas)

        upload.upload(on_upload, [upload, lang], [docs, corpus, results, ins, s_up, s_res, s_panel, s_tr, rid, translate_btn, measured],
                      api_name="add_pdf")
    ui.backend = be  # for tests and notebooks
    return ui


_EXAMPLE_KEYS = {f"example.{qid}" for qid, _ in PREPARED}


def example_label(e: dict, lang: str) -> str:
    key = f"example.{e['id']}"
    return t(key, lang) if key in _EXAMPLE_KEYS else e["label"]
