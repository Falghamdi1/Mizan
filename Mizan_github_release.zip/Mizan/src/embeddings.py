"""Embedding model -- one model, shared by both pipelines.

Default: intfloat/multilingual-e5-small (multilingual, covers Arabic, ~118M params, runs on CPU).
It expects "query: " / "passage: " prefixes, which are added here.

Target models (set MIZAN_EMBEDDING_MODEL): Qwen/Qwen3-Embedding-0.6B (test), Qwen/Qwen3-Embedding-4B (final).
Qwen3's tokenizer is byte-level BPE WITHOUT Unicode normalization, unlike e5's SentencePiece (which NFKC-folds),
so Arabic preprocessing may matter more here.

Fallback (MIZAN_EMBEDDER=hash): a dependency-free character-n-gram hashing embedder so the whole
pipeline can run offline. It is lexical, NOT semantic -- good for smoke tests, not for conclusions.
"""
from __future__ import annotations

import hashlib
import re
from functools import lru_cache

import numpy as np

from .config import SETTINGS


class HashingEmbedder:
    name = "hash-char-ngram-1024"
    dim = 1024

    def _vec(self, text: str) -> np.ndarray:
        v = np.zeros(self.dim, dtype=np.float32)
        t = " " + re.sub(r"\s+", " ", text) + " "
        for n in (3, 4):
            for i in range(len(t) - n + 1):
                h = int.from_bytes(hashlib.md5(t[i:i + n].encode("utf-8")).digest()[:4], "little")
                v[h % self.dim] += 1.0
        norm = np.linalg.norm(v)
        return v / norm if norm else v

    def embed_passages(self, texts: list[str]) -> np.ndarray:
        return np.stack([self._vec(t) for t in texts])

    def embed_query(self, text: str) -> np.ndarray:
        return self._vec(text)

    def count_tokens(self, texts: list[str]) -> list[int]:
        return [len(t.split()) for t in texts]  # whitespace words: approximate, labelled as such

    token_unit = "whitespace words (approx.)"


class STEmbedder:
    """sentence-transformers backend. Handles e5 (query:/passage: prefixes) and Qwen3-Embedding
    (instruction-prefixed queries, last-token pooling, left padding; documents get no prefix).
    Optional LoRA adapter (MIZAN_EMBEDDING_ADAPTER) for a fine-tuned Qwen3-Embedding."""

    def __init__(self, model_name: str):
        import torch
        from sentence_transformers import SentenceTransformer

        self.name = model_name
        low = model_name.lower()
        self._is_e5 = "e5" in low
        self._is_qwen = "qwen3-embedding" in low
        cuda = torch.cuda.is_available()
        kwargs = {}
        quant = SETTINGS.embed_quant if cuda else "none"
        if self._is_qwen:
            from .memory import half_dtype  # float16 on T4-class GPUs (no native bfloat16); CPU: float32

            mk = {"torch_dtype": half_dtype() if cuda else torch.float32}
            if cuda:
                mk["device_map"] = {"": 0}  # load straight onto the GPU: no full copy in CPU RAM
            if quant == "4bit":
                from transformers import BitsAndBytesConfig

                mk["quantization_config"] = BitsAndBytesConfig(
                    load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=half_dtype())
            kwargs["model_kwargs"] = mk
            kwargs["tokenizer_kwargs"] = {"padding_side": "left"}
        self.quant = quant
        self._batch = SETTINGS.embed_batch_size
        self.model = SentenceTransformer(model_name, device=None if (cuda and self._is_qwen) else ("cuda" if cuda else "cpu"), **kwargs)  # device_map decides on GPU
        self.model.max_seq_length = SETTINGS.max_seq_length
        adapter = SETTINGS.embedding_adapter
        if adapter:
            from pathlib import Path

            from .config import ROOT

            if not Path(adapter).is_absolute():
                adapter = str(ROOT / adapter)  # works from any working directory
            self.model.load_adapter(adapter)  # needs `pip install peft`
            self.name = f"{model_name}+lora:{adapter}"
        dim = getattr(self.model, "get_embedding_dimension", None) or self.model.get_sentence_embedding_dimension  # older ST
        self.dim = dim()
        self.token_unit = "embedding-model tokens"
        self._query_prompt = f"Instruct: {SETTINGS.query_instruction}\nQuery:" if self._is_qwen else None

    def embed_passages(self, texts: list[str]) -> np.ndarray:
        if self._is_e5:
            texts = [f"passage: {t}" for t in texts]
        while True:
            try:
                return self.model.encode(texts, normalize_embeddings=True, batch_size=self._batch, show_progress_bar=False)
            except Exception as e:  # CUDA out of memory: halve the batch and retry (embeddings do not depend on batch size)
                from . import memory

                if not memory.is_oom(e) or self._batch == 1:
                    raise
                memory.free()
                self._batch = max(1, self._batch // 2)
                print(f"  GPU out of memory while embedding: retrying with batch size {self._batch}", flush=True)

    def embed_query(self, text: str) -> np.ndarray:
        if self._is_e5:
            text = f"query: {text}"
        extra = {"prompt": self._query_prompt} if self._query_prompt else {}
        return self.model.encode([text], normalize_embeddings=True, show_progress_bar=False, **extra)[0]

    def count_tokens(self, texts: list[str]) -> list[int]:
        tok = self.model.tokenizer
        return [len(ids) for ids in tok(texts, add_special_tokens=False)["input_ids"]]


def release() -> None:
    """Unload the embedder (frees its GPU memory)."""
    get_embedder.cache_clear()


@lru_cache(maxsize=1)
def get_embedder():
    if SETTINGS.embedder == "hash":
        return HashingEmbedder()
    return STEmbedder(SETTINGS.embedding_model)
