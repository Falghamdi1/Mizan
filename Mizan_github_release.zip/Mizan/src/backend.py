"""The state and the logic behind the interface, without Gradio and without any display language.

`MizanBackend` runs the repository's pipelines (src/comparison.py), the citation check, the upload path and Mizan Insights
(src/insights_evidence.py builds the facts, src/insights.py has the model explain them and checks every statement), and returns plain
dicts. src/ui.py renders those dicts in English or Arabic, so switching the interface language never re-runs a model and never changes a
measured value, a retrieved passage or a generated text.

    backend = MizanBackend(pages, pipes, questions, synthetic, data_dir)
    backend.info()                                   # pipelines, corpus, prepared questions, settings, notices (codes, not sentences)
    res, panel, rid = backend.ask("ما مدة الترخيص؟")    # both pipelines on the same question; the Insights panel model
    panel = backend.generate(rid)                    # the analysis for that run (None = a newer run started; leave the screen)

The behaviour is the one the earlier Session class had (and tests/test_app_backend.py keeps checking): one shared corpus and set of
indexes, runs numbered so a late result of an old run is dropped, and a change of the document set removes the comparison, the insights
and any earlier prepared-question evaluation, so an old analysis can never sit under a new run.
"""
from __future__ import annotations

import hashlib
import re
import time
from pathlib import Path

from . import citations, insights, insights_evidence, monitoring, safety
from .comparison import compare
from .config import RAW_DIR, SETTINGS
from .ingestion import load_pdfs, pages_fingerprint
from .preprocessing import canonical_for_eval, get_config
from .rag import LLMError, Pipeline, call_llm
from .titles import topic_of
from .ui_theme import is_abstention

MOCK_PREFIX = "[MOCK LLM - no answer generated; showing top retrieved passage]"
MAX_PDF_MB = 60
# one-click questions (ids in eval/questions.json, kept out of the public repository): a plain fact, a fee from a table, a deadline,
# a visa rule and one the documents cannot answer. The labels are i18n keys (src/i18n.py: example.<id>).
PREPARED = [("r1", "Licence term"), ("r3", "Licence fee"), ("r5", "Renewal deadline"), ("r7", "Tourist visa"), ("r10", "Not in the documents")]
KIND = {"baseline": "standard"}
# A reading aid for people who do not read Arabic. It is a separate call to the configured generator on the finished answers: the answers,
# the prompt of the experiment and every measurement stay exactly as they are, and the screen labels the result as a machine translation.
TRANSLATE_SYSTEM = ("Translate the user's Arabic text into clear English. Translate faithfully: do not add, remove, correct or explain anything. "
                    "Keep numbers, file names and citations in square brackets exactly as they are. Reply with the translation only.")


def kind_of(name: str, index: int) -> str:
    return KIND.get(name, "standard" if index == 0 else "mizan")


def english_title(doc: str) -> str:
    """A readable English name from the file name itself (no invented titles): 'Tour-Guide-Regulations-Ar-V012.pdf' -> 'Tour Guide Regulations'."""
    stem = Path(doc).stem
    stem = re.sub(r"[-_ ]?(Ar|AR|ar)?[-_ ]?V\d+$", "", stem)
    stem = re.sub(r"[-_]+", " ", stem).strip()
    return stem or doc


# ---- upload ----------------------------------------------------------------------------------------------------------
def _log_ingestion_problems(skipped: list[dict]) -> None:
    """Rejected or damaged uploads are monitored events (counts and a short code, never file content)."""
    if monitoring.enabled():
        for _ in skipped:
            monitoring.get_monitor().record_event("ingestion_error", "upload", "rejected")


def ingest_pdfs(files: dict[str, bytes], state: dict, pipes: dict[str, Pipeline], data_dir: Path = RAW_DIR) -> dict:
    """Save uploaded PDFs next to the others and re-index every pipeline from the same pages. `state["pages"]` is updated.
    Duplicates (same SHA-256), non-PDFs and unreadable or scanned files are rejected; the existing corpus is never damaged.
    Returns {"added": [names], "skipped": [{"name", "reason"}], "warnings": [{"name", "kind", "pages", "detail"}], "seconds", "error"}."""
    data_dir = Path(data_dir)
    known = {hashlib.sha256(f.read_bytes()).hexdigest() for f in data_dir.glob("*.pdf")}
    saved, skipped, warnings = [], [], []
    for raw_name, data in files.items():
        name = re.sub(r"[^\w.\-]+", "_", Path(raw_name).name)
        name = name if name.lower().endswith(".pdf") else name + ".pdf"
        if not data.startswith(b"%PDF"):
            skipped.append({"name": raw_name, "reason": "not_pdf"})
        elif len(data) > MAX_PDF_MB * 2**20:
            skipped.append({"name": raw_name, "reason": "too_large"})
        elif hashlib.sha256(data).hexdigest() in known:
            skipped.append({"name": raw_name, "reason": "duplicate"})
        else:
            target, n = data_dir / name, 1
            while target.exists():  # same name, different content
                target, n = data_dir / f"{Path(name).stem}_{n}.pdf", n + 1
            target.write_bytes(data)
            saved.append(target)
            known.add(hashlib.sha256(data).hexdigest())
    out = {"added": [], "skipped": skipped, "warnings": warnings, "seconds": None, "error": ""}
    if not saved:
        _log_ingestion_problems([s for s in skipped if s["reason"] != "duplicate"])
        return out
    try:
        readable = {p.doc for p in load_pdfs(data_dir)}
    except RuntimeError:  # nothing readable at all
        readable = set()
    for f in [f for f in saved if f.name not in readable]:  # corrupt or scanned: reject, keep the corpus as it was
        f.unlink(missing_ok=True)
        saved.remove(f)
        skipped.append({"name": f.name, "reason": "unreadable"})
    if not saved:
        _log_ingestion_problems([s for s in skipped if s["reason"] != "duplicate"])
        return out
    t0 = time.perf_counter()
    state["pages"] = load_pdfs(data_dir)
    names = sorted(f.name for f in saved)
    for n in names:  # kept for Mizan Insights: which documents came from uploads and what the upload scan found (counts and page numbers only)
        doc_pages = [p for p in state["pages"] if p.doc == n]
        state.setdefault("uploaded", [])
        if n not in state["uploaded"]:
            state["uploaded"].append(n)
        state.setdefault("upload_notes", {})[n] = safety.upload_warnings(doc_pages)
        inj = sorted({p.page for p in doc_pages if safety.scan_injection(p.text)})
        pii: dict[str, int] = {}
        for p in doc_pages:
            for k, v in safety.scan_pii(p.text).items():
                pii[k] = pii.get(k, 0) + v
        if inj:
            warnings.append({"name": n, "kind": "injection", "pages": inj[:6], "detail": ""})
        if pii:
            warnings.append({"name": n, "kind": "personal_data", "pages": [], "detail": ", ".join(f"{k}: {v}" for k, v in pii.items())})
    _log_ingestion_problems([s for s in skipped if s["reason"] != "duplicate"])
    for p in pipes.values():  # same documents for every pipeline
        p.build(state["pages"])
    out.update(added=names, seconds=round(time.perf_counter() - t0, 1))
    return out


def upload_message_en(r: dict) -> str:
    """The English one-line report of an upload (also what the older string API returned)."""
    reasons = {"not_pdf": "not a PDF, skipped", "too_large": f"larger than {MAX_PDF_MB} MB, skipped", "duplicate": "already loaded, skipped",
               "unreadable": "no readable text (scanned or damaged), rejected"}
    parts = []
    if r["added"]:
        parts.append(f"Added {', '.join(r['added'])}; re-indexed both pipelines in {r['seconds']:.0f} s.")
    parts += [f"{s['name']}: {reasons.get(s['reason'], s['reason'])}" for s in r["skipped"]]
    for w in r["warnings"]:
        if w["kind"] == "injection":
            parts.append(f"{w['name']}: instruction-like text on page(s) {w['pages']}: those passages will be withheld from the model")
        else:
            parts.append(f"{w['name']}: possible personal data ({w['detail']}): the file is stored on this runtime's disk until you delete it")
    if r.get("error"):
        parts.append(r["error"])
    return " ".join(parts) or "No file received."


def add_pdfs(files: dict[str, bytes], state: dict, pipes: dict[str, Pipeline], data_dir: Path = RAW_DIR) -> str:
    """ingest_pdfs, reported as one English line (the API notebooks and tests use)."""
    return upload_message_en(ingest_pdfs(files, state, pipes, data_dir))


# ---- one pipeline's answer as plain data -------------------------------------------------------------------------------
def _relevant(passage, gold: dict | None) -> bool | None:
    """Same rule as evaluation.score: a fixed canonicalizer, and only the gold documents count."""
    if not gold or not gold.get("gold_evidence"):
        return None
    if gold.get("gold_docs") and passage.doc not in gold["gold_docs"]:
        return False
    text = canonical_for_eval(passage.text)
    return any((c := canonical_for_eval(ph)) and c in text for g in gold["gold_evidence"] for ph in g)


def pipeline_result(name: str, r, sc: dict | None, gold: dict | None, kind: str = "mizan") -> dict:
    answer, answer_kind = r.answer, "generated"
    if answer.startswith(MOCK_PREFIX):
        answer, answer_kind = answer.removeprefix(MOCK_PREFIX).strip(), "passage"
    abstained = is_abstention(r.answer)
    cites = None
    if answer_kind == "generated" and not abstained and (r.answer or "").strip():
        c = citations.check(r.answer, r.meta.get("shown", r.passages))
        cites = {"cited": c["n_cited"], "valid": c["n_valid"], "invalid": c["n_invalid"]}
    if not gold:
        evidence = None
    elif not gold.get("gold_evidence"):
        evidence = "unanswerable"
    else:
        evidence = "found" if sc and sc.get("hit") else "missing"
    withheld = {(w["doc"], w["page"]) for w in r.meta.get("withheld") or []}
    return {
        "id": name, "kind": kind, "answer": answer, "answer_kind": answer_kind, "abstained": abstained, "cached": bool(r.llm.cached),
        "evidence": evidence, "evidence_rank": sc.get("first_relevant_rank") if sc else None,
        "sources": [{"rank": x.rank, "title": topic_of(x.doc), "title_en": english_title(x.doc), "doc": x.doc, "page": x.page, "text": x.text,
                     "score": x.score, "rerank": x.rerank_score, "tokens": x.tokens, "relevant": _relevant(x, gold),
                     "withheld": (x.doc, x.page) in withheld} for x in r.passages],
        "tokens": {"retrieved": r.retrieved_tokens, "input": r.llm.input_tokens, "output": r.llm.output_tokens},
        "latency": {"retrieval_s": r.retrieval_latency_s, "generation_s": r.llm.latency_s},
        "citations": cites,
        "withheld": len(r.meta.get("withheld") or []),
    }


# ---- Mizan Insights as plain data ---------------------------------------------------------------------------------------
def evidence_view(ev) -> dict:
    return {"scope": ev.scope, "facts": [{"id": f["id"], "text": f["text"]} for f in ev.facts], "not_measured": list(ev.not_measured),
            "unsupported": list(ev.unsupported_claims), "notes": list(ev.meta.get("notes", [])), "documents": ev.meta.get("documents"),
            "pages": ev.meta.get("pages"), "corpus_fp": ev.meta.get("corpus_fingerprint"), "uploaded": list(ev.meta.get("uploaded") or []),
            "lang": ev.lang, "blocking": list(ev.blocking)}


def result_view(r) -> dict:
    return {"status": r.status, "message": r.message, "sections": r.sections, "model": r.model, "attempts": r.attempts,
            "from_cache": r.from_cache, "input_tokens": r.input_tokens, "output_tokens": r.output_tokens, "latency_s": r.latency_s,
            "errors": list(r.errors)}


def panel(state: str, ev=None, result=None, code: str = "", message: str = "") -> dict:
    """The Insights panel model. state: none | stale | message | loading | idle | ready."""
    return {"state": state, "code": code, "message": message, "evidence": evidence_view(ev) if ev is not None else None,
            "result": result_view(result) if result is not None else None}


class MizanBackend:
    def __init__(self, pages, pipes: dict[str, Pipeline], questions: list[dict], synthetic: bool = False, data_dir: Path = RAW_DIR):
        self.pipes, self.questions, self.synthetic, self.data_dir = pipes, questions, synthetic, Path(data_dir)
        self.state = {"pages": pages, "uploaded": [], "upload_notes": {}, "run_id": 0, "last": None, "aggregate": None, "evidence": None,
                      "insights": None}
        self.gold = {q["question"]: q for q in questions}

    # ---- what the screen shows before any question ------------------------------------------------------------------
    def examples(self) -> list[dict]:
        by_id = {q["id"]: q for q in self.questions}
        picked = [{"id": qid, "label": lbl, "question": by_id[qid]["question"]} for qid, lbl in PREPARED if qid in by_id]
        if picked or not self.questions:
            return picked
        # another question file (the synthetic sample): its first questions, named by their opening words
        return [{"id": q["id"], "label": " ".join(q["question"].split()[:4]), "question": q["question"]} for q in self.questions[:5]]

    def info(self) -> dict:
        pages, names = self.state["pages"], list(self.pipes)
        from .comparison import get_embedder_name
        return {
            "pipelines": [{"id": n, "kind": kind_of(n, i), "steps": get_config(n).enabled() or ["collapse_whitespace"],
                           "chunks": self.pipes[n].index_stats.get("chunks"), "index_tokens": self.pipes[n].index_stats.get("tokens")}
                          for i, n in enumerate(names)],
            "corpus": {"documents": len({p.doc for p in pages}), "pages": len(pages), "uploaded": list(self.state["uploaded"])},
            "examples": self.examples(),
            "settings": {"embedder": get_embedder_name().split("+lora:")[0].split("/")[-1],
                         "reranker": SETTINGS.reranker.split("/")[-1] if SETTINGS.reranker else "",
                         "rerank_top_n": SETTINGS.rerank_top_n, "top_k": SETTINGS.top_k, "chunk_size": SETTINGS.chunk_size,
                         "chunk_overlap": SETTINGS.chunk_overlap, "chunk_title": bool(SETTINGS.chunk_title),
                         "generator": "" if SETTINGS.llm_provider == "mock" else SETTINGS.llm_model.split("/")[-1],
                         "provider": SETTINGS.llm_provider, "prompt": SETTINGS.prompt_version},
            "synthetic": self.synthetic,
            "mock": SETTINGS.llm_provider == "mock",
            "upload_max_mb": MAX_PDF_MB,
            "insights_auto": insights.enabled(),
            "insights_unavailable": bool(insights.unavailable_reason()),
            "can_evaluate": any("gold_evidence" in q for q in self.questions),
            "n_prepared": sum("gold_evidence" in q for q in self.questions),
        }

    # ---- runs ------------------------------------------------------------------------------------------------------
    def new_run(self) -> int:
        self.state["run_id"] += 1
        self.state["evidence"] = self.state["insights"] = None
        return self.state["run_id"]

    def current_evidence(self):
        """Evidence of the state now: the last comparison and the prepared-question evaluation, each only if it belongs to the documents
        loaded now."""
        st = self.state
        fp = pages_fingerprint(st["pages"])
        if st["last"] and st["last"]["pages_fp"] != fp:
            st["last"] = None
        if st["aggregate"] and st["aggregate"]["corpus_sha256"] != fp:
            st["aggregate"] = None
        last = st["last"]
        return insights_evidence.build_evidence(
            pipes=self.pipes, pages=st["pages"], cmp=last and last["cmp"], question=last and last["question"], gold=last and last["gold"],
            gold_source=last["gold_source"] if last else "none", aggregate_eval=st["aggregate"], uploaded=st["uploaded"],
            upload_notes=st["upload_notes"], lang=insights.language())

    def prepare_panel(self, auto_on: bool) -> dict:
        """Build the evidence (no model) and return the panel model: loading, idle, or why no analysis is possible."""
        try:
            ev = self.current_evidence()
        except insights_evidence.EvidenceError as e:
            return panel("message", code="evidence_error", message=str(e))
        except Exception as e:  # noqa: BLE001 - the comparison must stay usable whatever goes wrong here
            return panel("message", code="evidence_failed", message=type(e).__name__)
        self.state["evidence"] = ev
        if ev.blocking or insights.unavailable_reason():
            self.state["insights"] = insights.generate_insights(ev)         # no model call: it only explains why there is none
            return panel("ready", ev, self.state["insights"])
        return panel("loading" if auto_on else "idle", ev)

    def ask(self, question: str, phrase: str = "", auto_on: bool = True) -> tuple[dict, dict, int]:
        """Run the question through every pipeline. Returns (result, insights panel model, run number)."""
        question, phrase = (question or "").strip(), (phrase or "").strip()
        if not question:
            return {"empty": True}, panel("none"), self.state["run_id"]
        rid = self.new_run()
        self.state["last"] = None
        if phrase:      # the user says which words in the documents answer the question: relevance can be measured for a free-text question
            q, source = {"id": "user", "type": "user", "question": question, "gold_evidence": [[phrase]]}, "user_phrase"
        else:
            q, source = self.gold.get(question), "prepared" if self.gold.get(question) else "none"
        t0 = time.perf_counter()
        try:
            cmp = compare(self.pipes, question, gold=q)
        except (LLMError, RuntimeError) as e:  # a visible message, never a stack trace in the middle of a demo
            return {"error": str(e) or type(e).__name__}, panel("message", code="comparison_failed"), rid
        names = list(self.pipes)
        self.state["last"] = {"question": question, "cmp": cmp, "gold": q, "gold_source": source, "pages_fp": pages_fingerprint(self.state["pages"])}
        res = {"question": question, "gold_source": source, "reference": (q or {}).get("reference_answer"), "phrase": phrase,
               "pipelines": [pipeline_result(n, cmp[n]["result"], cmp[n]["score"], q, kind_of(n, i)) for i, n in enumerate(names)],
               "elapsed_s": time.perf_counter() - t0, "run_id": rid, "monitor": self.monitor()}
        return res, self.prepare_panel(auto_on), rid

    def generate(self, rid: int, auto_on: bool = True, force: bool = False) -> dict | None:
        """Write the insights for run `rid`. None = leave the screen as it is (superseded, already explained, or generation is off)."""
        st = self.state
        ev = st["evidence"]
        if ev is None or rid != st["run_id"] or st["insights"] is not None or not (auto_on or force):
            return None
        result = insights.generate_insights(ev, force=force)
        if rid != st["run_id"]:
            return None      # a newer run started while the model was writing: this text no longer describes the screen
        st["insights"] = result
        return panel("ready", ev, result)

    def regenerate_start(self) -> tuple[dict, int]:
        if self.state["evidence"] is None:
            return panel("none"), self.state["run_id"]
        self.state["insights"] = None
        return panel("loading", self.state["evidence"]), self.state["run_id"]

    def regenerate(self, rid: int) -> dict | None:
        return self.generate(rid, True, force=True)

    def evaluate_prepared(self, auto_on: bool = True) -> tuple[dict, int]:
        """Retrieval-only evaluation of the prepared questions on the current documents, then a new analysis that includes it."""
        qs = [q for q in self.questions if "gold_evidence" in q]
        if not qs:
            return panel("message", code="no_prepared"), self.state["run_id"]
        try:
            self.state["aggregate"] = insights_evidence.evaluate_prepared(self.pipes, qs, self.state["pages"], f"{len(qs)} prepared evaluation questions")
        except (LLMError, RuntimeError) as e:
            return panel("message", code="evaluation_failed", message=str(e)), self.state["run_id"]
        rid = self.new_run()
        return self.prepare_panel(auto_on), rid

    def translate(self, rid: int) -> dict | None:
        """English translations of the answers of run `rid`, for reading only. None = that run is no longer on the screen."""
        last = self.state["last"]
        if last is None or rid != self.state["run_id"]:
            return None
        if SETTINGS.llm_provider == "mock":
            return {"run_id": rid, "status": "unavailable", "texts": {}, "model": ""}
        texts = {}
        try:
            for name, entry in last["cmp"].items():
                answer = entry["result"].answer
                texts[name] = call_llm(answer, [], system=TRANSLATE_SYSTEM, max_tokens=500).text.strip() if answer.strip() else ""
        except LLMError as e:
            return {"run_id": rid, "status": "failed", "texts": {}, "model": "", "message": str(e)}
        if rid != self.state["run_id"]:
            return None
        return {"run_id": rid, "status": "ok", "texts": texts, "model": f"{SETTINGS.llm_provider}:{SETTINGS.llm_model}"}

    def upload(self, files: dict[str, bytes]) -> tuple[dict, bool, int | None]:
        """Add PDFs and, if the document set changed, drop everything computed on the old one.
        Returns (upload report, changed, run number or None)."""
        before = pages_fingerprint(self.state["pages"])
        try:
            rep = ingest_pdfs(files, self.state, self.pipes, self.data_dir)
        except Exception as e:  # noqa: BLE001 - e.g. out of memory while re-indexing: the pages are new but an index may still be the old one
            rep = {"added": [], "skipped": [], "warnings": [], "seconds": None, "error": type(e).__name__}
        if pages_fingerprint(self.state["pages"]) == before:
            return rep, False, None
        rid = self.new_run()
        self.state["last"] = self.state["aggregate"] = None
        return rep, True, rid

    # ---- monitoring --------------------------------------------------------------------------------------------------
    @staticmethod
    def monitor() -> dict | None:
        """The rolling numbers of src/monitoring.py per pipeline and the active alert rules. None when monitoring is off or empty."""
        if not monitoring.enabled():
            return None
        m = monitoring.get_monitor()
        summ = m.summary()
        if not summ:
            return None
        return {"window": m.cfg.window, "pipelines": summ,
                "alerts": [{"rule": a.rule, "pipeline": a.pipeline, "message": a.message} for a in m.check_alerts()]}
