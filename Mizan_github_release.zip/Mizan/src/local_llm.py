"""In-process local generator and judge (Hugging Face transformers), for runtimes without an Ollama daemon (Colab).

    MIZAN_LLM_PROVIDER=hf        MIZAN_LLM_MODEL=Qwen/Qwen3-4B-Instruct-2507
    MIZAN_JUDGE_PROVIDER=hf      MIZAN_JUDGE_MODEL=ibm-granite/granite-3.3-2b-instruct
    MIZAN_HF_QUANT=4bit | none   (4bit = NF4, about 2.4 GiB for the 4B model; none = 16-bit, about 8 GiB)

Weights come from the Hugging Face Hub once; all inference runs on the local GPU. No API key. Decoding is greedy
(temperature 0), the same for every provider.

Memory: only ONE model is resident here at a time. Asking for a different model first unloads the current one and
frees its GPU memory, so the generator and the judge never sit in memory together (the judge is used only after all
answers exist). Switching back reloads from the local disk cache (about 15-30 s).
"""
from __future__ import annotations

from .config import SETTINGS
from . import memory

_CUR: dict = {}  # {"key": (model_id, quant), "tok": ..., "model": ...}


def release() -> None:
    """Unload the resident model and return its GPU memory."""
    _CUR.clear()
    memory.free()


def load(model_id: str, quant: str | None = None):
    """Return (tokenizer, model); loads (and downloads on first use) when `model_id` is not the resident model."""
    quant = (quant or SETTINGS.hf_quant or "4bit").lower()
    quant = "4bit" if quant == "auto" else quant  # "auto" was an older spelling of the default
    key = (model_id, quant)
    if _CUR.get("key") == key:
        return _CUR["tok"], _CUR["model"]
    release()  # unload the previous model BEFORE loading the next one: peak memory is the larger, not the sum
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

    if not torch.cuda.is_available():
        raise RuntimeError("The local generator needs a GPU runtime (Colab: Runtime > Change runtime type > T4 GPU). "
                           "Without a GPU run retrieval only: MIZAN_LLM_PROVIDER=mock.")
    dtype = memory.half_dtype()
    kwargs = {"device_map": {"": 0}}
    if quant == "4bit":
        kwargs["quantization_config"] = BitsAndBytesConfig(
            load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=dtype)
    tok = AutoTokenizer.from_pretrained(model_id)
    try:
        model = AutoModelForCausalLM.from_pretrained(model_id, dtype=dtype, **kwargs)
    except TypeError:  # transformers < 4.56 calls the argument torch_dtype
        model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype=dtype, **kwargs)
    _CUR.update(key=key, tok=tok, model=model.eval())
    return tok, _CUR["model"]


def generate(model_id: str, system: str, user: str, max_new_tokens: int, quant: str | None = None) -> tuple[str, int, int]:
    """Greedy answer. Returns (text, prompt tokens, generated tokens)."""
    import torch

    tok, model = load(model_id, quant)
    chat = ([{"role": "system", "content": system}] if system else []) + [{"role": "user", "content": user}]
    prompt = tok.apply_chat_template(chat, tokenize=False, add_generation_prompt=True, enable_thinking=False)
    enc = tok(prompt, return_tensors="pt", add_special_tokens=False).to(model.device)
    try:
        with torch.inference_mode():
            out = model.generate(**enc, max_new_tokens=max_new_tokens, do_sample=False, temperature=None, top_p=None,
                                 top_k=None, pad_token_id=tok.pad_token_id or tok.eos_token_id)
    except torch.cuda.OutOfMemoryError as e:
        memory.free()
        raise RuntimeError("GPU out of memory while generating. Use a smaller profile (compact) or MIZAN_MAX_TOKENS lower.") from e
    new = out[0, enc["input_ids"].shape[1]:].tolist()
    eos = model.generation_config.eos_token_id
    eos = set(eos if isinstance(eos, list) else [eos])
    while new and new[-1] in eos:  # the end-of-turn marker is not part of the answer
        new.pop()
    return tok.decode(new, skip_special_tokens=True).strip(), enc["input_ids"].shape[1], len(new)


def model_info(model_id: str) -> dict:
    """Facts for the notebook's model table (read from the loaded model, not typed in)."""
    tok, model = load(model_id)
    return {"parameters_b": round(model.num_parameters() / 1e9, 2),
            "gpu_memory_gib": round(model.get_memory_footprint() / 2**30, 2)}
