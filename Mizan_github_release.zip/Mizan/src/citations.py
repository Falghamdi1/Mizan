"""Citation check: does an answer cite sources that were really retrieved, and do they point at the right place?

The generator prompt (src/rag.py) asks for `[اسم الملف، صفحة N]` after every claim, using the file name and page number from the
passage headers. This module parses those markers and compares them with the passages the model was shown. It needs no LLM
and no judge, so it is cheap, deterministic and usable both in the evaluation (src/evaluation.py) and in live monitoring
(src/monitoring.py).

Definitions (per answer; all are surface checks on the marker, not on whether the claim itself is true):
  cited            number of markers found
  valid            markers naming a (file, page) that is among the passages shown to the model
  invalid          cited - valid: a source the model was never given (a fabricated or mistyped citation)
  matched          indices of the shown passages that a valid marker points at
  cites_gold       (evaluation only) at least one matched passage contains the gold evidence: the answer cites the passage that
                   answers the question. Judged with the same fixed canonicalizer as retrieval, so no pipeline is favoured.

What this does NOT establish: that the cited passage supports the sentence it follows (faithfulness needs a human or a validated
judge), or that an answer without markers is wrong. A page can hold several chunks; a marker is valid if ANY shown chunk has that
page, so `cites_gold` is the stricter number.
"""
from __future__ import annotations

import re

# [file، صفحة 8]  [file, page 8]  [file، ص 8]  (Arabic or Latin comma, Arabic-Indic digits allowed)
CITE = re.compile(r"\[\s*([^\[\]،,]+?)\s*[،,]\s*(?:صفحة|صفحه|ص|page|p\.?)\s*([0-9٠-٩]+)\s*\]", re.IGNORECASE)
_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")
_MIN_PARTIAL = 8  # a shortened file name must be at least this long to count as a match by containment


def _norm(name: str) -> str:
    n = name.strip().lower().replace("\\", "/")
    return re.sub(r"\.(pdf|html?|json)$", "", n)


def _same_source(cited: str, doc: str) -> bool:
    c, d = _norm(cited), _norm(doc)
    if not c:
        return False
    if c == d or c.split("/")[-1] == d.split("/")[-1]:
        return True                                     # whole path, or the file name without its folder / extension
    return len(c) >= _MIN_PARTIAL and (c in d or d in c)   # a shortened name ("Tour-Guide-Regulations")


def parse(answer: str) -> list[tuple[str, int]]:
    return [(m.group(1), int(m.group(2).translate(_DIGITS))) for m in CITE.finditer(answer or "")]


def check(answer: str, passages: list) -> dict:
    """{"n_cited", "n_valid", "n_invalid", "matched": sorted indices into `passages`} for one answer."""
    cited = parse(answer)
    matched: set[int] = set()
    valid = 0
    for name, page in cited:
        hit = [i for i, p in enumerate(passages) if int(p.page) == page and _same_source(name, p.doc)]
        if hit:
            valid += 1
            matched.update(hit)
    return {"n_cited": len(cited), "n_valid": valid, "n_invalid": len(cited) - valid, "matched": sorted(matched)}
