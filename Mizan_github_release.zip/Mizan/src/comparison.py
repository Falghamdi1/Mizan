"""Side-by-side comparison of pipelines for ONE question (used by app.py and demo.py), plus a
"what exactly changed" report on the preprocessing itself."""
from __future__ import annotations

from . import monitoring
from .evaluation import fmt, score
from .ingestion import Page, load_pdfs
from .preprocessing import get_config, preprocess_pages, preprocess_text, presentation_form_ratio, step_report
from .rag import Pipeline, RAGResult


def compare(pipelines: dict[str, Pipeline], question: str, gold: dict | None = None) -> dict[str, dict]:
    """Run every pipeline on the same question. `gold` is an optional eval question dict with
    gold_evidence; without it, relevance metrics are reported as n/a (never guessed)."""
    out = {}
    mon = monitoring.get_monitor() if monitoring.enabled() else None
    for name, p in pipelines.items():
        try:
            r: RAGResult = p.ask(question)
        except Exception as e:
            if mon:
                mon.record_error(name, question, e)
                mon.after_answer()
            raise
        if mon:
            mon.record(r)
        out[name] = {"result": r, "score": score(gold or {}, r) if gold else None}
    if mon:
        mon.after_answer()  # rules + notification once per question, after every pipeline has answered
    return out


def metric_rows(cmp: dict[str, dict]) -> list[list[str]]:
    """[[metric, value per pipeline...]] -- only measured values; n/a otherwise."""
    names = list(cmp)

    def col(f):
        return [f(cmp[n]) for n in names]

    rows = [
        ["Hit@k (needs gold evidence)"] + col(lambda c: fmt(c["score"]["hit"]) if c["score"] else "n/a"),
        ["Precision@k (needs gold evidence)"] + col(lambda c: fmt(c["score"]["precision"]) if c["score"] else "n/a"),
        ["Top-1 similarity"] + col(lambda c: fmt(c["result"].passages[0].score) if c["result"].passages else "n/a"),
        ["Retrieved tokens (embedding tokenizer)"] + col(lambda c: str(c["result"].retrieved_tokens)),
        ["LLM input tokens"] + col(lambda c: fmt(c["result"].llm.input_tokens)),
        ["LLM output tokens"] + col(lambda c: fmt(c["result"].llm.output_tokens)),
        ["Retrieval latency (s)"] + col(lambda c: fmt(c["result"].retrieval_latency_s)),
        ["LLM latency (s)" + (" [cached]" if any(cmp[n]["result"].llm.cached for n in names) else "")]
        + col(lambda c: fmt(c["result"].llm.latency_s)),
        ["Answer quality"] + ["not auto-measurable; read the answers"] * len(names),
    ]
    return rows


def sources_text(r: RAGResult) -> str:
    return "\n".join(f"{p.rank}. Source: {p.doc} — page {p.page}  (sim {p.score:.3f}, {p.tokens} tok)" for p in r.passages)


def effect_report(pages: list[Page], names: list[str]) -> str:
    """What does each preprocessing config actually do to the corpus? (chars; tokens need the embedder)"""
    raw_chars = sum(len(p.text) for p in pages)
    lines = [f"Raw corpus: {len(pages)} pages, {raw_chars} characters"]
    for doc in dict.fromkeys(p.doc for p in pages):
        r = presentation_form_ratio("".join(p.text for p in pages if p.doc == doc))
        lines.append(f"  extraction check {doc}: {r:.0%} of Arabic characters are presentation forms (U+FB50-FEFF)")
    for n in names:
        cfg = get_config(n)
        proc = preprocess_pages(pages, cfg)
        chars = sum(len(p.text) for p in proc)
        lines.append(f"{n}: enabled steps = {cfg.enabled()}; {chars} chars ({chars - raw_chars:+d}, "
                     f"{(chars - raw_chars) / raw_chars:+.1%})")
    return "\n".join(lines)


def text_diff_example(page: Page, name: str, max_chars: int = 400) -> str:
    cfg = get_config(name)
    steps = step_report(page.text, cfg)
    return (f"[{name}] {page.doc} p.{page.page}\n"
            f"steps: " + " -> ".join(f"{s}({n})" for s, n in steps) + "\n"
            + preprocess_text(page.text, cfg)[:max_chars])


# ----------------------------------------------------------------------------------
# Shared setup + HTML report (Arabic needs real RTL/shaping; most terminals cannot show it well)
# ----------------------------------------------------------------------------------
def load_pipelines(names=("baseline", "mizan-lite+repair_lam_alef")):
    from .config import resolve_data_dir
    from .rag import build_pipelines

    data_dir, synthetic = resolve_data_dir()
    pages = load_pdfs(data_dir)
    return pages, build_pipelines(pages, list(names)), synthetic


def setup_items(pipelines_names: list[str]) -> list[tuple[str, str]]:
    """The experiment setup as label/value pairs (identical for all pipelines)."""
    from pathlib import Path

    from .config import SETTINGS

    emb = get_embedder_name()
    adapter = Path(SETTINGS.embedding_adapter).name if SETTINGS.embedding_adapter else "none"
    return [
        ("Embedder", emb.split("+lora:")[0]),
        ("Fine-tuned adapter", adapter),
        ("Chunk titles", "on" if SETTINGS.chunk_title else "off"),
        ("Chunking", f"{SETTINGS.chunk_size} chars, overlap {SETTINGS.chunk_overlap}"),
        ("Retrieval", f"top-{SETTINGS.top_k}"),
        ("Generator", f"{SETTINGS.llm_provider}:{SETTINGS.llm_model}"),
        ("Prompt", SETTINGS.prompt_version),
    ]


# Responsible-use notices (docs/RESPONSIBLE_AI.md). Shown whatever the data or the generator.
NOTICE_EN = ("<strong>Check before you rely on an answer.</strong> Answers are generated from the documents listed and can be wrong "
             "or out of date; verify the cited page in the official document. This prototype is not legal or official advice.")
NOTICE_AR = "تحقق من الصفحة المذكورة في الوثيقة الرسمية قبل الاعتماد على أي إجابة. هذا النموذج الأولي ليس استشارة قانونية أو رسمية."
UPLOAD_NOTE = ("Uploaded PDFs are saved on this runtime's disk (data/raw) and stay there until deleted. Do not upload personal or confidential "
               "documents. Nothing is sent to an outside service while the generator is local.")
REMINDER = "Verify the cited page in the official document before relying on this answer."


def notice_html() -> str:
    from .ui_theme import alert
    return alert(NOTICE_EN + f'<br><span lang="ar" dir="rtl">{NOTICE_AR}</span>')


def status_alerts(synthetic: bool) -> str:
    from .config import SETTINGS
    from .ui_theme import alert

    out = ""
    if synthetic:
        out += alert("<strong>Synthetic sample data.</strong> Invented documents for checking the machinery. "
                     "Nothing here is a finding about real documents.")
    if SETTINGS.llm_provider == "mock":
        out += alert("<strong>Mock LLM.</strong> Answers are the top retrieved passage, not generated text. "
                     "Retrieval and token metrics are real; answer quality is not measured.")
    return out + notice_html()


def render_html(items: list[tuple[dict, dict]], pages: list[Page], pipelines: dict[str, Pipeline], synthetic: bool) -> str:
    """Standalone report. Only measured values are shown; interpretation is deliberately left out."""
    from .config import SETTINGS
    from .preprocessing import FLAGS
    from .ui_theme import CSS, ar, esc, metrics_table, pipeline_card, setup_strip

    names = list(pipelines)
    roles = ["Baseline"] + [f"Variant {i}" for i in range(1, len(names))] if len(names) > 2 else ["Baseline", "Mizan"]
    flag_rows = "".join(
        f"<tr><th scope='row' style='font-weight:400;text-align:start'><code>{esc(f)}</code></th>"
        + "".join(f"<td>{'on' if getattr(get_config(n), f) else '–'}</td>" for n in names) + "</tr>" for f in FLAGS)
    parts = [
        '<div class="mz-page mz"><h1>Mizan prototype: baseline vs Arabic-aware preprocessing</h1>'
        '<p class="lede">Hypothesis under test: Arabic-aware preprocessing changes retrieval quality and token cost '
        "compared with a basic pipeline. Everything below is identical for all pipelines except the preprocessing steps, "
        "and only measured values are shown.</p>",
        status_alerts(synthetic),
        setup_strip(setup_items(names)),
        "<h2>What differs between the pipelines</h2>",
        "<details><summary style='cursor:pointer;min-height:44px;display:flex;align-items:center'>Show preprocessing switches "
        "and the effect on the corpus</summary>"
        '<table class="mz-flags"><thead><tr><th scope="col" style="text-align:start">step</th>'
        + "".join(f'<th scope="col" style="text-align:start">{esc(n)}</th>' for n in names)
        + f"</tr></thead><tbody>{flag_rows}</tbody></table>"
        f'<pre class="mz-pre">{esc(effect_report(pages, names))}</pre></details>',
        "<h2>Questions</h2>",
    ]
    agg = {n: {"tok": [], "hit": []} for n in names}
    for q, cmp in items:
        parts.append(
            f'<article aria-label="question {esc(q["id"])}"><div class="mz-qhead">{ar(q["question"], "mz-question")}'
            f'<span class="mz-qtype">{esc(q.get("type", ""))}</span></div>'
            f'<div class="mz-cols" style="--n:{len(names)}">'
            + "".join(pipeline_card(n, roles[i], get_config(n).enabled(), cmp[n]["result"], i == len(names) - 1)
                      for i, n in enumerate(names))
            + "</div>" + metrics_table(metric_rows(cmp), names, "Measured for this question") + "</article>")
        for n in names:
            agg[n]["tok"].append(cmp[n]["result"].retrieved_tokens)
            sc = cmp[n]["score"]
            if sc and sc["hit"] is not None:
                agg[n]["hit"].append(sc["hit"])
    means = {n: (sum(v["tok"]) / len(v["tok"]) if v["tok"] else 0) for n, v in agg.items()}
    top = max(means.values()) or 1
    bars = "".join(
        f'<tr><th scope="row" style="text-align:start;font-weight:400;width:230px"><span class="mz-name{" is-b" if i == len(names) - 1 else ""}">{esc(n)}</span></th>'
        f'<td><div class="mz-bar{" is-b" if i == len(names) - 1 else ""}" style="width:{means[n] / top * 100:.0f}%"></div></td>'
        f'<td class="num" style="width:90px;font-variant-numeric:tabular-nums;text-align:end">{means[n]:.0f} tokens</td></tr>'
        for i, n in enumerate(names))
    hits = "".join(f"<li>{esc(n)}: hit@{SETTINGS.top_k} {sum(v['hit']) / len(v['hit']):.2f} over {len(v['hit'])} answerable questions</li>"
                   for n, v in agg.items() if v["hit"])
    parts.append(
        "<h2>Summary of what was measured</h2>"
        f'<div class="mz-card"><h3>Mean retrieved tokens per question (embedding tokenizer, top-{SETTINGS.top_k})</h3>'
        f'<table class="mz-bars" role="presentation">{bars}</table>'
        f'<ul style="margin:10px 0 0;padding-inline-start:18px">{hits}</ul>'
        '<p class="mz-note">No interpretation is attached on purpose. A difference here can come from Arabic-specific steps or from '
        "generic cleaning; run the ablations (<code>python -m src.evaluation --pipelines ...</code>) before attributing it. "
        "A handful of questions and a single run give observations, not conclusions.</p></div></div>")
    return (
        '<!doctype html><html lang="en"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width, initial-scale=1">'
        '<meta name="color-scheme" content="light dark"><title>Mizan prototype report</title>'
        f"<style>{CSS}</style></head><body class=\"mz-report\">{''.join(parts)}</body></html>"
    )


def get_embedder_name() -> str:
    from .embeddings import get_embedder

    return get_embedder().name
