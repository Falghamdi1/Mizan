"""Which documents get indexed: the PDFs, the web corpus (JSON/HTML), or both. Chosen by MIZAN_CORPUS (config.CORPUS).

The default is "pdf", so every earlier result and test is unchanged. Both pipelines always receive the same pages.
"""
from __future__ import annotations

import hashlib

from . import config
from .ingestion import Page, corpus_fingerprint as pdf_fingerprint, load_pdfs
from .web_corpus import load_web_corpus, web_fingerprint


def load_corpus(data_dir, kind: str | None = None) -> list[Page]:
    kind = kind or config.CORPUS
    pages: list[Page] = []
    if kind in ("pdf", "all"):
        pages += load_pdfs(data_dir)
    if kind in ("web", "all"):
        pages += load_web_corpus(config.WEB_DIR)[0]
    return pages


def corpus_fingerprint(data_dir, kind: str | None = None) -> str:
    """For "pdf" this is exactly the old PDF fingerprint, so results stay comparable."""
    kind = kind or config.CORPUS
    if kind == "pdf":
        return pdf_fingerprint(data_dir)
    parts = ([pdf_fingerprint(data_dir)] if kind == "all" else []) + [web_fingerprint(config.WEB_DIR)]
    return hashlib.sha256("".join(parts).encode("utf-8")).hexdigest()
