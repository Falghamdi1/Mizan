"""PDF ingestion: one record per page, with the metadata needed to cite sources.

Page numbers are the 1-based physical page index in the PDF (what a PDF viewer shows),
not the printed page label. Pages with no extractable text (e.g. scanned images) are
reported and skipped -- there is no OCR in this prototype.

Each Page carries two texts:
  text           what PyMuPDF extracts, untouched (this is what every pipeline uses by default)
  text_repaired  the same text with the lam-alef ligature defect repaired from glyph geometry.
                 Only used when a pipeline enables the `repair_lam_alef` preprocessing flag.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass

import pymupdf as fitz  # PyMuPDF

_ALEF = "اإأآ"


@dataclass
class Page:
    doc: str  # filename
    title: str  # PDF metadata title if present, else filename stem
    page: int  # 1-based physical page number
    text: str  # raw extracted text, untouched
    text_repaired: str = ""  # lam-alef-repaired variant ("" = not computed)


def repair_chars(chars: list[dict]) -> tuple[list[str], int]:
    """Repair the lam-alef ligature defect on one line of PyMuPDF `rawdict` chars.

    Some PDF fonts map the lam-alef ligature glyph to the wrong Unicode, so text is extracted as
    "ال" for "لا" (e.g. ثالثة for ثلاثة, الئحة for لائحة). The wrong output has a reliable geometric
    signature: the first character of the pair has zero width. Two variants occur:
      V1 (standalone ligature):  zero-width alef-form + ل            -> swap to ل + alef-form
      V2 (connected ligature):   [ـ][space] zero-width ا + ا          -> ل + ا, and drop the stray space
    A legitimate definite article "ال" has a normal-width alef and is never touched.
    Returns (characters, number of repairs).
    """
    out = [c["c"] for c in chars]
    drop: set[int] = set()
    n = len(chars)
    fixes = 0
    i = 0
    while i < n - 1:
        c, nx = chars[i], chars[i + 1]
        if c["c"] in _ALEF and c["bbox"][2] - c["bbox"][0] < 0.01:
            if nx["c"] == "ل":
                out[i], out[i + 1] = "ل", c["c"]
                fixes += 1
                i += 2
                continue
            if c["c"] == "ا" and nx["c"] == "ا":
                out[i] = "ل"
                if i >= 2 and chars[i - 1]["c"] == " " and chars[i - 2]["c"] == "ـ":
                    drop.add(i - 1)
                fixes += 1
                i += 2
                continue
        i += 1
    return [ch for k, ch in enumerate(out) if k not in drop], fixes


def _page_text(page: "fitz.Page", repair: bool) -> tuple[str, int]:
    lines, fixes = [], 0
    for b in page.get_text("rawdict")["blocks"]:
        if b["type"] != 0:
            continue
        for ln in b["lines"]:
            chars = [c for s in ln["spans"] for c in s["chars"]]
            if repair:
                txt, f = repair_chars(chars)
                fixes += f
            else:
                txt = [c["c"] for c in chars]
            lines.append("".join(txt))
    return "\n".join(lines), fixes


def load_pdf(path) -> tuple[list[Page], list[int], int]:
    pages: list[Page] = []
    empty: list[int] = []
    fixes = 0
    with fitz.open(path) as pdf:
        title = (pdf.metadata or {}).get("title") or path.stem
        for i, p in enumerate(pdf, start=1):
            text = p.get_text("text")
            if text.strip():
                repaired, f = _page_text(p, repair=True)
                fixes += f
                pages.append(Page(path.name, title.strip(), i, text, repaired if f else text))
            else:
                empty.append(i)
    return pages, empty, fixes


def load_pdfs(directory) -> list[Page]:
    """Load every PDF in `directory`. A PDF that cannot be opened or has no text is skipped with a warning;
    it is an error only if nothing at all can be loaded."""
    files = sorted(directory.glob("*.pdf"))
    if not files:
        raise FileNotFoundError(f"No PDF files found in {directory}. Put Arabic PDFs in data/raw/ "
                                "(see data/raw/README.txt, or run scripts/fetch_corpus.py).")
    all_pages: list[Page] = []
    seen: dict[str, str] = {}  # content fingerprint -> filename, to catch the same document under two names
    for f in files:
        try:
            pages, empty, fixes = load_pdf(f)
        except Exception as e:  # corrupt / zero-byte / encrypted file: do not kill the whole run
            print(f"  WARNING skipped {f.name}: cannot open as PDF ({type(e).__name__})")
            continue
        if not pages:
            print(f"  WARNING skipped {f.name}: no extractable text (scanned? OCR is not supported)")
            continue
        fingerprint = hashlib.sha256("".join(p.text for p in pages).encode("utf-8")).hexdigest()
        if fingerprint in seen:
            print(f"  WARNING {f.name} has the same text as {seen[fingerprint]}: duplicate documents distort retrieval")
        seen[fingerprint] = f.name
        note = f" (no text on pages {empty})" if empty else ""
        lig = f"; {fixes} lam-alef ligatures repairable" if fixes else ""
        print(f"  ingested {f.name}: {len(pages)} pages with text{note}{lig}")
        all_pages.extend(pages)
    if not all_pages:
        raise RuntimeError(f"None of the {len(files)} PDF files in {directory} could be read.")
    return all_pages


def pages_fingerprint(pages) -> str:
    """sha256 over (document, page, text, repaired text) of every page, in a fixed order: identifies exactly the text a pipeline is built
    from, wherever the files live. A pipeline records it when it builds its index (src/rag.py), so Mizan Insights can tell whether an
    index belongs to the documents that are loaded now."""
    h = hashlib.sha256()
    for p in sorted(pages, key=lambda x: (x.doc, x.page)):
        h.update(f"{p.doc}\x00{p.page}\x00".encode("utf-8"))
        h.update(hashlib.sha256((p.text or "").encode("utf-8")).digest())
        h.update(hashlib.sha256((p.text_repaired or "").encode("utf-8")).digest())
    return h.hexdigest()


def corpus_fingerprint(directory) -> str:
    """sha256 over (file name, file sha256) of all PDFs: recorded in every result file so a run can be tied to its exact corpus."""
    h = hashlib.sha256()
    for f in sorted(directory.glob("*.pdf")):
        h.update(f.name.encode("utf-8"))
        h.update(hashlib.sha256(f.read_bytes()).digest())
    return h.hexdigest()
