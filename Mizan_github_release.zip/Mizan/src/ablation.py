"""One-step ablations: which single preprocessing step changes retrieval?

Two views, both retrieval-only (no LLM), same documents, questions, embedder, chunker and top-k:
  add-one     baseline + <one step>            the effect of a step on top of plain whitespace cleanup
  leave-one   mizan minus <one step>           whether the full preset still needs the step
plus the reference arms baseline, mizan and mizan+repair_lam_alef.

Each variant is compared with `baseline` by a paired bootstrap over questions. Roughly thirty comparisons are made,
none corrected for multiple testing, so an interval that only just excludes zero is weak evidence. Chunk size is counted
in characters after cleaning, so a variant that shortens the text also changes the number and boundaries of chunks
(reported in the table): a step's effect and its chunking effect cannot be separated here.
"""
from __future__ import annotations


from .evaluation import run_eval
from .preprocessing import FLAGS, MIZAN, get_config
from .rag import Pipeline
from .stats import paired_bootstrap

REFERENCE = ["baseline", "mizan", "mizan+repair_lam_alef"]


def ablation_names() -> list[str]:
    steps = [f for f in FLAGS if f != "collapse_whitespace"]
    add = [f"baseline+{f}" for f in steps]
    leave = [f"mizan-no-{f}" for f in steps if getattr(MIZAN, f)]
    return REFERENCE + add + leave


def run_ablations(pages, questions_path, names: list[str] | None = None) -> dict:
    """One pipeline at a time: build, evaluate retrieval-only, free its index. (Keeping ~28 Chroma collections alive in
    one in-memory client made later queries return nothing; retrieval.search now raises if that happens.)
    Returns one result dict shaped like run_eval's, saved to results/ablations-<stamp>.json."""
    import json
    from datetime import datetime

    from . import retrieval
    from .config import RESULTS_DIR

    names = names or ablation_names()
    merged = None
    for i, n in enumerate(names, start=1):
        p = Pipeline(get_config(n))
        p.build(pages)
        r = run_eval([n], pipelines={n: p}, questions_path=questions_path, retrieve_only=True, save=False)
        retrieval.drop_index(n)
        merged = r if merged is None else {**merged, "pipelines": {**merged["pipelines"], **r["pipelines"]}}
        print(f"  {i}/{len(names)} {n}: {p.index_stats['chunks']} chunks", flush=True)
    RESULTS_DIR.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    (RESULTS_DIR / f"ablations-{stamp}.json").write_text(json.dumps(merged, ensure_ascii=False, indent=1), encoding="utf-8")
    return merged


def _col(result: dict, name: str, metric: str) -> dict:
    return {r["id"]: r[metric] for r in result["pipelines"][name]["per_question"] if r.get(metric) is not None}


def table(result: dict, ref: str = "baseline") -> list[dict]:
    """One row per variant: values, difference to `ref`, 95% interval, and a verdict about the interval only."""
    rows = []
    for n, p in result["pipelines"].items():
        row = {"variant": n, "chunks": p["index"]["chunks"], "retrieved tokens": round(p["aggregate"]["retrieved_tokens"]),
               "hit@k": p["aggregate"]["hit"], "MRR": p["aggregate"]["mrr"]}
        for m, key in (("hit", "hit"), ("mrr", "mrr")):
            if n == ref:
                row[f"Δ{m}"], row[f"CI {m}"], row[f"{m} verdict"] = None, "", "reference"
                continue
            b = paired_bootstrap(_col(result, ref, key), _col(result, n, key))
            mean, lo, hi, _ = b
            row[f"Δ{m}"] = mean
            row[f"CI {m}"] = f"[{lo:+.3f}, {hi:+.3f}]"
            row[f"{m} verdict"] = "higher" if lo > 0 else "lower" if hi < 0 else "n.d."
        rows.append(row)
    return rows


def markdown(result: dict, ref: str = "baseline") -> str:
    n_q = result["pipelines"][ref]["aggregate"]["n_answerable"]
    out = [f"Retrieval-only ablations, {n_q} answerable questions, paired bootstrap vs `{ref}` (n.d. = interval includes zero).",
           "", "| variant | chunks | retrieved tokens | hit@k | Δhit [95% CI] | MRR | ΔMRR [95% CI] |", "|---|---|---|---|---|---|---|"]
    for r in table(result, ref):
        dh = "reference" if r["hit verdict"] == "reference" else f"{r['Δhit']:+.3f} {r['CI hit']} {r['hit verdict']}"
        dm = "reference" if r["mrr verdict"] == "reference" else f"{r['Δmrr']:+.3f} {r['CI mrr']} {r['mrr verdict']}"
        out.append(f"| `{r['variant']}` | {r['chunks']} | {r['retrieved tokens']} | {r['hit@k']:.3f} | {dh} | {r['MRR']:.3f} | {dm} |")
    return "\n".join(out)
