"""Text preprocessing -- the ONLY thing that is allowed to differ between the pipelines.

Every transformation is a named boolean flag in PreprocessConfig, applied in the fixed
order of STEPS. That makes the experiment explicit ("what exactly are we changing?") and
lets us run ablations (turn one step off/on at a time) without touching any other code.

BASELINE  = what a typical quick pipeline does: trim + collapse runs of spaces.
MIZAN     = Arabic-aware normalization (prototype approximation of the wider Mizan idea).

This is NOT a tokenizer. It is text normalization applied before chunking/embedding.
The same function is applied to the user query inside each pipeline, so documents and
queries live in the same normalized space.
"""
from __future__ import annotations

import math
import re
import unicodedata
from collections import Counter
from dataclasses import dataclass, fields, replace
from typing import Callable

from .ingestion import Page

# ----------------------------------------------------------------------------------
# Character tables
# ----------------------------------------------------------------------------------
_INVISIBLE = dict.fromkeys(
    [0x200B, 0x200C, 0x200D, 0x200E, 0x200F, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E,
     0x2066, 0x2067, 0x2068, 0x2069, 0xFEFF, 0x00AD, 0x061C],
    None,
)
_TATWEEL = "ـ"
# harakat 064B-065F + superscript alef 0670 + Quranic annotation marks
_DIACRITICS = re.compile("[ً-ٰٟۖ-ۜ۟-۪ۨ-ۭ]")
_ALEF_FORMS = str.maketrans({"أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا"})
_YA_FORMS = str.maketrans({"ى": "ي"})  # alef maqsura -> ya
_PERSIAN_FORMS = str.maketrans({"ی": "ي", "ې": "ي", "ک": "ك", "ھ": "ه"})  # Persian/Urdu look-alikes (e.g. NFKC of the riyal sign gives "ریال")
_TA_MARBUTA = str.maketrans({"ة": "ه"})  # lossy: merges distinct words, OFF by default
_HAMZA_SEATS = str.maketrans({"ؤ": "و", "ئ": "ي"})  # lossy, OFF by default
_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
_PUNCT = str.maketrans({
    "،": ",", "؛": ";", "؟": "?", "«": '"', "»": '"', "“": '"', "”": '"',
    "‘": "'", "’": "'", "–": "-", "—": "-", "…": "...", "٪": "%", "٫": ".", "٬": ",",
})


# ----------------------------------------------------------------------------------
# Config
# ----------------------------------------------------------------------------------
@dataclass(frozen=True)
class PreprocessConfig:
    name: str = "custom"
    # --- basic hygiene (baseline has only this) ---
    collapse_whitespace: bool = False  # trim lines, collapse runs of spaces/tabs, cap blank lines
    # --- Arabic-aware steps (all OFF in baseline) ---
    remove_invisible_chars: bool = False  # zero-width / bidi control marks
    unicode_nfkc: bool = False  # folds presentation forms (U+FB50-FEFF) and ligatures such as lam-alef
    repair_lam_alef: bool = False  # fix reversed lam-alef ligature (ثالثة -> ثلاثة) using glyph geometry; documents only
    remove_repeated_lines: bool = False  # page headers/footers repeated across pages of a document
    join_broken_lines: bool = False  # PDF hard line wraps inside a paragraph -> single space
    remove_tatweel: bool = False  # kashida (ـ) elongation
    remove_diacritics: bool = False  # tashkeel
    normalize_alef: bool = False  # أ إ آ ٱ -> ا
    normalize_alef_maqsura: bool = False  # ى -> ي
    normalize_persian_forms: bool = False  # ی ک -> ي ك (Persian look-alike letters, appear via NFKC of ﷼ etc.)
    normalize_digits: bool = False  # Arabic-Indic / Persian digits -> ASCII
    normalize_punctuation: bool = False  # ، ؛ ؟ « » and typographic quotes/dashes -> ASCII
    normalize_ta_marbuta: bool = False  # ة -> ه   (lossy; off by default, ablation only)
    normalize_hamza_seats: bool = False  # ؤ ئ -> و ي (lossy; off by default, ablation only)

    def enabled(self) -> list[str]:
        return [f.name for f in fields(self) if f.name != "name" and getattr(self, f.name)]


FLAGS = [f.name for f in fields(PreprocessConfig) if f.name != "name"]

BASELINE = PreprocessConfig(name="baseline", collapse_whitespace=True)
MIZAN = PreprocessConfig(
    name="mizan",
    collapse_whitespace=True,
    remove_invisible_chars=True,
    unicode_nfkc=True,
    remove_repeated_lines=True,
    join_broken_lines=True,
    remove_tatweel=True,
    remove_diacritics=True,
    normalize_alef=True,
    normalize_alef_maqsura=True,
    normalize_persian_forms=True,
    normalize_digits=True,
    normalize_punctuation=True,
)


# Mizan-lite: only the steps that repair damage left by PDF text extraction (invisible marks, presentation forms and
# ligatures, kashida, look-alike letters, digit forms). It leaves every step that folds correct spelling (diacritics,
# alef / alef-maqsura forms, punctuation) and every step that deletes or reshapes text (repeated lines, joined lines)
# switched off. The set was fixed from reasoning and the first PDF ablation BEFORE it was run against the 77 PDF
# questions or the 250 web questions; changing it after seeing those results is tuning, not a pre-registered test.
MIZAN_LITE = PreprocessConfig(
    name="mizan-lite",
    collapse_whitespace=True,
    remove_invisible_chars=True,
    unicode_nfkc=True,
    remove_tatweel=True,
    normalize_persian_forms=True,
    normalize_digits=True,
)

_PRESETS = {"baseline": BASELINE, "mizan": MIZAN, "mizan-lite": MIZAN_LITE}


def get_config(name: str) -> PreprocessConfig:
    """'baseline' | 'mizan' | 'mizan-lite' | '<preset>+<flag>[+<flag>]' (add steps; 'mizan-lite+repair_lam_alef' is lite as
    the evaluation uses it) | 'mizan-no-<flag>' (ablate one step of the full preset)."""
    if name in _PRESETS:
        return _PRESETS[name]
    if name.startswith("mizan-no-"):
        flag = name.removeprefix("mizan-no-")
        _check_flag(flag)
        return replace(MIZAN, name=name, **{flag: False})
    if "+" in name and name.split("+")[0] in _PRESETS:
        base, *flags = name.split("+")
        for flag in flags:
            _check_flag(flag)
        return replace(_PRESETS[base], name=name, **{f: True for f in flags})
    raise ValueError(f"Unknown pipeline '{name}'. Use baseline, mizan, mizan-lite, <preset>+<flag>, mizan-no-<flag>.")


def _check_flag(flag: str) -> None:
    if flag not in FLAGS:
        raise ValueError(f"Unknown preprocessing flag '{flag}'. Valid: {', '.join(FLAGS)}")


# ----------------------------------------------------------------------------------
# Individual steps (text -> text). Order below is the execution order.
# ----------------------------------------------------------------------------------
def _collapse_whitespace(t: str) -> str:
    t = t.replace("\r\n", "\n").replace("\r", "\n").replace(" ", " ")
    lines = [re.sub(r"[ \t\f\v]+", " ", ln).strip() for ln in t.split("\n")]
    t = "\n".join(lines)
    return re.sub(r"\n{3,}", "\n\n", t).strip()


_MARKS = "\u064B-\u065F\u0670"


def _nfkc(t: str) -> str:
    t = unicodedata.normalize("NFKC", t)
    # Some presentation-form ligatures (e.g. U+FC5E shadda+fatha) expand to SPACE + mark under NFKC,
    # which would split the word that carries them. A space directly before a mark is never valid.
    return re.sub(f" (?=[{_MARKS}])", "", t)


def _join_broken_lines(t: str) -> str:
    # single newline = layout wrap; blank line = real paragraph break
    t = re.sub(r"(?<!\n)\n(?!\n)", " ", t)
    return re.sub(r"[ \t]+", " ", t)


STEPS: list[tuple[str, Callable[[str], str]]] = [
    ("remove_invisible_chars", lambda t: t.translate(_INVISIBLE)),
    ("unicode_nfkc", _nfkc),
    ("remove_tatweel", lambda t: t.replace(_TATWEEL, "")),
    ("remove_diacritics", lambda t: _DIACRITICS.sub("", t)),
    ("normalize_alef", lambda t: t.translate(_ALEF_FORMS)),
    ("normalize_alef_maqsura", lambda t: t.translate(_YA_FORMS)),
    ("normalize_persian_forms", lambda t: t.translate(_PERSIAN_FORMS)),
    ("normalize_ta_marbuta", lambda t: t.translate(_TA_MARBUTA)),
    ("normalize_hamza_seats", lambda t: t.translate(_HAMZA_SEATS)),
    ("normalize_digits", lambda t: t.translate(_DIGITS)),
    ("normalize_punctuation", lambda t: t.translate(_PUNCT)),
    ("join_broken_lines", _join_broken_lines),
    ("collapse_whitespace", _collapse_whitespace),  # always last: tidies what the others leave
]


def preprocess_text(text: str, cfg: PreprocessConfig) -> str:
    """Apply the enabled per-text steps. Used for both document pages and user queries."""
    for flag, fn in STEPS:
        if getattr(cfg, flag):
            text = fn(text)
    return text


def step_report(text: str, cfg: PreprocessConfig) -> list[tuple[str, int]]:
    """[(step, characters after step)] -- shows what each enabled step does to a text."""
    out = [("raw", len(text))]
    for flag, fn in STEPS:
        if getattr(cfg, flag):
            text = fn(text)
            out.append((flag, len(text)))
    return out


def presentation_form_ratio(text: str) -> float:
    """Share of Arabic-script characters that are presentation forms (U+FB50-FDFF, U+FE70-FEFF).
    High values mean the PDF text layer stores shaped glyphs; plain-letter queries will not match
    them unless something (NFKC here, or the embedding tokenizer) folds them."""
    arabic = [c for c in text if "؀" <= c <= "ۿ" or "ﭐ" <= c <= "﷿" or "ﹰ" <= c <= "﻿"]
    if not arabic:
        return 0.0
    return sum("ﭐ" <= c <= "﷿" or "ﹰ" <= c <= "﻿" for c in arabic) / len(arabic)


# ----------------------------------------------------------------------------------
# Corpus-level step: repeated headers / footers
# ----------------------------------------------------------------------------------
_PAGE_NUM = re.compile(r"(صفحه|صفحة|page|\bص\b|\bp\.)\s*#|^\W*#\W*$", re.IGNORECASE)


def _line_key(line: str) -> str:
    """Identity of a line for header/footer detection. Digits are masked ONLY for page-number-like
    lines ("صفحة 3", "Page 3", "- 3 -"), so "المادة 3" / "المادة 4" are never treated as one repeated line."""
    t = _nfkc(line).translate(_DIGITS).strip()
    masked = re.sub(r"[0-9]+", "#", t)
    return masked if _PAGE_NUM.search(masked) else t


def strip_repeated_lines(pages: list[Page], edge: int = 2) -> list[Page]:
    """Drop lines that repeat in the first/last `edge` lines of >= half the pages of a document.
    Pages with <= 2*edge lines are left untouched."""
    by_doc: dict[str, list[Page]] = {}
    for p in pages:
        by_doc.setdefault(p.doc, []).append(p)

    out: list[Page] = []
    for doc_pages in by_doc.values():
        n = len(doc_pages)
        threshold = max(2, math.ceil(n / 2))
        counts: Counter[str] = Counter()
        for p in doc_pages:
            lines = [ln for ln in p.text.split("\n") if ln.strip()]
            if len(lines) > 2 * edge:  # very short pages: never guess, keep everything
                counts.update({_line_key(ln) for ln in lines[:edge] + lines[-edge:]})
        repeated = {k for k, c in counts.items() if c >= threshold and n >= 2}
        for p in doc_pages:
            lines = p.text.split("\n")
            nonblank = [i for i, ln in enumerate(lines) if ln.strip()]
            edge_idx = set(nonblank[:edge] + nonblank[-edge:]) if len(nonblank) > 2 * edge else set()
            kept = [ln for i, ln in enumerate(lines) if not (i in edge_idx and _line_key(ln) in repeated)]
            out.append(replace(p, text="\n".join(kept)))
    return out


def preprocess_pages(pages: list[Page], cfg: PreprocessConfig) -> list[Page]:
    if cfg.repair_lam_alef:  # geometry-based, so it exists only at document level; queries are typed correctly
        pages = [replace(p, text=p.text_repaired or p.text) for p in pages]
    if cfg.remove_repeated_lines:
        pages = strip_repeated_lines(pages)
    return [replace(p, text=preprocess_text(p.text, cfg)) for p in pages]


# ----------------------------------------------------------------------------------
# Evaluation-only canonicalizer. FIXED and pipeline-independent: used to decide whether a
# retrieved chunk contains a gold phrase, so that neither pipeline gets credit or penalty
# for its own normalization during scoring.
# ----------------------------------------------------------------------------------
def canonical_for_eval(text: str) -> str:
    t = _nfkc(text).translate(_INVISIBLE)
    t = t.replace(_TATWEEL, "")
    t = _DIACRITICS.sub("", t)
    t = t.translate(_ALEF_FORMS).translate(_YA_FORMS).translate(_PERSIAN_FORMS).translate(_TA_MARBUTA).translate(_HAMZA_SEATS)
    t = t.translate(_DIGITS).lower()
    # Delete alef entirely: several real PDFs (e.g. the MoT regulations) extract the lam-alef ligature
    # reversed ("ثلاثة" -> "ثالثة", "الإرشاد" -> "اإلرشاد"). Deleting alef makes both spellings equal,
    # so gold phrases can be written in correct Arabic. Lenient on purpose; used only for scoring.
    t = t.replace("ا", "")
    t = re.sub(r"[^\w]+", " ", t)
    return re.sub(r"\s+", " ", t).strip()
