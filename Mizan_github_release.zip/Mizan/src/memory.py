"""GPU memory planning and release, so the full stack does not run out of memory.

The full stack is four models: a first-stage embedder, a second-stage reranker, a generator and (for the evaluation
step) an independent judge. They are not all resident at once:
  * embedder + reranker + generator stay loaded while questions are answered;
  * the judge is loaded only after every answer exists, and the generator is unloaded first (see local_llm.py);
  * every component that can be 4-bit is 4-bit by default, except the small ones.

`choose_profile` picks the best profile whose estimated need fits the GPU. The estimates are the weight sizes
measured when the models were loaded, plus about 2 GiB for activations, the CUDA context and fragmentation. They are
estimates: the notebook also runs one worst-case smoke test and steps down to the next profile if it still runs out of
memory. This module imports no project settings, so it can be used before anything is configured.
"""
from __future__ import annotations

import gc
from dataclasses import dataclass

EMBED_4B = "Qwen/Qwen3-Embedding-4B"
EMBED_06B = "Qwen/Qwen3-Embedding-0.6B"
RERANK_06B = "Qwen/Qwen3-Reranker-0.6B"
EMBED_CPU = "intfloat/multilingual-e5-small"  # 118M parameters: the 0.6B embedder needs far more than an hour to index on a CPU


@dataclass(frozen=True)
class Profile:
    name: str
    embedder: str
    embed_quant: str  # none | 4bit
    reranker: str  # "" = single-stage retrieval
    generator: bool  # False = retrieval only
    need_gib: float  # GPU memory needed with everything resident (weights + ~2 GiB working room)
    note: str


PROFILES = [
    Profile("full", EMBED_4B, "none", RERANK_06B, True, 13.0,
            "4B embedder in 16-bit (7.5 GiB) + 0.6B reranker (1.1) + 4B generator in 4-bit (2.4)"),
    Profile("full-4bit", EMBED_4B, "4bit", RERANK_06B, True, 8.6,
            "4B embedder in 4-bit + 0.6B reranker + 4B generator in 4-bit"),
    Profile("compact", EMBED_06B, "none", RERANK_06B, True, 6.6,
            "0.6B embedder + 0.6B reranker + 4B generator in 4-bit"),
    Profile("cpu", EMBED_CPU, "none", "", False, 0.0,
            "no GPU: small multilingual-e5 embedder on the CPU, retrieval only (no generated answers, no reranker)"),
]
BY_NAME = {p.name: p for p in PROFILES}


def gpu_gib() -> float:
    """Total memory of GPU 0 in GiB, or 0.0 without a usable GPU."""
    try:
        import torch

        if torch.cuda.is_available():
            return torch.cuda.get_device_properties(0).total_memory / 2**30
    except Exception:
        pass
    return 0.0


def half_dtype():
    """bfloat16 where the GPU supports it natively (Ampere and newer), otherwise float16 (T4)."""
    import torch

    return torch.bfloat16 if torch.cuda.is_available() and torch.cuda.is_bf16_supported(including_emulation=False) else torch.float16


def choose_profile(requested: str = "auto", vram_gib: float | None = None) -> Profile:
    """`requested` is a profile name or 'auto'. A named profile is honoured even if it looks too big (the smoke test
    will then say so); 'auto' takes the first profile that fits."""
    vram = gpu_gib() if vram_gib is None else vram_gib
    if requested != "auto":
        return BY_NAME[requested]
    return next((p for p in PROFILES if p.need_gib <= vram), PROFILES[-1])


def next_profile(p: Profile) -> Profile | None:
    i = PROFILES.index(p)
    return PROFILES[i + 1] if i + 1 < len(PROFILES) else None


def free() -> None:
    """Return cached GPU memory to the driver."""
    gc.collect()
    try:
        import torch

        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    except Exception:
        pass


def release_all() -> None:
    """Unload every model (embedder, reranker, generator/judge). Safe to call at any time, also when nothing is loaded."""
    from . import embeddings, local_llm, rerank

    embeddings.release()
    rerank.release()
    local_llm.release()
    free()


def report() -> str:
    try:
        import torch

        if torch.cuda.is_available():
            f, t = torch.cuda.mem_get_info()
            return f"GPU memory: {(t - f) / 2**30:.1f} GiB in use of {t / 2**30:.1f} GiB (this process allocated {torch.cuda.memory_allocated() / 2**30:.1f})"
    except Exception:
        pass
    return "no GPU"


def is_oom(exc: BaseException) -> bool:
    """True for CUDA out-of-memory errors in any of the shapes torch / bitsandbytes / accelerate raise them."""
    try:
        import torch

        if isinstance(exc, torch.cuda.OutOfMemoryError):
            return True
    except Exception:
        pass
    return "out of memory" in str(exc).lower()
