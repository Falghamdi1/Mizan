"""Loaders for the web-native Arabic corpus (JSON and HTML instead of PDF).

Raw files are downloaded by scripts/fetch_web_corpus.py into data/web/raw/ and parsed here with the standard library
only. Every loader returns the same `Page(doc, title, page, text)` records the PDF pipeline uses, so chunking,
embedding, retrieval, evaluation and the UI need no change.

  FAQ (tourism.sa)       one Page per answer; the question is NOT indexed (it is the evaluation query, see faq_pairs)
  News (tourism.sa)      one Page per item: title, then body
  Definitions/methods    one Page per glossary entry / methodology card (tourism.sa)
  Laws (Bureau of Experts, HTML)   one Page per article ("المادة ..."), plus one for the preamble if there is one
  GASTAT methodology reports (HTML)   one Page per section

The parsers are pure functions of the raw text, so they are tested without a network (tests/test_web_corpus.py).
"""
from __future__ import annotations

import hashlib
import json
import re
from html.parser import HTMLParser
from pathlib import Path

from .ingestion import Page

SKIP_TAGS = {"script", "style", "nav", "header", "footer", "noscript", "svg"}


def clean(text: str) -> str:
    """Whitespace only: no-break spaces and runs of spaces/tabs become one space, blank lines collapse."""
    text = text.replace("\xa0", " ")
    text = re.sub(r"[ \t\r\f\v]+", " ", text)
    return re.sub(r"\n\s*\n+", "\n", "\n".join(line.strip() for line in text.split("\n"))).strip()


# ---------------------------------------------------------------- JSON (tourism.sa CMS, rich-text blocks)

def _inline(node) -> str:
    if isinstance(node, list):
        return "".join(_inline(n) for n in node)
    if isinstance(node, dict):
        return node["text"] if isinstance(node.get("text"), str) else _inline(node.get("children") or [])
    return node if isinstance(node, str) else ""


def blocks_text(blocks) -> str:
    """Strapi rich text (list of paragraph / heading / list blocks) -> plain text, one block per line, list items as '- item'."""
    if isinstance(blocks, str):
        return clean(blocks)
    lines = []
    for b in blocks or []:
        if isinstance(b, dict) and b.get("type") == "list":
            lines += ["- " + _inline(item).strip() for item in b.get("children") or []]
        else:
            lines.append(_inline(b).strip())
    return clean("\n".join(lines))


def parse_faq(data: dict) -> tuple[list[Page], list[dict]]:
    """(pages, pairs). A pair is {question, answer, doc, page, category}. An answer repeated under several questions is
    indexed once; every pair still points at that single page."""
    pages, pairs, seen = [], [], {}
    for cat in data.get("data", []):
        category = (cat.get("title") or "").strip()
        n = 0
        for f in cat.get("faqs") or []:
            q, a = clean(f.get("question") or ""), blocks_text(f.get("answer"))
            if not q or not a:
                continue
            doc = f"faq/{category}"
            if a not in seen:
                n += 1
                seen[a] = (doc, n)
                pages.append(Page(doc, f"الأسئلة الشائعة: {category}", n, a, a))
            pairs.append({"question": q, "answer": a, "doc": seen[a][0], "page": seen[a][1], "category": category})
    return pages, pairs


def parse_news(*responses: dict) -> list[Page]:
    pages, seen = [], set()
    for data in responses:
        for item in data.get("data", []):
            title, body = clean(item.get("title") or ""), blocks_text(item.get("description"))
            if not body or item.get("id") in seen:
                continue
            seen.add(item.get("id"))
            text = f"{title}\n{body}"
            pages.append(Page(f"news/{item.get('date')}/{item.get('id')}", title, 1, text, text))
    return pages


def parse_definitions(data: dict) -> list[Page]:
    cards = (data.get("data") or {}).get("cards") or []
    pages = []
    for i, c in enumerate(cards, 1):
        label, body = clean(c.get("label") or ""), blocks_text(c.get("definition"))
        if label and body:
            text = f"{label}: {body}"
            pages.append(Page("definitions", "تعريفات السياحة", i, text, text))
    return pages


def parse_methodologies(data: dict) -> list[Page]:
    """A card is either one labelled text block, or a table: a title with several labelled blocks (detail, importance, ...)."""
    pages = []
    for i, c in enumerate((data.get("data") or {}).get("cards") or [], 1):
        card, table = c.get("card") or {}, c.get("table") or {}
        if table:
            head = clean(table.get("title") or "")
            rows = [(clean(r.get("label") or ""), blocks_text(r.get("value"))) for r in table.get("cards") or []]
            body = "\n".join(f"{lab}: {val}" for lab, val in rows if val)
        else:
            head, body = clean(card.get("label") or ""), blocks_text(card.get("value"))
        if head and body:
            text = f"{head}\n{body}"
            pages.append(Page("methodologies", "منهجيات السياحة", i, text, text))
    return pages


# ---------------------------------------------------------------- HTML

class _Text(HTMLParser):
    """Visible text of an HTML fragment; <br>, <p>, <li>, <div> and headings end a line."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.out, self.skip = [], 0

    def handle_starttag(self, tag, attrs):
        if tag in SKIP_TAGS:
            self.skip += 1
        if tag in ("br", "p", "li", "div", "tr", "h1", "h2", "h3", "h4"):
            self.out.append("\n")

    def handle_endtag(self, tag):
        if tag in SKIP_TAGS and self.skip:
            self.skip -= 1
        if tag in ("p", "li", "div", "tr", "h1", "h2", "h3", "h4"):
            self.out.append("\n")

    def handle_data(self, data):
        if not self.skip:
            self.out.append(data)


def html_text(html: str) -> str:
    p = _Text()
    p.feed(html)
    return clean("".join(p.out))


class _Law(HTMLParser):
    """Bureau of Experts law page: <h1 class="system_title">, then <div class="article_item"><h3>heading</h3><div class="HTMLContainer">."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.titles, self.articles, self.preamble = [], [], []
        self._depth, self._art, self._h1, self._h3, self._p = 0, None, False, False, 0
        self._head, self._buf, self._seen_article, self._skip = "", [], False, 0

    def handle_starttag(self, tag, attrs):
        cls = dict(attrs).get("class") or ""
        if tag in SKIP_TAGS:
            self._skip += 1
        if tag == "div":
            self._depth += 1
            if "article_item" in cls and self._art is None:
                self._art, self._head, self._buf, self._seen_article = self._depth, "", [], True
        elif tag == "h1" and "system_title" in cls:
            self._h1 = True
            self.titles.append("")
        elif tag == "h3" and self._art is not None:
            self._h3 = True
        elif tag == "p" and self._art is None and not self._seen_article and not self._skip:
            self._p += 1
        if tag in ("br", "p", "li") and self._art is not None:
            self._buf.append("\n")
        if tag in ("br", "p") and self._p:
            self.preamble.append("\n")

    def handle_endtag(self, tag):
        if tag in SKIP_TAGS and self._skip:
            self._skip -= 1
        if tag == "h1":
            self._h1 = False
        elif tag == "h3":
            self._h3 = False
        elif tag == "p" and self._p:
            self._p -= 1
        elif tag == "div":
            if self._art == self._depth:
                self.articles.append((clean(self._head), clean("".join(self._buf))))
                self._art = None
            self._depth -= 1

    def handle_data(self, data):
        if self._h1:
            self.titles[-1] += data
        elif self._h3:
            self._head += data
        elif self._art is not None:
            self._buf.append(data)
        elif self._p:
            self.preamble.append(data)


def parse_law(html: str, slug: str) -> list[Page]:
    """Pages of one law. doc = 'law/<slug>'; the article heading is the first line of each page's text, so it is
    searchable and shows in the citation."""
    p = _Law()
    p.feed(html)
    title = next((clean(t) for t in p.titles if clean(t)), slug)
    doc, pages, n = f"law/{slug}", [], 0
    preamble = clean("".join(p.preamble))
    if len(preamble) > 80:
        n += 1
        pages.append(Page(doc, title, n, f"{title}: ديباجة\n{preamble}", f"{title}: ديباجة\n{preamble}"))
    for head, body in p.articles:
        if body:
            n += 1
            text = f"{head}\n{body}" if head else body
            pages.append(Page(doc, title, n, text, text))
    return pages


def _is_heading(line: str) -> bool:
    return 3 <= len(line) <= 40 and not line.startswith(("•", "-")) and not line.endswith((":", ".", "،", "؛"))


def parse_gastat(html: str, slug: str) -> list[Page]:
    """GASTAT methodology-and-quality report: one Page per section (a short line without a bullet or final punctuation
    starts a section). Text after the cookie banner marker ('مخفي') is dropped."""
    lines = html_text(html).split("\n")
    if "مخفي" in lines:
        lines = lines[: lines.index("مخفي")]
    while lines and lines[0].strip() in ("عودة", ""):
        lines.pop(0)
    title = lines[0] if lines else slug
    lines = [x for x in lines[1:] if x != title and x.strip() != "عودة"]
    sections, head, body = [], title, []
    for line in lines:
        if _is_heading(line) and (not body or len(" ".join(body)) > 80):
            if body:
                sections.append((head, body))
                head, body = line, []
            else:  # two headings in a row: keep both in the section title
                head = line if head == title else f"{head} / {line}"
        else:
            body.append(line.replace("•", "-").strip())
    if body:
        sections.append((head, body))
    doc = f"gastat/{slug}"
    return [Page(doc, title, i, f"{head}\n" + "\n".join(b), f"{head}\n" + "\n".join(b)) for i, (head, b) in enumerate(sections, 1)]


# ---------------------------------------------------------------- the data/web directory

SOURCES = ("faq", "news", "definitions", "laws", "gastat")


def _read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_web_corpus(directory: Path, sources=SOURCES) -> tuple[list[Page], list[dict]]:
    """(pages, faq_pairs) from the raw files in `directory` (data/web/raw). A source whose files are missing is skipped
    with a message, so a partial download still works. Raises only if nothing could be loaded."""
    pages, pairs = [], []

    def add(name, found: list[Page], note=""):
        print(f"  web corpus {name}: {len(found)} pages{note}")
        pages.extend(found)

    if "faq" in sources and (directory / "faq.json").exists():
        found, pairs = parse_faq(_read_json(directory / "faq.json"))
        add("faq", found, f" ({len(pairs)} question/answer pairs)")
    if "news" in sources and (parts := sorted(directory.glob("news-*.json"))):
        add("news", parse_news(*[_read_json(p) for p in parts]))
    if "definitions" in sources:
        for name, fn in (("definitions", parse_definitions), ("methodologies", parse_methodologies)):
            if (directory / f"{name}.json").exists():
                add(name, fn(_read_json(directory / f"{name}.json")))
    if "laws" in sources:
        for f in sorted(directory.glob("law-*.html")):
            add(f.stem, parse_law(f.read_text(encoding="utf-8"), f.stem.removeprefix("law-")))
    if "gastat" in sources:
        for f in sorted(directory.glob("gastat-*.html")):
            add(f.stem, parse_gastat(f.read_text(encoding="utf-8"), f.stem.removeprefix("gastat-")))
    if not pages:
        raise FileNotFoundError(f"No web corpus files in {directory}. Run: python scripts/fetch_web_corpus.py")
    return pages, pairs


def web_fingerprint(directory: Path) -> str:
    """sha256 over (file name, file sha256) of the raw files, recorded in result files like the PDF fingerprint."""
    h = hashlib.sha256()
    for f in sorted(directory.glob("*.json")) + sorted(directory.glob("*.html")):
        h.update(f.name.encode("utf-8"))
        h.update(hashlib.sha256(f.read_bytes()).digest())
    return h.hexdigest()
