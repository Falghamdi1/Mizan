"""Shared look and HTML components for the Gradio app and the standalone demo report.

One source of truth for tokens, type scale and components, so both surfaces read as one tool.
Everything lives inside a `.mz` wrapper so it does not fight Gradio's own styles.

Design rules for this surface (an operating tool, Arabic content first):
  * restrained colour: one accent, used for the primary action and the current pipeline label only
  * numbers are shown side by side with a plain arithmetic difference; no winner/loser styling,
    because one run on a small test set must not be presented as a verdict
  * Arabic text carries lang="ar" dir="rtl", has a larger size and generous line height;
    file names and numbers stay left-to-right inside it
"""
from __future__ import annotations

import html

from .evaluation import ABSTAIN_MARKER
from .preprocessing import canonical_for_eval

FONT_STACK = '"Segoe UI", Tahoma, "Noto Sans Arabic", "Noto Sans", system-ui, -apple-system, sans-serif'

CSS = """
.mz, .mz-report {
  --bg:#f5f4f0; --surface:#ffffff; --surface-2:#ece9e2; --text:#1c1b19; --muted:#5a564e; --line:#d6d2c8;
  --accent:#0b5656; --accent-soft:#d9ebe8; --on-accent:#ffffff; --warn-bg:#fff3d1; --warn-line:#cfae48; --warn-text:#4a3700;
  --font:%(font)s; --mono:ui-monospace,"Cascadia Mono",Consolas,monospace;
  --fs-s:.8125rem; --fs-b:1rem; --fs-l:1.2rem; --fs-h2:1.35rem; --fs-h1:1.75rem;
  font-family:var(--font); color:var(--text);
}
.dark .mz {
  --bg:#141615; --surface:#1c1f1e; --surface-2:#262a28; --text:#ecebe6; --muted:#a5a199; --line:#3a3f3c;
  --accent:#6cc4bd; --accent-soft:#1f3b39; --warn-bg:#35290a; --warn-line:#8c7424; --warn-text:#f1dc9b;
}
@media (prefers-color-scheme: dark) {
  body.mz-report .mz, body.mz-report {
    --bg:#141615; --surface:#1c1f1e; --surface-2:#262a28; --text:#ecebe6; --muted:#a5a199; --line:#3a3f3c;
    --accent:#6cc4bd; --accent-soft:#1f3b39; --warn-bg:#35290a; --warn-line:#8c7424; --warn-text:#f1dc9b;
  }
}
body.mz-report { background:var(--bg); margin:0; }
.mz-page { max-width:1180px; margin:0 auto; padding:24px 16px 56px; }
.mz-page h1 { font-size:var(--fs-h1); line-height:1.2; margin:0 0 6px; font-weight:650; letter-spacing:-.01em; }
.mz-page h2, .mz h2 { font-size:var(--fs-h2); line-height:1.25; margin:28px 0 10px; font-weight:620; }
.mz h3 { font-size:var(--fs-b); margin:0 0 10px; font-weight:620; }
.mz p, .mz li, .mz dd, .mz td, .mz th { font-size:var(--fs-b); line-height:1.55; }
.mz .lede { color:var(--muted); max-width:70ch; margin:0 0 14px; }
.mz code, .mz .mono { font-family:var(--mono); font-size:.92em; }
.mz ::selection { background:var(--accent-soft); }
.mz :focus-visible { outline:2px solid var(--accent); outline-offset:2px; border-radius:4px; }

.mz-alert { background:var(--warn-bg); color:var(--warn-text); border:1px solid var(--warn-line);
  border-radius:8px; padding:10px 14px; margin:0 0 10px; font-size:var(--fs-b); }
.mz-setup { display:grid; grid-template-columns:repeat(auto-fit,minmax(210px,1fr)); gap:6px 24px;
  margin:12px 0 4px; padding:12px 16px; background:var(--surface); border:1px solid var(--line); border-radius:8px; }
.mz-setup div { min-width:0; }
.mz-setup dt { color:var(--muted); font-size:var(--fs-s); margin:0; }
.mz-setup dd { margin:0; overflow-wrap:anywhere; }

.mz-cols { display:grid; grid-template-columns:repeat(var(--n,2),minmax(0,1fr)); gap:14px; margin:10px 0; }
@media (max-width:760px) { .mz-cols { grid-template-columns:1fr; } }
.mz-card { background:var(--surface); border:1px solid var(--line); border-radius:8px; padding:16px; min-width:0; }
.mz-card header { display:flex; flex-wrap:wrap; align-items:baseline; gap:6px 10px; margin-bottom:10px; }
.mz-role { font-size:var(--fs-s); color:var(--muted); text-transform:none; }
.mz-name { font-family:var(--mono); font-size:.9rem; background:var(--surface-2); padding:2px 8px; border-radius:6px; }
.mz-name.is-b { background:var(--accent-soft); color:var(--accent); }
.mz-label { font-size:var(--fs-s); color:var(--muted); margin:14px 0 4px; font-weight:600; }
.mz-answer { font-size:var(--fs-l); line-height:1.95; margin:0; overflow-wrap:anywhere; }
.mz-tag { display:inline-block; font-size:var(--fs-s); color:var(--muted); border:1px solid var(--line);
  border-radius:999px; padding:1px 9px; margin-inline-start:8px; vertical-align:middle; }
.mz-sources { list-style:none; margin:0; padding:0; }
.mz-sources li { border-top:1px solid var(--line); }
.mz-sources li:first-child { border-top:0; }
.mz-sources summary { cursor:pointer; padding:11px 2px; min-height:44px; box-sizing:border-box; display:flex;
  flex-wrap:wrap; align-items:center; gap:2px 10px; }
.mz-sources .meta { color:var(--muted); font-size:var(--fs-s); font-variant-numeric:tabular-nums; }
.mz-passage { font-size:1.05rem; line-height:1.9; padding:2px 4px 12px; margin:0; overflow-wrap:anywhere; }

.mz-tablewrap { overflow-x:auto; background:var(--surface); border:1px solid var(--line); border-radius:8px;
  scrollbar-color:var(--line) transparent; }
.mz-table { border-collapse:collapse; width:100%%; min-width:520px; }
.mz-table caption { text-align:start; padding:12px 16px 4px; color:var(--muted); font-size:var(--fs-s); }
.mz-table th, .mz-table td { padding:9px 16px; border-top:1px solid var(--line); text-align:start; }
.mz-table thead th { border-top:0; font-size:var(--fs-s); color:var(--muted); font-weight:600; }
.mz-table td.num, .mz-table th.num { text-align:end; font-variant-numeric:tabular-nums; }
.mz-table td.delta { color:var(--muted); }
.mz-table td.na { color:var(--muted); }
.mz-note { color:var(--muted); font-size:var(--fs-s); margin:8px 2px 0; max-width:80ch; }

.mz-qhead { display:flex; flex-wrap:wrap; align-items:baseline; gap:6px 12px; }
.mz-question { font-size:var(--fs-l); line-height:1.9; font-weight:600; margin:0; }
.mz-qtype { font-size:var(--fs-s); color:var(--muted); border:1px solid var(--line); border-radius:999px; padding:1px 9px; }
.mz-bars { width:100%%; border-collapse:collapse; }
.mz-bars td { padding:5px 8px 5px 0; }
.mz-bar { height:14px; border-radius:3px; background:var(--muted); opacity:.55; }
.mz-bar.is-b { background:var(--accent); opacity:1; }
.mz-pre { background:var(--surface-2); border-radius:8px; padding:12px 14px; font-family:var(--mono); font-size:var(--fs-s);
  overflow-x:auto; white-space:pre-wrap; margin:10px 0 0; }
.mz-flags th, .mz-flags td { padding:5px 14px 5px 0; font-size:var(--fs-s); }
.mz-empty { color:var(--muted); padding:28px 4px; }
.mz-stats { display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:8px 16px; margin:14px 0 0;
  padding:10px 0 0; border-top:1px solid var(--line); }
.mz-stats dt { color:var(--muted); font-size:var(--fs-s); margin:0; }
.mz-stats dd { margin:0; font-variant-numeric:tabular-nums; font-size:var(--fs-b); }
.mz-nb { background:var(--bg); padding:16px; border-radius:8px; }
/* the look of the demo video: same dark tokens as the app's dark theme, also inside nested .mz blocks */
.mz-dark, .mz-dark .mz {
  --bg:#141615; --surface:#1c1f1e; --surface-2:#262a28; --text:#ecebe6; --muted:#a5a199; --line:#3a3f3c;
  --accent:#6cc4bd; --accent-soft:#1f3b39; --on-accent:#0e2927; --warn-bg:#35290a; --warn-line:#8c7424; --warn-text:#f1dc9b;
  color:var(--text);
}
.mz-hero { display:flex; align-items:center; gap:22px; margin:4px 0 8px; }
.mz-hero svg { width:104px; height:auto; flex:none; }
.mz-hero .mz-title { margin:0; }
.mz-hero .mz-sub { margin:2px 0 0; color:var(--muted); }
.mz-tagline { font-size:1.35rem; font-weight:600; margin:6px 0 4px; }
.mz-dark .mz-answer { font-size:1.45rem; line-height:1.7; font-weight:600; }
.mz-diff { text-align:center; margin:16px 0 6px; }
.mz-diff span { display:inline-block; background:var(--accent); color:var(--on-accent); font-weight:700; font-size:1.3rem;
  padding:10px 28px; border-radius:999px; }
.mz-took { color:var(--muted); font-size:var(--fs-s); margin:4px 2px 0; text-align:center; }
.mz-title { font-size:2rem; font-weight:700; letter-spacing:.14em; margin:4px 0 0; line-height:1.15; }
.mz-title span { font-weight:500; letter-spacing:0; margin-inline-start:.6em; color:var(--muted); }
.mz-sub { font-size:var(--fs-l); margin:2px 0 6px; }
.mz-flow { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:14px; margin:14px 0 6px; padding:0; list-style:none; }
.mz-flow li { border-top:2px solid var(--line); padding-top:8px; min-width:0; }
.mz-flow strong { display:block; font-size:var(--fs-s); color:var(--muted); font-weight:600; }
@media (max-width:760px) { .mz-flow { grid-template-columns:1fr; } .mz-title { font-size:1.5rem; } }

.mz-sources li { padding:4px 6px; }
.mz-sources { padding-top:2px; }
.mz-setup dd { font-size:var(--fs-b) !important; line-height:1.4 !important; }
.mz-setup dt { font-size:var(--fs-s) !important; }
@media (max-width:760px) {
  .mz-page h1, .mz h1 { font-size:1.4rem !important; }
  .mz-setup { grid-template-columns:repeat(2,minmax(0,1fr)); gap:8px 16px; padding:10px 12px; }
  .mz-card { padding:12px; }
  .mz-page { padding:16px 12px 40px; }
}

/* Touch targets and Gradio chrome we do not use in this tool */
.gradio-container button[role="tab"], .gradio-container .mz-run { min-height:44px; }
.gradio-container footer { display:none !important; }
.mz-ar textarea, .mz-ar input { font-family:var(--font); font-size:1.1rem; line-height:1.8; }

/* Mizan Insights panel (src/insights.py) */
.mz-insights { margin-top:22px; padding-top:6px; border-top:2px solid var(--line); }
.mz-insights h3 { margin:16px 0 6px; }
.mz-insights h4 { margin:12px 0 4px; font-size:var(--fs-b); }
.mz-scope { margin:4px 0 6px; color:var(--muted); font-size:var(--fs-s); }
.mz-chip { display:inline-block; font-size:var(--fs-s); border:1px solid var(--line); border-radius:999px; padding:1px 9px;
  margin-inline-end:8px; background:var(--surface-2); color:var(--text); }
.mz-fid { display:inline-block; font-family:var(--mono); font-size:.75rem; color:var(--accent); background:var(--accent-soft);
  border-radius:6px; padding:0 6px; margin-inline-end:4px; cursor:help; }
.mz-finding { background:var(--surface); border:1px solid var(--line); border-inline-start:4px solid var(--accent); border-radius:8px;
  padding:12px 16px; margin:10px 0; }
.mz-stance { display:inline-block; font-weight:650; color:var(--accent); margin-bottom:2px; }
.mz-itext { margin:2px 0 4px; }
.mz-ilist { list-style:none; margin:0; padding:0; }
.mz-ilist li { border-top:1px solid var(--line); padding:8px 2px; }
.mz-ilist li:first-child { border-top:0; }
.mz-loading { display:flex; align-items:center; gap:10px; padding:14px 16px; background:var(--surface); border:1px solid var(--line);
  border-radius:8px; margin:10px 0; }
.mz-spin { width:16px; height:16px; border:3px solid var(--line); border-top-color:var(--accent); border-radius:50%%; animation:mzspin 1s linear infinite; }
@keyframes mzspin { to { transform:rotate(360deg); } }
@media (prefers-reduced-motion: reduce) { .mz-spin { animation:none; } }
.mz-ledger { margin:14px 0 4px; background:var(--surface); border:1px solid var(--line); border-radius:8px; padding:6px 14px; }
.mz-ledger summary { cursor:pointer; min-height:44px; display:flex; align-items:center; }
.mz-facts { padding-inline-start:0; list-style:none; }
.mz-facts li { padding:4px 0; border-top:1px solid var(--line); }
.mz-facts li:first-child { border-top:0; }
""" % {"font": FONT_STACK}


def esc(s) -> str:
    return html.escape(str(s))


def ar(text: str, cls: str = "", tag: str = "p") -> str:
    """Arabic block: language and direction set, line breaks kept."""
    return f'<{tag} class="{cls}" lang="ar" dir="rtl">{esc(text).replace(chr(10), "<br>")}</{tag}>'


def ltr(text) -> str:
    """Isolate left-to-right material (file names, numbers) inside RTL context."""
    return f'<bdi dir="ltr">{esc(text)}</bdi>'


def alert(text: str) -> str:
    return f'<div class="mz-alert" role="note">{text}</div>'


def setup_strip(items: list[tuple[str, str]]) -> str:
    cells = "".join(f"<div><dt>{esc(k)}</dt><dd>{esc(v)}</dd></div>" for k, v in items)
    return f'<dl class="mz-setup">{cells}</dl>'


def is_abstention(answer: str) -> bool:
    return ABSTAIN_MARKER in canonical_for_eval(answer)


def stats_strip(items: list[tuple[str, str]]) -> str:
    cells = "".join(f"<div><dt>{esc(k)}</dt><dd>{esc(v)}</dd></div>" for k, v in items)
    return f'<dl class="mz-stats">{cells}</dl>'


def pipeline_card(name: str, role: str, steps: list[str], r, is_b: bool, stats: list[tuple[str, str]] | None = None) -> str:
    """One pipeline's answer, optional measured-values strip, and cited sources. `r` is a RAGResult."""
    tag = '<span class="mz-tag">no answer given (abstained)</span>' if is_abstention(r.answer) else ""
    srcs = "".join(
        f'<li><details><summary><strong>{p.rank}.</strong> {ltr(p.doc)} <span>page {p.page}</span>'
        f'<span class="meta">similarity {p.score:.3f} · {p.tokens} tokens</span></summary>'
        f'{ar(p.text, "mz-passage")}</details></li>'
        for p in r.passages
    )
    step_txt = ", ".join(steps) if steps else "whitespace cleanup only"
    return (
        f'<section class="mz-card" aria-label="{esc(role)} pipeline">'
        f'<header><h3>{esc(role)}</h3><span class="mz-name{" is-b" if is_b else ""}">{esc(name)}</span></header>'
        f'<details><summary class="mz-role" style="cursor:pointer;min-height:44px;display:flex;align-items:center">Preprocessing: {len(steps) or 1} '
        f'step{"s" if len(steps) != 1 else ""}</summary><p class="mz-note">{esc(step_txt)}</p></details>'
        f'<div class="mz-label">Answer{tag}</div>{ar(r.answer, "mz-answer")}'
        + (stats_strip(stats) if stats else "")
        + f'<div class="mz-label">Retrieved evidence (top {len(r.passages)})</div><ul class="mz-sources">{srcs}</ul>'
        "</section>"
    )


def _num(s: str):
    try:
        return float(s)
    except (TypeError, ValueError):
        return None


def metrics_table(rows: list[list[str]], names: list[str], caption: str = "Measured values", na_note: bool = True) -> str:
    """rows: [[metric, value per pipeline ...]]. With exactly two pipelines a plain arithmetic
    difference (second minus first) is added where both values are numbers. No verdict styling."""
    two = len(names) == 2
    head = "".join(f'<th scope="col" class="num">{esc(n)}</th>' for n in names)
    if two:
        head += '<th scope="col" class="num">difference (second − first)</th>'
    body = []
    for row in rows:
        metric, vals = row[0], row[1:]
        cells = "".join(
            f'<td class="num{" na" if _num(v) is None else ""}">{esc(v)}</td>' for v in vals)
        if two:
            a, b = _num(vals[0]), _num(vals[1])
            if a is not None and b is not None:
                d = b - a
                decimals = 3 if ("." in vals[0] or "." in vals[1]) else 0
                cells += f'<td class="num delta">{d:+.{decimals}f}</td>'
            else:
                cells += '<td class="num delta">–</td>'
        body.append(f'<tr><th scope="row">{esc(metric)}</th>{cells}</tr>')
    return (
        f'<div class="mz-tablewrap" role="region" aria-label="{esc(caption)}" tabindex="0"><table class="mz-table">'
        f'<caption>{esc(caption)}.{" “n/a” means not measurable for this question." if na_note else ""}</caption>'
        f'<thead><tr><th scope="col">Metric</th>{head}</tr></thead><tbody>{"".join(body)}</tbody></table></div>'
    )
