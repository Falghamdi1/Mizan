"""Second-stage reranker (Qwen3-Reranker).

Stage 1 (embedding search) returns the top-N candidates cheaply; stage 2 reads each (question, passage) pair
TOGETHER and scores relevance, which separates near-identical clauses that two independent vectors cannot.
Only the final top-k go to the LLM. Enabled with MIZAN_RERANKER=Qwen/Qwen3-Reranker-0.6B (or -4B);
MIZAN_RERANK_TOP_N controls how many candidates are reranked. Applied identically to every pipeline.

Scoring follows the model card: a chat prompt asks whether the document answers the query, and the score is
P("yes") from the logits of the "yes" / "no" tokens at the last position.
"""
from __future__ import annotations

from functools import lru_cache

import torch

from .config import SETTINGS

_PREFIX = ('<|im_start|>system\nJudge whether the Document meets the requirements based on the Query and the '
           'Instruct provided. Note that the answer can only be "yes" or "no".<|im_end|>\n<|im_start|>user\n')
_SUFFIX = "<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n"
_MAX_LEN = 1024


class QwenReranker:
    def __init__(self, model_name: str, load_4bit: bool = False):
        from transformers import AutoModelForCausalLM, AutoTokenizer

        self.name = model_name
        cuda = torch.cuda.is_available()
        from .memory import half_dtype  # float16 on T4-class GPUs (no native bfloat16)

        kwargs = {"torch_dtype": half_dtype() if cuda else torch.float32}
        if load_4bit:
            from transformers import BitsAndBytesConfig

            kwargs["quantization_config"] = BitsAndBytesConfig(
                load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=half_dtype())
            kwargs["device_map"] = {"": 0}
        self.tok = AutoTokenizer.from_pretrained(model_name, padding_side="left")
        self.model = AutoModelForCausalLM.from_pretrained(model_name, **kwargs).eval()
        if cuda and not load_4bit:
            self.model.to("cuda")
        self.device = next(self.model.parameters()).device
        self._batch = SETTINGS.rerank_batch
        self.yes = self.tok.convert_tokens_to_ids("yes")
        self.no = self.tok.convert_tokens_to_ids("no")
        self.pre = self.tok.encode(_PREFIX, add_special_tokens=False)
        self.suf = self.tok.encode(_SUFFIX, add_special_tokens=False)

    def _pair(self, query: str, doc: str) -> str:
        return f"<Instruct>: {SETTINGS.rerank_instruction}\n<Query>: {query}\n<Document>: {doc}"

    def _score_batch(self, query: str, docs: list[str]) -> list[float]:
        texts = [self._pair(query, d) for d in docs]
        room = _MAX_LEN - len(self.pre) - len(self.suf)
        ids = self.tok(texts, padding=False, truncation="longest_first", return_attention_mask=False,
                       max_length=room)["input_ids"]
        ids = [self.pre + x + self.suf for x in ids]
        batch = self.tok.pad({"input_ids": ids}, padding=True, return_tensors="pt").to(self.device)
        try:  # only the last position is needed: skip the (batch x length x 151k-vocabulary) logits tensor
            logits = self.model(**batch, logits_to_keep=1).logits[:, -1, :]
        except TypeError:  # older transformers
            logits = self.model(**batch).logits[:, -1, :]
        two = torch.stack([logits[:, self.no], logits[:, self.yes]], dim=1)
        return torch.nn.functional.log_softmax(two.float(), dim=1)[:, 1].exp().tolist()

    @torch.no_grad()
    def score(self, query: str, docs: list[str]) -> list[float]:
        """P(relevant) for each document, in input order. On CUDA out-of-memory the batch is halved and retried."""
        from . import memory

        scores: list[float] = []
        i = 0
        while i < len(docs):
            bs = self._batch
            try:
                scores += self._score_batch(query, docs[i:i + bs])
                i += bs
            except Exception as e:
                if not memory.is_oom(e) or bs == 1:
                    raise
                memory.free()
                self._batch = max(1, bs // 2)
                print(f"  GPU out of memory while reranking: retrying with batch size {self._batch}", flush=True)
        return scores


def release() -> None:
    """Unload the reranker (frees its GPU memory)."""
    get_reranker.cache_clear()


@lru_cache(maxsize=1)
def get_reranker() -> QwenReranker | None:
    if not SETTINGS.reranker:
        return None
    return QwenReranker(SETTINGS.reranker, load_4bit=SETTINGS.rerank_4bit)
