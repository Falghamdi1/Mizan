"""Monitoring for the interactive path: one log line per answer, rolling metrics, rule-based alerts, notification.

What it records (src/monitoring.py -> logs/queries.jsonl, one JSON object per line), for every answer shown in the UI/demo
and every failed attempt: time, pipeline, a hash of the question (the text only if MIZAN_MONITOR_LOG_TEXT=1), retrieved
doc/page ids, top similarity, token counts, retrieval / LLM / total latency, whether the answer was cached or a refusal,
and how many `[file, page N]` citations point at a page that was really retrieved.
It does NOT record answer text, passage text or uploaded document content.

Rules (evaluated per pipeline over the last `window` entries; thresholds from the environment, see .env.example):
  errors       generator/retrieval failures in the window >= MIZAN_ALERT_MAX_ERRORS
  refusals     refusal rate >= MIZAN_ALERT_REFUSAL_RATE        (needs >= MIZAN_ALERT_MIN_QUERIES answers)
  latency      p95 total latency > MIZAN_ALERT_P95_S seconds   (same minimum)
  citations    share of non-refusal answers with >= 1 valid citation < MIZAN_ALERT_MIN_CITATION_RATE (same minimum)
  retrieval    any answer with zero retrieved passages
  ingestion    any rejected / unreadable upload in the window
  security     any retrieved passage withheld because it contained instruction-like text (src/safety.py)

Delivery (`notify`): always written to logs/alerts.jsonl and the Python log; additionally POSTed to MIZAN_ALERT_WEBHOOK
(Slack/Discord/Teams-style: sends both "text" and "content") and mailed through MIZAN_ALERT_SMTP_* when set. A given
alert is not re-sent within MIZAN_ALERT_COOLDOWN_S. A failing channel never breaks the app; the failure is logged.

Not covered, on purpose: answer correctness (needs the evaluation set, see src/evaluation.py) and per-user data.

    python -m src.monitoring            # print the summary and current alerts from logs/queries.jsonl
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import smtplib
import threading
import time
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from email.message import EmailMessage
from pathlib import Path
from typing import Callable

from . import citations
from .config import ROOT

log = logging.getLogger("mizan.monitor")

# ---------------------------------------------------------------------------------------------------------------
# Citations: parsing and matching live in src/citations.py (shared with the evaluation).
# ---------------------------------------------------------------------------------------------------------------
_CITE = citations.CITE  # kept for older imports


def citation_report(answer: str, passages: list) -> dict:
    """Count `[file, page N]` citations in `answer` and how many name a (file, page) that is among `passages`."""
    c = citations.check(answer, passages)
    return {"n_cited": c["n_cited"], "n_valid": c["n_valid"]}


def is_refusal(answer: str) -> bool:
    from .evaluation import ABSTAIN_MARKER  # lazy: evaluation imports the pipeline stack
    from .preprocessing import canonical_for_eval
    return ABSTAIN_MARKER in canonical_for_eval(answer or "")


# ---------------------------------------------------------------------------------------------------------------
# Configuration (read from the environment when a Monitor is created, so tests and notebooks can change it)
# ---------------------------------------------------------------------------------------------------------------
def _env_float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, default))
    except ValueError:
        return float(default)


@dataclass(frozen=True)
class MonitorConfig:
    log_path: Path = ROOT / "logs" / "queries.jsonl"
    alerts_path: Path = ROOT / "logs" / "alerts.jsonl"
    log_text: bool = False
    window: int = 20
    min_queries: int = 5
    max_errors: int = 1
    refusal_rate: float = 0.5
    p95_s: float = 20.0
    min_citation_rate: float = 0.5
    cooldown_s: float = 300.0
    webhook: str = ""
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    mail_from: str = ""
    mail_to: str = ""

    @staticmethod
    def from_env() -> "MonitorConfig":
        e = os.getenv
        log_path = Path(e("MIZAN_MONITOR_LOG", str(ROOT / "logs" / "queries.jsonl")))
        return MonitorConfig(
            log_path=log_path, alerts_path=log_path.with_name("alerts.jsonl"),
            log_text=e("MIZAN_MONITOR_LOG_TEXT", "0") == "1",
            window=int(_env_float("MIZAN_ALERT_WINDOW", 20)), min_queries=int(_env_float("MIZAN_ALERT_MIN_QUERIES", 5)),
            max_errors=int(_env_float("MIZAN_ALERT_MAX_ERRORS", 1)), refusal_rate=_env_float("MIZAN_ALERT_REFUSAL_RATE", 0.5),
            p95_s=_env_float("MIZAN_ALERT_P95_S", 20.0), min_citation_rate=_env_float("MIZAN_ALERT_MIN_CITATION_RATE", 0.5),
            cooldown_s=_env_float("MIZAN_ALERT_COOLDOWN_S", 300.0), webhook=e("MIZAN_ALERT_WEBHOOK", ""),
            smtp_host=e("MIZAN_ALERT_SMTP_HOST", ""), smtp_port=int(_env_float("MIZAN_ALERT_SMTP_PORT", 587)),
            smtp_user=e("MIZAN_ALERT_SMTP_USER", ""), smtp_password=e("MIZAN_ALERT_SMTP_PASSWORD", ""),
            mail_from=e("MIZAN_ALERT_MAIL_FROM", ""), mail_to=e("MIZAN_ALERT_MAIL_TO", ""))


def enabled() -> bool:
    return os.getenv("MIZAN_MONITOR", "1") == "1"


@dataclass
class Alert:
    key: str          # stable id, used for the cool-down: "<rule>:<pipeline>"
    rule: str
    pipeline: str
    message: str

    def as_dict(self) -> dict:
        return {"key": self.key, "rule": self.rule, "pipeline": self.pipeline, "message": self.message}


def _p95(values: list[float]) -> float:
    s = sorted(values)
    return s[max(0, -(-95 * len(s) // 100) - 1)]          # nearest-rank percentile


# ---------------------------------------------------------------------------------------------------------------
# The monitor
# ---------------------------------------------------------------------------------------------------------------
class Monitor:
    def __init__(self, cfg: MonitorConfig | None = None, clock: Callable[[], float] = time.time,
                 notifier: Callable[[list[Alert], MonitorConfig], list[str]] | None = None):
        self.cfg = cfg or MonitorConfig.from_env()
        self._clock = clock
        self._notifier = notifier or deliver
        self._lock = threading.Lock()
        self._last_sent: dict[str, float] = {}

    # ---- writing ----
    def _append(self, path: Path, entry: dict) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps(entry, ensure_ascii=False)
        with self._lock, open(path, "a", encoding="utf-8") as f:
            f.write(line + "\n")

    def _base(self, pipeline: str, question: str) -> dict:
        e = {"ts": datetime.fromtimestamp(self._clock(), timezone.utc).isoformat(timespec="seconds"), "pipeline": pipeline,
             "q_hash": hashlib.sha1((question or "").strip().encode("utf-8")).hexdigest()[:12], "q_chars": len((question or "").strip())}
        if self.cfg.log_text:
            e["question"] = (question or "").strip()
        return e

    def record(self, result) -> dict:
        """Log one RAGResult. Never raises: a monitoring failure must not take the app down."""
        try:
            cite = citation_report(result.answer, (getattr(result, "meta", None) or {}).get("shown", result.passages))
            entry = self._base(result.pipeline, result.question) | {
                "kind": "answer", "n_passages": len(result.passages),
                "sources": [f"{p.doc}#{p.page}" for p in result.passages],
                "top_score": round(result.passages[0].score, 4) if result.passages else None,
                "retrieved_tokens": result.retrieved_tokens, "input_tokens": result.llm.input_tokens,
                "output_tokens": result.llm.output_tokens, "retrieval_s": round(result.retrieval_latency_s, 3),
                "llm_s": round(result.llm.latency_s, 3), "total_s": round(result.total_latency_s, 3),
                "prompt": (getattr(result, "meta", None) or {}).get("prompt"), "cached": bool(result.llm.cached), "refused": is_refusal(result.answer),
                "answer_chars": len(result.answer or ""), "n_cited": cite["n_cited"], "n_valid_cited": cite["n_valid"], "error": None}
            self._append(self.cfg.log_path, entry)
            for _ in (getattr(result, "meta", None) or {}).get("withheld", []):
                self.record_event("injection_withheld", result.pipeline, "instruction_like_passage")
            return entry
        except Exception as e:  # noqa: BLE001
            log.warning("monitoring could not record an answer: %s", type(e).__name__)
            return {}

    def record_event(self, event: str, pipeline: str, code: str = "") -> dict:
        """A non-answer event worth watching: 'ingestion_error' (a rejected or damaged upload), 'injection_withheld' (instruction-like text kept
        from the model). Only a kind and a short code are stored, never file names, document text or user text."""
        try:
            entry = self._base(pipeline, "") | {"kind": "event", "event": event, "code": code}
            self._append(self.cfg.log_path, entry)
            return entry
        except Exception as e:  # noqa: BLE001
            log.warning("monitoring could not record an event: %s", type(e).__name__)
            return {}

    def record_error(self, pipeline: str, question: str, exc: BaseException) -> dict:
        try:
            entry = self._base(pipeline, question) | {"kind": "error", "error": type(exc).__name__}
            self._append(self.cfg.log_path, entry)
            return entry
        except Exception as e:  # noqa: BLE001
            log.warning("monitoring could not record an error: %s", type(e).__name__)
            return {}

    # ---- reading ----
    def read(self, n: int | None = None) -> list[dict]:
        p = self.cfg.log_path
        if not p.exists():
            return []
        rows = []
        for ln in p.read_text(encoding="utf-8").splitlines():
            try:
                rows.append(json.loads(ln))
            except json.JSONDecodeError:  # a half-written line from a crash: skip it, keep the rest
                continue
        return rows[-n:] if n else rows

    def summary(self, window: int | None = None) -> dict[str, dict]:
        """Per pipeline, over the last `window` entries of that pipeline."""
        rows = self.read()
        out: dict[str, dict] = {}
        for pipe in sorted({r["pipeline"] for r in rows}):
            mine = [r for r in rows if r["pipeline"] == pipe][-(window or self.cfg.window):]
            ans = [r for r in mine if r.get("kind") == "answer"]
            nonref = [r for r in ans if not r["refused"]]
            tot = [r["total_s"] for r in ans]
            out[pipe] = {
                "entries": len(mine), "answers": len(ans), "errors": sum(r.get("kind") == "error" for r in mine),
                "refusal_rate": (sum(r["refused"] for r in ans) / len(ans)) if ans else None,
                "p50_s": (sorted(tot)[len(tot) // 2] if tot else None), "p95_s": (_p95(tot) if tot else None),
                "mean_input_tokens": _mean([r["input_tokens"] for r in ans if r.get("input_tokens") is not None]),
                "mean_retrieved_tokens": _mean([r["retrieved_tokens"] for r in ans]),
                "citation_rate": (sum(r["n_valid_cited"] > 0 for r in nonref) / len(nonref)) if nonref else None,
                "ingestion_errors": sum(r.get("event") == "ingestion_error" for r in mine),
                "injection_withheld": sum(r.get("event") == "injection_withheld" for r in mine),
                "empty_retrievals": sum(r["n_passages"] == 0 for r in ans), "cached_share": (sum(r["cached"] for r in ans) / len(ans)) if ans else None}
        return out

    # ---- alerts ----
    def check_alerts(self, window: int | None = None) -> list[Alert]:
        c, alerts = self.cfg, []
        for pipe, s in self.summary(window).items():
            if s["errors"] >= c.max_errors:
                alerts.append(Alert(f"errors:{pipe}", "errors", pipe, f"{s['errors']} failed request(s) in the last {s['entries']} for {pipe} (generator or retrieval error)."))
            if s["ingestion_errors"]:
                alerts.append(Alert(f"ingestion:{pipe}", "ingestion", pipe, f"{s['ingestion_errors']} upload(s) were rejected or unreadable in the last {s['entries']} entries."))
            if s["injection_withheld"]:
                alerts.append(Alert(f"security:{pipe}", "security", pipe, f"{s['injection_withheld']} retrieved passage(s) with instruction-like text were withheld from the model for {pipe} (possible prompt injection in a document)."))
            if s["empty_retrievals"]:
                alerts.append(Alert(f"retrieval:{pipe}", "retrieval", pipe, f"{s['empty_retrievals']} answer(s) for {pipe} had no retrieved passage."))
            if s["answers"] < c.min_queries:
                continue
            if s["refusal_rate"] is not None and s["refusal_rate"] >= c.refusal_rate:
                alerts.append(Alert(f"refusals:{pipe}", "refusals", pipe, f"{pipe} refused {s['refusal_rate']:.0%} of the last {s['answers']} questions (threshold {c.refusal_rate:.0%})."))
            if s["p95_s"] is not None and s["p95_s"] > c.p95_s:
                alerts.append(Alert(f"latency:{pipe}", "latency", pipe, f"{pipe} p95 latency {s['p95_s']:.1f} s over the last {s['answers']} answers (threshold {c.p95_s:.1f} s)."))
            if s["citation_rate"] is not None and s["citation_rate"] < c.min_citation_rate:
                alerts.append(Alert(f"citations:{pipe}", "citations", pipe, f"Only {s['citation_rate']:.0%} of {pipe}'s answers carry a valid [file, page] citation (threshold {c.min_citation_rate:.0%})."))
        return alerts

    def notify(self, alerts: list[Alert]) -> list[Alert]:
        """Send the alerts that are not in their cool-down. Returns the ones actually sent."""
        now, fresh = self._clock(), []
        with self._lock:
            for a in alerts:
                if now - self._last_sent.get(a.key, -1e18) >= self.cfg.cooldown_s:
                    self._last_sent[a.key] = now
                    fresh.append(a)
        if fresh:
            failures = []
            try:
                failures = self._notifier(fresh, self.cfg)
            except Exception as e:  # noqa: BLE001
                failures = [f"notifier: {type(e).__name__}"]
            for a in fresh:
                self._append(self.cfg.alerts_path, {"ts": datetime.fromtimestamp(now, timezone.utc).isoformat(timespec="seconds"),
                                                    **a.as_dict(), "delivery_failures": failures})
        return fresh

    def after_answer(self) -> list[Alert]:
        """Call after logging: evaluate the rules, send new alerts, return ALL currently active alerts (for the UI banner)."""
        active = self.check_alerts()
        self.notify(active)
        return active


def _mean(xs: list) -> float | None:
    return (sum(xs) / len(xs)) if xs else None


# ---------------------------------------------------------------------------------------------------------------
# Delivery channels. Return a list of failure strings (empty = everything configured worked).
# ---------------------------------------------------------------------------------------------------------------
def deliver(alerts: list[Alert], cfg: MonitorConfig) -> list[str]:
    text = "Mizan alert:\n" + "\n".join(f"- {a.message}" for a in alerts)
    for a in alerts:
        log.warning("ALERT %s: %s", a.key, a.message)
    failures = []
    if cfg.webhook:
        try:
            body = json.dumps({"text": text, "content": text}).encode("utf-8")
            req = urllib.request.Request(cfg.webhook, data=body, headers={"Content-Type": "application/json"}, method="POST")
            urllib.request.urlopen(req, timeout=8).close()
        except Exception as e:  # noqa: BLE001
            failures.append(f"webhook: {type(e).__name__}")
    if cfg.smtp_host and cfg.mail_to:
        try:
            msg = EmailMessage()
            msg["Subject"], msg["From"], msg["To"] = "Mizan alert", cfg.mail_from or cfg.smtp_user, cfg.mail_to
            msg.set_content(text)
            with smtplib.SMTP(cfg.smtp_host, cfg.smtp_port, timeout=10) as s:
                s.starttls()
                if cfg.smtp_user:
                    s.login(cfg.smtp_user, cfg.smtp_password)
                s.send_message(msg)
        except Exception as e:  # noqa: BLE001
            failures.append(f"email: {type(e).__name__}")
    for f in failures:
        log.warning("alert delivery failed (%s)", f)
    return failures


# ---------------------------------------------------------------------------------------------------------------
# Module-level convenience (one shared monitor; the UI and comparison.compare use these)
# ---------------------------------------------------------------------------------------------------------------
_MONITOR: Monitor | None = None


def get_monitor() -> Monitor:
    global _MONITOR
    if _MONITOR is None:
        _MONITOR = Monitor()
    return _MONITOR


def reset_monitor() -> None:
    """Forget the shared monitor (re-reads the environment on next use). For tests and notebooks."""
    global _MONITOR
    _MONITOR = None


def panel_html() -> str:
    """Small HTML block for the UI: active alerts, then the rolling numbers per pipeline. Empty string if nothing logged."""
    from .ui_theme import alert, esc
    m = get_monitor()
    summ = m.summary()
    if not summ:
        return ""
    banner = "".join(alert(f"<strong>Alert ({esc(a.rule)}).</strong> {esc(a.message)}") for a in m.check_alerts())
    fmt = lambda v, f: "n/a" if v is None else format(v, f)
    head = "".join(f'<th scope="col">{h}</th>' for h in ("pipeline", "answers", "errors", "refusal rate", "p50 s", "p95 s", "valid citations", "mean input tokens"))
    rows = "".join(
        f"<tr><td>{esc(p)}</td><td>{s['answers']}</td><td>{s['errors']}</td><td>{fmt(s['refusal_rate'], '.0%')}</td>"
        f"<td>{fmt(s['p50_s'], '.1f')}</td><td>{fmt(s['p95_s'], '.1f')}</td><td>{fmt(s['citation_rate'], '.0%')}</td>"
        f"<td>{fmt(s['mean_input_tokens'], '.0f')}</td></tr>" for p, s in summ.items())
    return (banner + f'<table class="mz-table"><caption>Monitoring: last {m.cfg.window} entries per pipeline '
            f'(logs/queries.jsonl)</caption><thead><tr>{head}</tr></thead><tbody>{rows}</tbody></table>')


def main() -> None:
    m = Monitor()
    summ = m.summary()
    if not summ:
        print(f"no entries in {m.cfg.log_path}")
        return
    for p, s in summ.items():
        print(p, json.dumps(s, ensure_ascii=False))
    alerts = m.check_alerts()
    print("ALERTS:" if alerts else "no active alerts")
    for a in alerts:
        print(" -", a.message)


if __name__ == "__main__":
    main()
