"""Safeguards that run without a model: instruction-like text inside documents, and personal data in uploads.

Threats (docs/RESPONSIBLE_AI.md):
  document-based prompt injection   a retrieved passage (or an uploaded PDF) that tells the model to ignore its rules, reveal its
                                    instructions or change behaviour. The passage text is untrusted DATA; the system prompt is the
                                    only trusted instruction. Passages that look like instructions are WITHHELD from the model and
                                    flagged in the UI and the monitor; if nothing safe is left, the system answers with the standard
                                    insufficient-evidence sentence and never calls the model.
  personal data in uploads          the Add PDF button stores files on the runtime's disk; a scan warns before anything is indexed
                                    onward (it warns, it does not delete: the owner decides).

Changes after the first measurement (scripts/safety_eval.py, eval/safety/, docs/RESPONSIBLE_AI.md section 4c), guided by the `dev` half only:
zero-width and bidi marks and soft hyphens are removed and text is NFKC-folded before matching (disguises), a second pass ignores punctuation
between words, "تجاهل" must start a word (no match inside "يتجاهل"), "not ignore the rules" and "the new instructions:" are no longer flagged, role-play
phrases need a role word, and phone numbers and IBANs are matched with spaces, dashes and Arabic-Indic digits.

What this is not: a complete defence. Pattern matching catches the common, literal attacks in Arabic and English (after removing
diacritics, kashida and alef variants, so cosmetic obfuscation does not hide them); it does not catch paraphrased or encoded
instructions, and a model can still be influenced by text that passes the scan. Measured false positives on the real corpora are in
tests/test_safety.py and docs/RESPONSIBLE_AI.md. The prompt-level defence (rule 7 of prompt v4) is separate and untested on a real model.
"""
from __future__ import annotations

import re
import unicodedata

_DIAC = re.compile("[ً-ٰٟـ]")                   # diacritics and tatweel
_INVISIBLE = re.compile("[\u00ad\u200b-\u200f\u202a-\u202e\u2060-\u2069\ufeff]")   # soft hyphen, zero-width, bidi marks, word joiner, BOM
_PUNCT = re.compile(r"[^\w\s]|_")
_ALEF = str.maketrans({"أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا", "ى": "ي", "ة": "ه"})
_WS = re.compile(r"\s+")


def normalize(text: str) -> str:
    """Matching space: NFKC (full-width and presentation forms folded), no invisible or bidi characters, no diacritics or kashida, one
    alef, one ya, one ta-marbuta form, single spaces, lower case."""
    t = _INVISIBLE.sub("", unicodedata.normalize("NFKC", text or ""))
    return _WS.sub(" ", _DIAC.sub("", t).translate(_ALEF)).lower()


def normalize_loose(text: str) -> str:
    """`normalize` with punctuation between words treated as a space ("ignore, all-previous" -> "ignore all previous")."""
    return _WS.sub(" ", _PUNCT.sub(" ", normalize(text))).strip()


_FILLER = r"(?:\s+(?:كل|جميع|اي|هذه|تلك|ما|هي|التي|الخاصه|ب|لك|لديك))*"
INJECTION: dict[str, re.Pattern] = {k: re.compile(v, re.IGNORECASE) for k, v in {
    # Arabic (matched on the normalized text: no hamza forms, no ta marbuta)
    "ar_ignore_instructions": r"(?<![ء-ي])[وفبل]?تجاهل" + _FILLER + r"\s+(?:ال)?(?:تعليمات|قواعد|اوامر|توجيهات)",
    "ar_ignore_previous": r"(?<![ء-ي])[وفبل]?تجاهل\s+(?:كل\s+)?ما\s+سبق",
    "ar_forget_instructions": r"(?:انس|انسي|انسوا)\s+(?:كل\s+)?(?:ال)?(?:تعليمات|قواعد|ما\s+(?:سبق|قيل|ذكر|كتب))",
    "ar_do_not_follow": r"لا\s+(?:تلتزم|تتبع|تتقيد)\s+ب(?:ال)?(?:تعليمات|قواعد|توجيهات)",
    "ar_reveal_prompt": r"(?:اكشف|اظهر|اعرض|اطبع|كرر)\s+(?:لي\s+)?(?:ال)?(?:تعليمات|موجه\s+النظام|برومبت|اوامر)\s*(?:الخاصه|الداخليه|السابقه|بك)?",
    "ar_system_prompt": r"موجه\s+النظام|رساله\s+النظام\s+ال(?:اصليه|سريه)",
    "ar_new_instructions": r"تعليمات\s+جديده\s*[:：]",
    "ar_you_are_now": r"(?:انت|انتي)\s+الان\s+(?:(?:مساعد|نموذج|روبوت|بوت)|(?:حر|بلا)\s+(?:من\s+)?(?:اي\s+)?(?:قيود|ضوابط|قواعد|حدود|تحفظ))",
    "ar_roleplay": r"(?:تصرف|تظاهر|تخيل)\s+(?:ك|ب)?(?:(?:مساعد|نموذج|روبوت|بوت)|(?:انك|انه|كانك)\s+(?:مساعد|نموذج|روبوت|بوت|خبير|ذكاء|شخص|حر|بلا))",
    "ar_always_answer": r"(?:اجب|رد|قل)\s+(?:دائما|دايما|فقط)\s+(?:ب|بكلمه|بعباره)",
    # English
    "en_ignore_instructions": r"(?<!not\s)(?<!never\s)(?<!n't\s)\b(?:ignore|disregard|forget|override|bypass)\s+(?:(?:all|any|the|your|my|these|those|previous|prior|above|earlier|system|safety)\s+)*(?:instructions?|rules?|prompts?|guidelines?|polic(?:y|ies)|restrictions?)",
    "en_forget_everything": r"\bforget\s+(?:everything|all\s+of\s+that)",
    "en_you_are_now": r"\byou\s+are\s+now\s+(?:a|an|in|the|free|unrestricted)\b",
    "en_reveal_prompt": r"\b(?:reveal|show|print|repeat|output|leak)\s+(?:me\s+)?(?:your|the)\s+(?:system\s+prompt|instructions?|hidden\s+prompt)",
    "en_new_instructions": r"(?<!the\s)(?<!these\s)(?<!those\s)(?<!following\s)\bnew\s+instructions?\s*[:：]",
    "en_jailbreak": r"\b(?:jailbreak|developer\s+mode|do\s+anything\s+now)\b",
    "en_do_not_follow": r"\bdo\s+not\s+follow\s+(?:the\s+)?(?:previous|above|system|safety)",
    "role_tag": r"<\s*/?\s*(?:system|assistant|instructions?)\s*>|\[\s*/?\s*(?:inst|system)\s*\]|^#{2,3}\s*(?:system|instruction)",
}.items()}


_STRICT_ONLY = {"role_tag", "ar_new_instructions", "en_new_instructions"}


def scan_injection(text: str) -> list[str]:
    """Names of the injection patterns found in `text` (empty = nothing instruction-like)."""
    t, loose = normalize(text), normalize_loose(text)
    # the punctuation-sensitive patterns (role tags, "new instructions:") run on the strict text only
    return [name for name, rx in INJECTION.items() if rx.search(t) or (name not in _STRICT_ONLY and rx.search(loose))]


def filter_passages(passages: list) -> tuple[list, list[dict]]:
    """Split retrieved passages into (kept, withheld). `withheld` items: {doc, page, patterns}. Order of `kept` is preserved."""
    kept, withheld = [], []
    for p in passages:
        hits = scan_injection(p.text)
        if hits:
            withheld.append({"doc": p.doc, "page": p.page, "patterns": hits})
        else:
            kept.append(p)
    return kept, withheld


# ---------------------------------------------------------------------------------------------------------------
# Personal data in uploads
# ---------------------------------------------------------------------------------------------------------------
_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")   # Arabic-Indic and Persian digits
PII: dict[str, re.Pattern] = {
    "email": re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+"),
    # mobile: 05x, +9665x, 009665x, 9665x; single spaces or dashes between digit groups are allowed
    "saudi_mobile": re.compile(r"(?<!\d)(?:\+?966|00966|0)[ -]?5(?:[ -]?\d){8}(?!\d)"),
    "national_or_iqama_id_with_label": re.compile(r"(?:رقم\s+(?:الهوية|الإقامة|الاقامة|السجل\s+المدني)|national\s+id|iqama)[^\d]{0,15}[12]\d{9}(?!\d)", re.IGNORECASE),
    "iban_sa": re.compile(r"\bSA\d{2}(?:[ -]?\d){20}(?!\d)", re.IGNORECASE),
}


def scan_pii(text: str) -> dict[str, int]:
    """{pattern: occurrences} for the patterns that matched (empty dict = nothing found). Counts only: the matches themselves are never returned."""
    t = _INVISIBLE.sub("", unicodedata.normalize("NFKC", text or "")).translate(_DIGITS)
    found = {name: len(rx.findall(t)) for name, rx in PII.items()}
    return {k: v for k, v in found.items() if v}


def mask_pii(text: str) -> str:
    """`text` with personal data replaced by a label such as [email], so it can be shown to a second model without the data itself. The text is
    NFKC-folded first (full-width and Arabic-Indic digits become ASCII), so it can differ from the input in form as well as in the masked parts."""
    t = _INVISIBLE.sub("", unicodedata.normalize("NFKC", text or "")).translate(_DIGITS)
    for name, rx in PII.items():
        t = rx.sub(f"[{name.replace('_with_label', '').replace('saudi_', '')}]", t)
    return t


def upload_warnings(pages: list) -> list[str]:
    """Human-readable warnings for the pages of one uploaded document (injection-like text, personal data)."""
    out, inj, pii = [], set(), {}
    for p in pages:
        if scan_injection(p.text):
            inj.add(p.page)
        for k, v in scan_pii(p.text).items():
            pii[k] = pii.get(k, 0) + v
    if inj:
        out.append(f"instruction-like text on page(s) {sorted(inj)[:6]}: those passages will be withheld from the model")
    if pii:
        out.append("possible personal data (" + ", ".join(f"{k}: {v}" for k, v in pii.items()) + "): the file is stored on this runtime's disk until you delete it")
    return out
