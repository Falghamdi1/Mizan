"""Small helpers for the Colab notebook: stage timing, model start-up, charts, the automatic summary and the UI launcher.

Nothing here changes the experiment. The summary only restates measured numbers: a difference is called
"distinguishable from zero" only when the paired-bootstrap interval excludes zero, and it says so when the sample is
too small to test.
"""
from __future__ import annotations

import os
import statistics as st
import sys
import time
from contextlib import contextmanager

from .stats import paired_bootstrap


class Stopwatch:
    """Wall-clock time per named stage; stages with the same name add up."""

    def __init__(self, t0: float | None = None) -> None:
        self.t0 = t0 or time.perf_counter()
        self.stages: dict[str, float] = {}

    @contextmanager
    def stage(self, name: str):
        t = time.perf_counter()
        try:
            yield
        finally:
            self.stages[name] = self.stages.get(name, 0.0) + time.perf_counter() - t

    def add(self, name: str, seconds: float) -> None:
        self.stages[name] = self.stages.get(name, 0.0) + seconds

    def total(self) -> float:
        return time.perf_counter() - self.t0

    def rows(self) -> list[tuple[str, str]]:
        return [(k, f"{v:.1f} s") for k, v in self.stages.items()] + [("whole notebook so far", f"{self.total() / 60:.1f} min")]


# ---------------------------------------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------------------------------------
def _col(result: dict, name: str, metric: str) -> dict:
    return {r["id"]: r[metric] for r in result["pipelines"][name]["per_question"] if r.get(metric) is not None}


def paired_line(result: dict, a: str, b: str, metric: str, label: str, digits: int = 3) -> dict:
    """One comparison: values, difference (b - a), interval, and a plain verdict about the interval only."""
    x, y = _col(result, a, metric), _col(result, b, metric)
    res = paired_bootstrap(x, y)
    if res is None:
        return {"label": label, "text": f"{label}: not measurable", "kind": "na"}
    mean, lo, hi, n = res
    ma, mb = st.fmean(x[i] for i in x if i in y), st.fmean(y[i] for i in y if i in x)
    kind = "up" if lo > 0 else "down" if hi < 0 else "flat"
    verdict = {"up": "Mizan higher, interval excludes zero", "down": "Mizan lower, interval excludes zero",
               "flat": "no difference distinguishable from zero"}[kind]
    if n < 20:
        verdict += f" (n={n} is too small for the interval to mean much)"
    return {"label": label, "kind": kind, "n": n, "a": ma, "b": mb, "diff": mean, "lo": lo, "hi": hi,
            "text": f"{label}: Standard {ma:.{digits}f}, Mizan {mb:.{digits}f}, difference {mean:+.{digits}f} "
                    f"[95% CI {lo:+.{digits}f}, {hi:+.{digits}f}], n={n}: {verdict}."}


def summary_lines(retrieval_run: dict, answer_run: dict, a: str, b: str) -> dict[str, list[str]]:
    """Group the measured comparisons into improved / not distinguishable / worse, plus the efficiency facts."""
    comps = [paired_line(retrieval_run, a, b, "hit", "Retrieval hit@k (retrieval-only run)"),
             paired_line(retrieval_run, a, b, "mrr", "Retrieval MRR (retrieval-only run)"),
             paired_line(retrieval_run, a, b, "precision", "Retrieval precision@k (retrieval-only run)"),
             paired_line(answer_run, a, b, "hit", "Retrieval hit@k (answer run)"),
             paired_line(answer_run, a, b, "keyword_coverage", "Answer keyword coverage (answer run)"),
             paired_line(answer_run, a, b, "judge_correct", "Judge: correct (answer run, unvalidated judge)")]
    groups = {"up": [], "flat": [], "down": [], "na": []}
    for c in comps:
        groups[c["kind"]].append(c["text"])
    eff = []
    for metric, label, d in (("retrieved_tokens", "Retrieved tokens per query", 0), ("input_tokens", "LLM input tokens per query", 0),
                             ("output_tokens", "LLM output tokens per query", 0)):
        x, y = _col(answer_run, a, metric), _col(answer_run, b, metric)
        if x and y:
            ma, mb = st.fmean(x.values()), st.fmean(y.values())
            eff.append(f"{label}: Standard {ma:.{d}f}, Mizan {mb:.{d}f} ({(mb - ma) / ma:+.1%}).")
    for metric, label in (("retrieval_latency_s", "Retrieval latency (median)"), ("llm_latency_s", "Generation latency (median)"),
                          ("total_latency_s", "End-to-end latency (median)")):
        x, y = list(_col(answer_run, a, metric).values()), list(_col(answer_run, b, metric).values())
        if x and y:
            eff.append(f"{label}: Standard {st.median(x):.2f} s, Mizan {st.median(y):.2f} s.")
    groups["efficiency"] = eff
    return groups


# ---------------------------------------------------------------------------------------------------------
# Notebook display
# ---------------------------------------------------------------------------------------------------------
def show_html(body: str, dark: bool = True) -> None:
    """Render project HTML (RTL Arabic, cards, tables) in a notebook cell on its own background (dark = the demo video's look)."""
    from IPython.display import HTML, display

    from .ui_theme import CSS

    display(HTML(f'<style>{CSS}</style><div class="mz{" mz-dark" if dark else ""} mz-nb">{body}</div>'))


def plot_results(retrieval_run: dict, answer_run: dict, a: str, b: str, labels=("Standard RAG", "Mizan")):
    """Three small charts: retrieval quality, tokens per query, median latency per query. Measured values only."""
    import matplotlib.pyplot as plt

    grey, teal = "#8a867c", "#0b5656"
    fig, ax = plt.subplots(1, 3, figsize=(13, 3.6), facecolor="white")

    def mean(run, name, m):
        v = list(_col(run, name, m).values())
        return st.fmean(v) if v else 0.0

    def med(run, name, m):
        v = list(_col(run, name, m).values())
        return st.median(v) if v else 0.0

    def grouped(axis, names, series, title, ylabel, fmt="{:.2f}"):
        w = 0.38
        for j, (name, colour, lab) in enumerate(zip((a, b), (grey, teal), labels)):
            xs = [i + (j - 0.5) * w for i in range(len(names))]
            vals = [s(name) for s in series]
            bars = axis.bar(xs, vals, w, color=colour, label=lab)
            for rect, v in zip(bars, vals):
                axis.annotate(fmt.format(v), (rect.get_x() + rect.get_width() / 2, rect.get_height()), ha="center",
                              va="bottom", fontsize=8, xytext=(0, 2), textcoords="offset points")
        axis.set_xticks(range(len(names)), names)
        axis.set_title(title, fontsize=10, loc="left")
        axis.set_ylabel(ylabel, fontsize=9)
        axis.spines[["top", "right"]].set_visible(False)

    n_r = len(_col(retrieval_run, a, "hit"))
    grouped(ax[0], ["hit@k", "MRR", "precision@k"],
            [lambda n, m=m: mean(retrieval_run, n, m) for m in ("hit", "mrr", "precision")],
            f"Retrieval quality ({n_r} questions, no LLM)", "mean")
    ax[0].set_ylim(0, 1.1)
    ax[0].legend(frameon=False, fontsize=8, loc="upper right")
    grouped(ax[1], ["retrieved", "LLM input", "LLM output"],
            [lambda n, m=m: mean(answer_run, n, m) for m in ("retrieved_tokens", "input_tokens", "output_tokens")],
            "Tokens per query (answer run)", "tokens", "{:.0f}")
    # latency: stacked retrieval + generation
    for j, (name, colour, lab) in enumerate(zip((a, b), (grey, teal), labels)):
        r, g = med(answer_run, name, "retrieval_latency_s"), med(answer_run, name, "llm_latency_s")
        ax[2].bar(j, r, color="#c9c5ba", width=0.5, label="retrieval" if j == 0 else None)
        ax[2].bar(j, g, bottom=r, color=colour, width=0.5, label="generation" if j == 0 else None)
        ax[2].annotate(f"{r + g:.1f} s", (j, r + g), ha="center", va="bottom", fontsize=8, xytext=(0, 2), textcoords="offset points")
    ax[2].set_xticks([0, 1], labels)
    ax[2].set_title("Median latency per query (answer run)", fontsize=10, loc="left")
    ax[2].set_ylabel("seconds", fontsize=9)
    ax[2].spines[["top", "right"]].set_visible(False)
    ax[2].legend(frameon=False, fontsize=8)
    fig.tight_layout()
    return fig


def results_rows(retrieval_run: dict, answer_run: dict, a: str, b: str) -> list[list[str]]:
    """[[metric, standard, mizan]] with measured values only (n/a when not measurable)."""
    def agg(run, name, key):
        return run["pipelines"][name]["aggregate"].get(key)

    def row(label, run, key, digits=3):
        cells = []
        for name in (a, b):
            v = agg(run, name, key)
            cells.append("n/a" if v is None else (f"{v:.{digits}f}" if digits else f"{v:.0f}"))
        return [label] + cells

    nr, na = agg(retrieval_run, a, "n_questions"), agg(answer_run, a, "n_questions")
    return [
        row(f"Hit@k before reranking, stage 1 ({nr} q)", retrieval_run, "first_stage_hit"),
        row(f"Gold evidence among the top-N candidates ({nr} q)", retrieval_run, "candidate_recall"),
        row(f"Hit@k after reranking, retrieval only ({nr} q)", retrieval_run, "hit"),
        row(f"MRR, retrieval only ({nr} q)", retrieval_run, "mrr"),
        row(f"Precision@k, retrieval only ({nr} q)", retrieval_run, "precision"),
        row(f"Hit@k, answer run ({na} q)", answer_run, "hit"),
        row(f"Answer keyword coverage ({na} q, surface check)", answer_run, "keyword_coverage"),
        row(f"Judge: correct, unvalidated ({na} q)", answer_run, "judge_correct"),
        row(f"Judge: faithful, unvalidated ({na} q)", answer_run, "judge_faithful"),
        row("Refused an answerable question (rate)", answer_run, "false_abstain_rate"),
        row("Retrieved tokens / query (embedding tokenizer)", answer_run, "retrieved_tokens", 0),
        row("LLM input tokens / query", answer_run, "input_tokens", 0),
        row("LLM output tokens / query", answer_run, "output_tokens", 0),
        row("Retrieval latency, s (median)", answer_run, "retrieval_latency_s", 3),
        row("Generation latency, s (median)", answer_run, "llm_latency_s", 2),
        row("End-to-end latency, s (median)", answer_run, "total_latency_s", 2),
    ]


def answers_html(answer_run: dict, questions: list[dict], a: str, b: str) -> str:
    """Every question with the reference answer and both generated answers, for a human to read."""
    from .ui_theme import ar, esc, is_abstention

    by_id = {q["id"]: q for q in questions}
    rows_a = {r["id"]: r for r in answer_run["pipelines"][a]["per_question"]}
    rows_b = {r["id"]: r for r in answer_run["pipelines"][b]["per_question"]}
    out = []
    for qid, ra in rows_a.items():
        rb, q = rows_b[qid], by_id[qid]

        def cell(r):
            tag = ' <span class="mz-tag">refused</span>' if is_abstention(r["answer"]) else ""
            ev = "n/a" if r["hit"] is None else ("evidence retrieved" if r["hit"] else "evidence NOT retrieved")
            if r.get("judge_correct") is not None:
                ev += f" · judge: {'correct' if r['judge_correct'] else 'incorrect'}, {'faithful' if r.get('judge_faithful') else 'unfaithful'}"
            return f'<div>{ar(r["answer"], "mz-answer")}<p class="mz-note">{esc(ev)}{tag}</p></div>'

        out.append(
            f'<details><summary style="cursor:pointer;min-height:44px;display:flex;align-items:center">'
            f'{esc(qid)} · {esc(q.get("type", ""))}</summary>{ar(q["question"], "mz-question")}'
            f'<p class="mz-label">Reference answer (written with the question)</p>{ar(q.get("reference_answer", "n/a"), "mz-passage")}'
            f'<div class="mz-cols"><div><p class="mz-label">Standard RAG</p>{cell(ra)}</div>'
            f'<div><p class="mz-label">Mizan</p>{cell(rb)}</div></div></details>')
    return "".join(out)


# ---------------------------------------------------------------------------------------------------------
# Models: choose a memory profile, download, load, smoke-test, step down on out-of-memory
# ---------------------------------------------------------------------------------------------------------
GENERATOR_ID = "Qwen/Qwen3-4B-Instruct-2507"
JUDGE_ID = "ibm-granite/granite-3.3-2b-instruct"  # not a Qwen model: an independent judge; Apache-2.0, no login
_WEIGHTS = ["*.json", "*.safetensors", "*.txt"]


def configure(profile, judge: bool = True, rerank_top_n: int = 20) -> None:
    """Apply a memory profile to the shared settings (identical for both pipelines)."""
    from . import config

    config.override(
        embedding_model=profile.embedder, embed_quant=profile.embed_quant, embedding_adapter="",
        reranker=profile.reranker, rerank_top_n=rerank_top_n, rerank_4bit=False,
        llm_provider="hf" if profile.generator else "mock", llm_model=GENERATOR_ID, hf_quant="4bit",
        judge_provider="hf" if (judge and profile.generator) else "", judge_model=JUDGE_ID if (judge and profile.generator) else "",
        chunk_title=True, llm_max_tokens=300, llm_cache=False)


def model_ids(profile, judge: bool = True) -> list[tuple[str, str]]:
    ids = [("Embedder (stage 1)", profile.embedder)]
    if profile.reranker:
        ids.append(("Reranker (stage 2)", profile.reranker))
    if profile.generator:
        ids.append(("Generator", GENERATOR_ID))
        if judge:
            ids.append(("Judge (evaluation)", JUDGE_ID))
    return ids


def _download(profile, judge, sw) -> dict:
    from huggingface_hub import snapshot_download

    paths = {}
    with sw.stage("2a model download (cached after the first run)"):
        for _, mid in model_ids(profile, judge):
            paths[mid] = snapshot_download(mid, allow_patterns=_WEIGHTS)
    return paths


def _load_and_test(profile, sw) -> None:
    """Load every resident model and run each at its worst-case input size, so an out-of-memory error shows up now,
    not in the middle of a question."""
    from . import local_llm, memory
    from .config import SETTINGS
    from .embeddings import get_embedder
    from .rerank import get_reranker

    with sw.stage("2b model load + memory check"):
        emb = get_embedder()
        emb.embed_passages(["الترخيص السياحي مدة سريان الترخيص " * 60] * SETTINGS.embed_batch_size)  # full-length batch
        emb.embed_query("تهيئة")
        rr = get_reranker()
        if rr is not None:
            rr.score("ما مدة الترخيص؟", ["نص عن الترخيص السياحي والمرخص له " * 120] * SETTINGS.rerank_top_n)
        if profile.generator:
            local_llm.generate(SETTINGS.llm_model, "", "السياق: " + "نص عن لائحة الإرشاد السياحي " * 160, 16)  # ~1.9k tokens: more than 4 passages + question ever need
        memory.free()


def start_models(requested: str, sw, judge: bool = True):
    """Pick the best profile that fits the GPU, download and load its models, and step down to the next profile if
    memory runs out. Returns (profile, {model id: local path})."""
    from . import memory

    profile = memory.choose_profile(requested)
    while True:
        configure(profile, judge)
        print(f"Profile '{profile.name}': {profile.note}")
        try:
            paths = _download(profile, judge, sw)
            _load_and_test(profile, sw)
            print(f"  models ready. {memory.report()}")
            return profile, paths
        except Exception as e:
            memory.release_all()
            nxt = memory.next_profile(profile)
            if memory.is_oom(e) and nxt is not None and requested == "auto":
                print(f"  out of GPU memory with '{profile.name}'; stepping down to '{nxt.name}'.")
                profile = nxt
                continue
            raise


def get_corpus(root) -> list[str]:
    """Download the 8 public PDFs (verified by SHA-256); fall back to PDFs the user placed in data/raw or a Drive folder."""
    import shutil
    import subprocess
    import sys
    from pathlib import Path

    root = Path(root)
    raw = root / "data" / "raw"
    r = subprocess.run([sys.executable, "scripts/fetch_corpus.py"], cwd=root, capture_output=True, text=True,
                       encoding="utf-8", errors="replace", env={**os.environ, "PYTHONIOENCODING": "utf-8"})
    out = [l for l in (r.stdout + r.stderr).splitlines() if l.strip()]
    drive = Path("/content/drive/MyDrive/Mizan_PDFs")
    if r.returncode != 0 and drive.is_dir():  # optional: PDFs kept in Google Drive
        for f in drive.glob("*.pdf"):
            if not (raw / f.name).exists():
                shutil.copy(f, raw / f.name)
                out.append(f"copied {f.name} from Drive")
    if not list(raw.glob("*.pdf")):
        raise RuntimeError(
            "No PDFs available: the download from the ministry site failed (it may block this network).\n"
            "Fix: open the Files panel on the left, upload the PDFs into mizan/data/raw/ (or into a Google Drive folder named "
            "Mizan_PDFs and mount Drive), then run this cell again.\n" + "\n".join(out[-6:]))
    return out


def launch(ui) -> None:
    """Show the Gradio UI in the notebook. Colab needs a public gradio.live link (the page is tunnelled; the models stay here);
    elsewhere it runs on localhost."""
    from .ui import launch_kwargs

    ui.launch(share="google.colab" in sys.modules, inline=True, prevent_thread_lock=True, **launch_kwargs())
