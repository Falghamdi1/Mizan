"""Paired bootstrap used by scripts/compare_runs.py and the Colab notebook."""
import random
import statistics as st


def paired_bootstrap(x: dict, y: dict, n: int = 5000, seed: int = 0):
    """Mean of (y - x) over the questions present in both dicts, with a 95% percentile interval from resampling
    questions with replacement. Returns (mean, low, high, n_questions) or None if the dicts share no question.
    Questions are treated as independent, which is optimistic when many come from the same page or document."""
    ids = sorted(set(x) & set(y))
    if not ids:
        return None
    diffs = [y[i] - x[i] for i in ids]
    rng = random.Random(seed)
    means = sorted(st.fmean(rng.choices(diffs, k=len(diffs))) for _ in range(n))
    return st.fmean(diffs), means[int(0.025 * n)], means[int(0.975 * n)], len(ids)
