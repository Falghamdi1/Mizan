"""Shared experiment settings.

Everything that must be IDENTICAL between the baseline and Mizan pipelines lives here
(embedding model, chunk size, top-k, LLM, temperature). The only thing that differs
between the pipelines is the PreprocessConfig (see preprocessing.py).
"""
from __future__ import annotations

import os
import sys
from dataclasses import dataclass, asdict
from pathlib import Path

from dotenv import load_dotenv

# Windows consoles default to a legacy codepage that cannot print Arabic.
for _s in (sys.stdout, sys.stderr):
    if hasattr(_s, "reconfigure"):
        _s.reconfigure(encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")

RAW_DIR = ROOT / "data" / "raw"
WEB_DIR = ROOT / "data" / "web" / "raw"  # JSON/HTML corpus, see scripts/fetch_web_corpus.py
WEB_QUESTIONS = ROOT / "data" / "web" / "questions_faq.json"  # built by scripts/make_faq_questions.py
PDF_FAQ_QUESTIONS = ROOT / "data" / "web" / "questions_pdf.json"  # built by scripts/make_pdf_questions.py (gold inside the PDFs)
PDF_FAQ_ALIGNMENT = ROOT / "eval" / "pdf_faq_alignment.json"  # FAQ question key -> gold phrase inside the PDFs
SAMPLE_DIR = ROOT / "data" / "sample"
PROCESSED_DIR = ROOT / "data" / "processed"
EVAL_DIR = ROOT / "eval"
RESULTS_DIR = ROOT / "results"


@dataclass(frozen=True)
class SharedSettings:
    # --- held constant across both pipelines -------------------------------------
    embedder: str = os.getenv("MIZAN_EMBEDDER", "st")  # "st" = sentence-transformers, "hash" = offline fallback
    embedding_model: str = os.getenv("MIZAN_EMBEDDING_MODEL", "intfloat/multilingual-e5-small")
    max_seq_length: int = int(os.getenv("MIZAN_MAX_SEQ_LENGTH", "512"))
    embed_batch_size: int = int(os.getenv("MIZAN_EMBED_BATCH", "16"))
    embed_quant: str = os.getenv("MIZAN_EMBED_QUANT", "none")  # none | 4bit (NF4, for the 4B embedder on small GPUs)
    embedding_adapter: str = os.getenv("MIZAN_EMBEDDING_ADAPTER", "")  # path to a LoRA adapter (fine-tuned Qwen3-Embedding)
    query_instruction: str = os.getenv(
        "MIZAN_QUERY_INSTRUCTION",
        "Given a question about Saudi tourism regulations, retrieve the regulation passage that answers it")
    # Optional second stage: rerank the top-N first-stage candidates with a cross-encoder-style model.
    reranker: str = os.getenv("MIZAN_RERANKER", "")  # e.g. Qwen/Qwen3-Reranker-0.6B ; empty = off
    rerank_top_n: int = int(os.getenv("MIZAN_RERANK_TOP_N", "20"))
    rerank_batch: int = int(os.getenv("MIZAN_RERANK_BATCH", "8"))
    rerank_4bit: bool = os.getenv("MIZAN_RERANK_4BIT", "0") == "1"  # QLoRA-style 4-bit load (needed for the 4B on 8 GB)
    rerank_instruction: str = os.getenv(
        "MIZAN_RERANK_INSTRUCTION",
        "Given a question about Saudi tourism regulations, judge whether the passage answers it. "
        "The passage must come from the specific regulation the question names, not from a similar regulation")
    chunk_title: bool = os.getenv("MIZAN_CHUNK_TITLE", "0") == "1"  # embed "<regulation title> + chunk" instead of bare chunk text
    chunk_size: int = int(os.getenv("MIZAN_CHUNK_SIZE", "600"))  # characters, after preprocessing
    chunk_overlap: int = int(os.getenv("MIZAN_CHUNK_OVERLAP", "100"))  # characters
    top_k: int = int(os.getenv("MIZAN_TOP_K", "4"))
    llm_provider: str = os.getenv("MIZAN_LLM_PROVIDER", "mock")  # hf | ollama (both local) | anthropic | openai | mock
    llm_model: str = os.getenv("MIZAN_LLM_MODEL", "claude-haiku-4-5-20251001")
    # Independent judge for LLM-as-judge scoring. Leave empty to reuse the generator (NOT recommended: self-preference bias).
    judge_provider: str = os.getenv("MIZAN_JUDGE_PROVIDER", "")
    judge_model: str = os.getenv("MIZAN_JUDGE_MODEL", "")
    prompt_version: str = os.getenv("MIZAN_PROMPT", "v1")  # v1 | v2 | v3: system prompt of the generator, see src/rag.py PROMPTS
    llm_temperature: float = 0.0
    llm_max_tokens: int = int(os.getenv("MIZAN_MAX_TOKENS", "600"))
    hf_quant: str = os.getenv("MIZAN_HF_QUANT", "4bit")  # local generator/judge precision: 4bit (tested) | none (16-bit)
    llm_cache: bool = os.getenv("MIZAN_LLM_CACHE", "1") == "1"  # 0 = always generate (fresh timings), never read/write the cache
    # NOTE: the LLM is shown each retrieved chunk exactly as it was indexed (i.e. after the
    # pipeline's own preprocessing). Known confound/design question -- see README "Limitations".

    def as_dict(self) -> dict:
        return asdict(self)


def override(**changes) -> None:
    """Change settings after import (the notebook does this once, after it has chosen a memory profile). SETTINGS is
    frozen so nothing changes by accident elsewhere; this is the single deliberate exception."""
    for k, v in changes.items():
        if not hasattr(SETTINGS, k):
            raise AttributeError(f"unknown setting '{k}'")
        object.__setattr__(SETTINGS, k, v)


# The two pipelines shown side by side in the demo and UI (comma separated; first = baseline).
DEMO_PIPELINES = tuple(x.strip() for x in os.getenv("MIZAN_PIPELINES", "baseline,mizan-lite+repair_lam_alef").split(",") if x.strip())

SETTINGS = SharedSettings()

# Which documents are indexed: "pdf" (data/raw, the default), "web" (data/web/raw) or "all". Same for both pipelines.
CORPUS = os.getenv("MIZAN_CORPUS", "pdf")
if CORPUS not in ("pdf", "web", "all"):
    raise ValueError(f"MIZAN_CORPUS must be pdf, web or all, not {CORPUS!r}")


def resolve_data_dir() -> tuple[Path, bool]:
    """Return (directory, is_synthetic_sample). Real PDFs in data/raw win over the sample."""
    if any(RAW_DIR.glob("*.pdf")):
        return RAW_DIR, False
    return SAMPLE_DIR, True


def resolve_questions_path() -> tuple[Path, bool]:
    """Return (path, is_sample). Questions follow the data: synthetic sample data -> the sample questions;
    real PDFs in data/raw -> eval/questions.json (sample questions would not match). That file quotes the documents and is kept out of the
    public repository; when it is absent the path is still returned and src.evaluation.load_questions decides whether that is an error."""
    override = os.getenv("MIZAN_QUESTIONS")  # e.g. eval/questions_large.json
    if override:
        return (ROOT / override), False
    if CORPUS == "web":  # the PDF questions do not fit the web corpus
        return WEB_QUESTIONS, False
    if resolve_data_dir()[1]:
        return EVAL_DIR / "questions.sample.json", True
    return EVAL_DIR / "questions.json", False
