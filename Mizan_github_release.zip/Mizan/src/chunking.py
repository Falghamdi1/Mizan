"""Chunking -- IDENTICAL for both pipelines. Chunks never cross page boundaries, so every
chunk's (file, page) citation is exact.

Sentences are split on sentence punctuation (. ! ? ؟ ؛) and blank lines only -- NOT on single
newlines -- so the splitter does not behave differently depending on how PDF lines wrapped.
Chunk size is measured in characters (after preprocessing).
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from .ingestion import Page

_SENT_SPLIT = re.compile(r"(?<=[.!?؟؛])\s+|\n\s*\n")


@dataclass
class Chunk:
    id: str
    doc: str
    title: str
    page: int
    index: int  # chunk number within the page
    text: str


def _sentences(text: str, max_len: int) -> list[str]:
    out: list[str] = []
    for s in _SENT_SPLIT.split(text):
        s = s.strip()
        while len(s) > max_len:  # very long run without punctuation: hard split on a space
            cut = s.rfind(" ", 0, max_len)
            cut = cut if cut > max_len // 2 else max_len
            out.append(s[:cut].strip())
            s = s[cut:].strip()
        if s:
            out.append(s)
    return out


def chunk_page(page: Page, size: int, overlap: int) -> list[Chunk]:
    sents = _sentences(page.text, size)
    groups: list[list[str]] = []
    cur: list[str] = []
    cur_len = 0
    for s in sents:
        if cur and cur_len + len(s) + 1 > size:
            groups.append(cur)
            # carry trailing sentences worth <= overlap chars into the next chunk
            carry: list[str] = []
            carried = 0
            for prev in reversed(cur):
                if carried + len(prev) > overlap:
                    break
                carry.insert(0, prev)
                carried += len(prev) + 1
            cur, cur_len = carry, carried
        cur.append(s)
        cur_len += len(s) + 1
    if cur:
        groups.append(cur)

    chunks = []
    for i, g in enumerate(groups):
        text = " ".join(g).strip()
        if text:
            chunks.append(Chunk(f"{page.doc}::p{page.page}::c{i}", page.doc, page.title, page.page, i, text))
    return chunks


def chunk_pages(pages: list[Page], size: int, overlap: int) -> list[Chunk]:
    out: list[Chunk] = []
    for p in pages:
        out.extend(chunk_page(p, size, overlap))
    return out
