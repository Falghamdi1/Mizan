"""Vector store (Chroma, persistent, cosine). One collection per pipeline so nothing is shared
except the embedding model. Collections are rebuilt from scratch on every `build_index` call:
the corpus is tiny and this removes any risk of stale vectors from an earlier config.
"""
from __future__ import annotations

import os
import re
import time
from functools import lru_cache
from dataclasses import dataclass

import chromadb

from .chunking import Chunk
from .config import PROCESSED_DIR
from .embeddings import get_embedder


@dataclass
class Retrieved:
    rank: int
    score: float  # cosine similarity (1 - cosine distance)
    chunk_id: str
    doc: str
    title: str
    page: int
    text: str
    tokens: int  # length under the embedding model's tokenizer
    rerank_score: float | None = None  # P(relevant) from the second stage, if enabled
    first_stage_rank: int | None = None  # rank before reranking


@lru_cache(maxsize=1)
def _client():
    """In-memory Chroma by default. Indexes are rebuilt from scratch on every run, so disk persistence
    bought nothing, and the on-disk client intermittently failed with
    "hnsw segment reader: Nothing found on disk" right after building several collections.
    Set MIZAN_CHROMA_PERSIST=1 to keep indexes in data/processed/chroma."""
    if os.getenv("MIZAN_CHROMA_PERSIST") == "1":
        return chromadb.PersistentClient(path=str(PROCESSED_DIR / "chroma"))
    return chromadb.EphemeralClient()


def _collection_name(pipeline: str) -> str:
    # Chroma names: 3-512 chars of [a-zA-Z0-9._-]
    return "mizan_" + re.sub(r"[^a-zA-Z0-9._-]", "_", pipeline)


# What was stored per pipeline, kept in memory so a collection that Chroma loses or silently empties can be rebuilt WITHOUT re-embedding.
# (Observed with the offline hash embedder: with three collections alive in one in-memory client, queries on one of them occasionally
# return nothing and keep doing so. The guard in `search` turns that into a rebuild instead of a crash or, worse, a miss.)
_STORE: dict[str, dict] = {}


def _populate(name: str, st: dict):
    client = _client()
    try:
        client.delete_collection(name)
    except Exception:
        pass
    col = client.create_collection(name, metadata={"hnsw:space": "cosine"})
    col.add(ids=st["ids"], embeddings=st["vectors"].tolist(), documents=st["texts"], metadatas=st["metas"])
    return col


def build_index(pipeline: str, chunks: list[Chunk]) -> dict:
    """Embed + store chunks. Returns index statistics (all measured, none estimated)."""
    emb = get_embedder()
    name = _collection_name(pipeline)
    texts = [c.text for c in chunks]
    vectors = emb.embed_passages(texts)
    tokens = emb.count_tokens(texts)
    _STORE[name] = {"ids": [c.id for c in chunks], "vectors": vectors, "texts": texts,
                    "metas": [{"doc": c.doc, "title": c.title, "page": c.page, "tokens": t} for c, t in zip(chunks, tokens)]}
    _populate(name, _STORE[name])
    return {
        "chunks": len(chunks),
        "chars": sum(len(t) for t in texts),
        "tokens": sum(tokens),
        "token_unit": emb.token_unit,
    }


def _query(col, vector, k: int) -> dict:
    return col.query(query_embeddings=[vector], n_results=k)


def search(pipeline: str, query_text: str, k: int) -> list[Retrieved]:
    """`query_text` must already be preprocessed with the same config as the index."""
    emb = get_embedder()
    name = _collection_name(pipeline)
    vector = emb.embed_query(query_text).tolist()
    res, col = None, None
    for attempt in range(3):
        try:
            col = _client().get_collection(name)
            res = _query(col, vector, k)
            if len(res["ids"][0]) >= min(k, col.count()):
                break
        except Exception:
            if name not in _STORE:
                raise
        if name in _STORE:       # the collection is missing, or returns nothing although it holds chunks: rebuild it from memory
            time.sleep(0.1 * attempt)
            col = _populate(name, _STORE[name])
            res = _query(col, vector, k)
            if len(res["ids"][0]) >= min(k, col.count()):
                break
    if res is None or len(res["ids"][0]) < min(k, col.count()):
        # Empty retrieval must never be scored as "not found".
        raise RuntimeError(f"Chroma returned {0 if res is None else len(res['ids'][0])} of {k} results for '{pipeline}' although the index has "
                           f"{col.count() if col is not None else '?'} chunks, also after rebuilding the collection from memory. "
                           "Build and evaluate pipelines one at a time and call retrieval.drop_index() after each (see src/ablation.py).")
    out = []
    for i, (cid, dist, doc, meta) in enumerate(
        zip(res["ids"][0], res["distances"][0], res["documents"][0], res["metadatas"][0]), start=1
    ):
        out.append(Retrieved(i, 1.0 - dist, cid, meta["doc"], meta["title"], meta["page"], doc, meta["tokens"]))
    return out


def drop_index(pipeline: str) -> None:
    """Free a pipeline's collection (used when many pipelines are evaluated one after another)."""
    _STORE.pop(_collection_name(pipeline), None)
    try:
        _client().delete_collection(_collection_name(pipeline))
    except Exception:
        pass
