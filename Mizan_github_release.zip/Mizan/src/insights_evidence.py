"""Mizan Insights, stages A to C: collect the evidence of the CURRENT run, check it, and decide what it can and cannot support.

No model runs here and no sentence of analysis is written here. This module only produces

  facts        a numbered ledger of measured or inspected statements about this run (F1, F2, ...), each computed from the
               objects of this run (the question, the documents loaded now, both pipelines' results, the metrics of src/evaluation.py)
  texts        the untrusted free text the model may need to read (question, answers, short passage snippets)
  not_measured what this run did not measure (answer correctness, faithfulness, ...)
  allowed      which conclusions the evidence permits, computed from the measurements (see `compute_allowed`)
  blocking     problems that make any analysis misleading (for example an index that does not belong to the loaded documents)

`src/insights.py` hands this to the configured LLM and checks what comes back against it.

Honesty rules built into the computation:
  * missing is never zero: an unmeasured value stays None and is reported as unmeasured;
  * a relative change is only computed when the baseline is a positive number;
  * one question is not an aggregate: aggregate statements need `evaluate_prepared` results, and an interval is computed only from
    MIN_N_INTERVAL answerable questions (paired bootstrap over questions, src/stats.py; questions are treated as independent);
  * "retrieval quality" needs gold evidence (a prepared question, or an evidence phrase typed by the user). Without it only
    descriptive differences exist, and no pipeline can be called better at retrieval;
  * an index is only trusted if it records the fingerprint of the documents loaded now (rag.Pipeline.build);
  * aggregate results computed on a different document set are dropped, never shown as current.
"""
from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from datetime import datetime
from difflib import SequenceMatcher

from . import citations, safety
from .config import SETTINGS
from .evaluation import ABSTAIN_MARKER, retrieval_only_result, score
from .ingestion import Page, pages_fingerprint
from .preprocessing import _INVISIBLE, FLAGS, canonical_for_eval, preprocess_pages, presentation_form_ratio
from .stats import paired_bootstrap

ANALYSIS_VERSION = "insights-1"
MIN_N_INTERVAL = 20          # answerable questions needed before an aggregate result counts as supported and gets an interval
SNIPPET_CHARS = 140          # how much of a retrieved passage the model may read
SNIPPETS_PER_PIPELINE = 3    # passages per pipeline whose text the model may read (all of them are listed in the facts)
ANSWER_CHARS = 450           # how much of an answer the model may read
MAX_EXAMPLES = 1             # extraction-artifact examples per document
MAX_DOC_LISTED = 2           # documents whose extraction check is spelled out in the facts: uploaded ones, then the top result of each pipeline, then the rest
TOKEN_EQUAL_BELOW = 0.01     # token counts within 1% of each other count as equal
ARABIC_CHARS_PER_TOKEN, OTHER_CHARS_PER_TOKEN = 2.6, 3.1   # measured on the Qwen3 tokenizer, on this module's JSON (2,387 real tokens, 2,423 estimated)


def estimate_tokens(text: str) -> int:
    """Token estimate for a prompt part, from the share of Arabic script (provider-independent; the real count is only known to the provider)."""
    ar = sum(0x0600 <= o <= 0x06FF or 0xFB50 <= o <= 0xFDFF or 0xFE70 <= o <= 0xFEFF for o in map(ord, text))
    return round(ar / ARABIC_CHARS_PER_TOKEN + (len(text) - ar) / OTHER_CHARS_PER_TOKEN)


def context_token_budget() -> int:
    """Tokens the evidence may take in the prompt. A local model served by Ollama has a 4,096-token window by default (prompt + answer),
    and the instructions and the answer need about 1,550 of it; set MIZAN_INSIGHTS_CONTEXT_TOKENS higher if the window is larger."""
    import os

    try:
        return max(800, int(os.getenv("MIZAN_INSIGHTS_CONTEXT_TOKENS", "2300")))
    except ValueError:
        return 2300

STANCES = ("standard_ahead", "mizan_ahead", "similar", "mixed", "insufficient_evidence")
RECOMMENDATIONS = ("standard", "mizan", "either", "no_recommendation")
SCOPES = ("single_question", "aggregate")
WITHHELD = "[text withheld: it contains instruction-like wording]"
AHEAD = {"standard": "standard_ahead", "mizan": "mizan_ahead"}

# What the code itself does that is not "only the preprocessing" (README section 2, ui.experiment_details). These describe the
# implementation, not a result.
KNOWN_CONFOUNDS = (
    "Chunks are cut by character count AFTER preprocessing, so the two indexes have different chunk counts and boundaries.",
    "The generator reads each pipeline's passages as indexed, that is after that pipeline's own preprocessing.",
    "Each pipeline preprocesses the query with its own configuration before retrieval (part of the intended variable).",
)

# Always true, so they are written into the instructions of the model once (src/insights.py) instead of being sent with every run; the
# panel still lists them.
NOT_MEASURED_ALWAYS = (
    "Answer correctness. No answer is graded automatically here; only people can grade it (scripts/human_grading.py).",
    "Whether a cited page really supports the sentence it follows. The citation check only compares the marker with the passages shown.",
)
STATIC_UNSUPPORTED = (
    "That either pipeline is better in general.",
    "Statistical significance (no significance test was run on the single question).",
    "That an answer is correct because it carries a citation, or wrong because its wording differs from the other answer.",
    "Any value for this run that is not in the facts; earlier project evaluations are not measurements of this run.",
)


class EvidenceError(ValueError):
    """The run cannot be analysed (wrong number of pipelines, nothing to compare). The message says why."""


# ---------------------------------------------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------------------------------------------
_ADIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
_IDENT = re.compile(r"[A-Za-z][A-Za-z0-9_.\-+]*\d[A-Za-z0-9_.\-+]*")      # V012, Qwen3-4B, F12, top-4, p.7: names, not quantities
_NUM = re.compile(r"(?<![\w.])\d+(?:\.\d+)?")
_THOUSANDS = re.compile("(?<=\\d)[,\u066c](?=\\d{3}(?!\\d))")
_KASHIDA = chr(0x0640)
_INVISIBLE_CHARS = {chr(c) for c in _INVISIBLE}


def number_tokens(text: str) -> list[str]:
    """Quantities written in `text`, as written (Arabic-Indic digits and thousands separators handled; identifiers such as file names,
    model names and fact ids are not quantities)."""
    t = _THOUSANDS.sub("", (text or "").translate(_ADIGITS))
    t = _IDENT.sub(" ", t)
    return [m.group(0) for m in _NUM.finditer(t)]


def strip_identifiers(text: str) -> str:
    """`text` with names that contain digits (top-4, Qwen3-4B, V012, F12, p.7) blanked out, so that the digit in a name is not read as a quantity."""
    return _IDENT.sub(" ", text or "")


def extract_numbers(text: str) -> list[float]:
    return [float(s) for s in number_tokens(text)]


def figures(text: str) -> list[str]:
    """Digits written in an answer, without the page numbers inside [file, page N] citation markers."""
    t = _THOUSANDS.sub("", citations.CITE.sub(" ", text or "").translate(_ADIGITS))
    return sorted({m.group(0) for m in re.finditer(r"\d+(?:\.\d+)?", t)}, key=lambda s: (len(s), s))


def _clean(text: str, limit: int) -> tuple[str, bool]:
    """Collapse whitespace, cap the length and withhold text that looks like an instruction (untrusted text is data)."""
    t = " ".join((text or "").split())
    if safety.scan_injection(t):
        return WITHHELD, True
    t = safety.mask_pii(t)                           # a second model gets no e-mail address, phone number, national ID or IBAN
    return (t if len(t) <= limit else t[:limit].rstrip() + " ..."), False


def _is_refusal(answer: str) -> bool:
    return ABSTAIN_MARKER in canonical_for_eval(answer or "")


def _r(x, d=3):
    return None if x is None else round(float(x), d)


def _pct(change: float | None) -> str:
    return "not defined" if change is None else f"{change * 100:+.1f}%"


def _rel(a, b):
    """(b - a) / a, only when both are measured and a is positive. None otherwise (never a division by zero, never a missing value as 0)."""
    return None if a is None or b is None or a <= 0 else (b - a) / a


def _versus(a, b, unit: str = "", digits: int = 0, lo: str = "lower", hi: str = "higher") -> str:
    """"Standard 1207, Mizan-lite 1155" is left to the caller; this returns the direction in words, computed here so that a small model does not
    have to compare numbers: "Mizan-lite 4.3% lower", "equal", or "change not defined" (a missing value or a baseline that is not positive)."""
    rel = _rel(a, b)
    if rel is None:
        return "change not defined"
    if abs(rel) < TOKEN_EQUAL_BELOW:
        return "equal"
    diff = abs(b - a)
    return f"Mizan-lite {abs(rel) * 100:.1f}% {lo if b < a else hi}" if unit == "%" else f"Mizan-lite {diff:.{digits}f}{unit} {lo if b < a else hi} ({abs(rel) * 100:.1f}%)"


def _higher(a, b) -> str | None:
    """Which pipeline has the higher value of a measured quantity ("standard" or "mizan"), "equal" within 1%, None if either is not measured."""
    if a is None or b is None:
        return None
    if a == b:
        return "equal"
    lo = min(a, b)
    if lo > 0 and abs(b - a) / lo < TOKEN_EQUAL_BELOW:
        return "equal"
    return "mizan" if b > a else "standard"


def _fav_lower(rel: float | None) -> str | None:
    """Which side is cheaper, from the relative change of the second over the first; None if it cannot be told."""
    return None if rel is None else ("equal" if abs(rel) < TOKEN_EQUAL_BELOW else "mizan" if rel < 0 else "standard")


def pipeline_labels(names: list[str]) -> dict[str, str]:
    b = names[1]
    return {"standard": "Standard" if names[0].startswith("baseline") else names[0],
            "mizan": "Mizan-lite" if "lite" in b else ("Mizan (full preset)" if b.startswith("mizan") else b)}


def _arabic_chars(text: str) -> int:
    return sum(0x0600 <= o <= 0x06FF or 0xFB50 <= o <= 0xFDFF or 0xFE70 <= o <= 0xFEFF for o in map(ord, text))


# ---------------------------------------------------------------------------------------------------------------
# Documents: what was loaded, what the extraction looks like (inspected, not assumed)
# ---------------------------------------------------------------------------------------------------------------
_DIAG_CACHE: dict[tuple[str, str], dict] = {}
_CANON_CACHE: dict[tuple[str, str], list[tuple[str, int, str]]] = {}


def _ligature_examples(pages: list[Page]) -> list[str]:
    out = []
    for p in pages:
        a, b = p.text.split(), p.text_repaired.split()
        for tag, i1, i2, j1, j2 in SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
            if tag == "replace" and i2 - i1 <= 2 and j2 - j1 <= 2:
                out.append(f"{' '.join(a[i1:i2])} -> {' '.join(b[j1:j2])}")
                break
        if len(out) >= MAX_EXAMPLES:
            break
    return out


def document_diagnostics(pages: list[Page], fp: str) -> dict[str, dict]:
    """Per document, measured on the extracted text of the documents loaded now: share of presentation forms, share of kashida,
    invisible characters, pages where the lam-alef repair changes the text, and a few examples of that change."""
    if len(_DIAG_CACHE) > 400:
        _DIAG_CACHE.clear()
    by_doc: dict[str, list[Page]] = {}
    for p in pages:
        by_doc.setdefault(p.doc, []).append(p)
    out = {}
    for doc, ps in by_doc.items():
        key = (fp, doc)
        if key not in _DIAG_CACHE:
            text = "".join(p.text for p in ps)
            arabic = _arabic_chars(text)
            changed = [p for p in ps if p.text_repaired and p.text_repaired != p.text]
            _DIAG_CACHE[key] = {
                "pages": len(ps), "chars": len(text),
                "presentation_forms_share": _r(presentation_form_ratio(text), 4),
                "kashida_share": _r(text.count(_KASHIDA) / arabic, 4) if arabic else 0.0,
                "invisible_chars": sum(c in _INVISIBLE_CHARS for c in text),
                "pages_changed_by_lam_alef_repair": len(changed),
                "examples": _ligature_examples(changed)}
        out[doc] = _DIAG_CACHE[key]
    return out


def observed_issues(d: dict) -> list[str]:
    """Plain list of what the diagnostics actually show for one document ([] = nothing observed)."""
    issues = []
    if d["presentation_forms_share"]:
        issues.append(f"{d['presentation_forms_share'] * 100:.1f}% of Arabic characters are presentation forms")
    if d["kashida_share"] and d["kashida_share"] >= 0.005:
        issues.append(f"kashida is {d['kashida_share'] * 100:.1f}% of Arabic characters")
    if d["invisible_chars"]:
        issues.append(f"{d['invisible_chars']} invisible or bidi control characters")
    if d["pages_changed_by_lam_alef_repair"]:
        issues.append(f"the lam-alef repair changes {d['pages_changed_by_lam_alef_repair']} of {d['pages']} pages")
    return issues


def _canon_pages(pages: list[Page], fp: str, cfg) -> list[tuple[str, int, str]]:
    key = (fp, cfg.name if cfg else "raw")
    if key not in _CANON_CACHE:
        if len(_CANON_CACHE) > 12:
            _CANON_CACHE.clear()
        src = preprocess_pages(pages, cfg) if cfg else pages
        _CANON_CACHE[key] = [(p.doc, p.page, canonical_for_eval(p.text)) for p in src]
    return _CANON_CACHE[key]


def evidence_presence(pages: list[Page], fp: str, cfg, gold: dict) -> dict:
    """Is the gold evidence in the text this pipeline indexes (page level, same canonical matcher as the evaluation)? Separates a text
    that never contained the evidence from a retrieval miss. A phrase split across two chunks is still found here (page level)."""
    groups = [[canonical_for_eval(ph) for ph in g] for g in (gold.get("gold_evidence") or [])]
    allowed = gold.get("gold_docs")
    found, hit_pages, docs = 0, 0, set()
    cp = [c for c in _canon_pages(pages, fp, cfg) if not allowed or c[0] in allowed]
    for g in groups:
        hits = [(d, pg) for d, pg, t in cp if any(ph and ph in t for ph in g)]
        found += bool(hits)
        hit_pages += len(hits)
        docs |= {d for d, _ in hits}
    return {"groups_found": found, "n_groups": len(groups), "pages": hit_pages, "docs": sorted(docs)}


# ---------------------------------------------------------------------------------------------------------------
# The evidence object
# ---------------------------------------------------------------------------------------------------------------
@dataclass
class Evidence:
    scope: str                              # single_question | aggregate | single_question_and_aggregate
    labels: dict[str, str]
    question: str | None
    facts: list[dict]
    texts: dict
    not_measured: list[str]
    unsupported_claims: list[str]
    allowed: dict
    dimensions: dict
    blocking: list[str]
    meta: dict
    checks: dict = field(default_factory=dict)      # for src/insights.py: which side is higher per measured quantity, who retrieved the gold evidence
    lang: str = "en"
    fingerprint: str = ""
    created: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))

    def context(self) -> dict:
        """What the model receives. The only free text in it (question, answers, excerpts) is under "untrusted". The measured dimensions and the
        pipeline settings are not repeated here: the facts say the same, and a local model has a 4,096-token window for prompt and reply together."""
        run = {k: self.meta[k] for k in ("documents", "pages", "corpus_fingerprint", "uploaded", "notes")}
        return {"analysis_version": ANALYSIS_VERSION, "run_scope": self.scope, "pipelines": self.labels, "run": run,
                "untrusted": {"question": self.question, **self.texts},
                "facts": [{"id": f["id"], "kind": f["kind"], "text": f["text"]} for f in self.facts],
                "not_measured": [x for x in self.not_measured if x not in NOT_MEASURED_ALWAYS],
                "claims_not_supported": [x for x in self.unsupported_claims if x not in STATIC_UNSUPPORTED], "allowed": self.allowed}

    def fact_numbers(self, ids: list[str]) -> list[float]:
        wanted = set(ids)
        return [n for f in self.facts if f["id"] in wanted for n in extract_numbers(f["text"])]

    def all_numbers(self) -> list[float]:
        """Every quantity anywhere in the evidence the model was given (facts, question, answers, snippets)."""
        return extract_numbers(json.dumps(self.context(), ensure_ascii=False))

    def untrusted_numbers(self) -> list[float]:
        return extract_numbers(json.dumps(self.context()["untrusted"], ensure_ascii=False))


class _Ledger:
    def __init__(self):
        self.facts: list[dict] = []

    def add(self, kind: str, scope: str, text: str) -> str:
        fid = f"F{len(self.facts) + 1}"
        self.facts.append({"id": fid, "kind": kind, "scope": scope, "text": text})
        return fid


# ---------------------------------------------------------------------------------------------------------------
# Aggregate: a retrieval-only evaluation on the prepared questions, with the repository's own metric code
# ---------------------------------------------------------------------------------------------------------------
def evaluate_prepared(pipes: dict, questions: list[dict], pages: list[Page], source: str = "prepared questions") -> dict:
    """Run every question that has a gold_evidence field (empty for unanswerable ones) through both pipelines, retrieval only, with
    `evaluation.score`. Returns a plain dict tied to the documents loaded now (pages fingerprint) and to the question set (hash)."""
    names = list(pipes)
    rows: dict[str, list[dict]] = {n: [] for n in names}
    for q in questions:
        if "gold_evidence" not in q:
            continue
        for n in names:
            s = score(q, retrieval_only_result(pipes[n], n, q["question"]))
            rows[n].append({"id": q["id"], "answerable": bool(q.get("gold_evidence")), **{k: s.get(k) for k in (
                "hit", "mrr", "precision", "first_relevant_rank", "candidate_recall", "retrieved_tokens", "retrieval_latency_s")}})
    qhash = hashlib.sha256(json.dumps([[q.get("id"), q.get("question"), q.get("gold_evidence")] for q in questions],
                                      ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()
    return {"names": names, "rows": rows, "n_questions": len(rows[names[0]]), "questions_sha256": qhash, "source": source,
            "corpus_sha256": pages_fingerprint(pages), "created": datetime.now().isoformat(timespec="seconds")}


def _mean(xs):
    xs = [x for x in xs if x is not None]
    return sum(xs) / len(xs) if xs else None


def aggregate_stats(agg: dict) -> dict:
    """Means, paired differences (second minus first) and, from MIN_N_INTERVAL answerable questions, a paired-bootstrap interval."""
    a, b = agg["names"]
    ra, rb = ({r["id"]: r for r in agg["rows"][n]} for n in (a, b))
    ids = [i for i in ra if i in rb and ra[i]["answerable"] and ra[i]["hit"] is not None and rb[i]["hit"] is not None]
    out = {"n_questions": agg["n_questions"], "n_answerable": len(ids), "metrics": {}, "supported": len(ids) >= MIN_N_INTERVAL}
    for m in ("hit", "mrr", "precision", "candidate_recall"):
        va, vb = {i: ra[i][m] for i in ids if ra[i][m] is not None}, {i: rb[i][m] for i in ids if rb[i][m] is not None}
        entry = {"standard": _r(_mean(va.values())), "mizan": _r(_mean(vb.values()))}
        both = sorted(set(va) & set(vb))
        if both:
            entry["diff"] = _r(_mean(vb[i] - va[i] for i in both))
            if len(both) >= MIN_N_INTERVAL:
                boot = paired_bootstrap({i: va[i] for i in both}, {i: vb[i] for i in both})
                entry["interval"] = [_r(boot[1]), _r(boot[2])] if boot else None
        out["metrics"][m] = entry
    out["only_standard_hit"] = sum(1 for i in ids if ra[i]["hit"] and not rb[i]["hit"])
    out["only_mizan_hit"] = sum(1 for i in ids if rb[i]["hit"] and not ra[i]["hit"])
    out["both_hit"] = sum(1 for i in ids if ra[i]["hit"] and rb[i]["hit"])
    out["neither_hit"] = sum(1 for i in ids if not ra[i]["hit"] and not rb[i]["hit"])
    out["retrieved_tokens"] = {"standard": _r(_mean(r["retrieved_tokens"] for r in agg["rows"][a]), 1),
                               "mizan": _r(_mean(r["retrieved_tokens"] for r in agg["rows"][b]), 1)}
    out["retrieval_latency_median_s"] = {}
    for key, n in (("standard", a), ("mizan", b)):
        lat = sorted(r["retrieval_latency_s"] for r in agg["rows"][n] if r["retrieval_latency_s"] is not None)
        out["retrieval_latency_median_s"][key] = _r(lat[len(lat) // 2], 3) if lat else None
    d = out["metrics"]["hit"].get("diff")
    iv = out["metrics"]["hit"].get("interval")
    if d is None or not ids:
        out["relation"], out["strength"] = None, "none"
    elif out["supported"] and iv:
        out["relation"] = "mizan" if iv[0] > 0 else "standard" if iv[1] < 0 else "equal"
        out["strength"] = "supported" if out["relation"] != "equal" else "not_distinguishable"
    else:
        out["relation"], out["strength"] = ("mizan" if d > 0 else "standard" if d < 0 else "equal"), "preliminary"
    return out


# ---------------------------------------------------------------------------------------------------------------
# What the evidence allows (deterministic constraints, not text)
# ---------------------------------------------------------------------------------------------------------------
def _dimension(measured: bool, favours: str | None, **extra) -> dict:
    return {"measured": measured, "favours": favours if measured else None, **extra}


def compute_allowed(dim: dict, agg_stats: dict | None, has_single: bool) -> dict:
    """From the measured dimensions, decide which stance and recommendation the evidence permits for each scope. The model chooses among
    them and writes the explanation; the validator rejects anything outside them.

    single question: a direction needs gold evidence for that question (dimension retrieval_quality); "mixed" needs two measured
                     dimensions (retrieval, grounding, answer behaviour, tokens) that favour different pipelines.
    aggregate:       a direction needs MIN_N_INTERVAL answerable questions and an interval that excludes zero; "similar" needs the same
                     sample size and an interval that includes zero; a smaller sample only allows "mixed" or "insufficient_evidence".
    Efficiency alone never allows "ahead"; with equal quality it allows a conditional recommendation of the cheaper pipeline."""
    by_scope: dict[str, list[str]] = {}
    recs: dict[str, set[str]] = {}
    unconditional: set[str] = set()
    if has_single:
        s, q, r = {"insufficient_evidence"}, dim["retrieval_quality"], {"no_recommendation"}
        single_dims = ("retrieval_quality", "grounding", "answer_behaviour", "efficiency_tokens")
        favours = {dim[k]["favours"] for k in single_dims if dim[k].get("measured") and dim[k].get("favours") in AHEAD}
        if q["measured"] and q["favours"] in AHEAD:
            s.add(AHEAD[q["favours"]])
            r.add(q["favours"])
        elif q["measured"] and q["favours"] == "equal":
            s.add("similar")
            if not q.get("both_missed"):                        # both missing the evidence is a shared failure: nothing to recommend
                r.add("either")
                if dim["efficiency_tokens"].get("favours") in AHEAD:
                    r.add(dim["efficiency_tokens"]["favours"])
        if len(favours) == 2:
            s.add("mixed")
        by_scope["single_question"], recs["single_question"] = sorted(s), r
    if agg_stats:
        s, tok, r = {"insufficient_evidence"}, dim.get("aggregate_efficiency_tokens", {}), {"no_recommendation"}
        strength, rel = agg_stats["strength"], agg_stats["relation"]
        if strength == "supported":
            s.add(AHEAD[rel])
            r.add(rel)
            unconditional.add(rel)
            if tok.get("measured") and tok.get("favours") in AHEAD and tok["favours"] != rel:
                s.add("mixed")
        elif strength == "not_distinguishable":
            s.add("similar")
            r.add("either")
            if tok.get("measured") and tok.get("favours") in AHEAD:
                r.add(tok["favours"])
                s.add("mixed")
        elif strength == "preliminary":
            s.add("mixed")                                  # a direction from a small set is reported as preliminary, never as a winner
        by_scope["aggregate"], recs["aggregate"] = sorted(s), r
    if not by_scope:
        by_scope["aggregate"], recs["aggregate"] = ["insufficient_evidence"], {"no_recommendation"}
    # a recommendation belongs to the scope of the finding it follows: what one question shows is never recommended as if it were the aggregate, and the
    # aggregate is never recommended for one question. Only a supported aggregate lifts the condition ("recommendation_without_condition", scope aggregate only).
    return {"stance_by_scope": by_scope, "recommendation": {k: sorted(v) for k, v in recs.items()}, "recommendation_without_condition": sorted(unconditional),
            "minimum_questions_for_a_supported_aggregate": MIN_N_INTERVAL}


# ---------------------------------------------------------------------------------------------------------------
# Build the evidence of one run
# ---------------------------------------------------------------------------------------------------------------
def _single(label: str, name: str, entry: dict, gold: dict | None) -> dict:
    r = entry["result"]
    sc = entry["score"] or (score(gold, r) if gold else None)
    shown = r.meta.get("shown", r.passages)
    refused = _is_refusal(r.answer)
    cit = citations.check(r.answer, shown) if (r.answer or "").strip() and not refused else None
    pass_figs = {f for p in shown for f in figures(safety.mask_pii(p.text))}      # personal data (a phone number is a string of digits) is not a "figure"
    ans_figs = figures(safety.mask_pii(r.answer)) if not refused else []
    answer, flagged = _clean(r.answer, ANSWER_CHARS)
    rows = []
    for p in r.passages:
        snippet = _clean(p.text, SNIPPET_CHARS)[0] if p.rank <= SNIPPETS_PER_PIPELINE else None
        rows.append({"rank": p.rank, "doc": p.doc, "page": p.page, "similarity": _r(p.score), "tokens": p.tokens, "snippet": snippet})
    return {"label": label, "name": name, "answer": answer, "answer_withheld": flagged, "refused": refused,
            "figures": ans_figs, "ungrounded_figures": [f for f in ans_figs if f not in pass_figs],
            "citations": cit and {"cited": cit["n_cited"], "valid": cit["n_valid"], "invalid": cit["n_invalid"]},
            "retrieved": rows, "withheld": r.meta.get("withheld") or [], "score": sc,
            "llm_input_tokens": r.llm.input_tokens, "llm_output_tokens": r.llm.output_tokens, "retrieved_tokens": r.retrieved_tokens,
            "retrieval_latency_s": _r(r.retrieval_latency_s, 3), "llm_latency_s": _r(r.llm.latency_s, 2), "llm_cached": r.llm.cached}


def _fit_budget(ev: Evidence) -> None:
    """Keep the evidence inside the prompt budget (a local model has a small window) by dropping the least important text first:
    passages beyond two and their length, then answer length, then all passage text, then the facts of documents that were not involved.
    The facts of the run, the dimensions and the allowed conclusions are never trimmed. What was trimmed is recorded in meta['notes']."""
    limit = context_token_budget()
    size = lambda: estimate_tokens(json.dumps(ev.context(), ensure_ascii=False))  # noqa: E731
    done = []

    def cut(t: str, n: int) -> str:
        return t if len(t) <= n else t[:n].rstrip() + " ..."

    if size() > limit:
        for t in ev.texts.values():
            t["passages"] = [{**p, "text": cut(p["text"], 90)} for p in t.get("passages", [])[:2]]
        done.append("passage excerpts shortened")
    if size() > limit:
        for t in ev.texts.values():
            t["answer"] = cut(t["answer"], 280)
        done.append("answers shortened")
    if size() > limit:
        for t in ev.texts.values():
            t["passages"] = []
        done.append("passage excerpts left out")
    if size() > limit:
        ev.facts = [f for f in ev.facts if not (f["kind"] == "document" and f["text"].startswith("The other "))]
        done.append("summary of uncited documents left out")
    if done:
        ev.meta["notes"].append("To fit the model's context window: " + ", ".join(done) + ". The facts of this run were not shortened.")


def build_evidence(*, pipes: dict, pages: list[Page], cmp: dict | None = None, question: str | None = None, gold: dict | None = None,
                   gold_source: str = "none", aggregate_eval: dict | None = None, uploaded: list[str] | None = None,
                   upload_notes: dict[str, list[str]] | None = None, lang: str = "en") -> Evidence:
    """Stage A to C for one state of the application.
    cmp            output of comparison.compare for `question` (None = aggregate only)
    gold           eval-style question dict with gold_evidence (a prepared question, or one built from a phrase the user typed)
    gold_source    "prepared" | "user_phrase" | "none"
    aggregate_eval output of `evaluate_prepared` (left out, and said so, if it belongs to another document set)"""
    names = list(pipes)
    if len(names) != 2:
        raise EvidenceError(f"Mizan Insights compares exactly two pipelines; this run has {len(names)}.")
    if not pages:
        raise EvidenceError("No documents are loaded.")
    if cmp is None and aggregate_eval is None:
        raise EvidenceError("Nothing to analyse: no comparison has been run yet.")
    labels = pipeline_labels(names)
    key = {"standard": names[0], "mizan": names[1]}
    roles = ("standard", "mizan")
    fp = pages_fingerprint(pages)
    L, blocking, notes, texts = _Ledger(), [], [], {}
    uploaded = [u for u in (uploaded or []) if u in {p.doc for p in pages}]
    has_single = cmp is not None

    # ---- stale aggregate -------------------------------------------------------------------------------------
    agg_stats = None
    if aggregate_eval is not None:
        if aggregate_eval.get("corpus_sha256") != fp or aggregate_eval.get("names") != names:
            notes.append("A prepared-question evaluation exists but was computed for a different document set or pipelines, so it is NOT part of this analysis.")
            aggregate_eval = None
        else:
            agg_stats = aggregate_stats(aggregate_eval)
    if cmp is None and aggregate_eval is None:
        raise EvidenceError("The prepared-question evaluation belongs to an earlier document set and there is no current comparison: run one again.")

    # ---- documents and indexes ---------------------------------------------------------------------------------
    diag = document_diagnostics(pages, fp)
    stats = {r_: pipes[key[r_]].index_stats for r_ in roles}
    index_ok = {r_: (stats[r_].get("pages_sha256") == fp) if stats[r_].get("pages_sha256") else None for r_ in roles}
    if any(v is False for v in index_ok.values()):
        bad = [labels[r_] for r_, v in index_ok.items() if v is False]
        blocking.append(f"The index of {', '.join(bad)} was not built from the documents that are loaded now. Re-add the documents or restart the application; "
                        "until then the comparison does not describe the current document set.")
    verified = all(v is True for v in index_ok.values())
    L.add("corpus", "run", f"The current document set has {len(diag)} documents and {len(pages)} pages (fingerprint {fp[:12]}). Uploaded in this session and still loaded: "
          + (", ".join(uploaded) if uploaded else "none") + ". "
          + ("Both indexes record this fingerprint, so both pipelines were built from, and answer from, these documents." if verified else
             "It could not be verified that both indexes were built from these documents."))
    if all(v is None for v in index_ok.values()):
        notes.append("The indexes do not record which documents they were built from, so it cannot be verified that they match the current document set.")
    for u in uploaded:
        for w in (upload_notes or {}).get(u, []):
            L.add("upload", "run", f"Upload check for {u}: {w}.")

    involved = set(uploaded)
    top_docs: list[str] = []
    if has_single:
        involved |= {p.doc for e in cmp.values() for p in e["result"].passages}
        top_docs = [e["result"].passages[0].doc for e in cmp.values() if e["result"].passages]
    listed = sorted(involved & set(diag), key=lambda d: (d not in uploaded, d not in top_docs, d))[:MAX_DOC_LISTED]
    if listed:
        parts = []
        for doc in listed:
            d = diag[doc]
            ex = f" (extracted -> repaired: {'; '.join(d['examples'])})" if d["examples"] else ""
            parts.append(f"{doc}, {d['pages']} pages: " + ("; ".join(observed_issues(d)) or "no artifact observed") + ex)
        L.add("document", "run", "Extraction check of the documents retrieved or uploaded, measured on their extracted text (presentation forms, kashida, invisible characters, "
              "pages changed by the lam-alef repair): " + " | ".join(parts) + ".")
    rest = sorted(x for x in diag if x not in listed)
    if rest:
        bad = [x for x in rest if observed_issues(diag[x])]
        L.add("document", "run", f"The other {len(rest)} loaded document(s): {len(bad)} show at least one extraction artifact under the same check.")

    # ---- design check ------------------------------------------------------------------------------------------
    ca, cb = pipes[names[0]].cfg, pipes[names[1]].cfg
    only_a = [f for f in FLAGS if getattr(ca, f) and not getattr(cb, f)]
    only_b = [f for f in FLAGS if getattr(cb, f) and not getattr(ca, f)]
    both_on = [f for f in FLAGS if getattr(ca, f) and getattr(cb, f)]
    L.add("design", "run", f"Preprocessing differs only in these steps. Enabled only for {labels['mizan']}: {', '.join(only_b) or 'none'}. "
          f"Enabled only for {labels['standard']}: {', '.join(only_a) or 'none'}. Enabled for both: {', '.join(both_on) or 'none'}.")
    s = SETTINGS
    emb = "hash (offline smoke-test embedder)" if s.embedder == "hash" else s.embedding_model + (
        f" with adapter {s.embedding_adapter.replace(chr(92), '/').split('/')[-1]}" if s.embedding_adapter else "")
    tok_change = _versus(stats["standard"].get("tokens"), stats["mizan"].get("tokens"))
    L.add("design", "run", f"Identical for both: embedder {emb}; reranker {s.reranker or 'none'}"
          + (f" (top {s.rerank_top_n} reranked)" if s.reranker else "") + f"; top-{s.top_k}; chunks of {s.chunk_size} characters, overlap {s.chunk_overlap}; "
          f"regulation title embedded with each chunk: {'yes' if s.chunk_title else 'no'}; "
          f"generator {s.llm_provider}:{s.llm_model}; prompt {s.prompt_version}. Index: {labels['standard']} {stats['standard'].get('chunks')} chunks, "
          f"{stats['standard'].get('tokens')} tokens; {labels['mizan']} {stats['mizan'].get('chunks')} chunks, {stats['mizan'].get('tokens')} tokens ({tok_change}). "
          "Known confound: chunking is by characters after preprocessing.")

    dim = {"retrieval_quality": _dimension(False, None), "grounding": _dimension(False, None),
           "answer_behaviour": _dimension(False, None), "efficiency_tokens": _dimension(False, None)}
    not_measured = list(NOT_MEASURED_ALWAYS)
    unsupported = list(STATIC_UNSUPPORTED)
    q_clean = None
    checks: dict = {"higher": {}, "hit": None}

    def truth(metric: str, a, b) -> None:
        h = _higher(a, b)
        if h:
            checks["higher"].setdefault(metric, [])
            if h not in checks["higher"][metric]:
                checks["higher"][metric].append(h)

    truth("index_tokens", stats["standard"].get("tokens"), stats["mizan"].get("tokens"))
    truth("index_chunks", stats["standard"].get("chunks"), stats["mizan"].get("chunks"))

    # ---- the single question -----------------------------------------------------------------------------------
    if has_single:
        q_clean, q_flag = _clean(question or "", 400)
        single = {r_: _single(labels[r_], key[r_], cmp[key[r_]], gold) for r_ in roles}
        sa, sb = single["standard"], single["mizan"]
        for r_, x in single.items():
            texts[r_] = {"answer": x["answer"], "passages": [{"rank": p["rank"], "text": p["snippet"]} for p in x["retrieved"] if p["snippet"]]}
        L.add("question", "single_question", "This part of the analysis covers ONE question. " + (
            "The question text was withheld because it contains instruction-like wording." if q_flag else
            f"It is a {'prepared' if gold_source == 'prepared' else 'free-text'} question of {len(question or '')} characters."))
        for r_ in roles:
            x = single[r_]
            listing = (f"{x['label']} retrieved (top {len(x['retrieved'])}): " + "; ".join(f"{p['rank']}. {p['doc']} page {p['page']}" for p in x["retrieved"]) + "."
                       if x["retrieved"] else f"{x['label']} retrieved no passage.")
            L.add("retrieval", "single_question", listing + (f" {len(x['withheld'])} passage(s) were withheld from the model because they contain "
                                                             "instruction-like wording." if x["withheld"] else ""))
        pa, pb = ({(p["doc"], p["page"]) for p in single[r_]["retrieved"]} for r_ in roles)
        top = [(single[r_]["retrieved"][0]["doc"], single[r_]["retrieved"][0]["page"]) if single[r_]["retrieved"] else None for r_ in roles]
        L.add("retrieval", "single_question", f"The two top-{SETTINGS.top_k} sets share {len(pa & pb)} (document, page) pairs; {len(pa - pb)} appear only for {labels['standard']} and "
              f"{len(pb - pa)} only for {labels['mizan']}. The top-1 page is " + ("the same." if top[0] == top[1] and top[0] else "different.")
              + " Similarity scores come from two different indexes (different text), so they are not directly comparable.")
        gold_ok = bool(gold and gold.get("gold_evidence")) and all(single[r_]["score"] and single[r_]["score"].get("hit") is not None for r_ in roles)
        if gold_ok:
            present = {r_: evidence_presence(pages, fp, pipes[key[r_]].cfg, gold) for r_ in roles}
            raw = evidence_presence(pages, fp, None, gold)
            src = "a prepared evaluation question" if gold_source == "prepared" else "an evidence phrase typed by the user"
            L.add("gold", "single_question", f"Gold evidence for this question comes from {src} ({raw['n_groups']} evidence group(s)). In the extracted text of the loaded documents it "
                  f"occurs on {raw['pages']} page(s); after {labels['standard']} preprocessing on {present['standard']['pages']}; after {labels['mizan']} preprocessing on {present['mizan']['pages']}.")
            if raw["pages"] == 0:
                notes.append("The evidence phrase was not found in any loaded document, so relevance metrics for this question mean nothing.")
            for r_ in roles:
                sc = single[r_]["score"]
                n_ret = len(single[r_]["retrieved"])
                L.add("gold", "single_question", f"{labels[r_]}: gold evidence " + (f"found in the top {n_ret} at rank {sc['first_relevant_rank']}" if sc["hit"] else f"NOT found in the top {n_ret}")
                      + f" (hit@{SETTINGS.top_k} = {sc['hit']}, precision@{SETTINGS.top_k} = {_r(sc['precision'])}"
                      + (f"; the candidate pool before reranking {'contained' if sc['candidate_recall'] else 'did not contain'} it" if sc.get("candidate_recall") is not None else "") + ").")
            ha, hb = (single[r_]["score"]["hit"] for r_ in roles)
            checks["hit"] = {"standard": int(ha), "mizan": int(hb)}
            cg = [single[r_]["score"].get("cites_gold") for r_ in roles if single[r_]["citations"] is not None]
            checks["cites_gold_all"] = bool(cg) and all(v == 1 for v in cg)      # every answer that cites a page cites one that holds the gold evidence
            if raw["pages"] == 0:                              # nothing to find: hit = 0 for both says nothing about either pipeline
                checks["hit"] = None
                not_measured.append("Whether the retrieved passages are the relevant ones for this question: the evidence phrase occurs in no loaded document, so the hit values are not evidence.")
            else:
                dim["retrieval_quality"] = _dimension(True, "mizan" if hb > ha else "standard" if ha > hb else "equal", basis="single_question_gold_evidence",
                                                      both_missed=not ha and not hb)
                if not ha and not hb:
                    L.add("gold", "single_question", "Neither pipeline retrieved the gold evidence for this question: a shared failure, not a tie that favours either.")
        else:
            not_measured.append("Whether the retrieved passages are the relevant ones for this question: no gold evidence exists for it, so hit@k, MRR and precision were not computed.")
            L.add("gold", "single_question", "No gold evidence exists for this question: retrieval relevance was not measured, so neither pipeline can be called better at retrieval from this run.")
        ra, rb = sa["refused"], sb["refused"]
        L.add("answer", "single_question", f"{labels['standard']} " + ("refused with the insufficient-evidence sentence" if ra else "gave an answer") + f"; {labels['mizan']} "
              + ("refused with the insufficient-evidence sentence" if rb else "gave an answer") + ".")
        for r_ in roles:
            x = single[r_]
            if x["citations"] is not None:
                c = x["citations"]
                cg = (x["score"] or {}).get("cites_gold") if gold else None
                L.add("citation", "single_question", f"{x['label']}'s answer cites {c['cited']} page(s); {c['valid']} of them are among the passages it was shown and {c['invalid']} are not."
                      + ("" if cg is None else f" A cited page {'holds' if cg else 'does not hold'} the gold evidence."))
            elif not x["refused"]:
                L.add("citation", "single_question", f"{x['label']}'s answer is empty.")
        kws = (gold or {}).get("answer_keywords") or []
        if kws and all(single[r_]["score"] and single[r_]["score"].get("keyword_coverage") is not None for r_ in roles):
            kw = {r_: round(single[r_]["score"]["keyword_coverage"] * len(kws)) for r_ in roles}
            L.add("keywords", "single_question", f"Reference keywords found in the answer text (a surface check of the wording, not a judgement of correctness): "
                  f"{labels['standard']} {kw['standard']} of {len(kws)}, {labels['mizan']} {kw['mizan']} of {len(kws)}.")
        if sa["figures"] or sb["figures"]:
            L.add("figures", "single_question", f"Figures written as digits in the answers (citation page numbers excluded): {labels['standard']} {sa['figures'] or 'none'}; {labels['mizan']} {sb['figures'] or 'none'}. "
                  f"Only in {labels['standard']}: {sorted(set(sa['figures']) - set(sb['figures'])) or 'none'}. Only in {labels['mizan']}: {sorted(set(sb['figures']) - set(sa['figures'])) or 'none'}.")
        for r_ in roles:
            x = single[r_]
            if x["figures"]:
                L.add("figures", "single_question", f"{x['label']}: " + (f"figures not found in the passages it was shown: {x['ungrounded_figures']}." if x["ungrounded_figures"]
                      else "every figure in its answer also appears in the passages it was shown.") + " (A surface check; a derived or spelled-out number is not caught.)")
        if not ra and not rb and sa["citations"] is not None and sb["citations"] is not None:
            pa_, pb_ = (single[r_]["citations"]["invalid"] + len(single[r_]["ungrounded_figures"]) for r_ in roles)
            dim["grounding"] = _dimension(True, "mizan" if pb_ < pa_ else "standard" if pa_ < pb_ else "equal", problems={"standard": pa_, "mizan": pb_})
        if ra != rb:
            dim["answer_behaviour"] = _dimension(True, ("mizan" if ra else "standard") if gold_ok else None, differs=True, refused={"standard": ra, "mizan": rb})
        else:
            dim["answer_behaviour"] = _dimension(True, "equal" if gold_ok else None, differs=False, refused={"standard": ra, "mizan": rb})
        if sa["llm_cached"] or sb["llm_cached"]:
            notes.append("At least one generator call was served from the answer cache: its token and latency numbers were measured when it was first generated.")
        ia, ib, rta, rtb = sa["llm_input_tokens"], sb["llm_input_tokens"], sa["retrieved_tokens"], sb["retrieved_tokens"]
        ntxt = lambda v: "not measured" if v is None else v  # noqa: E731
        L.add("efficiency", "single_question", f"Retrieved tokens (embedding tokenizer): {labels['standard']} {rta}, {labels['mizan']} {rtb} ({_versus(rta, rtb)}). "
              f"Generator input tokens: {labels['standard']} {ntxt(ia)}, {labels['mizan']} {ntxt(ib)} ({_versus(ia, ib)}). "
              f"Generator output tokens: {labels['standard']} {ntxt(sa['llm_output_tokens'])}, {labels['mizan']} {ntxt(sb['llm_output_tokens'])} ({_versus(sa['llm_output_tokens'], sb['llm_output_tokens'])}).")
        L.add("efficiency", "single_question", f"Latency of this single measurement: retrieval {labels['standard']} {sa['retrieval_latency_s']} s, {labels['mizan']} {sb['retrieval_latency_s']} s "
              f"({_versus(sa['retrieval_latency_s'], sb['retrieval_latency_s'], ' s', 3, 'shorter', 'longer')}); generation {labels['standard']} {sa['llm_latency_s']} s, {labels['mizan']} {sb['llm_latency_s']} s "
              f"({_versus(sa['llm_latency_s'], sb['llm_latency_s'], ' s', 2, 'shorter', 'longer')}). One measurement is noisy, and the second pipeline ran after the first.")
        truth("retrieved_tokens", rta, rtb)
        truth("input_tokens", ia, ib)
        truth("output_tokens", sa["llm_output_tokens"], sb["llm_output_tokens"])
        truth("retrieval_latency", sa["retrieval_latency_s"], sb["retrieval_latency_s"])
        truth("generation_latency", sa["llm_latency_s"], sb["llm_latency_s"])
        by_llm = _rel(ia, ib) is not None              # generator tokens are comparable only if both were measured and the first is positive
        rel = _rel(ia, ib) if by_llm else _rel(rta, rtb)
        dim["efficiency_tokens"] = _dimension(rel is not None, _fav_lower(rel), basis="generator_input_tokens" if by_llm else "retrieved_tokens", relative_change=_r(rel, 4))
        not_measured.append("Run-to-run variation of latency and tokens: this run measured one question once.")

    # ---- aggregate ---------------------------------------------------------------------------------------------
    if agg_stats:
        m, lab, rt = agg_stats["metrics"], labels, agg_stats["retrieved_tokens"]
        iv = m["hit"].get("interval")
        strength_text = {
            "supported": f"At least {MIN_N_INTERVAL} answerable questions, so an interval is computed (questions are treated as independent).",
            "not_distinguishable": "The interval includes zero: no difference is distinguishable from zero (that does not prove the pipelines are equal).",
            "preliminary": f"Fewer than {MIN_N_INTERVAL} answerable questions: any direction is preliminary and no interval is computed.",
            "none": "No answerable question could be compared."}[agg_stats["strength"]]
        L.add("aggregate", "aggregate", f"Retrieval-only evaluation on {agg_stats['n_questions']} questions ('{aggregate_eval['source']}', fingerprint {aggregate_eval['questions_sha256'][:12]}), "
              f"{agg_stats['n_answerable']} answerable, on the current document set; no answers were generated for it. {strength_text}")
        L.add("aggregate", "aggregate", f"hit@{SETTINGS.top_k}: {lab['standard']} {m['hit']['standard']}, {lab['mizan']} {m['hit']['mizan']}, difference ({lab['mizan']} minus {lab['standard']}) "
              f"{m['hit'].get('diff')}" + (f", paired-bootstrap 95% interval [{iv[0]}, {iv[1]}]" if iv else f", no interval (fewer than {MIN_N_INTERVAL} answerable questions)") + ". "
              f"MRR: {m['mrr']['standard']} vs {m['mrr']['mizan']}. Precision@{SETTINGS.top_k}: {m['precision']['standard']} vs {m['precision']['mizan']}. "
              f"Gold in the reranker's candidate pool: {m['candidate_recall']['standard']} vs {m['candidate_recall']['mizan']}.")
        L.add("aggregate", "aggregate", f"Per question: both found the evidence on {agg_stats['both_hit']}, only {lab['standard']} on {agg_stats['only_standard_hit']}, only {lab['mizan']} on "
              f"{agg_stats['only_mizan_hit']}, neither on {agg_stats['neither_hit']}.")
        L.add("aggregate", "aggregate", f"Mean retrieved tokens per question: {lab['standard']} {rt['standard']}, {lab['mizan']} {rt['mizan']} ({_versus(rt['standard'], rt['mizan'])}). "
              f"Median retrieval latency: {lab['standard']} {agg_stats['retrieval_latency_median_s']['standard']} s, {lab['mizan']} {agg_stats['retrieval_latency_median_s']['mizan']} s.")
        truth("retrieved_tokens", rt["standard"], rt["mizan"])
        truth("retrieval_latency", agg_stats["retrieval_latency_median_s"]["standard"], agg_stats["retrieval_latency_median_s"]["mizan"])
        rel = _rel(rt["standard"], rt["mizan"])
        dim["aggregate_efficiency_tokens"] = _dimension(rel is not None, _fav_lower(rel), basis="retrieved_tokens", relative_change=_r(rel, 4))
        dim["aggregate_retrieval_quality"] = _dimension(agg_stats["relation"] is not None, agg_stats["relation"], basis="prepared_question_gold_evidence", strength=agg_stats["strength"])
        not_measured.append("Answer quality in the prepared-question evaluation: it measures retrieval only.")
    else:
        not_measured.append("Aggregate retrieval performance: no prepared-question evaluation was run for this document set, so it has not been established.")
        unsupported.append("Any statement about how the pipelines perform on a set of questions.")

    allowed = compute_allowed(dim, agg_stats, has_single)
    scope = "single_question_and_aggregate" if has_single and agg_stats else "single_question" if has_single else "aggregate"
    meta = {"documents": len(diag), "pages": len(pages), "corpus_fingerprint": fp[:12], "uploaded": uploaded,
            "pipeline_configs": {"standard": names[0], "mizan": names[1]}, "top_k": SETTINGS.top_k,
            "generator": f"{SETTINGS.llm_provider}:{SETTINGS.llm_model}", "notes": notes, "language": lang}
    ev = Evidence(scope=scope, labels=labels, question=q_clean, facts=L.facts, texts=texts, not_measured=not_measured, unsupported_claims=unsupported,
                  allowed=allowed, dimensions=dim, blocking=blocking, meta=meta, checks=checks, lang=lang)
    _fit_budget(ev)
    ev.fingerprint = hashlib.sha256(json.dumps([ev.context(), lang], ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()
    return ev
