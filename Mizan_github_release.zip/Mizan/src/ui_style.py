"""Design tokens, the Gradio theme and the CSS of the interface (src/ui.py), in one place.

Two appearances share one structure: the `.dark` class on <body> (Gradio's own switch) selects the dark token set, so Gradio's
components and Mizan's HTML change together, instantly, in the browser. Light is a warm paper theme of its own, not an inversion.
Standard is slate with a square marker, Mizan-lite is teal with a diamond marker: a shape and a label, never colour alone.
"""

LIGHT = {
    "bg": "#f4f2ed", "surface": "#ffffff", "surface-2": "#f8f6f1", "sunken": "#efece5", "line": "#e1ddd3", "line-strong": "#c9c3b6",
    "text": "#1d1c1a", "text-2": "#4d4a43", "text-3": "#6a655c", "accent": "#0d6a63", "accent-hover": "#0a5852", "on-accent": "#ffffff",
    "accent-soft": "#e2f0ee", "std": "#4a5870", "std-soft": "#edf0f5", "mz": "#0d6a63", "mz-soft": "#e2f0ee", "warn": "#7a5b0b",
    "warn-soft": "#fbf3dc", "warn-line": "#e3cf8f", "bad": "#a3402b", "bad-soft": "#fbebe6", "good": "#1f6b3c", "good-soft": "#e6f3ea",
    "focus": "#0d6a63", "shadow": "0 1px 2px rgba(29,28,26,.06), 0 1px 1px rgba(29,28,26,.04)",
}
DARK = {
    "bg": "#131514", "surface": "#1b1e1d", "surface-2": "#212524", "sunken": "#171a19", "line": "#2f3432", "line-strong": "#454b48",
    "text": "#ecebe6", "text-2": "#c2beb5", "text-3": "#9a968d", "accent": "#6cc4bd", "accent-hover": "#82d2cb", "on-accent": "#0c2321",
    "accent-soft": "#1c3532", "std": "#a3b0c4", "std-soft": "#232a34", "mz": "#6cc4bd", "mz-soft": "#1c3532", "warn": "#ebd08a",
    "warn-soft": "#2e2611", "warn-line": "#6b5a24", "bad": "#ee9b86", "bad-soft": "#341f1a", "good": "#8fd3a6", "good-soft": "#1b3024",
    "focus": "#8fd6cf", "shadow": "none",
}


def _vars(d: dict) -> str:
    return ";".join(f"--mz-{k}:{v}" for k, v in d.items())


def gradio_theme():
    """Gradio's own components (inputs, buttons, radios, accordions) in the same palette, light and dark."""
    import gradio as gr

    L, D = LIGHT, DARK
    return gr.themes.Base(
        primary_hue=gr.themes.colors.teal, neutral_hue=gr.themes.colors.stone, radius_size=gr.themes.sizes.radius_md,
        font=["Segoe UI", "Noto Sans", "Noto Sans Arabic", "Tahoma", "system-ui", "sans-serif"],
        font_mono=["Cascadia Mono", "Consolas", "ui-monospace", "monospace"],
    ).set(
        body_background_fill=L["bg"], body_background_fill_dark=D["bg"],
        body_text_color=L["text"], body_text_color_dark=D["text"],
        body_text_color_subdued=L["text-3"], body_text_color_subdued_dark=D["text-3"],
        background_fill_primary=L["surface"], background_fill_primary_dark=D["surface"],
        background_fill_secondary=L["surface-2"], background_fill_secondary_dark=D["surface-2"],
        block_background_fill=L["surface"], block_background_fill_dark=D["surface"],
        block_border_color=L["line"], block_border_color_dark=D["line"],
        block_label_text_color=L["text-2"], block_label_text_color_dark=D["text-2"],
        block_title_text_color=L["text"], block_title_text_color_dark=D["text"],
        border_color_primary=L["line"], border_color_primary_dark=D["line"],
        input_background_fill=L["surface"], input_background_fill_dark=D["sunken"],
        input_border_color=L["line-strong"], input_border_color_dark=D["line-strong"],
        input_border_color_focus=L["focus"], input_border_color_focus_dark=D["focus"],
        input_placeholder_color=L["text-3"], input_placeholder_color_dark=D["text-3"],
        button_primary_background_fill=L["accent"], button_primary_background_fill_dark=D["accent"],
        button_primary_background_fill_hover=L["accent-hover"], button_primary_background_fill_hover_dark=D["accent-hover"],
        button_primary_text_color=L["on-accent"], button_primary_text_color_dark=D["on-accent"],
        button_primary_border_color=L["accent"], button_primary_border_color_dark=D["accent"],
        button_secondary_background_fill=L["surface"], button_secondary_background_fill_dark=D["surface-2"],
        button_secondary_background_fill_hover=L["surface-2"], button_secondary_background_fill_hover_dark=D["line"],
        button_secondary_text_color=L["text"], button_secondary_text_color_dark=D["text"],
        button_secondary_border_color=L["line-strong"], button_secondary_border_color_dark=D["line-strong"],
        checkbox_background_color=L["surface"], checkbox_background_color_dark=D["sunken"],
        checkbox_background_color_selected=L["accent"], checkbox_background_color_selected_dark=D["accent"],
        checkbox_border_color=L["line-strong"], checkbox_border_color_dark=D["line-strong"],
        checkbox_label_background_fill=L["surface"], checkbox_label_background_fill_dark=D["surface"],
        checkbox_label_background_fill_selected=L["accent-soft"], checkbox_label_background_fill_selected_dark=D["accent-soft"],
        checkbox_label_text_color=L["text-2"], checkbox_label_text_color_dark=D["text-2"],
        checkbox_label_text_color_selected=L["text"], checkbox_label_text_color_selected_dark=D["text"],
        color_accent=L["accent"], color_accent_soft=L["accent-soft"], color_accent_soft_dark=D["accent-soft"],
        button_border_width="1px", input_border_width="1px",
        block_label_background_fill="transparent", block_label_background_fill_dark="transparent",
        block_label_border_width="0px", block_title_background_fill="transparent", block_title_background_fill_dark="transparent",
        shadow_drop="none", shadow_drop_lg="none", block_shadow="none", block_shadow_dark="none",
        link_text_color=L["accent"], link_text_color_dark=D["accent"],
    )


CSS = """
:root { __LIGHT__; color-scheme: light;
  --mz-font: "Segoe UI", "Noto Sans", "Noto Sans Arabic", Tahoma, system-ui, sans-serif;
  --mz-font-ar: "Dubai", "Segoe UI", "Noto Sans Arabic", "Noto Naskh Arabic", Tahoma, sans-serif;
  --mz-font-text: "Segoe UI", "Noto Naskh Arabic", "Noto Sans Arabic", Tahoma, sans-serif;  /* source text: keeps kashida visible */
  --mz-mono: "Cascadia Mono", Consolas, ui-monospace, monospace;
  --mz-r: 10px; --mz-r-sm: 7px; }
.dark { __DARK__; color-scheme: dark; }
html[data-theme="dark"] { __DARK__; color-scheme: dark; }   /* the page behind a short screen follows the choice too */
:root[lang="ar"] { --mz-font: var(--mz-font-ar); }

/* ---- page frame ---------------------------------------------------------------------------------------------- */
html, body, gradio-app { background: var(--mz-bg) !important; }
#mz-measured:not(:has(.mz)) { display: none !important; }   /* step 3 takes no room until something was measured */
#mz-exhead:not(:has(.mz)) { display: none !important; }     /* no prepared questions (public checkout): no empty gap */
.gradio-container { max-width: 1200px !important; margin: 0 auto !important; padding: 18px 24px 40px !important; font-family: var(--mz-font) !important; }
.gradio-container .main, .gradio-container .wrap { gap: 14px; }
footer { display: none !important; }                        /* Gradio's "Use via API" footer: not part of this product */
/* Gradio writes dir="ltr" on every component block; in Arabic the blocks follow the page instead. Content keeps its own dir. */
html[dir="rtl"] .gradio-container .block[dir="ltr"] { direction: rtl; }
.mz, .mz * { box-sizing: border-box; }
.mz { color: var(--mz-text); font-family: var(--mz-font); font-size: 15px; line-height: 1.55; }
.mz p { margin: 0; }
.mz bdi, .mz .num { unicode-bidi: isolate; font-variant-numeric: tabular-nums; }
.mz .ltr { direction: ltr; unicode-bidi: isolate; }
.mz-muted { color: var(--mz-text-2); }
.mz-small { font-size: 13px; color: var(--mz-text-2); }

/* ---- top bar ----------------------------------------------------------------------------------------------------- */
#mz-top { align-items: center !important; gap: 12px !important; padding: 2px 0 12px; border-bottom: 1px solid var(--mz-line); margin-bottom: 4px; }
#mz-top { flex-wrap: nowrap !important; }
#mz-top > .mz-seg, #mz-top > #mz-corpuscol { flex: 0 0 auto !important; width: auto !important; min-width: 0 !important; }
#mz-top > #mz-brandcol { flex: 1 1 auto !important; min-width: 0 !important; }
#mz-asknote { min-height: 0 !important; }
.mz-brand { display: flex; align-items: center; gap: 12px; }
.mz-brand .mark { display: grid; place-items: center; width: 44px; height: 44px; flex: none; border-radius: 13px;
  background: #0e5a4f; color: #fff; box-shadow: inset 0 -3px 0 #00000022; }
.mz-brand .mark svg { width: 24px; height: 24px; stroke: #fff; }
.mz-brand .name { font-size: 21px; font-weight: 700; letter-spacing: -.01em; line-height: 1.1; }
.mz-brand .tag { font-size: 13px; color: var(--mz-text-2); }
.mz-corpus { display: inline-flex; gap: 6px; align-items: center; font-size: 13px; color: var(--mz-text-2); white-space: nowrap; }
.mz-corpus b { color: var(--mz-text); font-weight: 600; }
.mz-seg { flex: 0 0 auto !important; }
.mz-seg .wrap { flex-wrap: nowrap !important; gap: 0 !important; border: 1px solid var(--mz-line-strong); border-radius: 999px; padding: 2px; background: var(--mz-surface); }
.mz-seg label { margin: 0 !important; border: 0 !important; border-radius: 999px !important; padding: 4px 12px !important; min-height: 30px;
  background: transparent !important; box-shadow: none !important; font-size: 13px !important; color: var(--mz-text-2) !important; cursor: pointer; }
.mz-seg label.selected, .mz-seg label:has(input:checked) { background: var(--mz-accent-soft) !important; color: var(--mz-text) !important; font-weight: 600; }
.mz-seg input[type=radio] { position: absolute !important; opacity: 0 !important; width: 1px !important; height: 1px !important; }
.mz-seg label:has(input:focus-visible) { outline: 2px solid var(--mz-focus); outline-offset: 1px; }

/* ---- notices ----------------------------------------------------------------------------------------------------- */
.mz-notices { display: grid; gap: 6px; }
.mz-notice { display: flex; gap: 10px; align-items: flex-start; padding: 9px 12px; border-radius: var(--mz-r-sm); font-size: 13.5px;
  color: var(--mz-text-2); background: var(--mz-surface-2); border: 1px solid var(--mz-line); }
.mz-notice.warn { color: var(--mz-warn); background: var(--mz-warn-soft); border-color: var(--mz-warn-line); }
.mz-notice svg { flex: none; width: 16px; height: 16px; margin-top: 2px; }

/* ---- cards ------------------------------------------------------------------------------------------------------- */
.mz-card { background: var(--mz-surface) !important; border: 1px solid var(--mz-line) !important; border-radius: var(--mz-r) !important;
  box-shadow: var(--mz-shadow); padding: 16px 18px !important; }
.mz-step { display: flex; align-items: baseline; gap: 10px; margin: 0 0 8px; }
.mz-step .n { display: inline-grid; place-items: center; width: 22px; height: 22px; border-radius: 50%; font-size: 12px; font-weight: 700;
  color: var(--mz-on-accent); background: var(--mz-accent); flex: none; transform: translateY(-1px); }
.mz-step h2 { font-size: 16px; font-weight: 650; margin: 0; }
.mz-step .sub { font-size: 13px; color: var(--mz-text-2); }
#mz-question { padding: 0 !important; border: 0 !important; background: transparent !important; box-shadow: none !important; }
#mz-question textarea { font-size: 16px !important; line-height: 1.6 !important; unicode-bidi: plaintext; text-align: start; font-family: var(--mz-font-ar) !important; }
#mz-examples { gap: 6px !important; flex-wrap: wrap !important; }
#mz-examples button { flex: 0 0 auto !important; min-width: 0 !important; font-weight: 500 !important; font-size: 13.5px !important; border-radius: 999px !important; padding: 5px 12px !important; }
#mz-run { font-size: 15.5px !important; font-weight: 650 !important; min-height: 44px; }
#mz-clear { min-height: 44px; }
.mz-label { font-size: 13px; color: var(--mz-text-2); margin: 6px 0 4px; }
.mz-hint { font-size: 13px; color: var(--mz-text-2); margin-top: 4px; }
.mz-msg.warn { color: var(--mz-warn); font-size: 13.5px; margin-top: 2px; }
.mz-docs { display: flex; flex-wrap: wrap; gap: 4px 12px; align-items: baseline; }
.mz-docs .k { font-weight: 650; font-size: 14px; }
.mz-up { margin-top: 6px; display: grid; gap: 3px; font-size: 13.5px; }
.mz-up .ok { color: var(--mz-good); } .mz-up .warn { color: var(--mz-warn); } .mz-up .bad { color: var(--mz-bad); }
#mz-upload button { min-height: 34px; }

/* ---- what differs -------------------------------------------------------------------------------------------------- */
.mz-diff h3 { font-size: 15px; font-weight: 650; margin: 0 0 10px; }
.mz-pipes { display: grid; gap: 8px; margin-bottom: 14px; }
.mz-pipe { display: flex; gap: 10px; align-items: baseline; }
.mz-pipe .nm { font-weight: 650; white-space: nowrap; }
.mz-pipe .ds { color: var(--mz-text-2); font-size: 14px; }
.mz-mk { display: inline-block; width: 10px; height: 10px; flex: none; transform: translateY(-1px); }
.mz-mk.standard { border: 2px solid var(--mz-std); border-radius: 2px; }
.mz-mk.mizan { background: var(--mz-mz); transform: translateY(-1px) rotate(45deg); width: 9px; height: 9px; }
.mz-example-line { border: 1px solid var(--mz-line); border-radius: var(--mz-r-sm); overflow: hidden; }
.mz-example-line .cap { font-size: 12.5px; color: var(--mz-text-2); padding: 7px 12px; background: var(--mz-surface-2); border-bottom: 1px solid var(--mz-line); }
.mz-example-line .row { display: grid; grid-template-columns: 112px 1fr; gap: 10px; padding: 9px 12px; align-items: baseline; }
.mz-example-line .row + .row { border-top: 1px dashed var(--mz-line); }
.mz-example-line .lbl { font-size: 12.5px; color: var(--mz-text-2); }
.mz-example-line .txt { font-family: var(--mz-font-text); font-size: 17px; direction: rtl; text-align: right; }
.mz-example-line .bad-txt b { color: var(--mz-bad); font-weight: 700; }
.mz-example-line .good-txt b { color: var(--mz-mz); font-weight: 700; }
.mz-gloss { font-size: 13px; color: var(--mz-text-2); margin-top: 8px; }

/* ---- empty state ----------------------------------------------------------------------------------------------------- */
.mz-flow { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 0; counter-reset: s; border: 1px solid var(--mz-line);
  border-radius: var(--mz-r); background: var(--mz-surface); }
.mz-flow li { list-style: none; padding: 14px 16px; font-size: 14px; color: var(--mz-text-2); position: relative; }
.mz-flow li + li { border-inline-start: 1px solid var(--mz-line); }
.mz-flow li b { display: block; color: var(--mz-text); font-size: 13px; margin-bottom: 2px; }
.mz-flow { margin: 0; padding: 0; }

/* ---- results ------------------------------------------------------------------------------------------------------- */
.mz-results { display: grid; gap: 14px; }
.mz-qstrip { display: grid; gap: 4px; padding: 12px 16px; border: 1px solid var(--mz-line); border-radius: var(--mz-r); background: var(--mz-surface); }
.mz-qstrip .q { font-size: 17px; font-weight: 600; font-family: var(--mz-font-ar); }
.mz-qstrip .ref { font-size: 14px; color: var(--mz-text-2); }
.mz-qstrip .ref span { font-family: var(--mz-font-ar); color: var(--mz-text); }
.mz-summary { padding: 12px 16px; border-radius: var(--mz-r); background: var(--mz-surface-2); border: 1px solid var(--mz-line); }
.mz-summary h3 { font-size: 13px; font-weight: 650; text-transform: none; color: var(--mz-text-2); margin: 0 0 6px; }
.mz-summary ul { margin: 0; padding: 0; list-style: none; display: grid; gap: 4px; }
.mz-summary li { display: flex; gap: 8px; align-items: baseline; font-size: 14.5px; }
.mz-summary li::before { content: ""; width: 6px; height: 6px; border-radius: 50%; background: var(--mz-line-strong); flex: none; transform: translateY(-2px); }
.mz-summary .note { font-size: 12.5px; color: var(--mz-text-3); margin-top: 6px; }
.mz-cols { display: grid; grid-template-columns: repeat(var(--n, 2), minmax(0, 1fr)); gap: 14px; align-items: start; }
.mz-col { display: grid; gap: 10px; min-width: 0; }
.mz-ans { border: 1px solid var(--mz-line); border-radius: var(--mz-r); background: var(--mz-surface); overflow: hidden; }
.mz-ans header { display: flex; gap: 10px; align-items: baseline; padding: 10px 14px; border-bottom: 1px solid var(--mz-line); }
.mz-ans.standard header { background: var(--mz-std-soft); }
.mz-ans.mizan header { background: var(--mz-mz-soft); }
.mz-ans header .nm { font-weight: 700; font-size: 15.5px; }
.mz-ans header .ds { font-size: 13px; color: var(--mz-text-2); }
.mz-ans .body { padding: 12px 14px 14px; display: grid; gap: 10px; }
.mz-ans .lbl { font-size: 12.5px; color: var(--mz-text-2); }
.mz-answer { font-family: var(--mz-font-ar); font-size: 16.5px; line-height: 1.85; }
.mz-answer p + p { margin-top: 8px; }
.mz-answer.refused { color: var(--mz-text-2); }
.mz-tr { border-top: 1px dashed var(--mz-line-strong); padding-top: 8px; display: grid; gap: 4px; }
.mz-tr .lbl { font-size: 12px; color: var(--mz-text-3); }
.mz-tr p { font-size: 14.5px; line-height: 1.6; }
#mz-translate { flex: 0 0 auto !important; align-self: flex-start !important; width: auto !important; min-width: 0 !important;
  margin-top: -4px; padding-inline: 14px; }
.mz-cite { display: inline-block; max-width: 100%; padding: 0 6px; border-radius: 5px; font-size: 13px; line-height: 1.7;
  font-family: var(--mz-font); background: var(--mz-sunken); border: 1px solid var(--mz-line); unicode-bidi: isolate;
  overflow-wrap: anywhere; vertical-align: baseline; }
.mz-cite.ok { border-color: var(--mz-line-strong); }
.mz-cite.gold { border-color: var(--mz-good); background: var(--mz-good-soft); }
.mz-cite.bad { border-color: var(--mz-bad); background: var(--mz-bad-soft); }
.mz-facts-row { display: grid; gap: 5px; }
.mz-fact { display: flex; gap: 8px; align-items: baseline; font-size: 13.5px; }
.mz-fact .ic { flex: none; width: 15px; text-align: center; font-weight: 700; }
.mz-fact.good .ic { color: var(--mz-good); } .mz-fact.bad .ic { color: var(--mz-bad); } .mz-fact.neutral .ic { color: var(--mz-text-3); }
.mz-fact.warn { color: var(--mz-warn); } .mz-fact.warn .ic { color: var(--mz-warn); }
.mz-srcs { border: 1px solid var(--mz-line); border-radius: var(--mz-r); background: var(--mz-surface); overflow: hidden; }
.mz-srcs > .hd { font-size: 12.5px; color: var(--mz-text-2); padding: 8px 12px; border-bottom: 1px solid var(--mz-line); background: var(--mz-surface-2); }
.mz-src + .mz-src { border-top: 1px solid var(--mz-line); }
.mz-src summary { list-style: none; cursor: pointer; display: grid; grid-template-columns: 22px minmax(0, 1fr) auto; gap: 4px 10px; padding: 9px 12px; align-items: center; }
.mz-src summary::-webkit-details-marker { display: none; }
.mz-src summary:hover { background: var(--mz-surface-2); }
.mz-src summary:focus-visible { outline: 2px solid var(--mz-focus); outline-offset: -2px; }
.mz-src .rk { display: inline-grid; place-items: center; width: 22px; height: 22px; border-radius: 6px; background: var(--mz-sunken); font-size: 12px; font-weight: 700; }
.mz-src .tt { min-width: 0; display: grid; gap: 2px; }
.mz-src .tt .t1 { font-size: 14px; font-weight: 600; overflow-wrap: anywhere; }
.mz-src .tt .t2 { font-size: 12.5px; color: var(--mz-text-2); }
.mz-src .sc { display: grid; justify-items: end; gap: 3px; font-size: 12px; color: var(--mz-text-2); }
.mz-bar { width: 64px; height: 5px; border-radius: 3px; background: var(--mz-sunken); overflow: hidden; }
.mz-bar i { display: block; height: 100%; background: var(--mz-line-strong); }
.mz-col.standard .mz-bar i { background: var(--mz-std); } .mz-col.mizan .mz-bar i { background: var(--mz-mz); }
.mz-tags { grid-column: 2 / 4; display: flex; flex-wrap: wrap; gap: 5px; }
.mz-tag { font-size: 11.5px; padding: 1px 7px; border-radius: 999px; border: 1px solid var(--mz-line-strong); color: var(--mz-text-2); }
.mz-tag.gold { border-color: var(--mz-good); color: var(--mz-good); background: var(--mz-good-soft); }
.mz-tag.only { border-style: dashed; }
.mz-tag.held { border-color: var(--mz-warn-line); color: var(--mz-warn); background: var(--mz-warn-soft); }
.mz-src .chev { width: 10px; height: 10px; border-inline-end: 2px solid var(--mz-text-3); border-bottom: 2px solid var(--mz-text-3); transform: rotate(45deg);
  transition: transform .15s ease; margin-top: -4px; justify-self: end; }
.mz-src[open] .chev { transform: rotate(225deg); margin-top: 4px; }
.mz-passage { padding: 4px 14px 12px 14px; }
.mz-passage .cap { font-size: 12px; color: var(--mz-text-3); margin-bottom: 4px; }
.mz-passage .txt { font-family: var(--mz-font-text); font-size: 14.5px; line-height: 1.8; white-space: pre-wrap; padding: 10px 12px; border-radius: var(--mz-r-sm);
  background: var(--mz-sunken); max-height: 260px; overflow: auto; }
.mz-table { width: 100%; border-collapse: collapse; font-size: 14px; border: 0 !important; margin: 0 !important; }
.mz .mz-table th, .mz .mz-table td { border-left: 0 !important; border-right: 0 !important; border-top: 0 !important; }
.mz-table caption { text-align: start; font-size: 13px; font-weight: 650; color: var(--mz-text-2); padding: 0 0 8px; }
.mz-table th, .mz-table td { padding: 8px 10px; border-bottom: 1px solid var(--mz-line); text-align: start; }
.mz-table thead th { font-size: 12.5px; color: var(--mz-text-2); font-weight: 600; background: var(--mz-surface-2); }
.mz-table td.num, .mz-table th.num { text-align: end; font-variant-numeric: tabular-nums; white-space: nowrap; }
.mz-table tbody th { font-weight: 500; }
.mz-table .hint { display: block; font-weight: 400; font-size: 11.5px; color: var(--mz-text-3); }
.mz-tablewrap { border: 1px solid var(--mz-line); border-radius: var(--mz-r); padding: 12px 14px 4px; background: var(--mz-surface); overflow-x: auto; }
.mz-tablewrap .elapsed { font-size: 12.5px; color: var(--mz-text-3); padding: 8px 0; }
.mz-alert { padding: 10px 14px; border-radius: var(--mz-r-sm); border: 1px solid var(--mz-warn-line); background: var(--mz-warn-soft); color: var(--mz-warn); font-size: 14px; }
.mz-alert.bad { border-color: var(--mz-bad); background: var(--mz-bad-soft); color: var(--mz-bad); }
.mz-alert .detail { margin-top: 4px; font-size: 12.5px; opacity: .9; overflow-wrap: anywhere; text-align: start; }

/* ---- Mizan Insights ------------------------------------------------------------------------------------------------- */
.mz-ins { display: grid; gap: 12px; }
.mz-ins .hd { display: flex; flex-wrap: wrap; justify-content: space-between; gap: 6px 14px; align-items: baseline; }
.mz-ins .hd h2 { font-size: 18px; font-weight: 700; margin: 0; display: flex; gap: 10px; align-items: baseline; }
.mz-ins .hd h2 .n { display: inline-grid; place-items: center; width: 22px; height: 22px; border-radius: 50%; font-size: 12px; color: var(--mz-on-accent); background: var(--mz-accent); }
.mz-ins .how { font-size: 13.5px; color: var(--mz-text-2); max-width: 96ch; }
.mz-scope { display: inline-flex; gap: 6px; align-items: center; font-size: 12.5px; padding: 3px 10px; border-radius: 999px; border: 1px solid var(--mz-line-strong); color: var(--mz-text-2); }
.mz-finding { border: 1px solid var(--mz-line-strong); border-radius: var(--mz-r); padding: 14px 16px; background: var(--mz-surface-2); display: grid; gap: 6px; }
.mz-stance { display: flex; gap: 10px; align-items: center; font-size: 19px; font-weight: 700; }
.mz-stance .mz-mk { width: 12px; height: 12px; }
.mz-stance .eq { width: 14px; height: 2px; background: var(--mz-text-3); box-shadow: 0 5px 0 var(--mz-text-3); transform: translateY(-3px); }
.mz-gen { font-size: 15px; line-height: 1.65; }
.mz-fids { display: inline-flex; flex-wrap: wrap; gap: 4px; margin-inline-start: 6px; vertical-align: 1px; }
.mz-fid { font-family: var(--mz-mono); font-size: 11.5px; padding: 0 5px; border-radius: 4px; background: var(--mz-sunken); border: 1px solid var(--mz-line);
  color: var(--mz-text-2); cursor: help; }
.mz-fid:focus-visible { outline: 2px solid var(--mz-focus); }
.mz-isec h3 { font-size: 13px; font-weight: 650; color: var(--mz-text-2); margin: 0 0 6px; }
.mz-isec ul { margin: 0; padding: 0; list-style: none; display: grid; gap: 6px; }
.mz-isec li { padding-inline-start: 14px; position: relative; }
.mz-isec li::before { content: ""; position: absolute; inset-inline-start: 0; top: .7em; width: 5px; height: 5px; border-radius: 50%; background: var(--mz-line-strong); }
.mz-kind { font-size: 11.5px; padding: 0 6px; border-radius: 4px; border: 1px solid var(--mz-line-strong); color: var(--mz-text-2); margin-inline-end: 6px; }
.mz-igrid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 14px 22px; }
.mz-rec { display: grid; gap: 6px; align-content: start; } .mz-rec h3 { margin: 0 !important; }
.mz-rec .pill { justify-self: start; font-weight: 650; font-size: 14px; display: inline-flex; gap: 8px; align-items: center; }
.mz-prov { font-size: 12.5px; color: var(--mz-text-3); display: grid; gap: 2px; }
.mz-loading { display: grid; gap: 8px; padding: 14px 16px; border: 1px dashed var(--mz-line-strong); border-radius: var(--mz-r); }
.mz-loading p { font-size: 14px; color: var(--mz-text-2); }
.mz-skel { height: 10px; border-radius: 5px; background: var(--mz-sunken); position: relative; overflow: hidden; }
.mz-skel:nth-child(2) { width: 82%; } .mz-skel:nth-child(3) { width: 64%; }
.mz-skel::after { content: ""; position: absolute; inset: 0; transform: translateX(-100%); background: linear-gradient(90deg, transparent, var(--mz-line), transparent);
  animation: mzsh 1.4s ease-in-out infinite; }
@keyframes mzsh { to { transform: translateX(100%); } }
.mz-ledger { border: 1px solid var(--mz-line); border-radius: var(--mz-r); }
.mz-ledger > summary { cursor: pointer; padding: 9px 12px; font-size: 13.5px; color: var(--mz-text-2); }
.mz-ledger > summary:focus-visible { outline: 2px solid var(--mz-focus); }
.mz-ledger .in { padding: 0 14px 12px; display: grid; gap: 10px; }
.mz-ledger ol { margin: 0; padding: 0; list-style: none; display: grid; gap: 6px; }
.mz-ledger li { font-size: 13px; line-height: 1.5; }
.mz-ledger h4 { font-size: 12.5px; color: var(--mz-text-2); margin: 4px 0 0; font-weight: 650; }
.mz-ledger ul { margin: 0; padding-inline-start: 18px; font-size: 13px; color: var(--mz-text-2); }
#mz-ins-controls { gap: 10px !important; align-items: center !important; flex-wrap: wrap !important; }
#mz-ins-controls button { flex: 0 0 auto !important; min-width: 0 !important; }
#mz-auto { flex: 0 1 auto !important; width: auto !important; min-width: 0 !important; border: 0 !important; background: transparent !important; padding: 0 !important; }
#mz-auto label { border: 0 !important; background: transparent !important; padding: 4px 0 !important; }
#mz-question span[data-testid=block-info], #mz-phrase span[data-testid=block-info] { font-size: 13px; color: var(--mz-text-2); }

/* ---- details ----------------------------------------------------------------------------------------------------- */
.mz-more { display: grid; gap: 8px; }
.mz-more > details { border: 1px solid var(--mz-line); border-radius: var(--mz-r); background: var(--mz-surface); }
.mz-more > details > summary { cursor: pointer; padding: 11px 14px; font-weight: 600; font-size: 14px; }
.mz-more > details > summary:focus-visible { outline: 2px solid var(--mz-focus); }
.mz-more .in { padding: 0 14px 14px; display: grid; gap: 10px; }
.mz-kv { display: grid; grid-template-columns: max-content 1fr; gap: 6px 16px; font-size: 14px; margin: 0; }
.mz-kv dt { color: var(--mz-text-2); } .mz-kv dd { margin: 0; }
.mz-steps { display: grid; grid-template-columns: repeat(var(--n, 2), minmax(0, 1fr)); gap: 12px; }
.mz-steps ul { margin: 4px 0 0; padding-inline-start: 18px; font-size: 13.5px; }
.mz-foot { font-size: 12.5px; color: var(--mz-text-3); text-align: center; padding-top: 6px; }

/* ---- focus, motion, small screens ------------------------------------------------------------------------------------ */
.gradio-container button:focus-visible, .gradio-container textarea:focus-visible, .gradio-container input:focus-visible { outline: 2px solid var(--mz-focus) !important; outline-offset: 2px; }
@media (prefers-reduced-motion: reduce) { .mz *, .mz *::after { animation: none !important; transition: none !important; } }
@media (max-width: 900px) {
  .mz-cols, .mz-igrid, .mz-steps { grid-template-columns: minmax(0, 1fr); }
  .mz-flow { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .mz-flow li:nth-child(3) { border-inline-start: 0; }
  .mz-flow li:nth-child(n+3) { border-top: 1px solid var(--mz-line); }
}
@media (max-width: 560px) {
  .gradio-container { padding: 10px 12px 28px !important; }
  .mz-flow { grid-template-columns: minmax(0, 1fr); }
  .mz-flow li { border-inline-start: 0 !important; } .mz-flow li + li { border-top: 1px solid var(--mz-line); }
  .mz-brand .tag { display: none; }
  #mz-top { flex-wrap: wrap !important; } #mz-top > #mz-corpuscol { display: none !important; }
  .mz-example-line .row { grid-template-columns: minmax(0, 1fr); gap: 2px; }
  .mz-card { padding: 12px 12px !important; }
  /* a passage: rank and title on one line, its similarity underneath, so the title keeps the width */
  .mz-src summary { grid-template-columns: 22px minmax(0, 1fr); }
  .mz-src .sc { grid-column: 2; justify-items: start; grid-template-columns: auto 64px; align-items: center; gap: 8px; }
  .mz-src .mz-tags { grid-column: 2; }
}
""".replace("__LIGHT__", _vars(LIGHT)).replace("__DARK__", _vars(DARK))
