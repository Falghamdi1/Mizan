# P3 adjudication: instructions for the third grader

You decide the cells where the two graders disagreed or where one of them left a cell empty. You see the same kind of sheet they saw: a question, a reference answer and two answers, A and B. Nothing tells you which system wrote which answer, and the A/B order has been shuffled again for you. Do not try to find out.

**Your file:** `adjudication/p3_adjudication_input.csv` (65 rows). **Do not open** `adjudication/p3_adjudication_key.csv`, `KEY.json` or the graders' sheets.

## Grade every cell of every row

Mark both answers in each row, and the pick, even where you think the graders probably agreed. Only the disputed cells are used, but you are not told which ones they are, so your judgement is not anchored on theirs.

## Rubric (the same written rule the graders had: `eval/human_grading/RUBRIC.md`)

| field | 1 | 0 |
|---|---|---|
| **correct**, answerable question | the answer gives the key fact of the reference answer: the right number, duration, amount, condition or list item | vague, partial, wrong regulation, a different fact, or a refusal ("the documents do not contain it") when the reference has an answer |
| **correct**, unanswerable question (reference says it is not in the documents) — this is the **correct_refusal** endpoint | the answer says the documents do not contain it and invents nothing | any confident answer, even a plausible one |
| **supported** (not for refusals: leave empty) | the cited page really says what the answer claims; check the sources line | wrong page, wrong file, no usable citation, or the page does not say it |
| **better (A, B or tie)** — the **pairwise** pick | the answer a user would prefer: more correct first, then better supported | **tie** when both are equally good or equally bad (both right, or both wrong) |

Partial answers are graded **0**. Style, spelling and length do not count. Do not overrule the reference answer with your own knowledge: grade by the reference and write your doubt in `comment`.

## Follow the written rule strictly

- **Be strict, not kind.** When an answer is close but misses the key fact, it is 0. When you hesitate between 1 and 0, read the rule again and apply it literally.
- **Known problem 1:** on the web questions one grader was systematically more lenient: in 19 of 20 web `correct` disagreements, one grader gave 1 and the other 0, always in the same direction. Your decision should not split the difference; apply the rule.
- **Known problem 2:** agreement on web `supported` was low (kappa 0.507, below the 0.6 bar). Open the cited page in the sources line before you mark `supported` = 1. If the sources line does not let you check it, mark 0 and say so in `comment`.
- The claim this grading tests is "no loss of answer quality", not "better answers". You are not asked to find a winner.

## How to do it with the existing form

1. Open `tools/grading_form.html` in a browser (double-click). It runs offline and uploads nothing. Ignore its line about `grader_N.csv`: your file is the adjudication file.
2. Choose `adjudication/p3_adjudication_input.csv`.
3. For each row press **1 yes** / **0 no** under "Correct?" for answer A and answer B, the same under "Cited page supports it?" (skip refusals), and pick **Answer A**, **Answer B** or **tie**. Use ← → to move; **Jump to first incomplete** finds gaps. Your work is saved in the browser as you go.
4. Click **Download my graded CSV**. The browser saves `graded.csv`. Rename it to **`p3_adjudication_output.csv`** and put it in `adjudication/` (or send it to the team).

Do not edit the CSV by hand, reorder rows or change the header. The form keeps the header exactly as it was; that is the format the merge reads.

## Declaration

"I adjudicated without knowing which system produced which answer, alone, following the written rubric."

## For the team (after the grader is done)

```bash
python scripts/human_grading.py merge results/final_blind/grading_pdf --grader1 results/final_blind/graded/g1_pdf.csv --grader2 results/final_blind/graded/g2_pdf.csv --adjudicated adjudication/p3_adjudication_output.csv --adjudication-key adjudication/p3_adjudication_key.csv
python scripts/human_grading.py merge results/final_blind/grading_web --grader1 results/final_blind/graded/g1_web.csv --grader2 results/final_blind/graded/g2_web.csv --adjudicated adjudication/p3_adjudication_output.csv --adjudication-key adjudication/p3_adjudication_key.csv
```

Each report should say `Unresolved disagreements (left out): 0` and `Incomplete cells: 0`, and give the number of cells decided by the adjudicator.
