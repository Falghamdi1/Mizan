"""Predetermined demo: runs a few fixed questions through baseline and Mizan, prints a compact
terminal summary, and writes results/demo.html (proper Arabic RTL rendering, good for screen recording).

    python demo.py                 # default question set, opens the HTML report
    python demo.py --ids q2,q4,q5  # choose questions from the eval file
    python demo.py --no-open       # do not open the browser
    python demo.py --pipelines baseline,mizan-lite+repair_lam_alef,mizan+repair_lam_alef   # add the full preset as a third column

Deterministic: temperature 0, fixed questions, LLM answers cached on disk. Latency numbers are
wall-clock and vary slightly between runs.
"""
import argparse
import webbrowser

from src.comparison import compare, load_pipelines, metric_rows, render_html
from src.config import DEMO_PIPELINES, RESULTS_DIR, SETTINGS, resolve_questions_path
from src.evaluation import load_questions
from src.rag import LLMError

DEFAULT_IDS = {"sample": "q2,q4,q5,q8", "real": "r3,r4,r5,r10"}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ids", default=None, help="question ids from the active eval file")
    ap.add_argument("--pipelines", default=",".join(DEMO_PIPELINES))
    ap.add_argument("--no-open", action="store_true")
    args = ap.parse_args()

    print("=" * 72)
    print("MIZAN PROTOTYPE DEMO  -  testing whether Arabic-aware preprocessing changes retrieval")
    print(f"LLM: {SETTINGS.llm_provider}:{SETTINGS.llm_model}   top-k: {SETTINGS.top_k}   "
          f"chunk: {SETTINGS.chunk_size}/{SETTINGS.chunk_overlap} chars")
    print("=" * 72)
    names = [n.strip() for n in args.pipelines.split(",")]
    pages, pipelines, synthetic = load_pipelines(names)
    if synthetic:
        print("!! SYNTHETIC SAMPLE DATA: machinery check only, not a finding about real documents.")
    if SETTINGS.llm_provider == "mock":
        print("!! MOCK LLM: no generated answers. Set MIZAN_LLM_PROVIDER in .env for real answers.")

    wanted = [x.strip() for x in (args.ids or DEFAULT_IDS["sample" if synthetic else "real"]).split(",")]
    by_id = {q["id"]: q for q in load_questions(resolve_questions_path()[0], missing_ok=True)}
    if not by_id:
        raise SystemExit("The demo questions (eval/questions.json) are not here: they are kept out of the public repository. "
                         "Unzip mizan_private_eval.zip into the repository root, or run the app (python app.py) and type a question.")
    items = []
    for qid in wanted:
        q = by_id[qid]
        try:
            cmp = compare(pipelines, q["question"], gold=q)
        except LLMError as e:
            raise SystemExit(f"ERROR: {e}")
        items.append((q, cmp))
        print(f"\n[{qid}] ({q.get('type')}) {q['question']}")
        for n in names:
            r = cmp[n]["result"]
            top = r.passages[0] if r.passages else None
            where = f"{top.doc} p.{top.page} (sim {top.score:.3f})" if top else "nothing retrieved"
            print(f"  {n:<12} top1: {where} | "
                  f"retrieved tokens {r.retrieved_tokens} | retrieval {r.retrieval_latency_s * 1000:.0f} ms")
        for row in metric_rows(cmp)[:2]:
            print(f"  {row[0]:<34}" + "  ".join(f"{c:>10}" for c in row[1:]))

    RESULTS_DIR.mkdir(exist_ok=True)
    out = RESULTS_DIR / "demo.html"
    out.write_text(render_html(items, pages, pipelines, synthetic), encoding="utf-8")
    print(f"\nReport: {out}")
    if not args.no_open:
        webbrowser.open(out.as_uri())


if __name__ == "__main__":
    main()
